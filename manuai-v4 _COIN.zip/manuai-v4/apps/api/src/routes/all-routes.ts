import { Router } from 'express';
import { runRefresh, checkSeedDrift } from '../semantic/governance-runtime';
import { getPlantState } from '../simulation/engine';
import {
  loadWorkOrders, loadQualityDefects, loadQualityLines, loadSupplyRisks,
  loadTwinKPIs, loadTwinScenarios, loadTwinComponents, loadSafetyPermits,
  loadProductionOrders, loadSafetyZones, loadTechnicians, loadMachines,
  loadUtilities, loadEnergyAssets, loadEnergyWaste, loadEnergyDispatch,
  loadCarbonTrend, loadParts, loadPartsSpendHistory, loadPdmRules,
  loadPlatformConfig, loadSuppliers, loadSupplierPlantMap,
} from '../data/csv-loader';
import { createMaintenanceNotification, createPurchaseRequisition } from '../connectors/sap-odata';
import { getHistory, getLatest } from '../connectors/iot-hub';
import { semanticLayer, reloadConflictRules, warmKpiDefinitions } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { unifiedChat, agentRecommendation, semanticQuery, getLlmStatus } from '../ai/llm-client';
import { logger } from '../middleware/logger';
import { broadcast } from '../websocket/broadcaster';
import { z } from 'zod';
import { plantForAsset, normalizePlant, linesFor } from '../data/plant';
import {
  getSupplyChainDashboardMetrics, getExternalRiskAlerts, getManualApprovalRequests,
  getAutoApprovedOrders, getReorderRules, getActiveRulesCount,
  createReorderRequestFromRiskEvent, approveRequest, declineRequest, toggleRule, createReorderRule,
  getSupplierRiskDetail, getMonitoredSkus,
} from '../supply/governance';
import { getSafetyZones, getSupplyRisks, getSuppliers, getSupplierPlantMap, getAutoApprovedOrdersDb, getSkus, getDemandForecast, getQualityDefects } from '../database/db-queries';
import {
  applyWoOverrides, setWoOverride, isValidWoTransition,
  applyPartsOverrides, setPartsOverride, isValidPartsTransition,
  applySupplyReorderOverrides, setSupplyReorderOverride, getSupplyReorderOverride, listAllSupplyReorders,
  appendQualityRetrain, getQualityRetrainEntries, applyQualityRetrainEntries,
  applyPtwOverrides, setPtwOverride, getPtwOverride, isValidPtwTransition,
  applySafetyEventOverrides, setSafetyEventOverride, getSafetyEventOverride, isValidSafetyEventTransition,
  applyTwinScenarioRunOverrides, setTwinScenarioRun, getTwinScenarioRun, isValidScenarioTransition,
} from '../state/runtime-overrides';

// Resolve plant_id for events emitted from API routes whose `asset` field
// might be a machine id, a SKU/material code, or a scenario id. Backed by the
// CSV-derived topology (data/plant.ts) — no hardcoded asset arrays here.
function resolvePlant(assetOrSku: string | undefined | null): string {
  const a = String(assetOrSku ?? '');
  if (!a) return 'P1';
  // Direct asset lookup (machines + utilities, from CSV)
  const direct = plantForAsset(a);
  if (direct) return direct;
  // Material/SKU → look up the part record and map its asset_id to a plant
  try {
    const parts = loadParts() as any;
    const all = [...(parts?.orders ?? []), ...(parts?.inventory ?? [])];
    const part = all.find((p: any) => p.sku === a || p.id === a || p.order_id === a);
    if (part?.asset_id) {
      const fromAsset = plantForAsset(part.asset_id);
      if (fromAsset) return fromAsset;
    }
  } catch { /* parts CSV not loaded */ }
  return 'P1'; // safe default for unmapped identifiers
}

// ══════════════════════════════════════════════════════════════
// PdM Agent
// ══════════════════════════════════════════════════════════════
export const pdmRouter = Router();

pdmRouter.get('/assets', async (req, res) => {
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  // Use CSV-driven topology — no hardcoded machine arrays
  const plantMFilter=(id:string)=>!pfCode?true:plantForAsset(id)===pfCode;
  const state = getPlantState();
  const assets = state.machines.filter((m:any)=>plantMFilter(m.id)).map(m => ({
    id: m.id, name: m.name, line: m.line, plant: m.plant,
    oee: +Number(m.oee).toFixed(1), avail: +Number(m.avail).toFixed(1),
    perf: +Number(m.perf).toFixed(1), qual: +Number(m.qual).toFixed(1),
    health: +Number(m.health).toFixed(1), rul: Math.round(Number(m.rul)),
    status: m.status, loss: m.loss, lossMin: m.lossMin,
    vib: m.vib, temp: m.temp, pressure: +Number(m.pressure ?? 0).toFixed(1),
  }));
  // normalizePlant('All Plants') returns null, so gate on pfCode (like the
  // machine filter above) — NOT on the raw 'All Plants' string. The old check
  // (pfCode==='All Plants') was always false because pfCode is a code or null,
  // which made "All Plants" fall through to u.plant===null → zero utilities.
  const utilFilter=(u:any)=>!pfCode?true:(u.plant===pfCode);
  const utilityAssets = state.utilities.filter(utilFilter).map(u => ({
    id: u.id, name: u.name, health: Math.round(u.health), rul: Math.round(u.rul),
    status: u.status, oeeLink: u.oeeLink, plant: u.plant,
  }));
  res.json({
    assets, utilityAssets,
    plant_id:    pfCode ?? 'All Plants',
    source_mode: 'Synthetic',
    source_system: 'PI_HISTORIAN',
    ts: new Date().toISOString(),
  });
});

pdmRouter.get('/sensors/:assetId', async (req, res) => {
  const { assetId } = req.params;
  res.json({
    assetId,
    vibration: { latest: getLatest(assetId, 'vibration'), history: getHistory(assetId, 'vibration', 24) },
    temperature: { latest: getLatest(assetId, 'temperature'), history: getHistory(assetId, 'temperature', 24) },
  });
});

pdmRouter.get('/workorders', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const code = normalizePlant(req.query.plant);
  const all = loadWorkOrders() as any[];
  const filtered = code
    ? all.filter((w:any) => (w.plant && w.plant === code) || plantForAsset(String(w.asset ?? '')) === code)
    : all;
  // Layer runtime overrides on top of CSV — Start Work / Complete transitions live here
  const withOverrides = applyWoOverrides(filtered.map((w:any) => ({ ...w, status: w.status })));
  res.json({ orders: withOverrides });
});

// PATCH /api/pdm/workorders/:id { status, notes? }
// Records operator state transition (open → in_progress → completed),
// validates the transition server-side, publishes a semantic event so
// other agents (OEE, Twin) see the work being executed, broadcasts WS update.
pdmRouter.patch('/workorders/:id', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { status, notes } = req.body as { status: string; notes?: string };
  if (!['in_progress', 'completed'].includes(status)) {
    return res.status(400).json({ error: `Invalid target status: ${status}. Allowed: in_progress, completed.` });
  }
  // Locate the WO in CSV + apply any existing override to know the current effective status
  const all = applyWoOverrides(loadWorkOrders() as any[]);
  const wo = all.find((w:any) => w.id === id);
  if (!wo) return res.status(404).json({ error: `Work order ${id} not found` });
  if (!isValidWoTransition(wo.status, status)) {
    return res.status(409).json({ error: `Cannot transition from ${wo.status} to ${status}.` });
  }
  const now = new Date().toISOString();
  const ov = {
    status: status as any,
    startedAt:   status === 'in_progress' ? now : undefined,
    completedAt: status === 'completed'   ? now : undefined,
    updatedBy:   req.user?.name ?? 'unknown',
  };
  setWoOverride(id, ov);
  try {
    await semanticLayer.publishEvent({
      id: `WO-TX-${Date.now()}`, from: 'pdm', to: status === 'completed' ? 'oee' : 'pdm',
      type: status === 'completed' ? 'work_order_completed' : 'work_order_started',
      sev: 'info',
      msg: `WO ${id} ${status === 'in_progress' ? 'started' : 'completed'} by ${ov.updatedBy}${notes ? ` — ${notes}` : ''}`,
      impact: status === 'completed' ? 'Asset back online — semantic block clears' : 'Maintenance in progress',
      asset: wo.asset, plant_id: wo.plant ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish failure must not block the transition */ }
  broadcast('pdm', { type: 'wo_update', id, status, ts: now });
  res.json({ success: true, id, status, override: ov });
});

// Issue fix: real parts spend trend from parts_spend_history.csv.
// Reference design wants Nov→Apr stacked bars (planned green + unplanned red).
// Each plant has its own 6-month series; All Plants sums per month.
pdmRouter.get('/parts-spend', async (req, res) => {
  try {
    const code = normalizePlant(req.query.plant);
    const rows = loadPartsSpendHistory() as any[];
    let data: any[];
    if (code) {
      // Single plant — direct slice in CSV row order (Nov→Apr)
      data = rows
        .filter((r:any) => r.plant === code)
        .map((r:any) => ({ m: r.m, planned: r.planned, unplanned: r.unplanned }));
    } else {
      // All Plants — aggregate by month, preserving first-seen month order
      const order: string[] = [];
      const byMonth: Record<string, { planned: number; unplanned: number }> = {};
      for (const r of rows) {
        if (!byMonth[r.m]) { byMonth[r.m] = { planned: 0, unplanned: 0 }; order.push(r.m); }
        byMonth[r.m].planned   += Number(r.planned   || 0);
        byMonth[r.m].unplanned += Number(r.unplanned || 0);
      }
      data = order.map(m => ({ m, planned: byMonth[m].planned, unplanned: byMonth[m].unplanned }));
    }
    res.json({ data });
  } catch { res.json({ data: [] }); }
});

pdmRouter.post('/workorders', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { equipment, description, priority } = req.body as { equipment: string; description: string; priority?: string };
  // Issue 12: semantic governance — maintenance WO affects OEE.
  // plantId passed for CR-003 plant-fallback (gas precursor → block WOs in same plant).
  const conflict = semanticLayer.checkConflict({
    agent: 'pdm', type: 'work_order', assetId: equipment,
    plantId: resolvePlant(equipment) ?? undefined,
  });
  if (conflict.blocked) return res.status(409).json({ blocked: true, reason: conflict.reason, ruleId: conflict.ruleId });
  try {
    const wo = await createMaintenanceNotification({ equipment, text: description, priority });
    await semanticLayer.publishEvent({ id: `WO-${Date.now()}`, from: 'pdm', to: 'oee', type: 'work_order_created', sev: 'info', msg: `WO ${wo.MaintenanceNotification}: ${description}`, impact: 'Maintenance scheduled', asset: equipment, plant_id: resolvePlant(equipment), ts: new Date().toISOString() } as any);
    res.json({ success: true, workOrderId: wo.MaintenanceNotification });
  } catch { res.status(502).json({ error: 'SAP PM unavailable' }); }
});

pdmRouter.post('/parts-order', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity, assetId, reason } = req.body as { material: string; quantity: number; assetId: string; reason: string };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: `[ManuAI PdM] ${assetId}: ${reason}`, deliveryDate: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0] });
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

// PDM assets, utilities and work orders — all from CSV files
// REPLACE WITH: IoT Hub + SAP PM in Phase 3
const getPdmAssets = () => loadMachines();
const getUtilAssets = () => loadUtilities();
const getPdmWorkorders = () => loadWorkOrders();

// ══════════════════════════════════════════════════════════════
// Quality Vision Agent
// ══════════════════════════════════════════════════════════════
export const qualityRouter = Router();

qualityRouter.get('/defects', async (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  // DB-authoritative: trx_quality_defects via the db-queries reader (live rows
  // from upsertQualityDefect included). The reader falls back to CSV only when
  // the table is empty or the query fails.
  const allDef = await getQualityDefects(pfCode ?? undefined) as any[];
  // Normalize the two row shapes to the response contract the frontend reads
  // (`time` HH:MM + `type`): seeded DB rows carry time_of_day, live DB rows
  // carry only created_at (epoch ms), CSV-fallback rows carry `time`.
  const hhmm = (ms: any): string | null => {
    const dt = new Date(Number(ms));
    return isNaN(dt.getTime()) ? null
      : `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
  };
  const normDef = allDef.map((d: any) => ({
    ...d,
    time: d.time ?? d.time_of_day ?? (d.created_at != null ? hhmm(d.created_at) : null),
    type: d.type ?? d.defect_type,
  }));
  // Use CSV-driven line lists instead of hardcoded ['Line A','Line B'] / ['Line C','Line D']
  const plantLines = pfCode ? linesFor(pfCode) : [];
  // DB rows arrive plant-filtered by SQL (plant_id); the reader's CSV fallback
  // returns ALL rows and those carry no plant_id — apply the line-based filter
  // to rows without one so the plant selector still works in fallback mode.
  const defects = pfCode && pfCode !== 'All Plants' && plantLines.length
    ? normDef.filter((d: any) => d.plant_id
        ? d.plant_id === pfCode
        : (!d.line || plantLines.some(l => String(d.line).includes(l))))
    : normDef;
  const major = defects.filter((d:any) => d.severity === 'major').length;
  const minor = defects.filter((d:any) => d.severity === 'minor').length;
  // Build hourly trend — was hardcoded `for(let h=6;h<=18;h++)` which silently
  // dropped any defect outside the 06:00–18:00 window. Now the bucket range is
  // derived from BOTH the data range AND the config window — the actual range
  // is the union of both, so:
  //   • Default config window (06–18) always shown even when data is sparse
  //   • Any defect outside the config window expands the chart automatically
  // Config keys: quality_threshold.trend_start_hour / trend_end_hour.
  const parseHour = (t: any): number | null => {
    const m = String(t ?? '').match(/^(\d{1,2}):/);
    if (!m) return null;
    const h = Number(m[1]);
    return Number.isFinite(h) && h >= 0 && h <= 23 ? h : null;
  };
  const cfgTrend = (loadPlatformConfig() as any).qualityThreshold ?? {};
  const cfgStart = Number(cfgTrend.trend_start_hour ?? 6);
  const cfgEnd   = Number(cfgTrend.trend_end_hour   ?? 18);
  const hours = defects.map((d:any) => parseHour(d.time)).filter((h:any): h is number => h !== null);
  const minH = Math.min(cfgStart, hours.length ? Math.min(...hours) : cfgStart);
  const maxH = Math.max(cfgEnd,   hours.length ? Math.max(...hours) : cfgEnd);
  const hourly: Record<string, number> = {};
  for (let h = minH; h <= maxH; h++) hourly[`${String(h).padStart(2,'0')}:00`] = 0;
  for (const d of defects as any[]) {
    const bucket = ((d.time as string)?.slice(0, 2) ?? `${String(minH).padStart(2,'0')}`) + ':00';
    if (hourly[bucket] !== undefined) hourly[bucket]++;
  }
  const trend = Object.entries(hourly).map(([h, count]) => ({ h, defects: count }));
  res.json({
    log: defects, trend,          // what frontend expects
    defects,                       // legacy field
    summary: { total: defects.length, major, minor },
    window: { startHour: minH, endHour: maxH, configMin: cfgStart, configMax: cfgEnd }, // honest about the range shown
    source_mode: allDef.length && (allDef[0] as any)?.created_at != null ? 'DB' : 'CSV',
    source_system: 'VISION_AI_SAP_QM', plant_id: pfCode ?? 'All Plants',
  });
});
qualityRouter.get('/lines', async (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  const all = loadQualityLines() as any[];
  // Use CSV-driven line lists instead of hardcoded arrays
  const plantLines = pfCode ? linesFor(pfCode) : [];
  const filtered = pfCode && pfCode !== 'All Plants' && plantLines.length
    ? all.filter((l:any) => !l.line || plantLines.some(ln => String(l.line).includes(ln)))
    : all;
  res.json({ lines: filtered });
});

// Quality lines — from CSV files (REPLACE WITH Vision AI + MES in Phase 3).
// (The defects shim that lived here was dead code and shadowed the DB-first
// getQualityDefects reader from db-queries — removed when /defects went DB-first.)
const getQualityLines   = () => loadQualityLines();

// GET /api/quality/model/history — CSV seed (platform_config quality_model rows)
// with runtime retrain entries layered on top. The runtime entries archive any
// prior `deployed` rows so the live model is unambiguous.
qualityRouter.get('/model/history', async (_req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const cfg = loadPlatformConfig() as any;
  const seed = (cfg.qualityModel ?? []) as any[];
  res.json({ history: applyQualityRetrainEntries(seed) });
});

// POST /api/quality/retrain — federated retraining trigger.
// In Phase 1 the quality-vision service has /inspect + /models/status but no
// /retrain endpoint, so this generates a realistic outcome and records it.
// Phase A: forwards to quality-vision service /retrain (Azure ML pipeline run).
// 70% improvement, 20% no significant change, 10% regression — and then still
// "deployed" because the demo intentionally shows the operator workflow rather
// than a real model-promotion gate (Phase A: A/B + canary promotion).
qualityRouter.post('/retrain', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  // Establish the "current top" model from the existing history (runtime + CSV).
  const cfg = loadPlatformConfig() as any;
  const seed = (cfg.qualityModel ?? []) as any[];
  const merged = applyQualityRetrainEntries(seed);
  const top = merged[0] ?? { mAP: 0.964, precision: 0.95, recall: 0.92, samples: 8500, version: 'v3.1' };
  // Realistic outcome distribution — pseudo-random per call.
  const roll = Math.random();
  const outcome: 'improved' | 'no_change' | 'regression' =
    roll < 0.70 ? 'improved' : roll < 0.90 ? 'no_change' : 'regression';
  const delta = outcome === 'improved'
    ? { mAP: 0.001 + Math.random() * 0.004, prec: 0.001 + Math.random() * 0.003 }
    : outcome === 'no_change'
      ? { mAP: (Math.random() - 0.5) * 0.001, prec: (Math.random() - 0.5) * 0.001 }
      : { mAP: -(0.001 + Math.random() * 0.002), prec: -(0.001 + Math.random() * 0.002) };
  const lastVer = Number(String(top?.version ?? '3.1').replace(/^v/, '')) || 3.1;
  const newMAP  = +Math.max(0, Math.min(0.999, Number(top.mAP) + delta.mAP)).toFixed(3);
  const newPrec = +Math.max(0, Math.min(0.999, Number(top.precision) + delta.prec)).toFixed(3);
  const samples = Number(top.samples) + Math.floor(120 + Math.random() * 80);
  const entry = appendQualityRetrain({
    date:      new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit' }),
    version:   `v${(lastVer + 0.1).toFixed(1)}`,
    mAP:       newMAP,
    precision: newPrec,
    recall:    Number(top.recall ?? 0.92),
    samples,
    status:    'deployed',
    outcome,
    triggeredAt: new Date().toISOString(),
    triggeredBy: req.user?.name ?? 'unknown',
  });
  // Publish semantic event so the audit trail captures every retrain — including
  // regressions. Quality-channel because consumers are quality + audit.
  try {
    await semanticLayer.publishEvent({
      id: `QR-${Date.now()}`, from: 'quality', to: 'audit',
      type: 'model_retrained', sev: outcome === 'regression' ? 'warning' : 'info',
      msg: `Quality model ${entry.version} ${outcome === 'improved' ? `improved (mAP +${delta.mAP.toFixed(3)})` : outcome === 'no_change' ? 'no change' : `regressed (mAP ${delta.mAP.toFixed(3)})`}`,
      impact: outcome === 'regression' ? 'Model rolled back recommended — review training data' : `${samples.toLocaleString()} samples trained`,
      asset: entry.version, plant_id: 'All Plants', ts: entry.triggeredAt,
    } as any);
  } catch { /* event publish must not block response */ }
  res.json({ success: true, entry, outcome, delta });
});

// ══════════════════════════════════════════════════════════════
// Energy Optimisation Agent
// ══════════════════════════════════════════════════════════════
export const energyRouter = Router();

// ── Non-blocking ML cache (energy-optimizer) ─────────────────────────────────
// Same pattern as yield: /load reads the last cached dispatch and fires a
// background refresh (not awaited) when stale, so it never blocks on the service.
const _energyMlCache = new Map<string, { data: any; ts: number }>();
const _ENERGY_ML_TTL_MS = 15000;
function getEnergyMlCached(key: string, payload: any): any {
  const hit = _energyMlCache.get(key);
  const fresh = hit && (Date.now() - hit.ts) < _ENERGY_ML_TTL_MS;
  const url = process.env.ENERGY_SERVICE_URL;
  if (!fresh && url) {
    fetch(`${url}/dispatch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload), signal: AbortSignal.timeout(2500),
    })
      .then(r => (r.ok ? r.json() : null))
      .then(d => { if (d) _energyMlCache.set(key, { data: d, ts: Date.now() }); })
      .catch(() => { /* leave previous cached value */ });
  }
  return hit?.data ?? null;
}

energyRouter.get('/load', async (req, res) => {
  const state = getPlantState();
  const waste = getEnergyWasteList();

  // ML enrichment (non-blocking): served from a 15s cache; stale/cold cache fires
  // a background refresh that is NOT awaited, so /load never waits on the energy
  // service. `mlDispatch` is null until the first refresh lands (≤ one poll cycle).
  let mlDispatch: any = null;
  if (process.env.ENERGY_SERVICE_URL) {
    try {
      const ref = loadEnergyAssets() as any[];
      const refById = new Map(ref.map((r: any) => [r.id, r]));
      const hour = new Date().getHours();
      const inPeak = hour >= 18 && hour < 22;
      const assets = (state.energyAssets ?? []).map((a: any) => {
        const r = refById.get(a.id) ?? {};
        const rated = Number(r.rated_kw ?? a.kw ?? 1);
        return {
          asset_id: a.id, name: a.name,
          kw_current: Number(a.kw ?? 0), kw_rated: rated,
          load_factor: rated ? Math.min(1, Number(a.kw ?? 0) / rated) : 0.5,
          shiftable: String(r.shiftable).toLowerCase() === 'true',
          critical: String(r.critical).toLowerCase() === 'true',
          tariff_peak: inPeak,
        };
      });
      const cfg = loadPlatformConfig() as any;
      const peakLimit = Number(cfg.energyConfig?.peak_threshold_kw?.value ?? 1600);
      const payload = {
        plant_kw_total: Number(state.energyKw ?? assets.reduce((s, x) => s + x.kw_current, 0)),
        peak_demand_limit_kw: peakLimit,
        grid_carbon_g_per_kwh: 820,
        units_produced_today: 500,
        shift: inPeak ? 'evening' : (hour >= 6 && hour < 14 ? 'day' : 'night'),
        assets,
      };
      mlDispatch = getEnergyMlCached('energy', payload);
    } catch { /* trend/assets only */ }
  }

  res.json({
    trend: state.energyTrend, assets: state.energyAssets, waste, totalKw: state.energyKw,
    mlDispatch,                            // XGBoost dispatch plan (cached; null until first refresh)
    source_mode: mlDispatch ? 'ML+SIM' : 'SIM',
  });
});

energyRouter.post('/dispatch', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { assetId, action } = req.body as { assetId: string; action: string };
  // Issue 12: semantic governance — energy dispatch can affect yield-critical assets
  const conflict = semanticLayer.checkConflict({ agent: 'energy', type: 'dispatch', assetId });
  if (conflict.blocked) return res.status(409).json({ blocked: true, reason: conflict.reason, ruleId: conflict.ruleId });
  logger.info('Energy dispatch', { assetId, action, user: req.user?.name });
  await semanticLayer.publishEvent({ id: `ED-${Date.now()}`, from: 'energy', to: 'yield', type: 'energy_dispatch', sev: 'info', msg: `Dispatch ${action} on ${assetId}`, impact: 'Load profile change', asset: assetId, plant_id: resolvePlant(assetId), ts: new Date().toISOString() } as any);
  res.json({ success: true, assetId, action, dispatchedAt: new Date().toISOString() });
});

// Energy assets and waste — from CSV files (REPLACE WITH smart meters + IoT Hub in Phase 3)
const getEnergyAssetsList = () => loadEnergyAssets();
const getEnergyWasteList  = () => loadEnergyWaste();

// ══════════════════════════════════════════════════════════════
// Supply Chain Resilience Agent
// ══════════════════════════════════════════════════════════════
export const supplyRouter = Router();

// ── Non-blocking ML cache (supply-intelligence) ──────────────────────────────
const _supplyMlCache = new Map<string, { data: any; ts: number }>();
const _SUPPLY_ML_TTL_MS = 15000;
function getSupplyMlCached(key: string): any {
  const hit = _supplyMlCache.get(key);
  const fresh = hit && (Date.now() - hit.ts) < _SUPPLY_ML_TTL_MS;
  const url = process.env.SUPPLY_SERVICE_URL;
  if (!fresh && url) {
    fetch(`${url}/assess`, { signal: AbortSignal.timeout(2000) })
      .then(r => (r.ok ? r.json() : null))
      .then(d => { if (d) _supplyMlCache.set(key, { data: d, ts: Date.now() }); })
      .catch(() => { /* leave previous cached value */ });
  }
  return hit?.data ?? null;
}

// Issue 10 fix: risk scoring server-side; raw rows preserved for compatibility
supplyRouter.get('/risks', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  const allRaw = await getSupplyRisks() as any[];
  const raw = pf && pfCode && pfCode !== 'All Plants' ? allRaw.filter((r:any)=>!r.plant||r.plant===pfCode||r.plant==='Both') : allRaw;
  // Thresholds, economics, and action labels from platform_config — was scattered
  // hardcoded numbers and strings across this route and 2 frontend dashboards.
  const cfg = loadPlatformConfig() as any;
  const th = cfg.supplyThreshold ?? {};
  const stockCritical = Number(th.stock_critical_days ?? 14);
  const stockHigh     = Number(th.stock_high_days ?? 30);
  const finRiskTh     = Number(th.financial_risk_score_threshold ?? 40);
  const homeCountry   = String(th.home_country ?? 'India');
  const econ = cfg.supplyEconomics ?? {};
  const currency      = String(econ.exposure_currency ?? '\u20b9');
  const divisor       = Number(econ.exposure_divisor ?? 100000);
  const unitSuffix    = String(econ.exposure_unit ?? 'L/mo');
  const actionByTier  = cfg.supplyAction ?? { critical: 'Emergency PO required', high: 'Expedite delivery', medium: 'Monitor weekly' };
  // Join supplier region + per-plant order values (suppliers + supplier_plant_map)
  // so the Risk Monitor cards can show region and YTD/MTD exposure — data-driven.
  const supRegion = new Map((await getSuppliers() as any[]).map(s => [s.supplier_id, `${s.supplier_region} · ${s.supplier_country}`]));
  const ovMap = new Map((await getSupplierPlantMap() as any[]).map(m => [`${m.supplier_id}|${m.plant_id}`, m]));
  const scored = raw.map((s: any) => {
    const leadDrift = Number(s.lead_time_actual_days ?? 0) - Number(s.lead_time_contracted_days ?? 0);
    const stockDays = Number(s.current_stock_days ?? 0);
    const risk = stockDays < stockCritical ? 'critical' : stockDays < stockHigh ? 'high' : 'medium';
    // Stable composite id for React keys + runtime overrides. supplier_id alone
    // would collide when one supplier serves multiple SKUs.
    const risk_id = `${s.supplier_id}-${s.sku}`;
    // Exposure formatting from config — was `\u20b9${... / 100000}L/mo` literal.
    const exposureRaw = Number(s.monthly_consumption ?? 0) * Number(s.unit_cost_inr ?? 0);
    const exposure = s.monthly_consumption
      ? `${currency}${(exposureRaw / divisor).toFixed(1)}${unitSuffix}`
      : '\u2014';
    return {
      risk_id,
      supplier_id: s.supplier_id,
      supplier:  s.supplier_name,
      sku:       s.sku,
      desc:      s.description,
      risk, stockDays, leadDrift,
      exposure,
      monthly_consumption: Number(s.monthly_consumption ?? 0),
      unit_cost_inr:       Number(s.unit_cost_inr ?? 0),
      singleSource: s.single_source === true,
      reason:    Number(s.financial_risk_score ?? 0) > finRiskTh
        ? 'Financial distress'
        : (s.single_source === true && s.country_of_origin !== homeCountry)
          ? 'Geopolitical risk'
          : 'Lead time drift',
      action:    actionByTier[risk] ?? 'Review weekly',
      plant:     s.plant ?? null,
      region:    supRegion.get(s.supplier_id) ?? null,
      ytd_order_value: (ovMap.get(`${s.supplier_id}|${s.plant}`) as any)?.ytd_order_value ?? null,
      mtd_order_value: (ovMap.get(`${s.supplier_id}|${s.plant}`) as any)?.mtd_order_value ?? null,
    };
  });
  // Layer runtime reorder overrides on top — adds reorderStatus + prNumber per row
  const scoredWithOverrides = applySupplyReorderOverrides(scored);
  // Issue 5: enrich with supply-intelligence multi-factor assessment when available.
  // Non-blocking: served from a 15s cache with a background refresh (not awaited),
  // so /risks (which sits in the 15s dashboard poll) never waits on the service.
  const assessed: any = getSupplyMlCached('assess');
  res.json({
    risks: await getSupplyRisks(),  // raw rows — legacy consumers (DB-authoritative)
    scored: scoredWithOverrides, // pre-scored + override-aware
    assessed,                   // service multi-factor assessment (null if unavailable)
    source_mode: assessed ? 'SERVICE+CSV' : 'CSV',
    source_system: 'ERP_SUPPLIER_RISK', plant_id: pfCode ?? 'All Plants',
    // Surface the threshold config so the frontend can honour the same values
    thresholds: { stockCritical, stockHigh, leadDriftWarn: Number(th.lead_drift_warn_days ?? 5), leadDriftRed: Number(th.lead_drift_red_days ?? 10) },
  });
});
// ── Supply-chain governance endpoints (Increment 2) ────────────────────────
// All read paths are plant-filtered via the selectors; all values are derived
// (no counts computed in the UI). Mutations reset on restart (CSV-seeded store).
supplyRouter.get('/dashboard-metrics', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.json(await getSupplyChainDashboardMetrics(req.query.plant as string | undefined));
});
supplyRouter.get('/external-alerts', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  res.json({ alerts: await getExternalRiskAlerts(pf), plant_id: normalizePlant(pf) ?? 'All Plants' });
});
supplyRouter.get('/governance/manual', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  res.json({ requests: await getManualApprovalRequests(pf, req.query.all === '1'), plant_id: normalizePlant(pf) ?? 'All Plants' });
});
supplyRouter.get('/governance/auto', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  res.json({ orders: await getAutoApprovedOrders(pf), plant_id: normalizePlant(pf) ?? 'All Plants' });
});
supplyRouter.get('/governance/rules', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  res.json({ rules: await getReorderRules(pf), activeCount: await getActiveRulesCount(pf), plant_id: normalizePlant(pf) ?? 'All Plants' });
});
// GET /api/supply/risk-detail — supplier risk intelligence for the Risk Monitor
// popup. All sections derive from the data + semantic layer (governance.ts).
supplyRouter.get('/risk-detail', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const q = req.query as Record<string, string | undefined>;
  const detail = await getSupplierRiskDetail({
    supplierId: q.supplierId, skuId: q.skuId, skuCode: q.skuCode,
    plantId: normalizePlant(q.plantId) ?? q.plantId, riskEventId: q.riskEventId,
  });
  if (!detail.supplier && !detail.sku) return res.status(404).json({ error: 'supplier risk detail not found' });
  res.json(detail);
});
supplyRouter.post('/governance/create-reorder', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { riskId, plant } = req.body as { riskId: string; plant?: string };
  const out = await createReorderRequestFromRiskEvent(riskId, plant);
  res.status(out.ok ? 200 : 404).json(out);
});
supplyRouter.post('/governance/approve', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const out = await approveRequest((req.body as any).requestId);
  res.status(out.ok ? 200 : 404).json(out);
});
supplyRouter.post('/governance/decline', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const out = await declineRequest((req.body as any).requestId);
  res.status(out.ok ? 200 : 404).json(out);
});
supplyRouter.post('/governance/toggle-rule', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { ruleId, enabled } = req.body as { ruleId: string; enabled?: boolean };
  const out = await toggleRule(ruleId, enabled);
  res.status(out.ok ? 200 : 404).json(out);
});
supplyRouter.post('/governance/create-rule', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const out = await createReorderRule(req.body as Record<string, string>);
  res.status(out.ok ? 200 : 400).json(out);
});
// V39: enumerate distinct products available for a given plant. Drives the
// product selector dropdown on the Demand Forecast tab. Plant-aware: each
// plant has its own slice of the demand_forecast.csv frame, so the dropdown
// only offers products that actually have data for the selected plant.
supplyRouter.get('/products', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  // DB-authoritative: read via getDemandForecast (trx_demand_forecast). The DB
  // reader returns `week`; alias to `w` so downstream code is unchanged.
  const all = ((await getDemandForecast()) as any[]).map((r:any)=>({ ...r, w: r.week ?? r.w }));
  const filtered = pf && pfCode && pfCode !== 'All Plants'
    ? all.filter((r:any) => !r.plant || r.plant === pfCode || r.plant === 'Both')
    : all;
  const products = Array.from(new Set(filtered.map((r:any) => r.product).filter(Boolean))).sort();
  res.json({ products, plant_id: pfCode ?? 'All Plants' });
});

supplyRouter.get('/forecast', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  const productQ = (req.query.product as string | undefined)?.trim();
  // DB-authoritative: read via getDemandForecast (trx_demand_forecast). The DB
  // reader returns `week`; alias to `w` so the week-rolling logic below is unchanged.
  const allRows = ((await getDemandForecast()) as any[]).map((r:any)=>({ ...r, w: r.week ?? r.w }));
  let filtered = pf && pfCode && pfCode !== 'All Plants'
    ? allRows.filter((r:any)=>!r.plant||r.plant===pfCode)
    : allRows;
  // V39: product filter. If specified, narrow to a single SKU. If unspecified,
  // default to the first product alphabetically available for this plant so
  // the chart isn't empty when the dropdown hasn't been touched yet.
  const availableProducts = Array.from(new Set(filtered.map((r:any) => r.product).filter(Boolean))).sort() as string[];
  const productSelected: string | null = productQ && availableProducts.includes(productQ)
    ? productQ
    : (availableProducts[0] ?? null);
  if (productSelected) filtered = filtered.filter((r:any) => r.product === productSelected);

  // V35: roll the CSV's static W13..W21 sequence forward so the chart always
  // shows current ISO week + a few weeks back + a few weeks ahead. Was a fixed
  // window that drifted further into the past with every passing month.
  //
  // Anchor strategy: find the highest CSV week that has an actual value (the
  // "most recent observed week" in the CSV's frame), compute the offset to
  // today's ISO week, and shift every row by that offset. Forecast weeks shift
  // with it, so the future side of the chart always sits ahead of today.
  const parseW = (w: any): number => {
    const m = String(w ?? '').match(/W(\d+)/i);
    return m ? Number(m[1]) : NaN;
  };
  const isoWeek = (d: Date): number => {
    // ISO 8601 week number — Thursday-based
    const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const day = t.getUTCDay() || 7;
    t.setUTCDate(t.getUTCDate() + 4 - day);
    const yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    return Math.ceil(((t.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  };
  const currentIso = isoWeek(new Date());
  // Anchor = max CSV week that still has an actual_kg value (i.e. observed reality
  // in the CSV's frame). Forecast-only rows beyond that anchor map to future weeks.
  let anchor = -Infinity;
  for (const r of filtered) {
    const wk = parseW(r.w);
    if (!Number.isFinite(wk)) continue;
    const hasActual = r.actual != null;
    if (hasActual && wk > anchor) anchor = wk;
  }
  // If nothing observed, anchor to the largest week present (still useful) or skip
  if (!Number.isFinite(anchor)) {
    for (const r of filtered) {
      const wk = parseW(r.w);
      if (Number.isFinite(wk) && wk > anchor) anchor = wk;
    }
  }
  const offset = Number.isFinite(anchor) ? currentIso - (anchor as number) : 0;
  const wrap = (n: number) => {
    // Wrap into [1, 53]; 0 → 53, 54 → 1, etc.
    let x = ((n - 1) % 53 + 53) % 53 + 1;
    return x;
  };

  // Aggregate by shifted week when plant = All Plants (sum across plants for that
  // SKU/product); otherwise keep per-row values. Previously All Plants rendered
  // two bars per week (one per plant) because the chart's dataKey="w" matched both.
  type Agg = { w: string; week_no: number; product: string; actual?: number | null; forecast?: number | null; _actCount: number; _fcCount: number; };
  const byShiftedWeek: Record<string, Agg> = {};
  const aggregating = !pfCode || pfCode === 'All Plants';
  for (const r of filtered) {
    const csvWk = parseW(r.w);
    if (!Number.isFinite(csvWk)) continue;
    const shifted = wrap(csvWk + offset);
    const wLabel = `W${String(shifted).padStart(2, '0')}`;
    const actNum = r.actual != null ? Number(r.actual) : null;
    const fcNum  = r.forecast != null ? Number(r.forecast) : null;
    if (!byShiftedWeek[wLabel]) {
      byShiftedWeek[wLabel] = { w: wLabel, week_no: shifted, product: r.product ?? 'Selected Product', actual: null, forecast: null, _actCount: 0, _fcCount: 0 };
    }
    const cell = byShiftedWeek[wLabel];
    if (aggregating) {
      // Sum across plants — total org-wide demand for this product/week
      if (actNum != null) { cell.actual = (cell.actual ?? 0) + actNum; cell._actCount++; }
      if (fcNum  != null) { cell.forecast = (cell.forecast ?? 0) + fcNum;  cell._fcCount++; }
    } else {
      // Single plant — last write wins (rows are unique per plant anyway)
      if (actNum != null) cell.actual = actNum;
      if (fcNum  != null) cell.forecast = fcNum;
    }
  }
  // Order chronologically. The shifted weeks may cross a year boundary
  // (e.g. W50 → W2). Reconstruct order by walking N weeks back from currentIso.
  // Take the unique shifted weeks and order them by their "distance" from currentIso
  // so the chart reads past → present → future left-to-right.
  const sorted = Object.values(byShiftedWeek)
    .map(c => {
      // signed distance from current week, handling wrap (small magnitude wins)
      let d = c.week_no - currentIso;
      if (d > 26)  d -= 53;
      if (d < -26) d += 53;
      return { c, d };
    })
    .sort((a, b) => a.d - b.d);
  // V37: trim to current_week-3 ... current_week+3 (≈ reference image density,
  // 6-7 bars total). Was returning the full 9-week CSV span which made the
  // current-week marker hard to spot and bars looked thin.
  const PAST_WEEKS = 3;
  const FUTURE_WEEKS = 3;
  const trimmed = sorted.filter(s => s.d >= -PAST_WEEKS && s.d <= FUTURE_WEEKS);
  const orderedKeys: string[] = trimmed.map(s => s.c.w);
  const forecast = orderedKeys.map(k => {
    const c = byShiftedWeek[k];
    return {
      w:        c.w,
      week_no:  c.week_no,
      product:  c.product,
      actual:   c.actual,
      forecast: c.forecast,
    };
  });
  res.json({
    forecast,
    currentIsoWeek: currentIso,
    plant_id:       pfCode ?? 'All Plants',
    aggregated:     aggregating,
    product:        productSelected,
    products:       availableProducts,
    window:         { past: PAST_WEEKS, future: FUTURE_WEEKS },
  });
});

// GET /api/supply/inventory — V34: dedicated endpoint for the Inventory tab.
// Returns three top-line counts (Total SKUs Monitored, Safety Stock Alerts,
// Auto-Reorders Raised) plus the detail rows behind each so the frontend can
// list them out. Plant-aware throughout. Previously the Inventory tab
// derived its tiles inline from `supplyRisksData` which (a) didn't include
// auto-reorder history and (b) labelled "Supplier-SKU Rows" rather than the
// standard inventory KPIs operators expect.
supplyRouter.get('/inventory', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  const windowDays = Math.max(1, Math.min(90, Number(req.query.windowDays ?? 7)));

  // Source rows: supply_risks.csv is the SKU master (one row per supplier-SKU
  // pair). Each row carries current_stock_days and reorder_point_days so
  // "needs adjustment" = current_stock_days < reorder_point_days.
  const allRows = await getSupplyRisks() as any[];
  const rows = pf && pfCode && pfCode !== 'All Plants'
    ? allRows.filter((r:any) => !r.plant || r.plant === pfCode || r.plant === 'Both')
    : allRows;

  // Threshold config — same source the Risk Monitor tab honours.
  const cfg = loadPlatformConfig() as any;
  const th = cfg.supplyThreshold ?? {};
  const stockCritical = Number(th.stock_critical_days ?? 14);

  // Safety stock alerts: SKUs whose current stock cover is below the reorder
  // point (i.e. a purchase requisition should already be in motion).
  const safetyStockList = rows
    .filter((r:any) => Number(r.current_stock_days ?? 0) < Number(r.reorder_point_days ?? 0))
    .map((r:any) => ({
      riskId:           `${r.supplier_id}-${r.sku}`,
      sku:              r.sku,
      description:      r.description,
      supplier:         r.supplier_name,
      currentStockDays: Number(r.current_stock_days ?? 0),
      reorderPointDays: Number(r.reorder_point_days ?? 0),
      deficitDays:      Number(r.reorder_point_days ?? 0) - Number(r.current_stock_days ?? 0),
      monthlyConsumption: Number(r.monthly_consumption ?? 0),
      plant:            r.plant ?? null,
      severity:         Number(r.current_stock_days ?? 0) < stockCritical ? 'critical' : 'warning',
    }))
    .sort((a:any, b:any) => b.deficitDays - a.deficitDays);

  // Auto-reorders raised. DB-authoritative: reads the same gov_auto_approved_orders
  // the governance "Auto Approved" tab/tile uses, so the two panels reconcile.
  // No date-window filter — this is the rule-engine auto-approval history for the
  // plant, matching the tile count (previously a separate in-memory store + a
  // 7-day window silently produced 0 even when seeded auto-orders existed).
  // Resolve sku_id → sku_code and supplier_id → supplier_name for display.
  const skuById = new Map((await getSkus() as any[]).map(s => [s.sku_id, s]));
  const supById = new Map((await getSuppliers() as any[]).map(s => [s.supplier_id, s]));
  const autoReordersList = (await getAutoApprovedOrdersDb() as any[])
    .filter(o => !pfCode || pfCode === 'All Plants' || o.plant_id === pfCode)
    .map(o => {
      const sku = skuById.get(o.sku_id);
      const sup = supById.get(o.supplier_id);
      return {
        riskId:       o.order_id,
        sku:          sku?.sku_code ?? o.sku_id,
        description:  sku?.sku_name ?? '',
        supplier:     sup?.supplier_name ?? o.supplier_id,
        prNumber:     o.sap_status === 'PR Created' ? o.order_id : (o.sap_status ?? '—'),
        quantity:     o.approved_qty ?? null,
        reorderedAt:  o.approved_date,
        reorderedBy:  o.rule_name ?? 'Rule engine',
        plant:        o.plant_id ?? null,
      };
    })
    // Most-recent first (ISO yyyy-mm-dd string compare is safe)
    .sort((a, b) => String(b.reorderedAt).localeCompare(String(a.reorderedAt)));

  // Full monitored-SKU universe (union of SKU master + supply risks + inventory
  // positions) so the UI can list every SKU behind the "SKUs Monitored" count.
  const monitoredSkuList = await getMonitoredSkus(pf);

  res.json({
    summary: {
      totalSkus:           monitoredSkuList.length,
      safetyStockAlerts:   safetyStockList.length,
      autoReordersRaised:  autoReordersList.length,
      windowDays,
      plant_id:            pfCode ?? 'All Plants',
    },
    safetyStockList,
    monitoredSkuList,
    autoReordersList,
    source_system: 'ERP_SUPPLIER_RISK + SAP MM',
  });
});

supplyRouter.post('/reorder', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const { material, quantity } = req.body as { material: string; quantity: number };
  try {
    const pr = await createPurchaseRequisition({ material, plant: process.env.SAP_PLANT_CODE!, quantity, text: '[ManuAI Supply] Risk-triggered reorder', deliveryDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0] });
    await semanticLayer.publishEvent({ id: `SR-${Date.now()}`, from: 'supply', to: 'pdm', type: 'reorder_created', sev: 'info', msg: `PR ${pr.PurchaseRequisition}: ${quantity}x ${material}`, impact: 'Parts inbound', asset: material, plant_id: resolvePlant(material), ts: new Date().toISOString() } as any);
    res.json({ success: true, prId: pr.PurchaseRequisition });
  } catch { res.status(502).json({ error: 'SAP MM unavailable' }); }
});

// POST /api/supply/risks/:riskId/reorder
// Per-row reorder trigger from the Risk Monitor table. riskId = `${supplier_id}-${sku}`.
// Records the operator action in runtime overrides (so the button shows "ordered"
// after refresh), calls SAP MM, publishes a reorder_created semantic event to PdM.
supplyRouter.post('/risks/:riskId/reorder', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { riskId } = req.params;
  const { quantity, reason } = req.body as { quantity?: number; reason?: string };
  const existing = getSupplyReorderOverride(riskId);
  if (existing?.status === 'ordered') {
    return res.status(409).json({ error: `Reorder already raised for ${riskId} — PR ${existing.prNumber ?? 'unknown'}.` });
  }
  // Resolve the supply row from CSV to get sku, monthly_consumption, plant
  const rows = await getSupplyRisks() as any[];
  const row = rows.find((s:any) => `${s.supplier_id}-${s.sku}` === riskId);
  if (!row) return res.status(404).json({ error: `Risk row ${riskId} not found` });
  // Default reorder qty: monthly_consumption (1 month coverage). Operator can override via body.
  const qty = Number.isFinite(quantity) && (quantity as number) > 0
    ? (quantity as number)
    : Math.max(1, Number(row.monthly_consumption ?? 1));
  try {
    const pr = await createPurchaseRequisition({
      material: row.sku,
      plant: process.env.SAP_PLANT_CODE ?? row.plant ?? 'P1',
      quantity: qty,
      text: `[ManuAI Supply] Risk reorder for ${row.supplier_name} (${row.sku})${reason ? ` — ${reason}` : ''}`,
      deliveryDate: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
    });
    const now = new Date().toISOString();
    const prNumber = pr?.PurchaseRequisition ?? `PR-${Date.now()}`;
    const ov = setSupplyReorderOverride(riskId, {
      status: 'ordered',
      prNumber,
      reorderedAt: now,
      reorderedBy: req.user?.name ?? 'unknown',
      quantity: qty,
      reason,
    });
    try {
      await semanticLayer.publishEvent({
        id: `SR-${Date.now()}`, from: 'supply', to: 'pdm',
        type: 'reorder_created', sev: 'info',
        msg: `PR ${prNumber}: ${qty}x ${row.sku} from ${row.supplier_name}`,
        impact: `Parts inbound — ${row.lead_time_actual_days ?? '?'}d lead time`,
        asset: row.sku, plant_id: resolvePlant(row.sku) ?? row.plant ?? 'P1', ts: now,
      } as any);
    } catch { /* event publish must not block PR */ }
    res.json({ success: true, riskId, prNumber, quantity: qty, override: ov });
  } catch (e) {
    res.status(502).json({ error: 'SAP MM unavailable — PR not raised' });
  }
});

// ══════════════════════════════════════════════════════════════
// Digital Twin Operations Agent
// ══════════════════════════════════════════════════════════════
export const twinRouter = Router();

// Issue 5+11 fix: twin-sync service is authoritative; CSV computation is fallback
const TWIN_SERVICE_URL = process.env.TWIN_SERVICE_URL;
twinRouter.get('/status', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pfCode = normalizePlant(req.query.plant);
  // Compute accuracy honestly from the divergence percentages — was a magic
  // formula `100 - divergingCount * 1.2`. Replacement: 100 minus the mean
  // divergence percentage across all KPIs for the plant. This is what a real
  // digital twin would publish — if half your KPIs are 4% off, accuracy is ~96%.
  const computeAccuracy = (kpis: any[]): { accuracy: number; diverging: number; meanPct: number } => {
    if (!kpis.length) return { accuracy: 0, diverging: 0, meanPct: 0 };
    // Use live DB actuals where available (machine_health/OEE/energy), CSV fallback.
    let liveActuals: Record<string, number> = {};
    try { liveActuals = require('../database/queries').getTwinActuals(); } catch { liveActuals = {}; }
    let divergingCount = 0;
    let pctSum = 0;
    for (const k of kpis) {
      const actual = liveActuals[k.kpi_id] ?? Number(k.actual);
      const delta = Math.abs(Number(actual) - Number(k.twin_predicted));
      const pct = Number(k.twin_predicted) !== 0 ? delta / Math.abs(Number(k.twin_predicted)) * 100 : 0;
      pctSum += pct;
      if (pct > Number(k.threshold_pct)) divergingCount++;
    }
    const meanPct = pctSum / kpis.length;
    return {
      accuracy: +Math.max(0, Math.min(100, 100 - meanPct)).toFixed(1),
      diverging: divergingCount,
      meanPct: +meanPct.toFixed(2),
    };
  };
  if (TWIN_SERVICE_URL) {
    try {
      const r = await fetch(`${TWIN_SERVICE_URL}/status`, { signal: AbortSignal.timeout(2000) });
      if (r.ok) {
        const svc: any = await r.json();
        const allKpisLive = loadTwinKPIs() as any[];
        const plantKpis = pfCode ? allKpisLive.filter((k:any)=>!k.plant||k.plant===pfCode||k.plant==='Both') : allKpisLive;
        const calc = computeAccuracy(plantKpis);
        const allScenariosLive = loadTwinScenarios() as any[];
        const plantScenarios = pfCode ? allScenariosLive.filter((s:any)=>!s.plant||s.plant===pfCode||s.plant==='Both').length : allScenariosLive.length;
        return res.json({
          syncedAt: svc.synced_at ?? new Date().toISOString(),
          // Prefer service accuracy when not plant-filtered; otherwise compute from plant slice
          accuracy: pfCode ? calc.accuracy : (svc.accuracy_pct ?? calc.accuracy),
          diverging: pfCode ? calc.diverging : (svc.diverging_count ?? calc.diverging),
          mean_divergence_pct: calc.meanPct,
          scenarios: pfCode ? plantScenarios : (Array.isArray(svc.scenarios) ? svc.scenarios.length : allScenariosLive.length),
          source_mode: 'SERVICE', source_system: 'twin-sync', plant_id: pfCode ?? 'All Plants',
          modelSource: svc.model_source ?? 'computed-behavioural-v1',
        });
      }
    } catch { /* fall through to CSV */ }
  }
  // CSV fallback — honest accuracy from per-KPI divergence percentages
  const allKpis = loadTwinKPIs() as any[];
  const kpis = pfCode ? allKpis.filter((k:any) => !k.plant || k.plant === pfCode || k.plant === 'Both') : allKpis;
  const calc = computeAccuracy(kpis);
  const allScenarios = loadTwinScenarios() as any[];
  const scenarios = pfCode
    ? allScenarios.filter((s:any) => !s.plant || s.plant === pfCode || s.plant === 'Both').length
    : allScenarios.length;
  res.json({
    syncedAt: new Date().toISOString(),
    accuracy: calc.accuracy,
    diverging: calc.diverging,
    mean_divergence_pct: calc.meanPct,
    scenarios,
    source_mode:   'CSV',
    source_system: 'Azure_Digital_Twins',
    plant_id:      pfCode ?? 'All Plants',
    modelSource:   'computed-behavioural-v1',
  });
});
twinRouter.get('/divergence', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  const allKpis = loadTwinKPIs() as any[];
  const kpis = pf && pfCode && pfCode !== 'All Plants' ? allKpis.filter((k:any)=>!k.plant||k.plant===pfCode||k.plant==='Both') : allKpis;
  // Critical tier multiplier from config (twin_threshold.critical_multiplier).
  // Was hardcoded `* 2` inline. CSV default is 2 so behaviour is unchanged.
  const cfg = loadPlatformConfig() as any;
  const criticalMult = Number(cfg.twinThreshold?.critical_multiplier ?? 2);
  // Live actuals from the DB (machine_health / OEE / energy). KPIs not present
  // here fall back to the CSV's static actual — same pattern every agent uses.
  let liveActuals: Record<string, number> = {};
  try { liveActuals = require('../database/queries').getTwinActuals(); } catch { liveActuals = {}; }
  const machines = loadMachines() as any[];
  const mIdx = new Map(machines.map((m:any)=>[m.id,{line:m.line,plant:m.plant}]));
  const divergence = kpis.map((k:any) => {
    // Prefer the live DB reading; fall back to the CSV actual when not in DB.
    const actual = liveActuals[k.kpi_id] ?? k.actual;
    const actualSource = liveActuals[k.kpi_id] != null ? 'db' : 'csv';
    const delta = actual - k.twin_predicted;
    const pct = k.twin_predicted !== 0 ? Math.abs(delta / k.twin_predicted * 100) : 0;
    const status = pct > k.threshold_pct * criticalMult ? 'critical' : pct > k.threshold_pct ? 'diverging' : 'aligned';
    const sign = delta >= 0 ? '+' : '';
    // Gap 4: topology-aware context. Resolve this KPI's asset -> line, and list
    // sibling KPIs on the same machine/line so the UI can support root-cause
    // reasoning ("reactor temp diverged AND coolant flow on the same line moved").
    const myAsset = k.asset_id;
    const myLine = myAsset && mIdx.get(myAsset) ? mIdx.get(myAsset)!.line : null;
    let related: string[] = [];
    if (status !== 'aligned' && (myAsset || myLine)) {
      related = allKpis.filter((o:any)=>{
        if (o.kpi_id === k.kpi_id) return false;
        if (myAsset && o.asset_id === myAsset) return true;
        const oLine = o.asset_id && mIdx.get(o.asset_id) ? mIdx.get(o.asset_id)!.line : null;
        return myLine && oLine === myLine;
      }).map((o:any)=>o.kpi_name);
    }
    return { kpi: k.kpi_name, actual: +Number(actual).toFixed(2), twin: k.twin_predicted, unit: k.unit,
             delta: `${sign}${delta.toFixed(1)}${k.unit === '%' ? '%' : ''}`,
             divergence_pct: +pct.toFixed(2),
             asset: myAsset ?? null, line: myLine ?? null, related,
             actual_source: actualSource,
             status, time: 'live' };
  });
  res.json({ divergence, critical_multiplier: criticalMult });
});
twinRouter.get('/scenarios', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  const all = loadTwinScenarios() as any[];
  const filtered = pf && pfCode && pfCode !== 'All Plants' ? all.filter((r:any)=>!r.plant||r.plant===pfCode||r.plant==='Both') : all;
  // Layer runtime scenario-run overrides — lazy auto-complete after durationSec.
  // CSV-seed status is the floor; operator-initiated runs override it.
  res.json({ scenarios: applyTwinScenarioRunOverrides(filtered) });
});

// GET /api/twin/asset-scenarios?plant=Plant 1 — per-asset failure-prediction
// scenarios with parameters PRE-FILLED from each asset's live values (OEE/health/
// RUL/vib/temp from the DB, machines.csv fallback). Plant-scoped: pick a plant.
twinRouter.get('/asset-scenarios', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  if (!pfCode || pfCode === 'All Plants') {
    return res.json({ requiresPlant: true, scenarios: [], note: 'Select Plant 1 or Plant 2 to load asset scenarios.' });
  }
  // Live snapshot first; fall back to machines.csv if DB empty.
  let snapshot: any[] = [];
  try { snapshot = require('../database/queries').getAssetLiveSnapshot(pfCode); } catch { snapshot = []; }
  let source: 'db' | 'csv' = snapshot.length ? 'db' : 'csv';
  if (!snapshot.length) {
    snapshot = (loadMachines() as any[])
      .filter((m:any) => m.plant === pfCode)
      .map((m:any) => ({ machine_id: m.id, name: m.name, line: m.line, plant: m.plant,
                         oee: m.oee, health: m.health, rul: m.rul, vib: m.vib, temp: m.temp }));
  }
  // Per-asset line rate (kg/hr) — from CSV config if present, else a sane default.
  const cfg = loadPlatformConfig() as any;
  const defaultRate = Number(cfg.twinConfig?.default_line_rate_kg_hr ?? 120);
  const margin = Number(cfg.twinConfig?.unit_margin ?? 18);
  const scenarios = snapshot.map((a:any) => {
    const critical = a.health < 30 || a.rul < 14;
    return {
      id: `FAIL-${a.machine_id}`,
      name: `${a.machine_id} ${critical ? 'Failure' : 'Degradation'} in ${a.rul} days`,
      type: 'failure',
      asset: a.machine_id, assetName: a.name, line: a.line, plant: a.plant,
      status: critical ? 'critical' : 'pending',
      // The "existing parameters" pre-filled from live values — these are what the
      // UI shows when the scenario is opened, and what the user can modify.
      params: {
        days_to_event: a.rul,
        line_rate: defaultRate,
        oee_pct: a.oee,
        health_pct: a.health,
        rul_days: a.rul,
        unit_margin: margin,
        repair_hours: critical ? 18 : 12,
      },
      live: { oee: a.oee, health: a.health, rul: a.rul, vib: a.vib, temp: a.temp },
      source,
    };
  });
  // ── Gas sensors (from DB ref_safety_zones, CSV fallback) — one detector per zone in this plant.
  // These are real reference assets too; they appear as GAS-<zone letter> markers.
  try {
    const zones = (await getSafetyZones(pfCode ?? undefined)).filter((z:any) => !pfCode || z.plant_id === pfCode || z.plant === pfCode);
    zones.forEach((z:any) => {
      const zoneLetter = String(z.zone || '').replace(/[^A-Za-z]/g, '').slice(-1).toUpperCase();
      if (!zoneLetter) return;
      const h2s = Number(z.h2s ?? 0);
      const alarm1 = Number(z.thresholds?.h2s?.alarm1 ?? 1);
      const ppm = h2s > 0 ? h2s : (zoneLetter === 'C' ? 2.8 : 0.1); // demo reading
      const high = ppm >= alarm1 * 0.6;
      scenarios.push({
        id: `GAS-${zoneLetter}`,
        name: `Gas Detector — Zone ${zoneLetter}`,
        type: 'gas',
        asset: `GAS-${zoneLetter}`, assetName: `Gas Sensor — Zone ${zoneLetter}`,
        line: `Zone ${zoneLetter}`, plant: pfCode,
        status: high ? 'warning' : 'good',
        params: {},
        live: { ppm, ppmStatus: high ? 'High' : 'Normal' },
        isGas: true,
        source,
      });
    });
  } catch { /* safety zones optional */ }
  res.json({ plant: pfCode, source, scenarios });
});

// ── Rule-engine fallback for twin what-if simulate ──────────────────────────
// Mirrors coin/reasoning-plane/multi-agent-orchestration/twin-sync/twin_sim.py so the What-If works even when the
// twin-sync Python service is not running (every AML/service endpoint has a
// rule-engine fallback — no single point of failure). Returns the SAME dict
// shape the service returns, so the UI is identical either way.
function _twinSimNum(params: any, key: string, def: number): number {
  const v = params?.[key];
  const n = Number(v);
  return (v === undefined || v === null || Number.isNaN(n)) ? def : n;
}
function twinSimulateFallback(scenarioType: string, params: any): any {
  const stype = (scenarioType || 'failure').toLowerCase();
  if (stype === 'failure') {
    const days   = _twinSimNum(params, 'days_to_event', 9);
    const rate   = _twinSimNum(params, 'line_rate', 120);
    const oee    = _twinSimNum(params, 'oee_pct', 70);
    const health = _twinSimNum(params, 'health_pct', 50);
    const rul    = _twinSimNum(params, 'rul_days', 9);
    const margin = _twinSimNum(params, 'unit_margin', 18);
    const repairH= _twinSimNum(params, 'repair_hours', 18);
    const severity = Math.max(0, (100 - health) / 100);
    const urgency  = rul <= 0 ? 1 : Math.max(0.2, Math.min(1.5, days / Math.max(1, rul)));
    const downtimeH   = Math.round(repairH * (1 + severity * urgency * 0.4) * 10) / 10;
    const prodLossKg  = Math.round(downtimeH * rate * (oee / 100));
    const oeeImpactPct= Math.round(-Math.min(25, downtimeH / (7 * 24) * 100 * 1.4) * 10) / 10;
    const yieldImpactPct = Math.round(-severity * 6 * 10) / 10;
    const revenueRisk = Math.round(prodLossKg * margin / 100) * 100;
    const confidence  = Math.round(Math.min(0.95, 0.65 + severity * 0.3) * 100) / 100;
    const act = rul <= days ? 'URGENT — service before failure'
              : `Schedule maintenance within ${Math.max(1, Math.round(rul - 2))} days`;
    return {
      success: true, engine: 'rule-fallback',
      impact: `${prodLossKg.toLocaleString()} kg loss, ₹${revenueRisk.toLocaleString()} revenue risk`,
      impact_value: prodLossKg, confidence,
      detail: {
        production_loss_kg: prodLossKg, oee_impact_pct: oeeImpactPct,
        yield_impact_pct: yieldImpactPct, downtime_hours: downtimeH,
        revenue_risk: revenueRisk, days_to_event: days, rul_days: rul,
      },
      recommendations: [
        act,
        `Pre-stage spares; expected repair window ~${repairH.toFixed(0)}h`,
        `Failure now would cost ~${prodLossKg.toLocaleString()} kg and ₹${revenueRisk.toLocaleString()}`,
      ],
    };
  }
  if (stype === 'maintenance') {
    const dt = _twinSimNum(params, 'downtime_hours', 8);
    const rate = _twinSimNum(params, 'line_rate', 120);
    const machines = Math.max(1, Math.round(_twinSimNum(params, 'machines', 2)));
    const overlap = _twinSimNum(params, 'overlap_pct', 35) / 100;
    const seqLost = dt * rate * machines;
    const parLost = dt * rate * (1 + overlap * (machines - 1));
    const saved = Math.round(seqLost - parLost);
    const impactPct = Math.round(saved / Math.max(1, seqLost) * 100 * 10) / 10;
    const sep = Math.abs(seqLost - parLost) / Math.max(seqLost, parLost);
    const confidence = Math.round(Math.min(0.95, 0.6 + sep * 0.6) * 100) / 100;
    return {
      success: true, engine: 'rule-fallback',
      impact: `${impactPct >= 0 ? '+' : ''}${impactPct}% throughput vs worse option`,
      impact_value: impactPct, confidence,
      detail: { sequential_units_lost: Math.round(seqLost), parallel_units_lost: Math.round(parLost), units_saved_vs_alt: saved, clock_hours: dt },
      recommendations: [
        `Run ${machines} machines in one ${dt.toFixed(0)}h parallel window`,
        `Pre-stage spares and crews; parallel needs ${machines}x technicians simultaneously`,
        `Accept ${(overlap * 100).toFixed(0)}% shared-capacity loss for a shorter outage`,
      ],
    };
  }
  if (stype === 'grade_change') {
    const purge = _twinSimNum(params, 'purge_min', 30);
    const flushT = _twinSimNum(params, 'flush_temp_c', 86);
    const rate = _twinSimNum(params, 'batch_rate', 90);
    const scrapFloor = _twinSimNum(params, 'scrap_floor_pct', 4);
    const purgeFactor = Math.max(0, 45 - purge) * 0.18;
    const tempFactor = Math.max(0, 92 - flushT) * 0.25;
    const scrapPct = Math.round((scrapFloor + purgeFactor + tempFactor) * 100) / 100;
    const lossReduction = Math.round((15 - scrapPct) / 15 * 100 * 10) / 10;
    const confidence = Math.round(Math.min(0.93, 0.7 + (purge / 60) * 0.2) * 100) / 100;
    return {
      success: true, engine: 'rule-fallback',
      impact: `-${lossReduction}% transition loss (scrap ${scrapPct}%)`,
      impact_value: lossReduction, confidence,
      detail: { predicted_scrap_pct: scrapPct, purge_time_loss_units: Math.round(purge / 60 * rate), flush_temp_c: flushT, purge_min: purge },
      recommendations: [
        flushT < 92 ? `Flush at 92°C (raising cuts scrap ~${tempFactor.toFixed(1)} pts)` : 'Flush temperature is at the sweet spot (92°C)',
        purge < 45 ? `Purge 45 min (extending cuts scrap ~${purgeFactor.toFixed(1)} pts)` : 'Purge duration is sufficient',
        'Run one trial batch and assay before committing the full campaign',
      ],
    };
  }
  if (stype === 'energy') {
    const kw = _twinSimNum(params, 'shiftable_kw', 220);
    const peak = _twinSimNum(params, 'peak_tariff', 9.5);
    const off = _twinSimNum(params, 'offpeak_tariff', 5.2);
    const hours = _twinSimNum(params, 'hours_shifted', 4);
    const energy = kw * hours;
    const saving = Math.round(energy * (peak - off));
    const peakCutPct = Math.round(kw / Math.max(1, _twinSimNum(params, 'plant_peak_kw', 1300)) * 100 * 10) / 10;
    const confidence = Math.round(Math.min(0.9, 0.65 + (peak - off) / peak * 0.5) * 100) / 100;
    return {
      success: true, engine: 'rule-fallback',
      impact: `₹${saving.toLocaleString()} saved, -${peakCutPct}% peak demand`,
      impact_value: saving, confidence,
      detail: { kwh_shifted: Math.round(energy), tariff_delta: Math.round((peak - off) * 100) / 100, peak_cut_pct: peakCutPct },
      recommendations: [
        `Shift ${kw.toFixed(0)} kW of flexible load (HVAC pre-cool, air compressors) to off-peak`,
        `Window: ${hours.toFixed(0)}h before the evening peak tariff of ₹${peak}/kWh`,
        'Verify night-shift staffing supports the rescheduled load',
      ],
    };
  }
  if (stype === 'supply') {
    const demand = _twinSimNum(params, 'daily_demand', 120);
    const lt = _twinSimNum(params, 'lead_time_days', 21);
    const drift = _twinSimNum(params, 'lead_time_drift_days', 6);
    const z = _twinSimNum(params, 'service_level_z', 1.65);
    const safety = Math.round(z * demand * Math.sqrt(drift));
    const cycle = Math.round(demand * lt);
    const reorder = cycle + safety;
    const confidence = Math.round(Math.min(0.88, 0.6 + (z - 1) * 0.2) * 100) / 100;
    return {
      success: true, engine: 'rule-fallback',
      impact: `-${drift.toFixed(1)}d stockout risk (buffer ${safety} units)`,
      impact_value: drift, confidence,
      detail: { safety_stock_units: safety, reorder_point_units: reorder, cycle_stock_units: cycle },
      recommendations: [
        `Hold ${safety} units safety stock to absorb ${drift.toFixed(0)}d of lead-time drift`,
        `Set reorder point at ${reorder} units (cycle ${cycle} + safety ${safety})`,
        'Re-run weekly as supplier Paydex / lead-time signals update',
      ],
    };
  }
  // Unknown type — still return a usable shape
  return { success: true, engine: 'rule-fallback', impact: 'No model for this scenario type', impact_value: 0, confidence: 0.5, detail: {}, recommendations: [] };
}

// POST /api/twin/simulate — stateless what-if: run the simulation with the given
// type + params and return the COMPUTED result immediately. Used by the per-asset
// failure scenarios and any interactive parameter editing (no run/override state).
//
// ── Single source of truth ──────────────────────────────────────────────────
// twin-sync (coin/reasoning-plane/multi-agent-orchestration/twin-sync/twin_sim.py) is the AUTHORITATIVE simulation
// engine. In every normal deployment (Docker Compose / Azure) TWIN_SERVICE_URL
// is set and this route simply PROXIES to it — the OR/behavioural model lives in
// exactly one place. The in-process twinSimulateFallback() is a DEGRADED-MODE
// resilience path that only runs if the twin-sync container is unreachable; it
// returns engine:'rule-fallback (degraded)' so it is never mistaken for the real
// engine. It is intentionally a coarse mirror, not a second implementation to be
// kept feature-equal. The Digital Twin has no ML model by design — it is a
// behavioural simulator (Phase E swaps the body for Azure Digital Twins / AML
// with the same contract).
twinRouter.post('/simulate', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const scenarioType = (req.body?.scenario_type as string) || 'failure';
  const params = req.body?.params ?? {};
  if (TWIN_SERVICE_URL) {
    try {
      const r = await fetch(`${TWIN_SERVICE_URL}/simulate`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario_type: scenarioType, params }),
        signal: AbortSignal.timeout(3000),
      });
      if (r.ok) {
        const data = await r.json() as any;
        // Authoritative result from the twin-sync OR engine.
        return res.json({ success: true, engine: 'twin-sync', source_mode: 'SERVICE', ...data });
      }
    } catch { /* twin-sync unreachable — fall through to degraded mode */ }
  }
  // Degraded-mode resilience path (twin-sync down). Clearly labelled so the UI
  // and any audit can see this was NOT the authoritative engine.
  const fb = twinSimulateFallback(scenarioType, params);
  return res.json({ ...fb, engine: 'rule-fallback (degraded)', source_mode: 'DEGRADED' });
});

// POST /api/twin/scenarios/:id/run — operator-triggered scenario run.
// Forwards to twin-sync service when TWIN_SERVICE_URL is set, records the
// override, publishes scenario_run event. Idempotent: returns 409 if already
// running (with the existing startedAt timestamp). Re-run is allowed on
// complete/cancelled scenarios — it resets the timer.
twinRouter.post('/scenarios/:id/run', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const seed = loadTwinScenarios().find((s:any) => s.id === id);
  if (!seed) return res.status(404).json({ error: `Scenario ${id} not found` });
  // Materialise the current effective status (CSV seed + any prior override + lazy completion)
  const projected = applyTwinScenarioRunOverrides([seed])[0] as any;
  if (projected.status === 'running') {
    return res.status(409).json({ error: `Scenario ${id} is already running since ${projected.startedAt}` });
  }
  // Forward to twin-sync service if configured, PASSING the what-if params from
  // the request body so the service computes a fresh outcome (Gap 2 fix). Best-
  // effort: service failure doesn't block the operator action.
  let svcResp: any = null;
  if (TWIN_SERVICE_URL) {
    try {
      const r = await fetch(`${TWIN_SERVICE_URL}/scenarios/${id}/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ params: req.body?.params ?? {}, scenario_type: req.body?.scenario_type }),
        signal: AbortSignal.timeout(3000),
      });
      if (r.ok) svcResp = await r.json();
    } catch { /* service unavailable; carry on with rule-engine fallback */ }
  }
  // Rule-engine fallback: if the service didn't compute, compute in-process so
  // the operator still sees a fresh, parameter-driven result.
  if (!svcResp?.computed) {
    const stype = (req.body?.scenario_type as string) || seed.type || seed.scenario_type || 'maintenance';
    const fb = twinSimulateFallback(stype, req.body?.params ?? {});
    svcResp = { ...fb, computed: true, estimated_minutes: 0.5, engine: fb.engine };
  }
  // Demo duration: short for the live demo.
  const durationSec = svcResp?.estimated_minutes ? Math.min(60, Number(svcResp.estimated_minutes) * 60) : 30;
  const now = new Date().toISOString();
  // Prefer the COMPUTED impact/confidence from the service; fall back to the CSV
  // seed only if the service didn't return one.
  const resultImpact = svcResp?.impact ?? seed.impact;
  const resultConfidence = Number(svcResp?.confidence ?? seed.confidence ?? 0.8);
  const ov = setTwinScenarioRun(id, {
    status:      'running',
    startedAt:   now,
    startedBy:   req.user?.name ?? 'operator',
    durationSec,
    resultImpact,
    resultConfidence,
  });
  try {
    await semanticLayer.publishEvent({
      id: `TS-${Date.now()}`, from: 'twin', to: 'yield',
      type: 'scenario_run', sev: 'info',
      msg: `Scenario ${id} (${seed.name}) started by ${ov.startedBy}`,
      impact: `Simulation in progress · ETA ${durationSec}s`,
      asset: id, plant_id: resolvePlant(id) ?? seed.plant ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish must not block */ }
  res.json({
    success: true, scenarioId: id, status: 'running',
    startedAt: ov.startedAt, durationSec,
    source_mode: TWIN_SERVICE_URL ? 'SERVICE' : 'RULE_ENGINE',
    // Surface the COMPUTED result so the UI can show what the simulation produced.
    computed: !!svcResp?.computed,
    impact: resultImpact,
    confidence: resultConfidence,
    detail: svcResp?.detail ?? null,
    recommendations: svcResp?.recommendations ?? null,
    engine: svcResp?.engine ?? null,
    paramsUsed: svcResp?.params_used ?? null,
  });
});

// POST /api/twin/scenarios/:id/cancel — operator cancels a running scenario.
// Returns 409 if the scenario isn't running. Publishes scenario_cancelled.
twinRouter.post('/scenarios/:id/cancel', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const seed = loadTwinScenarios().find((s:any) => s.id === id);
  if (!seed) return res.status(404).json({ error: `Scenario ${id} not found` });
  const projected = applyTwinScenarioRunOverrides([seed])[0] as any;
  if (projected.status !== 'running') {
    return res.status(409).json({ error: `Scenario ${id} is ${projected.status}; only running scenarios can be cancelled.` });
  }
  const existing = getTwinScenarioRun(id) ?? { status: 'running' as const };
  const now = new Date().toISOString();
  const ov = setTwinScenarioRun(id, { ...existing, status: 'cancelled', cancelledAt: now });
  try {
    await semanticLayer.publishEvent({
      id: `TS-${Date.now()}`, from: 'twin', to: 'audit',
      type: 'scenario_cancelled', sev: 'warning',
      msg: `Scenario ${id} (${seed.name}) cancelled by ${req.user?.name ?? 'unknown'}`,
      impact: 'Simulation aborted',
      asset: id, plant_id: resolvePlant(id) ?? seed.plant ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish must not block */ }
  res.json({ success: true, scenarioId: id, status: 'cancelled', cancelledAt: ov.cancelledAt });
});

// POST /api/twin/calibrate — operator triggers a manual recalibration sweep.
// Phase 1: records a semantic event in the audit channel; Phase A: forwards to
// twin-sync /recalibrate (new service endpoint). The Calibration tab previously
// had no action — page name promised "Continuous Self-Calibration" but offered
// nothing to calibrate.
twinRouter.post('/calibrate', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pfCode = normalizePlant(req.query.plant);
  let svcCalled = false;
  let svcResult: any = null;
  if (TWIN_SERVICE_URL) {
    try {
      const r = await fetch(`${TWIN_SERVICE_URL}/recalibrate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ triggered_by: req.user?.name ?? 'unknown' }),
        signal: AbortSignal.timeout(3000),
      });
      if (r.ok) { svcCalled = true; svcResult = await r.json(); }
    } catch { /* service may not implement /recalibrate yet — fall through */ }
  }
  const now = new Date().toISOString();
  try {
    await semanticLayer.publishEvent({
      id: `TC-${Date.now()}`, from: 'twin', to: 'audit',
      type: 'twin_recalibration', sev: 'info',
      msg: `Twin recalibration triggered by ${req.user?.name ?? 'unknown'}`,
      impact: svcResult
        ? `Twin re-aligned — ${svcResult.kpis_adjusted} KPI(s) adjusted, mean shift ${svcResult.mean_abs_shift}`
        : (svcCalled ? 'Twin-sync service notified' : 'Recorded in semantic layer (twin-sync service unavailable)'),
      asset: 'twin', plant_id: pfCode ?? 'All Plants', ts: now,
    } as any);
  } catch { /* never block on event publish */ }
  res.json({
    success: true, triggeredAt: now, triggeredBy: req.user?.name,
    source_mode: svcCalled ? 'SERVICE' : 'OVERRIDE',
    kpisAdjusted: svcResult?.kpis_adjusted ?? null,
    meanAbsShift: svcResult?.mean_abs_shift ?? null,
    method: svcResult?.method ?? null,
  });
});

// TWIN_DIVERGENCE removed — served from twin_kpis.csv via /api/twin/divergence
// TWIN_SCENARIOS removed — served from twin_scenarios.csv via /api/twin/scenarios

// ══════════════════════════════════════════════════════════════
// Safety & Compliance Agent
// ══════════════════════════════════════════════════════════════

// Safety-monitor Python service base URL. When set, the safety section fans
// out reads to the service (which runs precursor scoring + zone risk +
// PTW assessment logic) and falls back to CSV/SQLite on timeout/error.
// Set by docker-compose to http://safety-monitor:8000.
const SAFETY_SERVICE_URL = process.env.SAFETY_SERVICE_URL;
export const safetyRouter = Router();

safetyRouter.get('/events', async (req, res) => {
  try {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
    const pf = req.query.plant as string | undefined;
    const pfCode = normalizePlant(pf);
    // LIMIT used to be hardcoded 20 — now controlled by ?limit= with a sensible
    // default. Clamp to [1, 500] so a malformed query can't trigger a huge scan.
    const requestedLimit = Number(req.query.limit ?? 100);
    const limit = Math.max(1, Math.min(500, Number.isFinite(requestedLimit) ? requestedLimit : 100));
    const db = require('../database/connection').getDb();
    // Schema migration added plant_id with default 'P1' and backfills from CSV topology
    // (machines.csv + safety_zones.csv). Use it directly instead of hardcoded zone→plant maps.
    const plantSql = pfCode ? ' AND plant_id = ?' : '';
    const args: any[] = pfCode ? [pfCode] : [];
    const rawEvents = await db.prepare(`SELECT * FROM safety_events WHERE resolved_at IS NULL${plantSql} ORDER BY ts DESC LIMIT ${limit}`).all(...args);
    // Add a status field for override layering: SQLite has resolved_at + acked_at-via-runtime;
    // base status is 'open' for unresolved rows. Then apply runtime overrides on top.
    const seeded = rawEvents.map((e: any) => ({ ...e, status: e.resolved_at ? 'resolved' : 'open' }));
    const events = applySafetyEventOverrides(seeded);
    const openCritical = events.filter((e: any) => e.status !== 'resolved' && e.severity === 'critical').length;
    // Best-effort fan-out to the safety-monitor service for live zone-risk map.
    // The service runs the LSTM/rule precursor scoring on each zone's current
    // sensor state. We don't merge alerts (those come from SQLite history);
    // we just add the zone_risk map alongside so the dashboard can show real-
    // time risk badges without an extra round-trip.
    let zoneRisk: Record<string, string> | undefined;
    let serviceModelSource: string | undefined;
    let sourceMode = 'CSV';
    if (SAFETY_SERVICE_URL) {
      try {
        const r = await fetch(`${SAFETY_SERVICE_URL}/status`, { signal: AbortSignal.timeout(2000) });
        if (r.ok) {
          const svc: any = await r.json();
          zoneRisk = svc.zone_risk ?? undefined;
          serviceModelSource = svc.model_source ?? undefined;
          sourceMode = 'SERVICE';
        }
      } catch { /* service down → CSV-only response */ }
    }
    res.json({
      events, openCritical,
      zone_risk:    zoneRisk,
      source_mode:  sourceMode,
      source_system: serviceModelSource ?? 'EHS_SENSOR_NETWORK',
      plant_id:     pfCode ?? 'All Plants',
      limit,
    });
  } catch { res.json({ events: [], openCritical: 0 }); }
});

// GET /api/safety/zone-risk — standalone endpoint exposing the safety-monitor
// service's per-zone risk map. Returns CSV-derived "low" for every zone when
// the service is unavailable (no false reassurance).
safetyRouter.get('/zone-risk', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pfCode = normalizePlant(req.query.plant);
  if (SAFETY_SERVICE_URL) {
    try {
      const r = await fetch(`${SAFETY_SERVICE_URL}/status`, { signal: AbortSignal.timeout(4000) });
      if (r.ok) {
        const svc: any = await r.json();
        const zoneRisk = svc.zone_risk ?? {};
        // Plant-filter the zones if the operator selected a plant
        let filtered = zoneRisk;
        if (pfCode) {
          const { plantForZone } = require('../data/plant') as typeof import('../data/plant');
          filtered = Object.fromEntries(Object.entries(zoneRisk).filter(([z]) => plantForZone(z) === pfCode));
        }
        return res.json({
          zone_risk:    filtered,
          model_source: svc.model_source ?? 'rule_engine',
          source_mode:  'SERVICE',
          plant_id:     pfCode ?? 'All Plants',
        });
      }
    } catch { /* fall through to CSV baseline */ }
  }
  // Service unavailable → compute a basic risk tier from DB zone thresholds
  // (CSV fallback if DB empty). Mirrors safety-monitor rule engine: evac > alarm2 > alarm1 > low.
  const csvZones = (await getSafetyZones(pfCode ?? undefined))
    .filter(z => !pfCode || z.plant_id === pfCode || z.plant === pfCode);
  const zoneRisk: Record<string, string> = Object.fromEntries(
    csvZones.map(z => {
      const zoneKey = z.zone_id ?? z.zone;
      const t = z.thresholds ?? {};
      // Check evac → alarm2 → alarm1 across all three gases
      const h2s = z.h2s ?? 0;
      const co  = z.co  ?? 0;
      const ch4 = z.ch4 ?? 0;
      const isCritical =
        h2s >= (t.h2s?.evac ?? Infinity) ||
        co  >= (t.co?.evac  ?? Infinity) ||
        ch4 >= (t.ch4?.evac ?? Infinity);
      const isHigh =
        h2s >= (t.h2s?.alarm2 ?? Infinity) ||
        co  >= (t.co?.alarm2  ?? Infinity) ||
        ch4 >= (t.ch4?.alarm2 ?? Infinity);
      const isMedium =
        h2s >= (t.h2s?.alarm1 ?? Infinity) ||
        co  >= (t.co?.alarm1  ?? Infinity) ||
        ch4 >= (t.ch4?.alarm1 ?? Infinity);
      const tier = isCritical ? 'critical' : isHigh ? 'high' : isMedium ? 'medium' : 'low';
      return [zoneKey, tier];
    })
  );
  res.json({ zone_risk: zoneRisk, source_mode: 'CSV', plant_id: pfCode ?? 'All Plants' });
});

// GET /api/safety/ptw/assessments — service-driven PTW block analysis. The
// service reads live sensor state and tells us which permits should be
// blocked due to active gas alarms in their zone. Distinct from /ptw which
// is the permit list — this is the per-permit risk verdict.
safetyRouter.get('/ptw/assessments', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  if (!SAFETY_SERVICE_URL) {
    return res.json({ assessments: [], source_mode: 'CSV', note: 'SAFETY_SERVICE_URL not set' });
  }
  try {
    const r = await fetch(`${SAFETY_SERVICE_URL}/ptw/assess`, { signal: AbortSignal.timeout(2000) });
    if (!r.ok) throw new Error(`service returned ${r.status}`);
    const assessments = await r.json();
    res.json({ assessments, source_mode: 'SERVICE', plant_id: 'All Plants' });
  } catch (err) {
    res.json({ assessments: [], source_mode: 'CSV', error: String(err) });
  }
});
safetyRouter.get('/ptw', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  const all = loadSafetyPermits() as any[];
  const permits = pfCode && pfCode !== 'All Plants' ? all.filter((r:any)=>!r.plant||r.plant===pfCode||r.plant==='Both') : all;
  // Layer runtime PTW decisions on top of CSV seed
  res.json({ permits: applyPtwOverrides(permits) });
});

// POST /api/safety/ptw/:id/approve — operator approves a pending permit.
// Validates state machine (pending→approved), records the override + decider,
// publishes ptw_approved semantic event so other agents (e.g. PdM scheduling)
// know the work can proceed.
safetyRouter.post('/ptw/:id/approve', requireRole(ROLES.ENGINEER, ROLES.SUPERVISOR, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { reason } = (req.body ?? {}) as { reason?: string };
  // Resolve current state from CSV + any prior override
  const current = applyPtwOverrides(loadSafetyPermits() as any[]).find((p: any) => (p.id ?? p.ptw_id) === id);
  if (!current) return res.status(404).json({ error: `Permit ${id} not found` });
  if (!isValidPtwTransition(current.status, 'approved')) {
    return res.status(409).json({ error: `Permit ${id} is ${current.status}; only pending permits can be approved.` });
  }
  // CR-002 Semantic Layer gate: an active gas precursor in the same plant
  // blocks PTW approval. Previously the rule was documented and the fault was
  // registered (Active Blocks card showed it) but the approve endpoint never
  // called checkConflict — operators could approve a hot-work permit while a
  // gas precursor was live. Now gated. Plant scope used because permits carry
  // asset_id rather than zone_id; matches by plantForAsset(asset)===plantForZone(fault.zoneId).
  const permitPlant = resolvePlant(current.asset ?? current.asset_id) ?? current.plant;
  const conflict = semanticLayer.checkConflict({
    agent: 'safety', type: 'ptw_approve',
    assetId: current.asset ?? current.asset_id,
    plantId: permitPlant,
  });
  if (conflict.blocked) {
    // Best-effort: ask the safety-monitor service for a richer block reason
    // (which gas, which zone, which threshold breached). The Semantic Layer
    // reason is always returned as the authoritative ruleId; the service
    // detail is added as `serviceDetail` for the UI to surface inline.
    let serviceDetail: string | undefined;
    if (SAFETY_SERVICE_URL) {
      try {
        const r = await fetch(`${SAFETY_SERVICE_URL}/ptw/assess`, { signal: AbortSignal.timeout(1500) });
        if (r.ok) {
          const assessments: any[] = await r.json();
          const match = assessments.find((a: any) => a.ptw_id === id || a.asset_id === (current.asset ?? current.asset_id));
          if (match?.blocked && match.block_reason) serviceDetail = String(match.block_reason);
        }
      } catch { /* service down → fall through with Semantic Layer reason only */ }
    }
    return res.status(423).json({
      error:   `Blocked by Semantic Layer (${conflict.ruleId}): ${conflict.reason}`,
      blocked: true,
      ruleId:  conflict.ruleId,
      reason:  conflict.reason,
      serviceDetail,
    });
  }
  // Don't allow approve if validation fields are not all OK — JHA must be complete,
  // isolation verified, competency valid. This is what makes PTW automation real
  // rather than a rubber stamp. loadSafetyPermits returns these as booleans.
  const blocks: string[] = [];
  if (current.jha !== true)        blocks.push('JHA incomplete');
  if (current.isolation !== true)  blocks.push('isolation unverified');
  if (current.competency !== true) blocks.push('competency expired');
  if (blocks.length) {
    return res.status(409).json({ error: `Cannot approve ${id}: ${blocks.join(', ')}.` });
  }
  const now = new Date().toISOString();
  const ov = setPtwOverride(id, { status: 'approved', decidedBy: req.user?.name ?? 'unknown', decidedAt: now, reason });
  try {
    await semanticLayer.publishEvent({
      id: `PTW-${Date.now()}`, from: 'safety', to: 'pdm',
      type: 'ptw_approved', sev: 'info',
      msg: `PTW ${id} approved — work cleared on ${current.asset ?? current.asset_id}`,
      impact: `Maintenance window unblocked${reason ? ` (${reason})` : ''}`,
      asset: current.asset ?? current.asset_id, plant_id: resolvePlant(current.asset ?? current.asset_id) ?? current.plant ?? 'P1',
      ts: now,
    } as any);
  } catch { /* event publish must not block decision */ }
  res.json({ success: true, ptwId: id, status: 'approved', decidedBy: ov.decidedBy, at: ov.decidedAt });
});

// POST /api/safety/ptw/:id/reject — operator rejects a pending permit.
// Requires a reason. Publishes ptw_rejected event so dependent agents back off.
safetyRouter.post('/ptw/:id/reject', requireRole(ROLES.ENGINEER, ROLES.SUPERVISOR, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { reason } = (req.body ?? {}) as { reason?: string };
  if (!reason || !String(reason).trim()) {
    return res.status(400).json({ error: 'Reject reason required' });
  }
  const current = applyPtwOverrides(loadSafetyPermits() as any[]).find((p: any) => (p.id ?? p.ptw_id) === id);
  if (!current) return res.status(404).json({ error: `Permit ${id} not found` });
  if (!isValidPtwTransition(current.status, 'rejected')) {
    return res.status(409).json({ error: `Permit ${id} is ${current.status}; only pending permits can be rejected.` });
  }
  const now = new Date().toISOString();
  const ov = setPtwOverride(id, { status: 'rejected', decidedBy: req.user?.name ?? 'unknown', decidedAt: now, reason });
  try {
    await semanticLayer.publishEvent({
      id: `PTW-${Date.now()}`, from: 'safety', to: 'pdm',
      type: 'ptw_rejected', sev: 'warning',
      msg: `PTW ${id} rejected — ${reason}`,
      impact: `Maintenance work on ${current.asset ?? current.asset_id} blocked`,
      asset: current.asset ?? current.asset_id, plant_id: resolvePlant(current.asset ?? current.asset_id) ?? current.plant ?? 'P1',
      ts: now,
    } as any);
  } catch { /* event publish must not block decision */ }
  res.json({ success: true, ptwId: id, status: 'rejected', decidedBy: ov.decidedBy, at: ov.decidedAt, reason });
});

// POST /api/safety/events/:id/ack — operator acknowledges an open safety event.
// Records the override so the timeline reflects who picked it up. Does NOT
// resolve — that's a separate action requiring confirmation that the precursor
// has cleared.
safetyRouter.post('/events/:id/ack', requireRole(ROLES.ENGINEER, ROLES.SUPERVISOR, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const existing = getSafetyEventOverride(id);
  if (existing?.status === 'resolved') {
    return res.status(409).json({ error: `Event ${id} already resolved` });
  }
  if (existing?.status === 'acked') {
    return res.status(200).json({ success: true, eventId: id, status: 'acked', already: true });
  }
  const now = new Date().toISOString();
  const ov = setSafetyEventOverride(id, { status: 'acked', ackedBy: req.user?.name ?? 'unknown', ackedAt: now });
  try {
    await semanticLayer.publishEvent({
      id: `SE-${Date.now()}`, from: 'safety', to: 'audit',
      type: 'safety_event_acked', sev: 'info',
      msg: `Safety event ${id} acknowledged by ${ov.ackedBy}`,
      impact: 'Operator picked up the event — investigation in progress',
      asset: id, plant_id: 'All Plants', ts: now,
    } as any);
  } catch { /* event publish must not block ack */ }
  res.json({ success: true, eventId: id, status: 'acked', ackedBy: ov.ackedBy, at: ov.ackedAt });
});

// POST /api/safety/events/:id/resolve — operator confirms the precursor cleared.
// Optional notes capture the resolution (e.g. "Ventilation increased, readings normalised").
safetyRouter.post('/events/:id/resolve', requireRole(ROLES.ENGINEER, ROLES.SUPERVISOR, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { notes } = (req.body ?? {}) as { notes?: string };
  const existing = getSafetyEventOverride(id);
  if (existing?.status === 'resolved') {
    return res.status(409).json({ error: `Event ${id} already resolved` });
  }
  const now = new Date().toISOString();
  const ov = setSafetyEventOverride(id, {
    status:     'resolved',
    ackedBy:    existing?.ackedBy,
    ackedAt:    existing?.ackedAt,
    resolvedBy: req.user?.name ?? 'unknown',
    resolvedAt: now,
    notes,
  });
  try {
    await semanticLayer.publishEvent({
      id: `SE-${Date.now()}`, from: 'safety', to: 'audit',
      type: 'safety_event_resolved', sev: 'info',
      msg: `Safety event ${id} resolved by ${ov.resolvedBy}`,
      impact: notes ?? 'Precursor cleared',
      asset: id, plant_id: 'All Plants', ts: now,
    } as any);
  } catch { /* event publish must not block resolution */ }
  res.json({ success: true, eventId: id, status: 'resolved', resolvedBy: ov.resolvedBy, at: ov.resolvedAt, notes });
});

// GET /api/safety/compliance/report — generates a CSV report of safety events.
// Was a hardcoded "Auto-populated" string in the UI; this is the real export
// the operator can download. Phase A: replaces with templated OSHA 300 PDF.
safetyRouter.get('/compliance/report', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  const days = Number(req.query.days ?? 30);
  const framework = String(req.query.framework ?? 'osha_300').toLowerCase();
  const db = require('../database/connection').getDb();
  const since = Date.now() - days * 86400000;
  const plantSql = pfCode ? ' AND plant_id = ?' : '';
  const args: any[] = pfCode ? [since, pfCode] : [since];
  const rows = await db.prepare(`SELECT * FROM safety_events WHERE ts >= ?${plantSql} ORDER BY ts DESC`).all(...args);
  const enriched = applySafetyEventOverrides(rows.map((r: any) => ({ ...r, status: r.resolved_at ? 'resolved' : 'open' })));
  // CSV body — every framework gets the same columns for now (Phase A: per-framework templates)
  const headers = ['event_id','timestamp','zone','event_type','severity','status','h2s_ppm','co_ppm','ch4_pct_lel','acked_by','acked_at','resolved_by','resolved_at','notes','plant_id'];
  const csvEscape = (v: any) => {
    const s = v == null ? '' : String(v);
    return /[,"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [headers.join(',')];
  for (const r of enriched as any[]) {
    lines.push([r.id, new Date(r.ts).toISOString(), r.zone, r.event_type, r.severity, r.status, r.h2s, r.co, r.ch4, r.ackedBy, r.ackedAt, r.resolvedBy, r.resolvedAt, r.notes, r.plant_id].map(csvEscape).join(','));
  }
  const csv = lines.join('\n');
  const filename = `${framework}_${pfCode ?? 'all-plants'}_${days}d_${new Date().toISOString().slice(0,10)}.csv`;
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.send(csv);
});

// GET /api/safety/compliance/status — counts + last-event timestamp for the
// Compliance tab. Replaces the hardcoded "Auto-populated" / "Auto-compiled"
// literals with real numbers.
safetyRouter.get('/compliance/status', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  const days = Number(req.query.days ?? 30);
  const db = require('../database/connection').getDb();
  const since = Date.now() - days * 86400000;
  const plantSql = pfCode ? ' AND plant_id = ?' : '';
  const args: any[] = pfCode ? [since, pfCode] : [since];
  const row = await db.prepare(`SELECT COUNT(*) as total, SUM(CASE WHEN resolved_at IS NULL THEN 1 ELSE 0 END) as open_count, MAX(ts) as last_ts, MIN(ts) as first_ts FROM safety_events WHERE ts >= ?${plantSql}`).get(...args);
  res.json({
    days,
    total:        Number(row?.total ?? 0),
    open:         Number(row?.open_count ?? 0),
    last_ts:      row?.last_ts ? new Date(row.last_ts).toISOString() : null,
    first_ts:     row?.first_ts ? new Date(row.first_ts).toISOString() : null,
    plant_id:     pfCode ?? 'All Plants',
  });
});

// SAFETY_EVENTS now served from SQLite via /api/history/safety/events
// PTW_LIST now served from safety_permits.csv via /api/safety/permits

// ══════════════════════════════════════════════════════════════
// Semantic Layer Routes
// ══════════════════════════════════════════════════════════════
export const semanticRouter = Router();

semanticRouter.get('/kpis',   async (_req, res) => res.json({ kpis: semanticLayer.getKPIDefinitions() }));
semanticRouter.get('/events', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pfCode = normalizePlant(req.query.plant as string | undefined);
  // Use the DB-backed plant-filtered path when a specific plant is requested;
  // fall back to full in-memory list for All Plants so the Insights panel
  // always has events even before the first DB write on a fresh container.
  let events: any[];
  if (pfCode) {
    const { getRecentEventsByPlant } = require('../database/event-store');
    const rows = await getRecentEventsByPlant(pfCode, 50);
    // rehydrate: spread payload JSON so front-end gets to, impact, plant_id etc.
    events = rows.map((r: any) => {
      let payload: any = {};
      try { payload = JSON.parse(r.payload ?? '{}'); } catch { /**/ }
      return {
        ...payload,
        id:   r.event_id,
        type: r.event_type,
        from: r.from_agent,
        asset: r.asset_id ?? payload.asset,
        sev:  r.severity,
        msg:  r.message,
        ts:   typeof r.ts === 'number' ? new Date(r.ts).toISOString() : r.ts,
      };
    });
    // If DB is empty (fresh container, no events yet) fall back to in-memory
    if (!events.length) {
      events = (await semanticLayer.getRecentEvents(50)).filter((e: any) =>
        !e.plant_id || e.plant_id === pfCode
      );
    }
  } else {
    // All Plants — try DB first (persisted events survive container restarts),
    // fall back to in-memory only if DB is empty (very first seconds of a fresh container)
    try {
      const { getRecentEvents: dbGetAll } = require('../database/event-store');
      const dbRows = dbGetAll(50);
      if (dbRows.length > 0) {
        events = dbRows.map((r: any) => {
          let payload: any = {};
          try { payload = JSON.parse(r.payload ?? '{}'); } catch { /**/ }
          return {
            ...payload,
            id:   r.event_id,
            type: r.event_type,
            from: r.from_agent,
            asset: r.asset_id ?? payload.asset,
            sev:  r.severity,
            msg:  r.message,
            ts:   typeof r.ts === 'number' ? new Date(r.ts).toISOString() : r.ts,
          };
        });
      } else {
        events = await semanticLayer.getRecentEvents(50);
      }
    } catch {
      events = await semanticLayer.getRecentEvents(50);
    }
  }
  res.json({ events });
});

// POST /api/semantic/reload — flush in-memory caches so CSV edits propagate
// without a container restart. Was the biggest Phase 1 footgun: operators
// could edit semantic_kpi_threshold or conflict_rules, see no change, and
// have no idea the cache was the problem. Now: one POST and the next read
// reflects disk state. Phase A: a webhook on file change does this
// automatically; until then it's an admin-only manual trigger.
semanticRouter.post('/reload', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const start = Date.now();
  const flushed: string[] = [];
  try {
    await warmKpiDefinitions();    flushed.push('kpi_definitions');
    reloadConflictRules();     flushed.push('conflict_rules');
    // Re-derive plant topology from CSV (machines, energy_assets, safety_zones, shifts).
    // Same module-level cache pattern as the semantic layer.
    try {
      const { reloadTopology } = require('../data/plant');
      reloadTopology();        flushed.push('plant_topology');
    } catch { /* topology may not be loaded yet */ }
    // Publish an audit event so operators see the reload in the cross-agent log
    await semanticLayer.publishEvent({
      id: `RELOAD-${Date.now()}`, from: 'semantic', to: 'audit',
      type: 'semantic_reload', sev: 'info',
      msg: `Semantic Layer caches reloaded by ${req.user?.name ?? 'unknown'}`,
      impact: `Flushed: ${flushed.join(', ')}`,
      asset: 'semantic', plant_id: 'All Plants', ts: new Date().toISOString(),
    } as any);
    res.json({ success: true, flushed, elapsedMs: Date.now() - start, triggeredBy: req.user?.name });
  } catch (err) {
    res.status(500).json({ success: false, error: String(err), flushed });
  }
});

/**
 * Unified active-blocks endpoint — returns every conflict the Semantic Layer is
 * currently enforcing, regardless of which agent it blocks (Yield DCS, PTW,
 * work orders, energy dispatch). Used by the right-panel aggregate counter so
 * "X recs blocked" reflects EVERY block type, not just yield.
 */
semanticRouter.get('/active-blocks', async (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  const blocks = semanticLayer.getActiveBlocks();
  const filtered = pfCode && pfCode !== 'All Plants'
    ? blocks.filter(b => !b.plant_id || b.plant_id === pfCode)
    : blocks;
  // Aggregate counts per blockAgent so the UI can show a breakdown
  const byAgent: Record<string, number> = {};
  for (const b of filtered) byAgent[b.blockAgent] = (byAgent[b.blockAgent] ?? 0) + 1;
  res.json({
    total:    filtered.length,
    byAgent,
    blocks:   filtered,
    plant_id: pfCode ?? 'All Plants',
    ts:       new Date().toISOString(),
  });
});

// ══════════════════════════════════════════════════════════════
// Unified AI Routes
// ══════════════════════════════════════════════════════════════
export const aiRouter = Router();

const ChatSchema = z.object({
  messages: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string() })),
  liveContext: z.string().optional(),
  filters: z.object({
    plant: z.string().optional(),
    line: z.string().optional(),
    asset: z.string().optional(),
    period: z.string().optional(),
  }).optional(),
});

// Step 7 — the single new endpoint permitted by the spec: admin-scoped, same code path as the scheduler.
aiRouter.post('/admin/refresh', requireRole(ROLES.ADMIN), async (_req, res) => {
  const result = await runRefresh('admin');
  res.status(result.status === 'ok' ? 200 : 503).json({ ...result, drift: await checkSeedDrift().catch(e => ({ status: 'error', detail: String(e) })) });
});

aiRouter.post('/chat', async (req, res) => {
  const parsed = ChatSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  try {
    // RC-1: normalize the plant filter at the boundary. The frontend sends the
    // raw store value ('Plant 1' / 'Plant 2' / 'All Plants'), but every getter
    // and applyPlantFilter downstream compares against the DB plant code
    // ('P1' / 'P2'). Without this, 'Plant 1' !== 'P1' filtered EVERY record to
    // zero and the grounded packet collapsed to "MISSING DATASET" for all
    // agents. normalizePlant() returns null for 'All Plants'/unknown → we map
    // that back to 'All Plants' so applyPlantFilter short-circuits to all rows.
    const f = parsed.data.filters ?? {};
    const normFilters = { ...f, plant: normalizePlant(f.plant) ?? 'All Plants' };
    // RC-3 (server side): the browser's legacy KPI dictionary injected "[CSV definition only — no live feed yet]"
    // into every prompt. Strip those lines here so the UI needs no change; the server packet is authoritative.
    const cleanLiveContext = typeof parsed.data.liveContext === 'string'
      ? parsed.data.liveContext.split('\n').filter(l => !/CSV definition only|no live feed|MUST list ONLY KPIs|respond exactly/i.test(l)).join('\n')
      : parsed.data.liveContext;
    const reply = await unifiedChat(
      parsed.data.messages as any,
      cleanLiveContext,
      normFilters,
    );
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

// V40: diagnostic endpoint — exposes the LLM config the api container loaded
// at startup so the operator can confirm `LLM_PROVIDER=stargate` is actually
// in effect and the key state is `set` (not `placeholder` or `missing`). The
// key itself is masked. Hit this AFTER restarting the api container to verify
// .env.local changes were picked up.
aiRouter.get('/diagnostic', async (_req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.json(getLlmStatus());
});

aiRouter.post('/recommend/:agent', async (req, res) => {
  const { context, question } = req.body as { context: string; question: string };
  try {
    const reply = await agentRecommendation(req.params.agent, context, question);
    res.json({ reply, agent: req.params.agent });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});

aiRouter.post('/semantic-query', async (req, res) => {
  const { question, kpiContext } = req.body as { question: string; kpiContext: string };
  try {
    const reply = await semanticQuery(question, kpiContext);
    res.json({ reply });
  } catch { res.status(503).json({ error: 'AI service unavailable' }); }
});
