#!/usr/bin/env python3
"""
ManuAI — Yield Model Scoring Entry Point (Azure ML compatible)
===============================================================

Azure ML managed-endpoint scoring script. Matches the YieldPrediction contract
the yield-optimizer service expects, so wiring is:

    AML_YIELD_ENDPOINT=https://<endpoint>/score
    AML_API_KEY=<key>

The yield-optimizer service (V43) POSTs a ProcessParams payload here and gets
back a full YieldPrediction. On any error it falls back to the rule engine.

Local test:
    python score.py --selftest
"""

import os
import csv
import json
import joblib
import numpy as np
from pathlib import Path

_MODEL = None
_TARGETS = None
_SENS = None

PARAM_KEYS = ["tic_101", "pic_102", "sic_204", "fic_301", "tic_205", "fic_401"]


def _load_targets():
    """Load yield_params.csv for target/unit/name used in recommendations."""
    targets = {}
    csv_dir = os.environ.get("CSV_DATA_DIR", "/app/data/csv")
    path = Path(csv_dir) / "yield_params.csv"
    if not path.exists():
        path = Path(__file__).resolve().parents[4] / "data" / "csv" / "yield_params.csv"
    if path.exists():
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                tag = (row.get("id") or "").strip()
                if tag:
                    targets[tag.lower().replace("-", "_")] = {
                        "name": (row.get("name") or "").strip(),
                        "unit": (row.get("unit") or "").strip(),
                        "target": float(row.get("target") or 0),
                        "min": float(row.get("min") or 0),
                        "max": float(row.get("max") or 0),
                        "tag": tag,
                    }
    return targets


def init():
    global _MODEL, _TARGETS
    model_dir = os.getenv("AZUREML_MODEL_DIR")
    candidate = (Path(model_dir) / "yield_model.joblib") if model_dir \
        else (Path(__file__).parent / "yield_model.joblib")
    _MODEL = joblib.load(candidate)
    _TARGETS = _load_targets()


def _featurize(rec):
    """Build the feature vector (params + one-hot product) the model expects."""
    feats = []
    for k in _MODEL["param_keys"]:
        feats.append(float(rec.get(k, _TARGETS.get(k, {}).get("target", 0))))
    product = rec.get("product", _MODEL["products"][0])
    for p in _MODEL["products"]:
        feats.append(1.0 if product == p else 0.0)
    return feats


def run(raw_data):
    if _MODEL is None:
        init()
    data = json.loads(raw_data) if isinstance(raw_data, str) else raw_data
    records = data.get("records") if isinstance(data, dict) and "records" in data else [data]

    yield_model = _MODEL["yield_model"]
    grade_model = _MODEL["grade_model"]
    grades = _MODEL["grades"]

    out = []
    for rec in records:
        feats = np.array([_featurize(rec)], dtype=float)
        predicted = float(np.clip(yield_model.predict(feats)[0], 50, 98))
        grade_proba = grade_model.predict_proba(feats)[0]
        grade_prob = {grades[i]: round(float(grade_proba[i]), 3) for i in range(len(grades))}

        # Recommendations: for each param off-target, compute target setpoint +
        # the yield delta from moving it back (estimated via model perturbation)
        recs = []
        for k in PARAM_KEYS:
            meta = _TARGETS.get(k)
            if not meta:
                continue
            cur = float(rec.get(k, meta["target"]))
            tgt = meta["target"]
            span = meta["max"] - meta["min"]
            if span <= 0 or abs(cur - tgt) / span < 0.04:
                continue
            # Counterfactual: what yield if this param were at target?
            cf = dict(rec); cf[k] = tgt
            cf_feats = np.array([_featurize(cf)], dtype=float)
            cf_yield = float(np.clip(yield_model.predict(cf_feats)[0], 50, 98))
            delta = max(0.0, cf_yield - predicted)
            if delta < 0.05:
                continue
            recs.append({
                "tag_id": meta["tag"], "name": meta["name"],
                "current": round(cur, 2), "recommended": round(tgt, 2),
                "unit": meta["unit"], "delta_yield_pct": round(delta, 2),
                "confidence": round(min(0.95, 0.80 + delta * 0.05), 2),
                "reason": f"{'Above' if cur > tgt else 'Below'} target by "
                          f"{abs(cur-tgt):.1f} {meta['unit']}; model estimates "
                          f"+{delta:.1f}% yield if corrected.",
            })
        recs.sort(key=lambda r: -r["delta_yield_pct"])
        bottleneck = recs[0]["name"] if recs else "n/a"
        total_improvement = round(sum(r["delta_yield_pct"] for r in recs), 1)

        out.append({
            "batch_id": rec.get("batch_id", "unknown"),
            "predicted_yield_pct": round(predicted, 1),
            "yield_low": round(predicted - 1.8, 1),
            "yield_high": round(predicted + 1.8, 1),
            "grade_probability": grade_prob,
            "recommendations": recs,
            "bottleneck": bottleneck,
            "estimated_improvement_pct": total_improvement,
            "model_source": _MODEL.get("version", "baseline-synthetic-v1"),
        })

    return out[0] if len(out) == 1 else {"results": out}


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        init()
        # On-target batch → high yield, few recs
        ontarget = run({"batch_id": "B-TEST-1", "product": "PC-Auto-Grade",
                        "tic_101": 186, "pic_102": 8.4, "sic_204": 395,
                        "fic_301": 138, "tic_205": 47, "fic_401": 28.6})
        # Off-target batch → lower yield, recommendations
        offtarget = run({"batch_id": "B-TEST-2", "product": "PC-Auto-Grade",
                         "tic_101": 196, "pic_102": 10.5, "sic_204": 460,
                         "fic_301": 165, "tic_205": 70, "fic_401": 22})
        print("ON-TARGET :", json.dumps(ontarget))
        print()
        print("OFF-TARGET:", json.dumps(offtarget))
