#!/usr/bin/env python3
"""
ManuAI — Yield Baseline Model Training Harness
===============================================

Trains the Yield prediction ensemble on synthetic batch data:
  1. Yield regressor  — XGBoost, predicts actual_yield_pct
  2. Grade classifier — XGBoost multiclass (A/B/C)

The model learns the NON-LINEAR yield surface (quadratic penalties +
parameter interactions) that the linear rule engine cannot represent — this is
the measurable uplift Phase E promises over the Phase A rule engine.

Validation compares the trained model against the rule-engine baseline on a
held-out test set, so we can quantify the improvement.

Output:
    yield_model.joblib
    yield_metrics.json
"""

import json
import csv
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import (mean_absolute_error, r2_score,
                             f1_score, accuracy_score)
import xgboost as xgb

BASE = Path(__file__).resolve().parents[4]
YIELD_PARAMS_CSV = BASE / "data" / "csv" / "yield_params.csv"
ML_THRESH_CSV    = BASE / "data" / "csv" / "ml_thresholds.csv"

PARAM_KEYS = ["tic_101", "pic_102", "sic_204", "fic_301", "tic_205", "fic_401"]
GRADES = ["A", "B", "C"]


def load_rule_engine_config():
    """Load targets + sensitivities to replicate the rule-engine baseline."""
    targets, sens, base_yield = {}, {}, 91.5
    if YIELD_PARAMS_CSV.exists():
        with open(YIELD_PARAMS_CSV, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                tag = (row.get("id") or "").strip()
                if tag:
                    targets[tag.lower().replace("-", "_")] = float(row.get("target") or 0)
    if ML_THRESH_CSV.exists():
        with open(ML_THRESH_CSV, newline="", encoding="utf-8") as f:
            for row in csv.reader(f):
                if row and row[0] == "yield":
                    if row[1] == "sensitivity":
                        try: sens[row[2].replace("_pct_per_unit", "")] = float(row[3])
                        except (ValueError, IndexError): pass
                    elif row[1] == "model" and row[2] == "base_yield_pct":
                        try: base_yield = float(row[3])
                        except (ValueError, IndexError): pass
    default_sens = {"tic_101": 0.35, "pic_102": 1.20, "sic_204": 0.008,
                    "fic_301": 0.12, "tic_205": 0.18, "fic_401": 0.40}
    for k, v in default_sens.items():
        sens.setdefault(k, v)
    return targets, sens, base_yield


def rule_engine_predict(df, targets, sens, base_yield):
    """Replicate the linear rule-engine yield prediction for comparison."""
    preds = np.full(len(df), base_yield, dtype=float)
    for key in PARAM_KEYS:
        if key in targets:
            preds -= np.abs(df[key].values - targets[key]) * sens[key]
    return np.clip(preds, 50, 98)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(Path(__file__).parent / "yield_training_data.parquet"))
    ap.add_argument("--out-model", default=str(Path(__file__).parent / "yield_model.joblib"))
    ap.add_argument("--out-metrics", default=str(Path(__file__).parent / "yield_metrics.json"))
    ap.add_argument("--test-frac", type=float, default=0.25)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    df = pd.read_parquet(args.data)
    print(f"Loaded {len(df):,} batches")

    # One-hot product as a feature (recipe matters)
    products = sorted(df["product"].unique())
    for p in products:
        df[f"prod_{p}"] = (df["product"] == p).astype(int)
    prod_cols = [f"prod_{p}" for p in products]
    feat_cols = PARAM_KEYS + prod_cols

    X = df[feat_cols].values
    y_yield = df["actual_yield_pct"].values
    grade_idx = df["grade"].map({g: i for i, g in enumerate(GRADES)}).values

    Xtr, Xte, ytr, yte, gtr, gte, idx_tr, idx_te = train_test_split(
        X, y_yield, grade_idx, np.arange(len(df)),
        test_size=args.test_frac, random_state=args.seed)
    print(f"Train: {len(Xtr):,} | Test: {len(Xte):,}")

    # ── Yield regressor ────────────────────────────────────────────────────
    yield_model = xgb.XGBRegressor(
        n_estimators=400, max_depth=6, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=args.seed,
        objective="reg:squarederror", n_jobs=-1)
    yield_model.fit(Xtr, ytr)
    ypred = np.clip(yield_model.predict(Xte), 50, 98)
    ml_mae = mean_absolute_error(yte, ypred)
    ml_r2  = r2_score(yte, ypred)

    # ── Rule-engine baseline on the SAME test rows (for uplift comparison) ──
    targets, sens, base_yield = load_rule_engine_config()
    df_te = df.iloc[idx_te]
    rule_pred = rule_engine_predict(df_te, targets, sens, base_yield)
    rule_mae = mean_absolute_error(yte, rule_pred)
    rule_r2  = r2_score(yte, rule_pred)

    # ── Grade classifier ───────────────────────────────────────────────────
    grade_model = xgb.XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=args.seed,
        objective="multi:softprob", num_class=3,
        eval_metric="mlogloss", n_jobs=-1)
    grade_model.fit(Xtr, gtr)
    gpred = grade_model.predict(Xte)
    g_acc = accuracy_score(gte, gpred)
    g_f1  = f1_score(gte, gpred, average="weighted")

    fi = dict(sorted(
        zip(feat_cols, [float(x) for x in yield_model.feature_importances_]),
        key=lambda kv: kv[1], reverse=True))

    mae_improvement = round((rule_mae - ml_mae) / rule_mae * 100, 1)

    metrics = {
        "model": "ManuAI Yield Baseline Ensemble (synthetic pre-train)",
        "n_batches": int(len(df)),
        "yield_regressor": {"mae_pct": round(ml_mae, 4), "r2": round(ml_r2, 4)},
        "rule_engine_baseline": {"mae_pct": round(rule_mae, 4), "r2": round(rule_r2, 4)},
        "uplift_vs_rule_engine": {
            "mae_reduction_pct": mae_improvement,
            "note": f"ML model is {mae_improvement}% more accurate (MAE) than the "
                    f"linear rule engine on held-out batches — it captures the "
                    f"non-linear interactions the rule engine cannot."
        },
        "grade_classifier": {"accuracy": round(g_acc, 4), "weighted_f1": round(g_f1, 4)},
        "feature_importance": {k: round(v, 4) for k, v in fi.items()},
        "features": feat_cols,
        "products": products,
        "note": "Baseline for Phase A deployment. Fine-tune on real SAP PP "
                "confirmed-yield + PI param data before retiring the rule engine.",
    }

    joblib.dump({
        "yield_model": yield_model,
        "grade_model": grade_model,
        "features": feat_cols,
        "param_keys": PARAM_KEYS,
        "products": products,
        "grades": GRADES,
        "version": "baseline-synthetic-v1",
    }, args.out_model)

    with open(args.out_metrics, "w") as f:
        json.dump(metrics, f, indent=2)

    print("\n── Validation (held-out batches) ──")
    print(f"  ML yield regressor : MAE {ml_mae:.3f}% | R2 {ml_r2:.4f}")
    print(f"  Rule-engine baseline: MAE {rule_mae:.3f}% | R2 {rule_r2:.4f}")
    print(f"  → ML is {mae_improvement}% more accurate than the rule engine")
    print(f"  Grade classifier   : Acc {g_acc:.4f} | Weighted-F1 {g_f1:.4f}")
    print(f"\n  Top features: " + ", ".join(f"{k} {v*100:.0f}%" for k, v in list(fi.items())[:4]))
    print(f"\nModel:   {args.out_model}")
    print(f"Metrics: {args.out_metrics}")


if __name__ == "__main__":
    main()
