#!/usr/bin/env python3
"""
ManuAI — Yield Synthetic Training Data Generator
=================================================

Generates labelled (process-params → actual-yield) batches for training a
Yield-prediction model (XGBoost regressor + grade classifier).

DESIGN NOTE — why this beats the rule engine:
  The live rule engine (yield-optimizer/main.py) uses a LINEAR sensitivity
  model: yield = base - Σ |param - target| * sensitivity. Real polymer/welding
  processes are non-linear and have INTERACTION effects (e.g. high reactor temp
  is only harmful when pressure is also high; coolant flow matters more at high
  jacket temp). We synthesise yields using a richer physics model that includes:
    • the linear sensitivity term (so the model still learns the basics)
    • quadratic penalties (deviation hurts more the further out you go)
    • two interaction terms (temp×pressure, jacket-temp×coolant-flow)
    • per-product base-yield offsets
    • batch-level process noise
  An XGBoost model trained on this learns the non-linear surface the linear rule
  engine cannot — which is exactly the uplift Phase E promises.

Targets/sensitivities/base-yield are read from the SAME CSVs the service uses
(yield_params.csv, ml_thresholds.csv) so the synthetic ground truth is anchored
to the real configuration.

Output: yield_training_data.parquet (+ preview CSV)
"""

import os
import csv
import math
import random
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[4]
YIELD_PARAMS_CSV = BASE / "data" / "csv" / "yield_params.csv"
ML_THRESH_CSV    = BASE / "data" / "csv" / "ml_thresholds.csv"

PARAM_KEYS = ["tic_101", "pic_102", "sic_204", "fic_301", "tic_205", "fic_401"]
PRODUCTS   = ["PC-Auto-Grade", "PC-Elec-Housing", "ABS-Consumer", "Weld-Steel-A", "Weld-Steel-B"]


def load_targets():
    """Read yield_params.csv → per-param target/min/max."""
    targets = {}
    if YIELD_PARAMS_CSV.exists():
        with open(YIELD_PARAMS_CSV, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                tag = (row.get("id") or "").strip()
                if not tag:
                    continue
                key = tag.lower().replace("-", "_")
                targets[key] = {
                    "name": (row.get("name") or "").strip(),
                    "unit": (row.get("unit") or "").strip(),
                    "target": float(row.get("target") or 0),
                    "min": float(row.get("min") or 0),
                    "max": float(row.get("max") or 0),
                    "plant": (row.get("plant") or "P1").strip(),
                }
    return targets


def load_thresholds():
    """Read ml_thresholds.csv yield rows → sensitivity + model constants."""
    sens, model, grades = {}, {}, {}
    if ML_THRESH_CSV.exists():
        with open(ML_THRESH_CSV, newline="", encoding="utf-8") as f:
            for row in csv.reader(f):
                if not row or row[0] != "yield":
                    continue
                _, cat, key, val = row[0], row[1], row[2], row[3]
                try:
                    v = float(val)
                except ValueError:
                    continue
                if cat == "sensitivity":
                    sens[key.replace("_pct_per_unit", "")] = v
                elif cat == "model":
                    model[key] = v
                elif cat == "grade_thresholds":
                    grades[key] = v
    return sens, model, grades


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-batches", type=int, default=20000,
                    help="Number of synthetic batches to generate")
    ap.add_argument("--out", default=str(Path(__file__).parent / "yield_training_data.parquet"))
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    targets = load_targets()
    sens, model, grades = load_thresholds()

    if not targets:
        raise SystemExit("Could not load yield_params.csv — aborting")

    base_yield  = model.get("base_yield_pct", 91.5)
    clamp_min   = model.get("clamp_min", 50)
    clamp_max   = model.get("clamp_max", 98)
    a_grade_min = grades.get("a_grade_min_yield", 90)
    b_grade_min = grades.get("b_grade_min_yield", 80)

    # Default sensitivities if CSV missing any
    default_sens = {"tic_101": 0.35, "pic_102": 1.20, "sic_204": 0.008,
                    "fic_301": 0.12, "tic_205": 0.18, "fic_401": 0.40}
    for k, v in default_sens.items():
        sens.setdefault(k, v)

    # Per-product base-yield offsets (different recipes yield differently)
    product_offset = {p: random.uniform(-1.5, 1.0) for p in PRODUCTS}

    rows = []
    for i in range(args.n_batches):
        product = random.choice(PRODUCTS)
        plant = "P1" if product.startswith(("PC", "ABS")) else "P2"

        # Sample each param around its operating range (not just near target —
        # we need the model to see off-target conditions to learn the surface)
        params = {}
        for key in PARAM_KEYS:
            t = targets.get(key)
            if not t:
                params[key] = 0.0
                continue
            span = t["max"] - t["min"]
            # Most batches run CLOSE to target (well-controlled plant); a minority
            # drift off. Weighted toward tight control so grade mix is realistic.
            spread = span * random.choice([0.02, 0.02, 0.03, 0.05, 0.05, 0.08, 0.15, 0.25])
            val = np.random.normal(t["target"], spread)
            params[key] = float(np.clip(val, t["min"], t["max"]))

        # ── Ground-truth yield surface (NON-LINEAR — the part the rule engine misses) ──
        y = base_yield + product_offset[product]

        # 1. Linear sensitivity term (what the rule engine knows)
        for key in PARAM_KEYS:
            t = targets.get(key)
            if not t:
                continue
            dev = abs(params[key] - t["target"])
            y -= dev * sens[key]

        # 2. Quadratic penalty — deviation hurts disproportionately far out
        for key in PARAM_KEYS:
            t = targets.get(key)
            if not t:
                continue
            span = max(t["max"] - t["min"], 1e-6)
            norm_dev = (params[key] - t["target"]) / span
            y -= (norm_dev ** 2) * 3.5   # quadratic bowl (softened)

        # 3. Interaction: reactor temp × pressure (both high = exothermic risk)
        t_temp, t_pres = targets["tic_101"]["target"], targets["pic_102"]["target"]
        temp_excess = max(0, params["tic_101"] - t_temp)
        pres_excess = max(0, params["pic_102"] - t_pres)
        y -= (temp_excess * pres_excess) * 0.08

        # 4. Interaction: jacket temp × coolant flow (insufficient cooling at high jacket temp)
        t_jacket, t_cool = targets["tic_205"]["target"], targets["fic_401"]["target"]
        jacket_excess = max(0, params["tic_205"] - t_jacket)
        cool_deficit  = max(0, t_cool - params["fic_401"])
        y -= (jacket_excess * cool_deficit) * 0.12

        # 5. Batch process noise
        y += np.random.normal(0, 0.9)

        y = float(np.clip(y, clamp_min, clamp_max))

        # Grade assignment from yield
        if y >= a_grade_min:
            grade = "A"
        elif y >= b_grade_min:
            grade = "B"
        else:
            grade = "C"

        row = {
            "batch_id": f"B-{i:06d}",
            "product": product,
            "plant_id": plant,
            **{key: round(params[key], 3) for key in PARAM_KEYS},
            "actual_yield_pct": round(y, 3),
            "grade": grade,
        }
        rows.append(row)

    df = pd.DataFrame(rows)
    df.to_parquet(args.out, index=False)
    df.head(2000).to_csv(args.out.replace(".parquet", "_preview.csv"), index=False)

    print(f"Generated {len(df):,} synthetic batches")
    print(f"  Yield range : {df['actual_yield_pct'].min():.1f} .. {df['actual_yield_pct'].max():.1f} %")
    print(f"  Mean yield  : {df['actual_yield_pct'].mean():.2f} %")
    print(f"  Grade mix   : {df['grade'].value_counts(normalize=True).round(3).to_dict()}")
    print(f"  Products    : {df['product'].nunique()} across {df['plant_id'].nunique()} plants")
    print(f"\nWritten: {args.out}")


if __name__ == "__main__":
    main()
