"""
ManuAI — Supply Intelligence Service  v2.0
Predicts supply shortfalls 4–8 weeks ahead using composite risk scoring
across lead-time drift, supplier financial health, and geopolitical exposure.

Mock mode uses rule-based risk logic with realistic Indian manufacturing context.
Live mode: set DNB_API_KEY + SAP_ODATA_BASE_URL for live ERP/D&B integration.
"""

import os, random, logging
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime, timedelta
from ml_thresholds import get_threshold, list_thresholds
from service_health import register_health

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Supply Intelligence", version="2.0.0")
register_health(app, "supply-intelligence", required_files=["ml_thresholds.csv", "supply_risks.csv"], model_file="supply_model.joblib")

MOCK = not bool(os.getenv("SAP_ODATA_BASE_URL"))
if MOCK:
    logger.warning("SAP_ODATA_BASE_URL not set — supply intelligence running in mock/rule mode")


# ── Models ────────────────────────────────────────────────────────────────────

class SupplierInput(BaseModel):
    supplier_id: str
    supplier_name: str
    sku: str
    description: str
    current_stock_days: float       # days of cover
    reorder_point_days: float
    lead_time_contracted_days: int
    lead_time_actual_days: int      # recent rolling average
    open_po_qty: float
    monthly_consumption: float
    unit_cost_inr: float
    single_source: bool
    country_of_origin: str
    financial_risk_score: float     # 0–100 (D&B paydex proxy)

class RiskAssessment(BaseModel):
    supplier_id: str
    supplier_name: str
    sku: str
    description: str
    overall_risk: str               # "critical" | "high" | "medium" | "low"
    risk_score: float               # 0–100
    lead_time_drift_days: int
    shortfall_probability_pct: float
    weeks_to_stockout: float
    exposure_inr: float
    risk_factors: List[str]
    recommended_action: str
    suggested_safety_stock_uplift_pct: float
    alternate_suppliers: List[str]

class SupplyForecastPoint(BaseModel):
    week_label: str
    forecast_consumption: float
    forecast_stock: float
    reorder_trigger: bool
    risk_flag: bool

class SupplyResponse(BaseModel):
    assessments: List[RiskAssessment]
    overall_plant_risk: str
    critical_count: int
    total_exposure_inr: float
    model_source: str


# ── Static supplier catalogue (replaces ERP fetch in mock mode) ───────────────


# ── CSV-driven suppliers (Issue 6 fix): mounted /app/data/csv, fallback to inline ──
import csv as _csv
import os as _os

_CSV_DIR = _os.environ.get("CSV_DATA_DIR", "/app/data/csv")

def _csv_suppliers():
    path = _os.path.join(_CSV_DIR, "supply_risks.csv")
    if not _os.path.exists(path):
        return None
    with open(path, encoding="utf-8-sig") as f:
        rows = list(_csv.DictReader(f))
    return [{
        "supplier_id": r["supplier_id"], "supplier_name": r["supplier_name"],
        "sku": r["sku"], "description": r["description"],
        "current_stock_days": float(r["current_stock_days"]),
        "reorder_point_days": float(r["reorder_point_days"]),
        "lead_time_contracted_days": int(r["lead_time_contracted_days"]),
        "lead_time_actual_days": int(r["lead_time_actual_days"]),
        "open_po_qty": float(r.get("open_po_qty") or 0),  # not in CSV — default 0
        "monthly_consumption": float(r["monthly_consumption"]),
        "unit_cost_inr": float(r["unit_cost_inr"]),
        "single_source": str(r["single_source"]).lower() == "true",
        "country_of_origin": r["country_of_origin"],
        "financial_risk_score": float(r["financial_risk_score"]),
    } for r in rows]

_FALLBACK_SUPPLIERS: List[dict] = [
    {"supplier_id":"SUP-001","supplier_name":"Siemens AG","sku":"SRV-750W",
     "description":"750W Servo Drive J1","current_stock_days":8,"reorder_point_days":15,
     "lead_time_contracted_days":21,"lead_time_actual_days":39,"open_po_qty":4,
     "monthly_consumption":6,"unit_cost_inr":84000,"single_source":True,
     "country_of_origin":"Germany","financial_risk_score":18},

    {"supplier_id":"SUP-002","supplier_name":"Alfa Laval","sku":"HX-PLATES",
     "description":"Plate Heat Exchanger Elements","current_stock_days":22,"reorder_point_days":20,
     "lead_time_contracted_days":28,"lead_time_actual_days":35,"open_po_qty":1,
     "monthly_consumption":0.5,"unit_cost_inr":420000,"single_source":False,
     "country_of_origin":"Sweden","financial_risk_score":32},

    {"supplier_id":"SUP-003","supplier_name":"SKF India","sku":"BRG-6205",
     "description":"Deep Groove Ball Bearing 6205","current_stock_days":45,"reorder_point_days":10,
     "lead_time_contracted_days":7,"lead_time_actual_days":7,"open_po_qty":20,
     "monthly_consumption":30,"unit_cost_inr":1200,"single_source":False,
     "country_of_origin":"India","financial_risk_score":12},

    {"supplier_id":"SUP-004","supplier_name":"BASF Chemicals","sku":"CMPD-X12",
     "description":"Compound X-12 Base Resin","current_stock_days":6,"reorder_point_days":14,
     "lead_time_contracted_days":30,"lead_time_actual_days":51,"open_po_qty":0,
     "monthly_consumption":12,"unit_cost_inr":96000,"single_source":True,
     "country_of_origin":"Germany","financial_risk_score":55},

    {"supplier_id":"SUP-005","supplier_name":"Parker Hannifin India","sku":"HYD-SEAL-KIT",
     "description":"Hydraulic Seal Kit HPU","current_stock_days":30,"reorder_point_days":12,
     "lead_time_contracted_days":14,"lead_time_actual_days":16,"open_po_qty":3,
     "monthly_consumption":4,"unit_cost_inr":8500,"single_source":False,
     "country_of_origin":"India","financial_risk_score":20},
]

# CSV is authoritative (Issue 6 fix)
MOCK_SUPPLIERS: List[dict] = _csv_suppliers() or _FALLBACK_SUPPLIERS



def _compute_risk(s: SupplierInput) -> RiskAssessment:
    score = 0.0
    factors = []
    alts = []

    lead_drift = s.lead_time_actual_days - s.lead_time_contracted_days
    if lead_drift > 0:
        score += min(lead_drift * 1.8, 40)
        factors.append(f"Lead-time drift +{lead_drift}d over contract")

    # Financial risk
    if s.financial_risk_score > 50:
        score += (s.financial_risk_score - 50) * 0.8
        factors.append("Elevated supplier financial risk (D&B score)")

    # Single source
    if s.single_source:
        score += 20
        factors.append("Single-source supplier — no alternate")
        alts.append("Identify alternate source urgently")
    else:
        alts.append("Alternate suppliers on panel")

    # Stock coverage vs reorder
    if s.current_stock_days < s.reorder_point_days:
        score += 25
        factors.append(f"Stock below reorder point ({s.current_stock_days:.0f}d < {s.reorder_point_days:.0f}d)")

    # Geopolitical
    high_risk_countries = ["Germany", "China", "Taiwan", "Ukraine", "Russia"]
    if s.country_of_origin in high_risk_countries and lead_drift > 5:
        score += 12
        factors.append(f"Origin: {s.country_of_origin} — trade/logistics risk flag")

    score = min(score, 100)

    # Risk score → bucket — thresholds from ml_thresholds.csv (service=supply)
    crit_min   = get_threshold('supply', 'risk_score', 'critical_min', 70)
    high_min   = get_threshold('supply', 'risk_score', 'high_min',     45)
    medium_min = get_threshold('supply', 'risk_score', 'medium_min',   25)
    if   score >= crit_min:   overall = "critical"
    elif score >= high_min:   overall = "high"
    elif score >= medium_min: overall = "medium"
    else:                     overall = "low"

    daily_consumption = s.monthly_consumption / 30
    weeks_to_stockout = (s.current_stock_days / 7) if daily_consumption > 0 else 99

    # Stockout response brackets — CSV-driven
    emergency_days       = get_threshold('supply', 'stockout', 'emergency_days', 7)
    emer_shortfall       = get_threshold('supply', 'stockout', 'emergency_shortfall_prob', 85)
    emer_uplift          = get_threshold('supply', 'stockout', 'emergency_safety_uplift', 50)
    crit_shortfall       = get_threshold('supply', 'stockout', 'critical_shortfall_prob', 65)
    crit_uplift          = get_threshold('supply', 'stockout', 'critical_safety_uplift', 40)
    high_shortfall       = get_threshold('supply', 'stockout', 'high_shortfall_prob',    40)
    high_uplift          = get_threshold('supply', 'stockout', 'high_safety_uplift',     20)
    low_shortfall        = get_threshold('supply', 'stockout', 'low_shortfall_prob',     10)

    if s.current_stock_days < emergency_days:
        shortfall_prob = emer_shortfall
        action = "Emergency procurement — expedite now"
        safety_uplift = emer_uplift
    elif score >= crit_min:
        shortfall_prob = crit_shortfall
        action = f"Dual-source immediately; safety stock +{crit_uplift}%"
        safety_uplift = crit_uplift
    elif score >= high_min:
        shortfall_prob = high_shortfall
        action = "Increase safety stock and issue early PO"
        safety_uplift = high_uplift
    else:
        shortfall_prob = low_shortfall
        action = "Monitor; no action required"
        safety_uplift = 0

    exposure_mult = get_threshold('supply', 'exposure', 'multiplier_months', 1.5)
    exposure = s.unit_cost_inr * s.monthly_consumption * exposure_mult

    return RiskAssessment(
        supplier_id=s.supplier_id,
        supplier_name=s.supplier_name,
        sku=s.sku,
        description=s.description,
        overall_risk=overall,
        risk_score=round(score, 1),
        lead_time_drift_days=lead_drift,
        shortfall_probability_pct=shortfall_prob,
        weeks_to_stockout=round(weeks_to_stockout, 1),
        exposure_inr=round(exposure, 0),
        risk_factors=factors,
        recommended_action=action,
        suggested_safety_stock_uplift_pct=safety_uplift,
        alternate_suppliers=alts,
    )


# ── Azure ML hook ─────────────────────────────────────────────────────────────
# Set AML_SUPPLY_ENDPOINT (+ AML_API_KEY) to score via the trained XGBoost model
# (coin/runtime-plane/ai-workflows/supply/score.py). On any error the rule engine is used as automatic fallback,
# so supply assessment never goes dark from a model failure.

_AML_ENDPOINT = os.getenv("AML_SUPPLY_ENDPOINT", "")
_AML_KEY      = os.getenv("AML_API_KEY", "")
AML_MOCK      = not bool(_AML_ENDPOINT)
if AML_MOCK:
    logger.warning("AML_SUPPLY_ENDPOINT not set — supply risk scored by rule engine")


def _aml_assess(s: SupplierInput) -> RiskAssessment:
    """Call the Azure ML scoring endpoint for one supplier; fall back to rules."""
    headers = {"Content-Type": "application/json"}
    if _AML_KEY:
        headers["Authorization"] = f"Bearer {_AML_KEY}"
    try:
        resp = httpx.post(_AML_ENDPOINT, json=s.model_dump(), headers=headers, timeout=10.0)
        resp.raise_for_status()
        return RiskAssessment(**resp.json())
    except Exception as exc:
        logger.warning(f"AML supply endpoint error — falling back to rule engine: {exc}")
        return _compute_risk(s)


# ── Local in-process model serving (ML_LOCAL=true) ───────────────────────────
# Loads the pre-trained XGBoost bundle (supply_model.joblib) and scores in-proc
# via ml_score.run(), so the demo serves real ML WITHOUT an Azure ML endpoint.
# Rule engine remains the final fallback if the model is absent or errors.
ML_LOCAL = os.getenv("ML_LOCAL", "").lower() in ("1", "true", "yes")
_LOCAL_OK = False
_ml = None
if ML_LOCAL:
    try:
        import ml_score as _ml  # copied from coin/runtime-plane/ai-workflows/supply/score.py at build time
        _ml.init()
        _LOCAL_OK = True
        logger.info("[ML] supply local model loaded — serving in-process")
    except Exception as _e:
        logger.warning(f"[ML] supply local model unavailable, using rule engine: {_e}")


def _assess_one(s: SupplierInput) -> RiskAssessment:
    """Route a single supplier: AML endpoint → local model → rule engine."""
    if not AML_MOCK:
        return _aml_assess(s)
    if _LOCAL_OK:
        try:
            return RiskAssessment(**_ml.run(s.model_dump()))
        except Exception as exc:
            logger.warning(f"[ML] local supply inference failed — rule fallback: {exc}")
    return _compute_risk(s)


@app.get("/assess", response_model=SupplyResponse)
def assess():
    """Run supply risk assessment against the mock supplier catalogue."""
    suppliers = [SupplierInput(**s) for s in MOCK_SUPPLIERS]
    assessments = [_assess_one(s) for s in suppliers]
    assessments.sort(key=lambda a: -a.risk_score)

    critical = sum(1 for a in assessments if a.overall_risk == "critical")
    high     = sum(1 for a in assessments if a.overall_risk == "high")
    overall  = "critical" if critical else ("high" if high else "medium")
    total_exp = sum(a.exposure_inr for a in assessments)

    return SupplyResponse(
        assessments=assessments,
        overall_plant_risk=overall,
        critical_count=critical,
        total_exposure_inr=round(total_exp, 0),
        model_source=("azure_ml" if not AML_MOCK else ("local_ml" if _LOCAL_OK else "rule_engine")),
    )


@app.post("/assess/custom", response_model=RiskAssessment)
def assess_custom(supplier: SupplierInput):
    return _assess_one(supplier)


@app.get("/forecast/{sku}", response_model=List[SupplyForecastPoint])
def forecast(sku: str):
    s = next((SupplierInput(**x) for x in MOCK_SUPPLIERS if x["sku"] == sku), None)
    if not s:
        raise HTTPException(404, f"SKU {sku} not in catalogue")
    daily_cons = s.monthly_consumption / 30
    stock = s.current_stock_days * daily_cons
    result = []
    for i in range(8):
        label = f"W{i+17}"
        consumption = daily_cons * 7 * (1 + random.uniform(-0.05, 0.05))
        stock = max(0, stock - consumption + (daily_cons * 7 if i == 3 else 0))
        result.append(SupplyForecastPoint(
            week_label=label,
            forecast_consumption=round(consumption, 1),
            forecast_stock=round(stock, 1),
            reorder_trigger=stock < s.reorder_point_days * daily_cons,
            risk_flag=stock < daily_cons * 7,
        ))
    return result


@app.get("/thresholds")
def thresholds():
    return list_thresholds('supply')
