"""
ManuAI — Yield Optimiser Service  v2.1

All numeric constants moved out of code:
  * TARGETS / min / max come from data/csv/yield_params.csv (the same CSV the
    Node API and dashboards read). Eliminates target-drift between layers.
  * Sensitivity coefficients, base yield, penalty weights, confidence
    parameters come from data/csv/ml_thresholds.csv (service=yield).

Set AML_YIELD_ENDPOINT to swap in a real Azure ML model.
"""
import os, csv, random, logging
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict
from ml_thresholds import get_threshold, get_category, list_thresholds
from service_health import register_health

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Yield Optimiser", version="2.1.0")
register_health(app, "yield-optimizer", required_files=["ml_thresholds.csv", "yield_params.csv"], model_file="yield_model.joblib")

MOCK = not bool(os.getenv("AML_YIELD_ENDPOINT"))
if MOCK:
    logger.warning("AML_YIELD_ENDPOINT not set — yield optimiser running in mock/rule mode")


class ProcessParams(BaseModel):
    batch_id: str
    tic_101: float
    pic_102: float
    sic_204: float
    fic_301: float
    tic_205: float
    fic_401: float
    run_minutes: float = 0.0
    current_yield_pct: Optional[float] = None


class SetPointRec(BaseModel):
    tag_id: str
    name: str
    current: float
    recommended: float
    unit: str
    delta_yield_pct: float
    confidence: float
    reason: str


class YieldPrediction(BaseModel):
    batch_id: str
    predicted_yield_pct: float
    yield_low: float
    yield_high: float
    grade_probability: Dict[str, float]
    recommendations: List[SetPointRec]
    bottleneck: str
    estimated_improvement_pct: float
    model_source: str


# ── Targets loaded from yield_params.csv at startup ─────────────────────────
# Eliminates the previous duplication where target/min/max were hardcoded
# both here AND in data/csv/yield_params.csv (and could silently drift).

_CSV_DIR = os.environ.get('CSV_DATA_DIR', '/app/data/csv')

def _load_targets_from_csv() -> Dict[str, dict]:
    """Read yield_params.csv → {tag_id_lower: {name, unit, target, min, max, tag}}.
    Tag IDs in the CSV are like 'TIC-101'; we key by 'tic_101' to match ProcessParams field names."""
    path = os.path.join(_CSV_DIR, 'yield_params.csv')
    targets: Dict[str, dict] = {}
    try:
        with open(path, newline='', encoding='utf-8') as f:
            for row in csv.DictReader(f):
                tag = (row.get('id') or '').strip()
                if not tag:
                    continue
                key = tag.lower().replace('-', '_')
                targets[key] = {
                    'name':   (row.get('name') or '').strip(),
                    'unit':   (row.get('unit') or '').strip(),
                    'target': float(row.get('target') or 0),
                    'min':    float(row.get('min') or 0),
                    'max':    float(row.get('max') or 0),
                    'tag':    tag,
                }
    except FileNotFoundError:
        logger.warning(f"yield_params.csv not found at {path} — using empty target set")
    except Exception as e:
        logger.error(f"Failed to load yield_params.csv: {e}")
    return targets


_TARGETS_CACHE: Optional[Dict[str, dict]] = None


def _get_targets() -> Dict[str, dict]:
    """Lazy-load + cache. Provides a hardcoded fallback so the service still
    functions if the CSV is unavailable in early container startup."""
    global _TARGETS_CACHE
    if _TARGETS_CACHE is None:
        _TARGETS_CACHE = _load_targets_from_csv()
        if not _TARGETS_CACHE:
            # Last-resort fallback so the service can still respond
            _TARGETS_CACHE = {
                "tic_101": {"name": "Reactor Temp", "unit": "°C",    "target": 186, "min": 160, "max": 200, "tag": "TIC-101"},
                "pic_102": {"name": "Pressure",     "unit": "bar",   "target": 8.4, "min": 6.0, "max": 12.0,"tag": "PIC-102"},
                "sic_204": {"name": "Mixing Speed", "unit": "RPM",   "target": 395, "min": 300, "max": 500, "tag": "SIC-204"},
                "fic_301": {"name": "Feed Rate",    "unit": "kg/hr", "target": 138, "min": 100, "max": 180, "tag": "FIC-301"},
                "tic_205": {"name": "Jacket Temp",  "unit": "°C",    "target": 47,  "min": 30,  "max": 80,  "tag": "TIC-205"},
                "fic_401": {"name": "Coolant Flow", "unit": "L/min", "target": 28.6,"min": 20,  "max": 40,  "tag": "FIC-401"},
            }
    return _TARGETS_CACHE


def _clamp(val, mn, mx):
    return max(mn, min(mx, val))


def _noise(scale=None):
    if scale is None:
        scale = get_threshold('yield', 'model', 'noise_scale', 0.02)
    return (random.random() - 0.5) * scale


def _rule_predict(p: ProcessParams) -> YieldPrediction:
    """All tunable constants CSV-driven; see data/csv/ml_thresholds.csv (service=yield)
    and data/csv/yield_params.csv (target/min/max)."""
    targets = _get_targets()
    params = {
        "tic_101": p.tic_101, "pic_102": p.pic_102, "sic_204": p.sic_204,
        "fic_301": p.fic_301, "tic_205": p.tic_205, "fic_401": p.fic_401,
    }

    # Sensitivity: % yield lost per unit deviation from target — from CSV
    sensitivity = {
        "tic_101": get_threshold('yield', 'sensitivity', 'tic_101_pct_per_unit', 0.35),
        "pic_102": get_threshold('yield', 'sensitivity', 'pic_102_pct_per_unit', 1.20),
        "sic_204": get_threshold('yield', 'sensitivity', 'sic_204_pct_per_unit', 0.008),
        "fic_301": get_threshold('yield', 'sensitivity', 'fic_301_pct_per_unit', 0.12),
        "tic_205": get_threshold('yield', 'sensitivity', 'tic_205_pct_per_unit', 0.18),
        "fic_401": get_threshold('yield', 'sensitivity', 'fic_401_pct_per_unit', 0.40),
    }

    base_yield     = get_threshold('yield', 'model', 'base_yield_pct', 91.5)
    uncertainty    = get_threshold('yield', 'model', 'uncertainty_pct', 1.8)
    clamp_min      = get_threshold('yield', 'model', 'clamp_min', 50)
    clamp_max      = get_threshold('yield', 'model', 'clamp_max', 98)
    skip_threshold = get_threshold('yield', 'model', 'skip_deviation_pct', 0.04)
    base_conf      = get_threshold('yield', 'confidence', 'base', 0.82)

    penalties = {}
    for key, val in params.items():
        if key not in targets:
            continue
        tgt = targets[key]["target"]
        penalties[key] = abs(val - tgt) * sensitivity[key]

    total_penalty = sum(penalties.values())
    predicted = _clamp(base_yield - total_penalty + _noise() * 2, clamp_min, clamp_max)

    # Build recommendations — skip params barely off target
    recs = []
    for key, val in params.items():
        if key not in targets:
            continue
        meta = targets[key]
        tgt = meta["target"]
        dev = val - tgt
        span = meta["max"] - meta["min"]
        if span <= 0 or abs(dev) / span < skip_threshold:
            continue
        delta_yield = penalties[key]
        # Confidence drops as deviation widens relative to the full span
        conf = base_conf - (abs(dev) / span) * 0.15
        recs.append(SetPointRec(
            tag_id=meta["tag"],
            name=meta["name"],
            current=round(val, 2),
            recommended=round(tgt, 2),
            unit=meta["unit"],
            delta_yield_pct=round(delta_yield, 2),
            confidence=round(_clamp(conf, 0.0, 1.0), 2),
            reason=f"{'Above' if dev > 0 else 'Below'} target by {abs(dev):.1f} {meta['unit']}; "
                   f"estimated +{delta_yield:.1f}% yield if corrected.",
        ))

    recs.sort(key=lambda r: -r.delta_yield_pct)

    bottleneck_key = max(penalties, key=penalties.get) if penalties else None
    bottleneck = targets[bottleneck_key]["name"] if bottleneck_key else "n/a"
    total_improvement = sum(r.delta_yield_pct for r in recs)

    # Grade probabilities — anchored to predicted yield
    grade_a_min = get_threshold('yield', 'grade_thresholds', 'a_grade_min_yield', 90)
    grade_a = _clamp(0.78 + (predicted - grade_a_min) * 0.03 + _noise(0.04), 0, 1)
    grade_b = _clamp(0.19 - (predicted - grade_a_min) * 0.02 + _noise(0.02), 0, 1)
    grade_c = _clamp(1 - grade_a - grade_b, 0, 1)

    return YieldPrediction(
        batch_id=p.batch_id,
        predicted_yield_pct=round(predicted, 1),
        yield_low=round(predicted - uncertainty, 1),
        yield_high=round(predicted + uncertainty, 1),
        grade_probability={"A": round(grade_a, 3), "B": round(grade_b, 3), "C": round(grade_c, 3)},
        recommendations=recs,
        bottleneck=bottleneck,
        estimated_improvement_pct=round(total_improvement, 1),
        model_source="rule_engine",
    )


_AML_ENDPOINT = os.getenv("AML_YIELD_ENDPOINT", "")
_AML_KEY      = os.getenv("AML_API_KEY", "")

def _aml_predict(params: ProcessParams) -> YieldPrediction:
    """Call Azure ML scoring endpoint. Falls back to rule engine on any error."""
    payload = params.model_dump()
    headers = {"Content-Type": "application/json"}
    if _AML_KEY:
        headers["Authorization"] = f"Bearer {_AML_KEY}"
    try:
        resp = httpx.post(_AML_ENDPOINT, json=payload, headers=headers, timeout=10.0)
        resp.raise_for_status()
        data = resp.json()
        # AML endpoint returns YieldPrediction-shaped JSON — validate with Pydantic
        return YieldPrediction(**data)
    except Exception as exc:
        logger.warning(f"AML endpoint error — falling back to rule engine: {exc}")
        result = _rule_predict(params)
        return result.model_copy(update={"model_source": f"rule_engine_fallback:{type(exc).__name__}"})


# ── Local in-process model serving (ML_LOCAL=true) ───────────────────────────
ML_LOCAL = os.getenv("ML_LOCAL", "").lower() in ("1", "true", "yes")
_LOCAL_OK = False
_ml = None
if ML_LOCAL:
    try:
        import ml_score as _ml  # copied from coin/runtime-plane/ai-workflows/yield/score.py at build time
        _ml.init()
        _LOCAL_OK = True
        logger.info("[ML] yield local model loaded — serving in-process")
    except Exception as _e:
        logger.warning(f"[ML] yield local model unavailable, using rule engine: {_e}")


@app.post("/predict", response_model=YieldPrediction)
def predict(params: ProcessParams):
    if not MOCK:
        return _aml_predict(params)
    if _LOCAL_OK:
        try:
            return YieldPrediction(**_ml.run(params.model_dump()))
        except Exception as exc:
            logger.warning(f"[ML] local yield inference failed — rule fallback: {exc}")
    return _rule_predict(params)


@app.get("/thresholds")
def thresholds():
    return {
        "ml_thresholds": list_thresholds('yield'),
        "targets_from_yield_params_csv": _get_targets(),
    }
