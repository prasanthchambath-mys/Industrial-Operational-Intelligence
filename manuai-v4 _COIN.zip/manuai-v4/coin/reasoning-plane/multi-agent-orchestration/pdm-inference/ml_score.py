#!/usr/bin/env python3
"""
ManuAI — PdM Model Scoring Entry Point (Azure ML compatible)
=============================================================

This is the scoring script an Azure ML managed endpoint runs. It matches the
contract the pdm-inference service expects, so wiring is just:

    AML_PDM_ENDPOINT=https://<your-aml-endpoint>/score
    AML_API_KEY=<key>

The pdm-inference service (coin/reasoning-plane/multi-agent-orchestration/pdm-inference/main.py) POSTs a feature
vector here and gets back {failure_prob, rul_days, top_features, ...}. On any
error it falls back to its rule engine — so a cold endpoint never takes down
production.

Local test:
    python score.py --selftest
"""

import os
import json
import joblib
import numpy as np
from pathlib import Path

_MODEL = None
_FEATURES = None

# Failure-mode thresholds (mirror ml_thresholds.csv pdm.failure_modes)
BEARING_VIB_MIN, BEARING_TEMP_MIN = 5.0, 25.0
OVERTEMP_MIN, SEAL_LEAK_PVAR_MIN  = 35.0, 0.5
AMBIENT_TEMP = 30.0


def init():
    """Azure ML calls this once on container start."""
    global _MODEL, _FEATURES
    model_path = os.getenv("AZUREML_MODEL_DIR")
    if model_path:
        candidate = Path(model_path) / "pdm_model.joblib"
    else:
        candidate = Path(__file__).parent / "pdm_model.joblib"
    bundle = joblib.load(candidate)
    _MODEL = bundle
    _FEATURES = bundle["features"]


def _failure_mode(vib, temp, pvar):
    td = temp - AMBIENT_TEMP
    if pvar >= SEAL_LEAK_PVAR_MIN:        return "seal_leak"
    if td >= OVERTEMP_MIN and vib < BEARING_VIB_MIN: return "overtemperature"
    if vib >= BEARING_VIB_MIN and td >= BEARING_TEMP_MIN: return "bearing_wear"
    if vib >= BEARING_VIB_MIN:            return "imbalance"
    return "bearing_wear"


def _featurize(rec):
    """Accept the pdm-inference SensorFeatures shape, fill missing with defaults."""
    return [
        float(rec.get("vibration_mm_s", rec.get("vib", 3.0))),
        float(rec.get("temperature_c",  rec.get("temp", 60.0))),
        float(rec.get("temp_delta_c",   rec.get("temperature_c", 60.0) - AMBIENT_TEMP if "temperature_c" in rec else 30.0)),
        float(rec.get("pressure_bar",   rec.get("pressure", 8.0))),
        float(rec.get("pressure_variance", 0.1)),
        float(rec.get("run_hours", 2000.0)),
        float(rec.get("health_score", rec.get("health", 80.0))),
        float(rec.get("degrade_rate", 0.05)),
    ]


def run(raw_data):
    """
    Azure ML calls this per request. raw_data is a JSON string or dict.
    Accepts a single record or {"records": [...]}.
    Returns scoring result(s) matching the PdM service contract.
    """
    if _MODEL is None:
        init()

    data = json.loads(raw_data) if isinstance(raw_data, str) else raw_data
    records = data.get("records") if isinstance(data, dict) and "records" in data else [data]

    rul_model = _MODEL["rul_model"]
    clf_model = _MODEL["clf_model"]

    out = []
    for rec in records:
        feats = _featurize(rec)
        X = np.array([feats], dtype=float)
        rul_days = float(np.clip(rul_model.predict(X)[0], 0, 200))
        fail_prob = float(clf_model.predict_proba(X)[:, 1][0])

        # 90% CI from configured multipliers
        rul_low, rul_high = round(rul_days * 0.75, 1), round(rul_days * 1.25, 1)

        # Top contributing features for explainability
        importances = rul_model.feature_importances_
        ranked = sorted(zip(_FEATURES, importances), key=lambda kv: kv[1], reverse=True)
        top = [{"feature": k, "weight": round(float(v), 3)} for k, v in ranked[:3]]

        mode = _failure_mode(feats[0], feats[1], feats[4])

        # Action band (matches pdm.rul_thresholds)
        if rul_days <= 7:    action = "CRITICAL"
        elif rul_days <= 14: action = "URGENT"
        elif rul_days <= 30: action = "PLAN"
        else:                action = "MONITOR"

        out.append({
            "rul_days": round(rul_days, 1),
            "rul_ci_low": rul_low,
            "rul_ci_high": rul_high,
            "failure_prob": round(fail_prob, 4),
            "failure_mode": mode,
            "action": action,
            "top_features": top,
            "model_source": _MODEL.get("version", "baseline-synthetic-v1"),
        })

    return out[0] if len(out) == 1 else {"results": out}


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        init()
        # Healthy machine
        healthy = run({"vibration_mm_s": 2.1, "temperature_c": 58, "pressure_bar": 8.0,
                       "pressure_variance": 0.05, "run_hours": 1200, "health_score": 88, "degrade_rate": 0.04})
        # Failing machine (like MCH-03)
        failing = run({"vibration_mm_s": 9.1, "temperature_c": 92, "pressure_bar": 11.8,
                       "pressure_variance": 0.6, "run_hours": 7800, "health_score": 17, "degrade_rate": 0.28})
        print("HEALTHY :", json.dumps(healthy))
        print("FAILING :", json.dumps(failing))
