import httpx
"""
ManuAI — Energy Optimiser Service  v2.0
Load dispatch engine: analyses plant energy profile and recommends
demand-response actions to reduce peak kW and kWh/unit cost.

Mock mode uses rule-based load analysis.
Live mode: set AML_ENERGY_ENDPOINT to call the Azure ML scoring endpoint.
"""

import os, math, random, logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from ml_thresholds import get_threshold, list_thresholds
from service_health import register_health

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Energy Optimiser", version="2.0.0")
register_health(app, "energy-optimizer", required_files=["ml_thresholds.csv"], model_file="energy_model.joblib")

MOCK = not bool(os.getenv("AML_ENERGY_ENDPOINT"))
if MOCK:
    logger.warning("AML_ENERGY_ENDPOINT not set — energy optimiser running in mock/rule mode")


# ── Models ────────────────────────────────────────────────────────────────────

class AssetLoad(BaseModel):
    asset_id: str
    name: str
    kw_current: float
    kw_rated: float
    load_factor: float        # 0–1
    shiftable: bool           # can load be shifted off-peak?
    critical: bool            # must not interrupt production
    tariff_peak: bool         # currently in peak tariff window?

class EnergyInput(BaseModel):
    plant_kw_total: float
    peak_demand_limit_kw: float   # contractual limit
    grid_carbon_g_per_kwh: float  # current grid intensity
    units_produced_today: int
    shift: str                    # "day" | "evening" | "night"
    assets: List[AssetLoad]

class DispatchAction(BaseModel):
    asset_id: str
    asset_name: str
    action: str               # "reduce_speed" | "defer_start" | "shift_off_peak" | "shutdown_idle"
    kw_saving: float
    kwh_saving_today: float
    cost_saving_inr: float
    carbon_saving_kg: float
    risk: str                 # "none" | "low" | "medium"
    reason: str

class EnergyPrediction(BaseModel):
    plant_kw_current: float
    plant_kw_optimised: float
    kwh_per_unit_current: float
    kwh_per_unit_optimised: float
    carbon_intensity_current: float
    carbon_intensity_optimised: float
    peak_breach_risk: bool
    actions: List[DispatchAction]
    total_kw_saving: float
    total_cost_saving_inr: float
    total_carbon_saving_kg: float
    model_source: str


def _tariff_peak()    -> float: return get_threshold('energy', 'tariff', 'peak_inr_per_kwh',     12.0)
def _tariff_offpeak() -> float: return get_threshold('energy', 'tariff', 'off_peak_inr_per_kwh',  6.5)
def _carbon_factor()  -> float: return get_threshold('energy', 'carbon', 'grid_factor_kgco2_per_kwh', 0.82)


def _rule_dispatch(inp: EnergyInput) -> EnergyPrediction:
    actions: List[DispatchAction] = []
    total_saving_kw = 0.0

    for a in inp.assets:
        if a.critical:
            continue

        saving_kw = 0.0
        action_type = ""
        reason = ""
        risk = "none"

        if a.load_factor < 0.25 and a.kw_current > 20:
            # Idle phantom load
            saving_kw = a.kw_current * 0.85
            action_type = "shutdown_idle"
            reason = f"Load factor {a.load_factor:.0%} — asset appears idle; phantom load detected."
            risk = "low"
        elif a.tariff_peak and a.shiftable and a.kw_current > 30:
            # Shift to off-peak
            saving_kw = a.kw_current * 0.0  # no kW saving but cost saving
            kwh_today = a.kw_current * 4     # 4h remaining in shift
            cost_saving = kwh_today * (_tariff_peak() - _tariff_offpeak())
            action_type = "shift_off_peak"
            reason = "Peak tariff window active — defer to night shift for ₹{:.0f} saving.".format(cost_saving)
            risk = "low"
        elif inp.plant_kw_total > inp.peak_demand_limit_kw * 0.92 and a.load_factor > 0.7:
            # Near peak demand limit — reduce non-critical loads
            saving_kw = a.kw_current * 0.15
            action_type = "reduce_speed"
            reason = "Plant approaching peak demand limit ({:.0f}/{:.0f} kW); throttle 15%.".format(
                inp.plant_kw_total, inp.peak_demand_limit_kw)
            risk = "medium"

        if not action_type:
            continue

        kwh_saving = saving_kw * 6  # 6-hour horizon
        cost_saving = kwh_saving * (_tariff_peak() if a.tariff_peak else _tariff_offpeak())
        carbon_saving = kwh_saving * inp.grid_carbon_g_per_kwh / 1000

        actions.append(DispatchAction(
            asset_id=a.asset_id,
            asset_name=a.name,
            action=action_type,
            kw_saving=round(saving_kw, 1),
            kwh_saving_today=round(kwh_saving, 1),
            cost_saving_inr=round(cost_saving, 0),
            carbon_saving_kg=round(carbon_saving, 2),
            risk=risk,
            reason=reason,
        ))
        total_saving_kw += saving_kw

    actions.sort(key=lambda x: -x.cost_saving_inr)

    opt_kw = inp.plant_kw_total - total_saving_kw
    units = max(inp.units_produced_today, 1)

    kwh_curr = inp.plant_kw_total / units if units else 0
    kwh_opt  = opt_kw / units if units else 0
    ci_curr  = kwh_curr * _carbon_factor()
    ci_opt   = kwh_opt  * _carbon_factor()

    return EnergyPrediction(
        plant_kw_current=round(inp.plant_kw_total, 1),
        plant_kw_optimised=round(opt_kw, 1),
        kwh_per_unit_current=round(kwh_curr, 3),
        kwh_per_unit_optimised=round(kwh_opt, 3),
        carbon_intensity_current=round(ci_curr, 3),
        carbon_intensity_optimised=round(ci_opt, 3),
        peak_breach_risk=inp.plant_kw_total > inp.peak_demand_limit_kw * 0.90,
        actions=actions,
        total_kw_saving=round(total_saving_kw, 1),
        total_cost_saving_inr=round(sum(a.cost_saving_inr for a in actions), 0),
        total_carbon_saving_kg=round(sum(a.carbon_saving_kg for a in actions), 2),
        model_source="rule_engine",
    )


_AML_ENDPOINT = os.getenv("AML_ENERGY_ENDPOINT", "")
_AML_KEY      = os.getenv("AML_API_KEY", "")

def _aml_dispatch(inp: EnergyInput) -> EnergyPrediction:
    """Call Azure ML scoring endpoint. Falls back to rule engine on any error."""
    headers = {"Content-Type": "application/json"}
    if _AML_KEY:
        headers["Authorization"] = f"Bearer {_AML_KEY}"
    try:
        resp = httpx.post(_AML_ENDPOINT, json=inp.model_dump(), headers=headers, timeout=10.0)
        resp.raise_for_status()
        return EnergyPrediction(**resp.json())
    except Exception as exc:
        logger.warning(f"AML energy endpoint error — falling back to rule engine: {exc}")
        result = _rule_dispatch(inp)
        return result.model_copy(update={"model_source": f"rule_engine_fallback:{type(exc).__name__}"})


# ── Local in-process model serving (ML_LOCAL=true) ───────────────────────────
ML_LOCAL = os.getenv("ML_LOCAL", "").lower() in ("1", "true", "yes")
_LOCAL_OK = False
_ml = None
if ML_LOCAL:
    try:
        import ml_score as _ml  # copied from coin/runtime-plane/ai-workflows/energy/score.py at build time
        _ml.init()
        _LOCAL_OK = True
        logger.info("[ML] energy local model loaded — serving in-process")
    except Exception as _e:
        logger.warning(f"[ML] energy local model unavailable, using rule engine: {_e}")


@app.post("/dispatch", response_model=EnergyPrediction)
def dispatch(inp: EnergyInput):
    if not MOCK:
        return _aml_dispatch(inp)
    if _LOCAL_OK:
        try:
            return EnergyPrediction(**_ml.run(inp.model_dump()))
        except Exception as exc:
            logger.warning(f"[ML] local energy inference failed — rule fallback: {exc}")
    return _rule_dispatch(inp)


@app.get("/thresholds")
def thresholds():
    return list_thresholds('energy')
