# Migration / retrofit log

This solution was retrofitted onto the CoIN one-repository standard by the
coin-retrofit skill from an existing codebase at
`C:\Users\bhagyashree.borkar\Documents\Projects\Enterprise - Solutions\manuai-v4`
(in place) on 2026-09-25. Code that could not be physically moved into `coin/`
yet is declared in `solution.yaml` as `status: activated` with a pointer
rationale, and tracked here until it moves.

## What moved

| Component | From | To | Rewired |
|-----------|------|----|---------|
| Decision Apps | `apps/web/` | `coin/experience-plane/decision-apps/` | `docker-compose.yml`, `docker-compose.azure-sim.yml` (context + `dockerfile: ../../../infra/...`), `.github/workflows/ci.yml` (9 refs incl. SWA `app_location`), `.github/workflows/docker-publish.yml`, `deploy-azure.sh`, `infra/azure/phase-a/scripts/build-and-push-images.{sh,ps1}`, root `package.json` scripts |
| Multi-Agent Orchestration (the 7 agent services + `ml_thresholds.py`) | `services/` | `coin/reasoning-plane/multi-agent-orchestration/<agent>/` | Both compose files (context + `dockerfile: ../../../../infra/...`), `docker-publish.yml` matrix context, `deploy-azure.sh`, `build-and-push-images.{sh,ps1}`, path comments in `apps/api/src/routes/all-routes.ts` |
| AI Workflows (pdm, yield, energy, supply) | `ml/` | `coin/runtime-plane/ai-workflows/<model>/` | Repo-root resolution `Path(__file__).resolve().parents[2]` → `parents[4]` in 6 places (`*/generate_training_data.py`, `yield/score.py`, `yield/train_yield_model.py`), path comments in the agents' `main.py` / `ml_score.py` |

Verified after the move: all 14 compose build entries resolve (context + Dockerfile);
all 7 agents boot from their new folders and return 200 on `/health` and `/ready`;
all 4 `score.py --selftest` runs pass; generator repo-root paths resolve to `data/csv/`.
The web app could not be `npm run build` on the retrofit machine (no Node.js
installed); it has no relative paths reaching outside its folder, so run
`npm run build --prefix coin/experience-plane/decision-apps` once to confirm.

## Pointer model

An asset that cannot move into `coin/<plane>-plane/<component>/...` yet
(tightly coupled to surrounding app code, lives in a client environment,
or belongs to another repo/system you don't control) is still declared in
`solution.yaml` with `status: activated` and a rationale that says where
it actually lives and why it hasn't moved. Every row below must have a
target date or explicit "no target — permanent pointer" — silent debt is
not allowed.

**Shared blocker for every `apps/api/src/**` row (checked, not assumed):** the API is one
TypeScript deployable built by `tsc` with `rootDir: ./src` into `dist/`
(`infra/docker/Dockerfile.api` copies only `apps/api/src`; `package.json` `main` and the
image `CMD` are `dist/index.js`). A `.ts` file under `coin/` cannot be compiled into that
`dist/` without (a) widening `rootDir`, which changes the output layout and breaks `main`,
the image `CMD` and the three `__dirname`-relative data paths (`csv-loader.ts`,
`connection.ts`, `governance-runtime.ts`), or (b) a runtime path-alias layer: emitted
`require()`s aren't rewritten by `tsc` `paths`, and `ts-node-dev` can't resolve
`node_modules` from `coin/`. Unlike the Python agents and the web app, this is a build
change, not a mechanical rewire, so it is logged as one migration step (row 0) that
unblocks the rest.

| Date | Component | Currently lives at | Reason not yet moved | Target |
|------|-----------|---------------------|-----------------------|--------|
| 2026-09-25 | *(enabler — row 0)* | `apps/api/tsconfig.json`, `infra/docker/Dockerfile.api`, `.github/workflows/ci.yml` (`build-api` context `./apps/api`) | Build cannot yet compile TS from `coin/` (see above) | Next sprint: bundle the API with esbuild/tsup (or `tsconfig-paths` at runtime), widen Docker context to repo root, then move rows below starting with Connectors |
| 2026-09-25 | Connectors | `apps/api/src/connectors/` (pi-historian, sap-odata, iot-hub, opc-ua, lims) | TS build blocker only; 2–4 importers each — small rewire once row 0 lands | First move after row 0 |
| 2026-09-25 | Live Capture | `apps/api/src/connectors/iot-hub.ts` | TS build blocker; 3 importers | Moves out of `connectors/` with the Connectors move |
| 2026-09-25 | Data Dispatch | `apps/api/src/connectors/opc-ua.ts`, `sap-odata.ts` write paths; routes `yield.ts` (`/dcs-write`), `pdm.ts` | Write-back shares its client with the read-side connectors; split after Connectors move | After Connectors |
| 2026-09-25 | AI Engine | `apps/api/src/ai/llm-client.ts` | TS build blocker; 1 importer, but it imports `semantic/governance-runtime` (`agentPrompt`) | With row 0 + Prompt Registry |
| 2026-09-25 | Prompt Registry | `AGENT_PROMPTS` in `apps/api/src/ai/llm-client.ts`; `agentPrompt()` in `apps/api/src/semantic/governance-runtime.ts`; DB table `semantic_prompt_template` (DDL not in this repo) | TS build blocker; the prompts are inline in the LLM client | Pull prompts into a data file under `coin/reasoning-plane/prompt-registry/` after row 0 |
| 2026-09-25 | Retrieval (RAG) | `apps/api/src/ai/ai-context-builder.ts`, `ai/semantic-history.ts` | TS build blocker; context builder imports 9 API modules (db-queries, csv-loader, simulation, resolver…) | After Connectors / Semantic Model |
| 2026-09-25 | Conversation | `POST /api/ai/chat` in `apps/api/src/routes/all-routes.ts` (2,017-line multi-router file) | Route is one block in a file shared by 8 routers; needs `aiRouter` split out first | After row 0; split `aiRouter` into its own file |
| 2026-09-25 | Multi-Agent Orchestration (coordinator half) | `apps/api/src/semantic/service.ts` (10 importers), `apps/api/src/orchestration/scenario-engine.ts` (2) | TS build blocker. The agents themselves moved | After row 0 |
| 2026-09-25 | Semantic Model | `apps/api/src/semantic/resolver.ts` (6 importers), `semantic/live-sources.ts` | TS build blocker | After row 0 |
| 2026-09-25 | Business Codex | `data/csv/semantic_kpi_definitions.csv`, `data/csv/conflict_rules.csv` | `data/csv/` is one seed folder read by the API image (`COPY data/csv`), 7 compose volume mounts, `CSV_DATA_DIR` defaults in 3 TS files and every agent's `ml_thresholds.py`; per-file split would fork the seed set | Permanent-ish: keep `data/csv` as the seed store; revisit if the codex moves to DB-only authoring |
| 2026-09-25 | Synthetic Data | `apps/api/src/simulation/engine.ts` (12 importers), `data/csv/*` seeds | TS build blocker and 12 importers (routes, KPI engine, scenario engine, AI context) | After row 0 |
| 2026-09-25 | Knowledge Graph | `coin/reasoning-plane/multi-agent-orchestration/twin-sync/twin_topology.py`; `apps/api/src/data/plant.ts` (18 importers) | `twin_topology.py` is imported by `twin-sync/main.py` and must stay inside that image's build context; `plant.ts` has 18 importers | No target — permanent pointer for the Python half; revisit `plant.ts` after row 0 |
| 2026-09-25 | Refinery | `apps/api/src/kpi/engine.ts` (4 importers); `semantic_refresh()` SQL in `database/schema.ts` | TS build blocker | After row 0 |
| 2026-09-25 | Data Ingestion | `apps/api/src/data/csv-loader.ts` (26 importers), `database/seed-*.ts`, `ingestion/index.ts` | 26 importers: the loader is threaded through most of the API | After row 0, as its own step |
| 2026-09-25 | Operational Store | `apps/api/src/database/connection.ts` (26 importers), `schema.ts`; `infra/azure/phase-a/modules/{postgres,redis}.bicep` | 26 importers; Bicep modules are referenced relatively by `main.bicep` | No target — permanent pointer for the Bicep half; TS half after row 0 |
| 2026-09-25 | Signals | `apps/api/src/simulation/engine.ts`, `database/writer.ts` (`writeAlertToDB`), `websocket/broadcaster.ts` (10 importers), `routes/oee.ts` | Logic is spread across the simulator, the writer and the broadcaster, with no single module | After row 0: extract an alert service first |
| 2026-09-25 | Orchestration | `startSemanticScheduler()` in `apps/api/src/semantic/governance-runtime.ts`; timers in `simulation/engine.ts`, `kpi/engine.ts` | In-process timers inside the API; no standalone scheduler to move | Revisit if jobs move to Container Apps Jobs / an external scheduler |
| 2026-09-25 | Compute | `infra/azure/phase-a/` (main.bicep + modules/container-apps.bicep), `infra/docker/Dockerfile.*` | `phase-a/` is one IaC deployment unit spanning Compute, Network, Security, Access, Observability and Operational Store; `main.bicep` references `modules/` relatively and its 7 scripts, 4 runbooks and README reference `phase-a` paths. The Dockerfiles are referenced by 2 compose files, 2 workflows and 3 scripts | No target — permanent pointer (IaC stays one deployable) |
| 2026-09-25 | Network | `coin/experience-plane/decision-apps/nginx.conf.template` (moved with the web image); ingress in `infra/azure/phase-a/modules/container-apps.bicep` | nginx template must stay in the web build context (`COPY nginx.conf.template`); ingress is part of the Bicep unit | No target — permanent pointer |
| 2026-09-25 | Security | `helmet` / `express-rate-limit` in `apps/api/src/index.ts`; `infra/azure/phase-a/modules/{keyvault,identity}.bicep` | Middleware is registered in the API entrypoint; Bicep is part of the IaC unit | No target — permanent pointer |
| 2026-09-25 | Access Fabric | `apps/api/src/middleware/auth.ts` (7 importers) | TS build blocker; imported by `index.ts` + 6 route files (`requireRole()` gates) | After row 0 |
| 2026-09-25 | Observability | `apps/api/src/middleware/logger.ts` (33 importers), `routes/health.ts`, `startup-state.ts`; `infra/azure/phase-a/modules/monitoring.bicep`; per-agent `service_health.py` | 33 importers (almost every API file); `service_health.py` must stay in each agent's build context | Logger: no target — permanent pointer; health routes after row 0 |
| 2026-09-25 | AI DevOps | `.github/workflows/ci.yml`, `.github/workflows/docker-publish.yml` | GitHub requires workflows under `.github/workflows/` | No target — permanent pointer |

## Retrofit mapping notes

- **"9 AI agents" vs 7 services.** The product's agents are OEE, Yield, PdM, Quality,
  Energy, Supply, Twin, Safety and the Semantic layer. Seven have a Python service
  (moved into Multi-Agent Orchestration). OEE is computed in the API
  (`routes/oee.ts`, `kpi/engine.ts`), and the Semantic layer *is* the coordinator
  (still a pointer).
- **Multi-Agent Orchestration is split.** The agents moved; their coordinator (conflict
  rules + degradation cascade) did not. Both halves belong to the same component.
- **Explainability is embedded, not separate.** Reasons and feature weights are
  returned by each agent / `score.py`; there is no standalone explainability module
  to move, so its code stays inside the moved agents and pipelines.
- **`ml_thresholds.py` / `service_health.py` are duplicated per agent on purpose.** Each
  agent image builds from its own folder. The canonical `ml_thresholds.py` now sits at
  `coin/reasoning-plane/multi-agent-orchestration/ml_thresholds.py`.
- **Model handoff is manual.** `coin/runtime-plane/ai-workflows/<model>/score.py` and
  `*_model.joblib` are copied by hand into the matching agent as `ml_score.py`, which is why
  Model Registry is `not-applicable`.
- **Industry.** Set to `manufacturing` (process plants: reactors, DCS, SAP PP/PM/MM/QM).
  The template's enum comment has no manufacturing value.
- **Pre-retrofit snapshot.** The repo is not under git; a tarball of the pre-retrofit
  tree (without node_modules) was written to the retrofit session's scratchpad. Initialise
  git before the row-0 build change.
