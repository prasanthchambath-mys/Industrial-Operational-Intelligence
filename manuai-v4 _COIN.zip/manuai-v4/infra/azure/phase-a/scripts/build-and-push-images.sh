#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# build-and-push-images.sh — Build the 9 service images from the EXISTING
# Dockerfiles (no local Docker file is modified) and push them to ACR.
#
# Build contexts/Dockerfiles mirror docker-compose.yml exactly:
#   web                 context coin/experience-plane/decision-apps              -f infra/docker/Dockerfile.web (VITE_* build args empty)
#   api                 context .                     -f infra/docker/Dockerfile.api
#   <python service>    context coin/reasoning-plane/multi-agent-orchestration/<svc>     -f infra/docker/Dockerfile.python
#
# PREREQUISITES (run yourself):
#   az login
#   Docker daemon running locally
#
# Usage:
#   ./build-and-push-images.sh -g <resource-group> -r <acr-name> -t <image-tag> -e <dev|test|prod>
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../../.." && pwd)"   # infra/azure/phase-a/scripts -> repo root

RESOURCE_GROUP=""
ACR_NAME=""
IMAGE_TAG="latest"
ENV_NAME=""

usage() {
  echo "Usage: $0 -g <resource-group> -r <acr-name> -t <image-tag> -e <dev|test|prod>"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -g|--resource-group) RESOURCE_GROUP="$2"; shift 2;;
    -r|--acr-name)       ACR_NAME="$2"; shift 2;;
    -t|--tag)            IMAGE_TAG="$2"; shift 2;;
    -e|--env)            ENV_NAME="$2"; shift 2;;
    -h|--help)           usage;;
    *) echo "Unknown argument: $1"; usage;;
  esac
done

[[ -z "$RESOURCE_GROUP" || -z "$ACR_NAME" || -z "$ENV_NAME" ]] && usage

command -v az >/dev/null 2>&1 || { echo "ERROR: Azure CLI (az) not found. Run 'az login' first."; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "ERROR: Docker not found. Start Docker and retry."; exit 1; }

LOGIN_SERVER="$(az acr show --name "$ACR_NAME" --resource-group "$RESOURCE_GROUP" --query loginServer -o tsv)"
[[ -z "$LOGIN_SERVER" ]] && { echo "ERROR: could not resolve ACR login server for '$ACR_NAME'."; exit 1; }

echo "==> Logging Docker into ACR '$ACR_NAME' ($LOGIN_SERVER)"
az acr login --name "$ACR_NAME"

cd "$REPO_ROOT"
echo "==> Building from repo root: $REPO_ROOT (tag: $IMAGE_TAG)"

build_push() {
  local image="$1"; local dockerfile="$2"; local context="$3"; shift 3
  local ref="${LOGIN_SERVER}/${image}:${IMAGE_TAG}"
  echo "---- build $ref (ctx=$context, file=$dockerfile)"
  docker build -t "$ref" -f "$dockerfile" "$@" "$context"
  echo "---- push  $ref"
  docker push "$ref"
}

# web (build args empty: nginx proxies /api and /socket.io at runtime via API_UPSTREAM)
build_push "web" "infra/docker/Dockerfile.web" "coin/experience-plane/decision-apps" --build-arg VITE_API_URL= --build-arg VITE_WS_URL=

# api (context = repo root so data/csv is baked for the one-time DB seed)
build_push "api" "infra/docker/Dockerfile.api" "."

# 7 Python services
for svc in pdm-inference yield-optimizer energy-optimizer quality-vision supply-intelligence twin-sync safety-monitor; do
  build_push "$svc" "infra/docker/Dockerfile.python" "coin/reasoning-plane/multi-agent-orchestration/$svc"
done

echo "==> All 9 images built and pushed to $LOGIN_SERVER with tag '$IMAGE_TAG'."
echo "    Re-run deploy (or 'az containerapp update --image') so apps pick up the new tag."
