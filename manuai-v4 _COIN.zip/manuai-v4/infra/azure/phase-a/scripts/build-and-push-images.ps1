<#
.SYNOPSIS
  Build the 9 service images from the EXISTING Dockerfiles and push to ACR.

.DESCRIPTION
  No local Docker file is modified. Build contexts/Dockerfiles mirror
  docker-compose.yml exactly. Run `az login` and have Docker running first.

.EXAMPLE
  ./build-and-push-images.ps1 -ResourceGroup rg-manuai-dev -AcrName manuaidevacrxxxxxx -Tag latest -Env dev
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$ResourceGroup,
  [Parameter(Mandatory = $true)][string]$AcrName,
  [string]$Tag = 'latest',
  [Parameter(Mandatory = $true)][ValidateSet('dev', 'test', 'prod')][string]$Env
)
$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot  = Resolve-Path (Join-Path $scriptDir '../../../..')

if (-not (Get-Command az -ErrorAction SilentlyContinue))     { throw "Azure CLI (az) not found. Run 'az login' first." }
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Docker not found. Start Docker and retry.' }

$loginServer = az acr show --name $AcrName --resource-group $ResourceGroup --query loginServer -o tsv
if ([string]::IsNullOrEmpty($loginServer)) { throw "Could not resolve ACR login server for '$AcrName'." }

Write-Host "==> Logging Docker into ACR '$AcrName' ($loginServer)"
az acr login --name $AcrName

Push-Location $repoRoot
try {
  Write-Host "==> Building from repo root: $repoRoot (tag: $Tag)"

  function Build-Push {
    param([string]$Image, [string]$Dockerfile, [string]$Context, [string[]]$ExtraArgs = @())
    $ref = "$loginServer/${Image}:$Tag"
    Write-Host "---- build $ref (ctx=$Context, file=$Dockerfile)"
    docker build -t $ref -f $Dockerfile @ExtraArgs $Context
    if ($LASTEXITCODE -ne 0) { throw "docker build failed for $Image" }
    Write-Host "---- push  $ref"
    docker push $ref
    if ($LASTEXITCODE -ne 0) { throw "docker push failed for $Image" }
  }

  # web (build args empty: nginx proxies /api and /socket.io at runtime via API_UPSTREAM)
  Build-Push -Image 'web' -Dockerfile 'infra/docker/Dockerfile.web' -Context 'coin/experience-plane/decision-apps' `
    -ExtraArgs @('--build-arg', 'VITE_API_URL=', '--build-arg', 'VITE_WS_URL=')

  # api (context = repo root so data/csv is baked for the one-time DB seed)
  Build-Push -Image 'api' -Dockerfile 'infra/docker/Dockerfile.api' -Context '.'

  # 7 Python services
  foreach ($svc in @('pdm-inference', 'yield-optimizer', 'energy-optimizer', 'quality-vision', 'supply-intelligence', 'twin-sync', 'safety-monitor')) {
    Build-Push -Image $svc -Dockerfile 'infra/docker/Dockerfile.python' -Context "coin/reasoning-plane/multi-agent-orchestration/$svc"
  }

  Write-Host "==> All 9 images built and pushed to $loginServer with tag '$Tag'."
  Write-Host "    Re-run deploy (or 'az containerapp update --image') so apps pick up the new tag."
}
finally {
  Pop-Location
}
