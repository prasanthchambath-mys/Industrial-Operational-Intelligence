# RUL Trend — Browser Console Debug (no terminal needed)

Open the dashboard in your browser, press **F12** → **Console** tab, paste each block, hit Enter.
This tells us EXACTLY where the break is, in 30 seconds, without Docker access.

---

## CHECK 1 — Is the new API build deployed?
Paste this:

```js
fetch('/api/history/pdm/health-daily/MCH-06?days=14')
  .then(r => r.json())
  .then(d => console.log('BUILD:', d.build, '| POINTS:', d.points, '| rows:', (d.data||[]).length, d.data))
  .catch(e => console.log('ERROR (endpoint missing = stale API):', e));
```

**Interpret:**
- `BUILD: V75-daily-trend POINTS: 15` and 15 rows → **new API is live.** Go to CHECK 2.
- `BUILD: undefined` or 404/ERROR → **API container is STALE.** The rebuild didn't take. See FIX A.
- `POINTS: 1` (one row) → DB has only one day of data. See FIX C.

---

## CHECK 2 — Is the frontend bundle new, or cached?
Paste this:

```js
console.log('fetchRulTrend source check — look for "health-daily" below:');
console.log(window.location.href);
// Force a fresh fetch the way the app does:
Promise.all(['MCH-06','MCH-03'].map(id =>
  fetch(`/api/history/pdm/health-daily/${id}?days=14`).then(r=>r.json())
)).then(([a,b]) =>
  console.log('MCH-06 days:', (a.data||[]).map(r=>r.day), '\nMCH-03 days:', (b.data||[]).map(r=>r.day))
);
```

**Interpret:**
- You see ~15 dates listed (06-08 … 06-22) → backend is feeding the chart correctly.
  If the chart STILL shows dots, the **web bundle is cached** → see FIX B.
- You see 1 date → backend issue, go back to CHECK 1.

---

## CHECK 3 — What is the chart actually receiving?
With the PdM page open, paste:

```js
// Grab the React props off the chart's data — quick visual:
fetch('/api/pdm/assets?plant=All%20Plants').then(r=>r.json()).then(a=>{
  const all=[...(a.assets||[]),...(a.utilityAssets||[])].sort((x,y)=>x.rul-y.rul);
  console.log('Top-3 at-risk the chart requests:', all.slice(0,3).map(m=>`${m.id}=${m.name}(rul ${m.rul})`));
});
```

This confirms which 3 machine IDs the chart pulls. They must be IDs that exist in `machine_health`.

---

# FIXES

## FIX A — API container is stale (CHECK 1 showed no build marker)
The api image was not rebuilt from new source. Run on the Docker host:
```
docker compose down -v
docker compose build --no-cache api web
docker compose up -d
```
Then re-run CHECK 1. The `--no-cache` is mandatory; without it Docker reuses the
old compiled `dist/`. `down -v` removes any persisted DB volume.

If it STILL shows no marker after this, the image being run is not the one being
built — check you're in the right directory (D:\Project\17-June-2026\manuai-v4)
and that docker-compose.yml `build:` points at infra/docker/Dockerfile.api, not
a prebuilt `image:` tag.

## FIX B — Web bundle is cached (CHECK 1 ✓ but chart still dots)
The browser or nginx served the old JS bundle.
1. Hard refresh: **Ctrl+Shift+R** (or open in an Incognito window).
2. If still stale: `docker compose build --no-cache web && docker compose up -d web`
3. Confirm in DevTools → Network → the main `index-*.js` is freshly downloaded (200, not 304/disk cache).

## FIX C — DB only has one day (CHECK 1 showed POINTS: 1)
A stale SQLite DB survived, or history never seeded.
```
docker compose down -v      # the -v drops the DB volume
docker compose up -d         # history reseeds 30 days on boot
```
Watch the api logs for: `[DB] Seeding 30 days of history...`
If you instead see `[DB] Historical data already present — skipping seed`,
the old DB is still mounted — confirm no named volume is persisting /app/data.
