"""
ManuAI — shared service health / readiness / version endpoints (Phase A).

Adds three operational endpoints to a FastAPI app WITHOUT touching any
prediction or business logic:

  GET /health   Liveness. 200 if the process is up. Never touches DB, Azure,
                OpenAI, Redis, or model files.
  GET /ready    Readiness. 200 only when required LOCAL files/config are present.
                For Phase A it does NOT require Azure ML, live connectors, or
                Postgres. DATA_SOURCE=db is surfaced honestly as "not implemented
                yet" (503) — we never pretend db mode is ready.
  GET /version  Service name, version tag, and APP_ENV.

Environment (all optional; safe local-Docker defaults):
  APP_ENV         local-docker | azure-sim | azure-phase-a   (default local-docker)
  DATA_SOURCE     csv | db                                    (default csv)
  CSV_DATA_DIR    dir holding required CSVs                    (default /app/data/csv)
  ML_LOCAL        true|false  in-process joblib serving        (default false)
  AML_ENABLED     true|false  Azure ML scoring                 (default false)
  SERVICE_VERSION free-text build/version tag                  (default phase-a-ready)

This module is intentionally dependency-free beyond FastAPI (already required by
every service) and is duplicated per-service dir, mirroring ml_thresholds.py,
because each service image is built from its own build context.
"""
import os
from datetime import datetime, timezone

from fastapi import FastAPI
from fastapi.responses import JSONResponse


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _bool_env(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def register_health(app: FastAPI, service: str, required_files=None,
                    model_file: str = None, rule_engine: bool = True) -> None:
    """Register /health, /ready, /version on `app`.

    required_files : filenames expected inside CSV_DATA_DIR when DATA_SOURCE=csv.
    model_file     : optional joblib filename in the service dir; only checked
                     when ML_LOCAL=true (Phase E). Ignored in Phase A defaults.
    """
    required_files = list(required_files) if required_files else ["ml_thresholds.csv"]
    service_dir = os.path.dirname(os.path.abspath(__file__))

    @app.get("/health")
    def health():
        # Pure liveness — must not depend on DB / Azure / Redis / models.
        return {"status": "live", "service": service, "timestamp": _now()}

    @app.get("/version")
    def version():
        return {
            "service": service,
            "version": os.getenv("SERVICE_VERSION") or "phase-a-ready",
            "appEnv": os.getenv("APP_ENV", "local-docker"),
            "timestamp": _now(),
        }

    @app.get("/ready")
    def ready():
        data_source = (os.getenv("DATA_SOURCE", "csv") or "csv").strip().lower()
        csv_dir = os.getenv("CSV_DATA_DIR", "/app/data/csv")
        ml_local = _bool_env("ML_LOCAL", False)
        base = {
            "service": service,
            "dataSource": data_source,
            "mlLocal": ml_local,
            "amlEnabled": _bool_env("AML_ENABLED", False),
            "ruleEngine": rule_engine,
            "timestamp": _now(),
        }

        # DB mode is surfaced but not implemented yet — never pretend it is ready.
        if data_source == "db":
            return JSONResponse(status_code=503, content={
                **base,
                "status": "not_ready",
                "requiredFiles": {"status": "skipped", "reason": "db mode"},
                "reason": "DATA_SOURCE=db is not implemented yet for this service",
            })

        # CSV mode: verify required local config/data files exist.
        missing = [f for f in required_files
                   if not os.path.isfile(os.path.join(csv_dir, f))]

        # Local-ML model is only required when ML_LOCAL=true (Phase E). Phase A
        # default (ML_LOCAL=false) serves via the rule engine, so it is optional.
        if ml_local and model_file and not os.path.isfile(os.path.join(service_dir, model_file)):
            missing.append(model_file + " (ML_LOCAL=true)")

        if missing:
            return JSONResponse(status_code=503, content={
                **base,
                "status": "not_ready",
                "requiredFiles": {"status": "missing", "dir": csv_dir, "missing": missing},
            })

        return {
            **base,
            "status": "ready",
            "requiredFiles": {"status": "ok", "dir": csv_dir, "checked": required_files},
        }
