"""
ManuAI — shared ML threshold loader.

Every Python ML service imports this module to fetch its tuning constants from
data/csv/ml_thresholds.csv. This replaces the dozens of hardcoded numbers that
were previously scattered across services/*/main.py.

Usage:
    from ml_thresholds import get_threshold, get_category

    # Single value
    health_critical = get_threshold('pdm', 'rul_thresholds', 'critical_days', 7)

    # Whole category as dict
    iso = get_category('pdm', 'vibration_iso10816')
    # → {'good_max': 2.3, 'satisfactory_max': 4.5, 'unsatisfactory_max': 7.1}

Resolution order:
    1. Environment variable override: ML_<SERVICE>_<CATEGORY>_<KEY>=<value>
       e.g. ML_PDM_RUL_THRESHOLDS_CRITICAL_DAYS=5
    2. ml_thresholds.csv at CSV_DATA_DIR (default /app/data/csv)
    3. Hardcoded fallback supplied by caller

The CSV is reloaded only at process start. Calling reload() forces a re-read.
"""
import csv
import os
import threading
from typing import Dict, Optional, Any

_LOCK = threading.Lock()
_CACHE: Optional[Dict[str, Dict[str, Dict[str, float]]]] = None

_CSV_DIR = os.environ.get('CSV_DATA_DIR', '/app/data/csv')
_CSV_PATH = os.path.join(_CSV_DIR, 'ml_thresholds.csv')


def _coerce_number(raw: str) -> Any:
    """Try to coerce a CSV string to a number; return original string if not numeric."""
    if raw is None or raw == '':
        return None
    try:
        if '.' in raw or 'e' in raw.lower():
            return float(raw)
        return int(raw)
    except (ValueError, TypeError):
        return raw


def _load() -> Dict[str, Dict[str, Dict[str, Any]]]:
    """Read ml_thresholds.csv into nested dict: {service: {category: {key: value}}}."""
    table: Dict[str, Dict[str, Dict[str, Any]]] = {}
    try:
        with open(_CSV_PATH, newline='', encoding='utf-8') as f:
            for row in csv.DictReader(f):
                svc = (row.get('service') or '').strip()
                cat = (row.get('category') or '').strip()
                key = (row.get('key') or '').strip()
                val = _coerce_number((row.get('value') or '').strip())
                if not (svc and cat and key) or val is None:
                    continue
                table.setdefault(svc, {}).setdefault(cat, {})[key] = val
    except FileNotFoundError:
        # CSV not mounted — every lookup will fall back to its default
        pass
    except Exception as e:
        # Any other parse issue: log to stderr but don't crash the service
        import sys
        print(f'[ml_thresholds] warning: failed to load {_CSV_PATH}: {e}', file=sys.stderr)
    return table


def _ensure_loaded():
    global _CACHE
    if _CACHE is None:
        with _LOCK:
            if _CACHE is None:
                _CACHE = _load()


def reload() -> None:
    """Force a re-read of ml_thresholds.csv on next get_threshold() call."""
    global _CACHE
    with _LOCK:
        _CACHE = None


def get_threshold(service: str, category: str, key: str, default: Any) -> Any:
    """
    Retrieve a single threshold value.

    Args:
        service: 'pdm' | 'yield' | 'quality' | 'safety' | 'energy' | 'supply' | 'twin' | 'sim_engine'
        category: subgroup within the service (e.g. 'vibration_iso10816')
        key: the named constant (e.g. 'good_max')
        default: fallback value if not found in CSV or env

    Returns:
        The CSV value, env override, or default — in that priority order.
    """
    # 1. Env override (highest priority — lets you tune per-deployment without CSV edit)
    env_var = f'ML_{service.upper()}_{category.upper()}_{key.upper()}'
    env_val = os.environ.get(env_var)
    if env_val is not None:
        coerced = _coerce_number(env_val)
        return coerced if coerced is not None else default

    # 2. CSV lookup
    _ensure_loaded()
    if _CACHE is not None:
        try:
            return _CACHE[service][category][key]
        except KeyError:
            pass

    # 3. Hardcoded fallback
    return default


def get_category(service: str, category: str, defaults: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Retrieve a whole category as a dict. Caller-supplied defaults fill any
    missing keys so services don't crash if the CSV row is removed.
    """
    defaults = defaults or {}
    _ensure_loaded()
    out = dict(defaults)
    if _CACHE is not None:
        out.update(_CACHE.get(service, {}).get(category, {}))
    return out


def list_thresholds(service: Optional[str] = None) -> Dict[str, Any]:
    """Return all loaded thresholds, optionally filtered by service. For /thresholds endpoint."""
    _ensure_loaded()
    if _CACHE is None:
        return {}
    if service:
        return {service: _CACHE.get(service, {})}
    return dict(_CACHE)
