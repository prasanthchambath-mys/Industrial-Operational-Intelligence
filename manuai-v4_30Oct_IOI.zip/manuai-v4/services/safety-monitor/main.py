import httpx
"""
ManuAI — Safety Monitor Service  v2.0
LSTM-based (mock: rule-based) safety precursor detection.
Analyses multi-sensor streams for gas leak precursors, LOTO deviations,
proximity violations, and over-temperature events.

Mock mode uses rule-based thresholds on synthetic sensor data.
Live mode: set AML_SAFETY_ENDPOINT for Azure ML LSTM scoring endpoint.
"""

import os, random, logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime, timedelta
from ml_thresholds import get_threshold, get_category, list_thresholds
from service_health import register_health
from enum import Enum

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Safety Monitor", version="2.0.0")
register_health(app, "safety-monitor", required_files=["ml_thresholds.csv", "safety_zones.csv", "safety_permits.csv"])

MOCK = not bool(os.getenv("AML_SAFETY_ENDPOINT"))
if MOCK:
    logger.warning("AML_SAFETY_ENDPOINT not set — safety monitor running in mock/rule mode")


# ── Models ────────────────────────────────────────────────────────────────────

class SensorStream(BaseModel):
    zone_id: str
    h2s_ppm: float = 0.0
    co_ppm: float = 0.0
    ch4_pct_lel: float = 0.0    # % of Lower Explosive Limit
    temp_c: float = 25.0
    pressure_bar: float = 1.0
    vibration_mms: float = 0.0
    personnel_count: int = 0
    amr_in_zone: bool = False
    loto_active: bool = False
    loto_verified: bool = True

class SafetyAlert(BaseModel):
    alert_id: str
    zone_id: str
    alert_type: str
    severity: str          # "critical" | "high" | "medium" | "low"
    signal_description: str
    action_required: str
    precursor_score: float  # 0–1 probability of incident
    auto_action_taken: str
    timestamp: str
    status: str            # "open" | "acknowledged" | "resolved"

class PTWAssessment(BaseModel):
    ptw_id: str
    asset_id: str
    work_type: str
    blocked: bool
    block_reason: Optional[str]
    jha_complete: bool
    isolation_verified: bool
    competency_valid: bool
    recommendation: str

class SafetyStatus(BaseModel):
    open_critical: int
    alerts: List[SafetyAlert]
    zone_risk: Dict[str, str]    # zone_id → risk level
    model_source: str


# ── Thresholds ────────────────────────────────────────────────────────────────

def _load_gas_thresholds():
    """Lazy-load gas thresholds from ml_thresholds.csv (service=safety).
    Returns dict matching the original GAS_THRESHOLDS shape."""
    return {
        "h2s_ppm":    get_category('safety', 'gas_h2s_ppm',
                                   {"alarm1": 1.0,  "alarm2": 5.0,  "evac": 10.0}),
        "co_ppm":     get_category('safety', 'gas_co_ppm',
                                   {"alarm1": 25.0, "alarm2": 50.0, "evac": 100.0}),
        "ch4_pct_lel":get_category('safety', 'gas_ch4_pct_lel',
                                   {"alarm1": 10.0, "alarm2": 20.0, "evac": 25.0}),
    }


_GAS_CACHE = None
def GAS_THRESHOLDS():
    """Backward-compat callable that returns the gas threshold dict.
    Was previously a module-level dict; now a function so CSV reloads take effect
    when reload() is called via the ml_thresholds module."""
    global _GAS_CACHE
    if _GAS_CACHE is None:
        _GAS_CACHE = _load_gas_thresholds()
    return _GAS_CACHE


# ── CSV-driven data (Issue 6 fix): mounted /app/data/csv, fallback to inline ──
import csv as _csv
import os as _os

_CSV_DIR = _os.environ.get("CSV_DATA_DIR", "/app/data/csv")

def _load_csv_rows(filename):
    path = _os.path.join(_CSV_DIR, filename)
    if not _os.path.exists(path):
        return None
    with open(path, encoding="utf-8-sig") as f:
        return list(_csv.DictReader(f))

def _csv_zones():
    rows = _load_csv_rows("safety_zones.csv")
    if not rows:
        return None
    return [{
        "zone_id": r["zone_id"],
        "h2s_ppm": float(r["h2s_ppm_baseline"]),
        "co_ppm": float(r["co_ppm_baseline"]),
        "ch4_pct_lel": float(r["ch4_pct_lel_baseline"]),
        "temp_c": 35.0, "pressure_bar": 1.1, "vibration_mms": 2.0,
        "personnel_count": int(r["personnel_normal"]),
        "amr_in_zone": str(r["amr_enabled"]).lower() == "true",
        "loto_active": False, "loto_verified": True,
    } for r in rows]

def _csv_ptws():
    rows = _load_csv_rows("safety_permits.csv")
    if not rows:
        return None
    return [{
        "ptw_id": r["ptw_id"], "asset_id": r["asset_id"], "work_type": r["work_type"],
        "jha": str(r["jha_complete"]).lower() == "true",
        "iso": str(r["isolation_verified"]).lower() == "true",
        "comp": str(r["competency_valid"]).lower() == "true",
    } for r in rows]

_FALLBACK_ZONES = [
    {"zone_id":"Zone A","h2s_ppm":0.0,  "co_ppm":8.0,  "ch4_pct_lel":0.0, "temp_c":38,"pressure_bar":1.1,"vibration_mms":2.1,"personnel_count":3,"amr_in_zone":False,"loto_active":False,"loto_verified":True},
    {"zone_id":"Zone B","h2s_ppm":0.0,  "co_ppm":12.0, "ch4_pct_lel":3.0, "temp_c":42,"pressure_bar":1.2,"vibration_mms":1.8,"personnel_count":2,"amr_in_zone":True, "loto_active":False,"loto_verified":True},
    {"zone_id":"Zone C","h2s_ppm":2.8,  "co_ppm":22.0, "ch4_pct_lel":8.5, "temp_c":61,"pressure_bar":2.1,"vibration_mms":5.2,"personnel_count":4,"amr_in_zone":False,"loto_active":True, "loto_verified":True},
    {"zone_id":"Zone D","h2s_ppm":0.0,  "co_ppm":4.0,  "ch4_pct_lel":0.0, "temp_c":29,"pressure_bar":1.0,"vibration_mms":0.9,"personnel_count":1,"amr_in_zone":False,"loto_active":False,"loto_verified":True},
]

_FALLBACK_PTWS = [
    {"ptw_id":"PTW-0341","asset_id":"MCH-06","work_type":"Hot work",            "jha":True,  "iso":True,  "comp":True},
    {"ptw_id":"PTW-0340","asset_id":"CMP-001","work_type":"Confined space",      "jha":True,  "iso":True,  "comp":True},
    {"ptw_id":"PTW-0339","asset_id":"HYD-003","work_type":"Electrical isolation", "jha":False, "iso":False, "comp":True},
]

# CSV is authoritative (Issue 6 fix)
MOCK_ZONES = _csv_zones() or _FALLBACK_ZONES
MOCK_PTWS = _csv_ptws() or _FALLBACK_PTWS



def _assess_zone(z: SensorStream) -> List[SafetyAlert]:
    alerts = []
    ts = datetime.utcnow().isoformat()

    # Gas precursor check
    for gas, key in [("H₂S", "h2s_ppm"), ("CO", "co_ppm"), ("CH₄", "ch4_pct_lel")]:
        val = getattr(z, key)
        thresh = GAS_THRESHOLDS()[key]
        if val >= thresh["evac"]:
            alerts.append(SafetyAlert(
                alert_id=f"EVT-{random.randint(100,999)}", zone_id=z.zone_id,
                alert_type="Gas leak precursor",
                severity="critical",
                signal_description=f"{gas} at {val:.1f} — EVACUATION threshold exceeded",
                action_required="Immediate evacuation; notify EHS; isolate source",
                precursor_score=0.97, auto_action_taken="Evacuation alarm activated",
                timestamp=ts, status="open"))
        elif val >= thresh["alarm2"]:
            alerts.append(SafetyAlert(
                alert_id=f"EVT-{random.randint(100,999)}", zone_id=z.zone_id,
                alert_type="Gas concentration high",
                severity="high",
                signal_description=f"{gas} at {val:.1f} — Alarm-2 threshold",
                action_required="Investigate source; prepare for evacuation",
                precursor_score=0.72, auto_action_taken="EHS team notified",
                timestamp=ts, status="open"))
        elif val >= thresh["alarm1"]:
            alerts.append(SafetyAlert(
                alert_id=f"EVT-{random.randint(100,999)}", zone_id=z.zone_id,
                alert_type="Gas precursor",
                severity="medium",
                signal_description=f"{gas} at {val:.1f} — Alarm-1 threshold",
                action_required="Monitor closely; check ventilation",
                precursor_score=0.45, auto_action_taken="Ventilation boosted",
                timestamp=ts, status="open"))

    # LOTO deviation
    if z.loto_active and not z.loto_verified:
        alerts.append(SafetyAlert(
            alert_id=f"EVT-{random.randint(100,999)}", zone_id=z.zone_id,
            alert_type="LOTO deviation",
            severity="high",
            signal_description="LOTO active but isolation not verified in CMMS",
            action_required="Halt work; verify isolation before proceeding",
            precursor_score=0.68, auto_action_taken="Work order suspended",
            timestamp=ts, status="open"))

    # AMR proximity
    if z.amr_in_zone and z.personnel_count > 0:
        alerts.append(SafetyAlert(
            alert_id=f"EVT-{random.randint(100,999)}", zone_id=z.zone_id,
            alert_type="Proximity alert",
            severity="medium",
            signal_description=f"AMR detected in zone with {z.personnel_count} personnel",
            action_required="Slow AMR to safety speed; clear zone if needed",
            precursor_score=0.38, auto_action_taken="AMR speed reduced to 0.3 m/s",
            timestamp=ts, status="open"))

    # Over-temperature
    if z.temp_c > 55:
        alerts.append(SafetyAlert(
            alert_id=f"EVT-{random.randint(100,999)}", zone_id=z.zone_id,
            alert_type="Over-temperature",
            severity="high" if z.temp_c > 70 else "medium",
            signal_description=f"Zone temperature {z.temp_c:.0f}°C — above safe working limit",
            action_required="Check cooling; restrict personnel access",
            precursor_score=0.55, auto_action_taken="Cooling alert issued to maintenance",
            timestamp=ts, status="open"))

    return alerts


def _ptw_assess(p: dict, active_gas_zones: List[str]) -> PTWAssessment:
    blocked = False
    block_reason = None
    rec = "Permit can be approved subject to standard checks."

    if p["work_type"] in ("Hot work", "Confined space"):
        if any(active_gas_zones):
            blocked = True
            block_reason = f"Active gas precursor detected in plant — hot/confined work blocked"
            rec = "Do NOT approve until gas readings clear and zone is certified safe."

    if not p["jha"]:
        blocked = True
        block_reason = "JHA incomplete — cannot approve"
        rec = "Complete Job Hazard Analysis before resubmitting."

    if not p["iso"]:
        blocked = True
        block_reason = "Energy isolation not verified"
        rec = "Verify and document LOTO / isolation before approval."

    return PTWAssessment(
        ptw_id=p["ptw_id"], asset_id=p["asset_id"], work_type=p["work_type"],
        blocked=blocked, block_reason=block_reason,
        jha_complete=p["jha"], isolation_verified=p["iso"], competency_valid=p["comp"],
        recommendation=rec,
    )


@app.get("/status", response_model=SafetyStatus)
def safety_status():
    zones = [SensorStream(**z) for z in MOCK_ZONES]
    all_alerts = []
    zone_risk = {}
    for z in zones:
        alerts = _assess_zone(z)
        all_alerts.extend(alerts)
        sevs = [a.severity for a in alerts]
        zone_risk[z.zone_id] = "critical" if "critical" in sevs else ("high" if "high" in sevs else ("medium" if "medium" in sevs else "low"))

    open_critical = sum(1 for a in all_alerts if a.severity == "critical" and a.status == "open")
    return SafetyStatus(open_critical=open_critical, alerts=all_alerts, zone_risk=zone_risk, model_source="rule_engine")


@app.post("/assess/zone", response_model=List[SafetyAlert])
def assess_zone(z: SensorStream):
    return _assess_zone(z)


@app.get("/ptw/assess", response_model=List[PTWAssessment])
def assess_ptws():
    # Find zones with active critical gas alerts
    zones = [SensorStream(**z) for z in MOCK_ZONES]
    gas_zones = []
    for z in zones:
        for gas, key in [("h2s_ppm", "h2s_ppm"), ("co_ppm", "co_ppm"), ("ch4_pct_lel", "ch4_pct_lel")]:
            val = getattr(z, key)
            if val >= GAS_THRESHOLDS()[gas]["alarm2"]:
                gas_zones.append(z.zone_id)

    return [_ptw_assess(p, gas_zones) for p in MOCK_PTWS]


@app.get("/thresholds")
def thresholds():
    return list_thresholds('safety')
