"""
ManuAI — Digital Twin asset topology (pragmatic, CSV-derived).

The audit's Gap 4: the twin was a FLAT list of KPIs with no notion of which asset
a KPI belongs to or how assets relate. This module builds a real hierarchy

    Plant -> Line -> Machine -> KPI

from the existing machines.csv + twin_kpis.csv, and exposes relationship queries
so divergence can be reasoned about topologically ("the reactor temp diverged AND
the coolant flow on the same line also moved").

This is not the full Azure Digital Twins DTDL graph, but it delivers the actual
capability: related-asset reasoning. Phase E swaps the build_graph() source for an
ADT model query; the graph shape and the related_kpis() contract stay the same.
"""
from __future__ import annotations
import csv as _csv
import os as _os
from typing import Dict, List, Optional

_CSV_DIR = _os.environ.get("CSV_DATA_DIR", "/app/data/csv")


def _load(filename: str) -> List[dict]:
    path = _os.path.join(_CSV_DIR, filename)
    if not _os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig") as f:
        return list(_csv.DictReader(f))


def build_graph() -> Dict:
    """Construct the Plant -> Line -> Machine -> KPI graph from CSVs.

    Returns a nested dict plus flat lookup indexes. Plant-level KPIs (asset_id
    blank) attach to a synthetic 'PLANT' node under each plant they apply to.
    """
    machines = _load("machines.csv")
    kpis = _load("twin_kpis.csv")

    # machine_id -> {line, plant}
    machine_idx: Dict[str, Dict] = {}
    for m in machines:
        mid = m.get("id")
        if mid:
            machine_idx[mid] = {"line": m.get("line"), "plant": m.get("plant")}

    # Assemble KPI nodes with their resolved parent asset/line/plant.
    kpi_nodes = []
    for k in kpis:
        kid = k.get("kpi_id")
        asset = (k.get("asset_id") or "").strip() or None
        plant = (k.get("plant") or "").strip() or None
        line = None
        if asset and asset in machine_idx:
            line = machine_idx[asset]["line"]
            plant = machine_idx[asset]["plant"]
        kpi_nodes.append({
            "kpi_id": kid, "name": k.get("kpi_name"), "unit": k.get("unit"),
            "asset_id": asset, "line": line, "plant": plant,
            "scope": "asset" if asset else "plant",
        })

    # Build the nested hierarchy.
    plants: Dict[str, Dict] = {}
    for kn in kpi_nodes:
        # A plant-level KPI (plant 'Both' or blank) lands under every real plant.
        target_plants = []
        if kn["plant"] in (None, "Both", "All Plants"):
            target_plants = sorted({v["plant"] for v in machine_idx.values()})
        else:
            target_plants = [kn["plant"]]
        for p in target_plants:
            plants.setdefault(p, {"plant": p, "lines": {}, "plant_kpis": []})
            if kn["scope"] == "plant":
                plants[p]["plant_kpis"].append(kn["kpi_id"])
            else:
                line = kn["line"] or "Unassigned"
                plants[p]["lines"].setdefault(line, {"line": line, "machines": {}})
                mid = kn["asset_id"]
                plants[p]["lines"][line]["machines"].setdefault(mid, {"machine": mid, "kpis": []})
                plants[p]["lines"][line]["machines"][mid]["kpis"].append(kn["kpi_id"])

    return {"plants": plants, "kpi_nodes": {k["kpi_id"]: k for k in kpi_nodes},
            "machine_idx": machine_idx}


def related_kpis(kpi_id: str, graph: Optional[Dict] = None) -> List[str]:
    """KPIs topologically related to the given one, for divergence root-cause.

    Relationship priority:
      1. Same machine (strongest — likely same physical cause)
      2. Same line   (process-coupled)
      3. Same plant level (weakest — shared utilities)
    Returns kpi_ids excluding the input, nearest-first.
    """
    graph = graph or build_graph()
    node = graph["kpi_nodes"].get(kpi_id)
    if not node:
        return []
    same_machine, same_line, same_plant = [], [], []
    for other_id, other in graph["kpi_nodes"].items():
        if other_id == kpi_id:
            continue
        if node["asset_id"] and other["asset_id"] == node["asset_id"]:
            same_machine.append(other_id)
        elif node["line"] and other["line"] == node["line"]:
            same_line.append(other_id)
        elif node["plant"] and other["plant"] == node["plant"]:
            same_plant.append(other_id)
    return same_machine + same_line + same_plant


def topology_summary() -> Dict:
    g = build_graph()
    n_plants = len(g["plants"])
    n_lines = sum(len(p["lines"]) for p in g["plants"].values())
    n_machines = len(g["machine_idx"])
    n_kpis = len(g["kpi_nodes"])
    return {
        "plants": n_plants, "lines": n_lines, "machines": n_machines, "kpis": n_kpis,
        "source": "machines.csv + twin_kpis.csv (Phase E: Azure Digital Twins DTDL graph)",
    }
