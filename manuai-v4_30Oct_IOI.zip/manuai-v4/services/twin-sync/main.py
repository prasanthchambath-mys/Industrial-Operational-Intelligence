"""
ManuAI — Digital Twin Sync Service  v2.0
Compares live plant KPIs against Azure Digital Twins model predictions
and flags divergence that indicates model drift or process anomalies.

Mock mode synthesises realistic divergence data.
Live mode: set ADT_INSTANCE_URL + AZURE_CLIENT_ID + AZURE_CLIENT_SECRET.
"""

import os, random, math, logging
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime, timedelta
from ml_thresholds import get_threshold, list_thresholds
from service_health import register_health
import twin_model
import twin_sim
import twin_topology

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI Digital Twin Sync", version="2.0.0")
register_health(app, "twin-sync", required_files=["ml_thresholds.csv", "twin_kpis.csv", "twin_scenarios.csv"])

MOCK = not bool(os.getenv("ADT_INSTANCE_URL"))
if MOCK:
    logger.warning("ADT_INSTANCE_URL not set — digital twin sync running in mock mode")


# ── Models ────────────────────────────────────────────────────────────────────

class KPIPoint(BaseModel):
    kpi_id: str
    kpi_name: str
    unit: str
    actual: float
    twin_predicted: float
    divergence_pct: float
    abs_delta: float
    status: str              # "aligned" | "diverging" | "critical"
    last_aligned: str        # ISO timestamp
    asset_id: Optional[str]
    related_kpis: List[str] = []   # topologically related KPIs (Gap 4)

class ScenarioResult(BaseModel):
    scenario_id: str
    name: str
    description: str
    status: str              # "pending" | "running" | "complete" | "error"
    impact_summary: str
    confidence: float
    started_at: Optional[str]
    completed_at: Optional[str]
    recommendations: List[str]

class TwinSyncStatus(BaseModel):
    synced_at: str
    accuracy_pct: float
    diverging_count: int
    critical_count: int
    kpi_points: List[KPIPoint]
    scenarios: List[ScenarioResult]
    model_source: str


# ── Mock KPI library ──────────────────────────────────────────────────────────

def _jitter(base, noise_pct=0.02):
    return round(base * (1 + (random.random() - 0.5) * noise_pct), 2)



# ── CSV-driven data (Issue 6 fix): load from mounted /app/data/csv, fallback to inline ──
import csv as _csv
import os as _os

_CSV_DIR = _os.environ.get("CSV_DATA_DIR", "/app/data/csv")

def _load_csv(filename):
    path = _os.path.join(_CSV_DIR, filename)
    if not _os.path.exists(path):
        return None
    with open(path, encoding="utf-8-sig") as f:
        return list(_csv.DictReader(f))

def _csv_kpi_defs():
    rows = _load_csv("twin_kpis.csv")
    if not rows:
        return None
    return [{
        "id": r["kpi_id"], "name": r["kpi_name"], "unit": r["unit"],
        "twin": float(r["twin_predicted"]), "actual_base": float(r["actual"]),
        "asset": r.get("asset_id") or None,
        "threshold": float(r.get("divergence_threshold_pct", 3.0)),
    } for r in rows]

def _csv_scenarios(fallback):
    rows = _load_csv("twin_scenarios.csv")
    if not rows:
        return None
    # Preserve detailed recs from inline data when IDs match; CSV is authoritative for status/impact
    rec_map = {s["id"]: s.get("recs", []) for s in fallback}
    desc_map = {s["id"]: s.get("description", "") for s in fallback}
    return [{
        "id": r["id"], "name": r["name"], "status": r["status"],
        "impact": r["impact"], "confidence": float(r["confidence"]),
        "description": desc_map.get(r["id"], r["name"]),
        "recs": rec_map.get(r["id"], ["See scenario detail in Digital Twin console"]),
    } for r in rows]

_FALLBACK_KPI_DEFS = [
    {"id":"PLANT_OEE",         "name":"Plant OEE",            "unit":"%",      "twin":79.4,  "actual_base":76.8,  "asset":None,     "threshold":3.0},
    {"id":"REACTOR_TEMP",      "name":"Reactor Temp TIC-101", "unit":"°C",     "twin":186.0, "actual_base":182.0, "asset":"MCH-01", "threshold":2.0},
    {"id":"MCH06_VIBRATION",   "name":"MCH-06 Vibration RMS", "unit":"mm/s",   "twin":8.1,   "actual_base":10.2,  "asset":"MCH-06", "threshold":1.5},
    {"id":"LINEDC_SPEED",      "name":"Conveyor Speed Line D","unit":"m/s",    "twin":1.24,  "actual_base":1.24,  "asset":"MCH-07", "threshold":0.05},
    {"id":"PLANT_ENERGY",      "name":"Plant kWh/Unit",        "unit":"kWh/u", "twin":4.82,  "actual_base":5.14,  "asset":None,     "threshold":5.0},
    {"id":"YIELD_PCT",         "name":"Batch Yield %",         "unit":"%",     "twin":91.5,  "actual_base":89.3,  "asset":None,     "threshold":2.0},
    {"id":"MCH03_TEMP",        "name":"MCH-03 Spindle Temp",  "unit":"°C",     "twin":72.0,  "actual_base":92.0,  "asset":"MCH-03", "threshold":8.0},
    {"id":"COOLANT_FLOW",      "name":"Coolant Flow FIC-401",  "unit":"L/min", "twin":28.6,  "actual_base":28.6,  "asset":None,     "threshold":2.0},
]

_FALLBACK_SCENARIOS = [
    {
        "id":"SCN-01","name":"Maintenance Window Optimisation",
        "description":"Simulate MCH-03 and MCH-06 maintenance in parallel vs sequential. Model quantifies throughput impact.",
        "status":"running","impact":"+4.2% throughput","confidence":0.91,
        "recs":["Schedule MCH-06 weekend window","Defer MCH-03 to following Monday","Pre-stage spare parts by Thursday"],
    },
    {
        "id":"SCN-02","name":"Grade Change X-12 → Y-07",
        "description":"Predict transition loss when switching reactor from Compound X-12 to Y-07 grade.",
        "status":"complete","impact":"-18% transition loss","confidence":0.87,
        "recs":["Flush reactor at 92°C not 86°C","Extend purge to 45 min","Run trial batch before full campaign"],
    },
    {
        "id":"SCN-03","name":"Energy Load Shift Off-Peak",
        "description":"Evaluate moving HVAC pre-cooling and compressed air generation to night shift.",
        "status":"pending","impact":"-11% peak demand","confidence":0.84,
        "recs":["Pre-cool Zone A from 22:00","Stage air compressors from 23:30","Review night-shift staffing"],
    },
]

# CSV is authoritative; inline data is fallback only (Issue 6 fix)
MOCK_KPI_DEFS = _csv_kpi_defs() or _FALLBACK_KPI_DEFS
MOCK_SCENARIOS = _csv_scenarios(_FALLBACK_SCENARIOS) or _FALLBACK_SCENARIOS


def _build_kpi(d: dict, inputs: dict | None = None) -> KPIPoint:
    # Gap 1 fix: the expected ("twin") value is now COMPUTED from operating inputs
    # via twin_model.predict(), not a static CSV constant. With no inputs it equals
    # the commissioned base (back-compatible); with live inputs it adjusts, so a
    # reading that moved because conditions changed is no longer a false divergence.
    actual = _jitter(d["actual_base"])
    twin   = twin_model.predict(d["id"], d["twin"], inputs or {})
    delta_abs = actual - twin
    div_pct = abs(delta_abs / twin) * 100 if twin != 0 else 0

    # Critical-band multiplier — was hardcoded as `threshold * 2`.
    # Now CSV-driven so process engineers can adjust how aggressively
    # the system flags divergence as "critical" vs merely "diverging".
    crit_mult = get_threshold('twin', 'divergence', 'critical_multiplier', 2.0)
    if div_pct > d["threshold"] * crit_mult:
        status = "critical"
    elif div_pct > d["threshold"]:
        status = "diverging"
    else:
        status = "aligned"

    mins_ago = random.randint(0, 240)
    last_aligned = (datetime.utcnow() - timedelta(minutes=mins_ago)).isoformat()

    # Topology-aware context (Gap 4): when a KPI is off, surface related KPIs on
    # the same machine/line so the UI can support root-cause reasoning.
    related = twin_topology.related_kpis(d["id"]) if status != "aligned" else []

    return KPIPoint(
        kpi_id=d["id"], kpi_name=d["name"], unit=d["unit"],
        actual=actual, twin_predicted=twin,
        divergence_pct=round(div_pct, 2),
        abs_delta=round(delta_abs, 2),
        status=status,
        last_aligned=last_aligned,
        asset_id=d.get("asset"),
        related_kpis=related,
    )


@app.get("/status", response_model=TwinSyncStatus)
def status():
    kpis = [_build_kpi(d) for d in MOCK_KPI_DEFS]
    diverging = [k for k in kpis if k.status in ("diverging","critical")]
    critical  = [k for k in kpis if k.status == "critical"]

    # Accuracy: proportion of KPIs within threshold
    accuracy = round((len(kpis) - len(diverging)) / len(kpis) * 100, 1) if kpis else 100

    scenarios = [
        ScenarioResult(
            scenario_id=s["id"], name=s["name"],
            description=s["description"],
            status=s["status"],
            impact_summary=s["impact"],
            confidence=s["confidence"],
            started_at=(datetime.utcnow() - timedelta(hours=2)).isoformat() if s["status"] != "pending" else None,
            completed_at=datetime.utcnow().isoformat() if s["status"] == "complete" else None,
            recommendations=s["recs"],
        )
        for s in MOCK_SCENARIOS
    ]

    return TwinSyncStatus(
        synced_at=datetime.utcnow().isoformat(),
        accuracy_pct=accuracy,
        diverging_count=len(diverging),
        critical_count=len(critical),
        kpi_points=kpis,
        scenarios=scenarios,
        model_source="computed-behavioural-v1" if MOCK else "azure-digital-twins",
    )


class ScenarioRunRequest(BaseModel):
    params: Optional[Dict] = None     # user-supplied what-if parameters
    scenario_type: Optional[str] = None  # override; else inferred from the scenario

# Map scenario id -> simulator type (mirrors the 'type' column in twin_scenarios.csv).
_SCENARIO_TYPE = {
    "SCN-01": "maintenance", "SCN-05": "maintenance",
    "SCN-02": "grade_change", "SCN-06": "grade_change",
    "SCN-03": "energy",
    "SCN-04": "supply",
}

@app.post("/scenarios/{scenario_id}/run")
def run_scenario(scenario_id: str, req: ScenarioRunRequest | None = None):
    s = next((x for x in MOCK_SCENARIOS if x["id"] == scenario_id), None)
    if not s:
        raise HTTPException(404, f"Scenario {scenario_id} not found")
    # Gap 2 fix: actually RUN a parameterised simulation and return a COMPUTED
    # outcome, instead of echoing the pre-authored constant. Change the params ->
    # get a different answer. The scenario_type routes to the right simulator.
    req = req or ScenarioRunRequest()
    stype = (req.scenario_type
             or _SCENARIO_TYPE.get(scenario_id)
             or str(s.get("type", "maintenance")))
    result = twin_sim.simulate(stype, req.params or {})
    return {
        "success": True,
        "scenario_id": scenario_id,
        "name": s["name"],
        "status": "complete",
        "computed": True,
        "impact": result["impact"],
        "impact_value": result["impact_value"],
        "confidence": result["confidence"],
        "detail": result.get("detail", {}),
        "recommendations": result.get("recommendations", s.get("recs", [])),
        "engine": result.get("engine"),
        "params_used": result.get("params_used", {}),
    }


@app.post("/simulate")
def simulate_endpoint(payload: dict | None = None):
    # Stateless what-if: compute an outcome for a scenario_type + params directly.
    payload = payload or {}
    stype = payload.get("scenario_type", "failure")
    params = payload.get("params", {})
    result = twin_sim.simulate(stype, params)
    return {"success": True, **result}


@app.get("/topology")
def topology():
    # Gap 4 fix: expose the Plant -> Line -> Machine -> KPI hierarchy built from
    # machines.csv + twin_kpis.csv. Phase E swaps the source for an ADT DTDL graph.
    g = twin_topology.build_graph()
    return {"summary": twin_topology.topology_summary(), "plants": g["plants"]}


@app.get("/divergence/{kpi_id}/related")
def divergence_related(kpi_id: str):
    # Topology-aware root-cause helper: which KPIs are related to a diverging one.
    related = twin_topology.related_kpis(kpi_id)
    node = twin_topology.build_graph()["kpi_nodes"].get(kpi_id)
    return {"kpi_id": kpi_id, "node": node, "related_kpis": related}


@app.post("/recalibrate")
def recalibrate(payload: dict | None = None):
    # Gap 5 fix: real (lightweight) recalibration. We feed the current KPI set as
    # observations to twin_model.recalibrate(), which learns a per-KPI bias from
    # the actual-vs-expected residual so subsequent predictions track reality.
    # Phase E swaps this for an Azure ML retraining run; the contract is identical.
    triggered_by = (payload or {}).get("triggered_by")
    observations = [
        {"kpi_id": d["id"], "base": d["twin"], "actual": d["actual_base"], "inputs": (payload or {}).get("inputs", {})}
        for d in MOCK_KPI_DEFS
    ]
    summary = twin_model.recalibrate(observations, triggered_by=triggered_by)
    return {
        "success": True,
        "recalibrated": True,
        "kpis_adjusted": summary["kpis_adjusted"],
        "mean_abs_shift": summary["mean_abs_shift"],
        "at": summary["at"],
        "method": "per-KPI residual bias correction",
        "note": "Phase E: this becomes an Azure ML retraining run",
    }


@app.get("/thresholds")
def thresholds():
    return list_thresholds('twin')
