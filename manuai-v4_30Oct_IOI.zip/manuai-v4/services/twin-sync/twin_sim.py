"""
ManuAI — Digital Twin what-if simulation (pragmatic, parameterised).

Replaces the pre-authored scenario OUTCOMES (the "+4.2% throughput" constants in
twin_scenarios.csv) with values COMPUTED from the parameters the user supplies.
Change the inputs -> get a different, recomputed answer. That is the capability
the audit flagged as missing (Gap 2): the what-if is now interactive, not a
slideshow.

Contract (kept identical to what a heavy engine would expose):

    simulate(scenario_type: str, params: dict) -> dict
        -> { impact: str, impact_value: float, confidence: float,
             detail: {...computed intermediate values...},
             recommendations: [str, ...] }

Phase E: swap the body of each _sim_* for a discrete-event simulation
(SimPy / FlexSim / AnyLogic) or the behavioural models in twin_model.py. Callers
in main.py only ever see this dict shape, so they don't change.

Every model here is transparent first-order operations research — enough to make
the scenario genuinely responsive to its inputs, not high-fidelity plant physics.
"""
from __future__ import annotations
from typing import Dict


def _f(params: Dict, key: str, default: float) -> float:
    try:
        v = params.get(key)
        return float(v) if v is not None else float(default)
    except Exception:
        return float(default)


# ── Maintenance-window optimisation ──────────────────────────────────────────
def _sim_maintenance(params: Dict) -> Dict:
    """Parallel vs sequential maintenance of N machines.
    Inputs: downtime_hours (per machine), line_rate (units/hr), machines (count),
            mode ('parallel'|'sequential'), overlap_pct (capacity lost when parallel).
    Computes throughput lost under each mode and the delta.
    """
    dt = _f(params, "downtime_hours", 8.0)
    rate = _f(params, "line_rate", 120.0)          # units/hr the line makes
    machines = max(1, int(_f(params, "machines", 2)))
    overlap = _f(params, "overlap_pct", 35.0) / 100.0  # shared-capacity loss if parallel
    mode = str(params.get("mode", "parallel")).lower()

    # Sequential: each machine's window is serial -> total downtime = N * dt,
    # but only ONE machine's worth of capacity is lost at a time.
    seq_units_lost = dt * rate * 1.0 * machines          # one machine's capacity, N windows
    seq_clock_hours = dt * machines

    # Parallel: all windows at once -> downtime = dt (one window), but the lines
    # share resources, so capacity lost is more than one machine's worth.
    par_units_lost = dt * rate * (1.0 + overlap * (machines - 1))
    par_clock_hours = dt

    chosen = "parallel" if mode == "parallel" else "sequential"
    lost = par_units_lost if chosen == "parallel" else seq_units_lost
    alt = seq_units_lost if chosen == "parallel" else par_units_lost
    saved_units = round(alt - lost, 0)

    # Throughput impact vs the worse option, expressed as %.
    base_window_output = max(1.0, seq_units_lost)
    impact_pct = round(saved_units / base_window_output * 100.0, 1)

    # Confidence: higher when the two options are clearly separated.
    sep = abs(seq_units_lost - par_units_lost) / max(seq_units_lost, par_units_lost)
    confidence = round(min(0.95, 0.6 + sep * 0.6), 2)

    recs = []
    if chosen == "parallel":
        recs = [
            f"Run {machines} machines in one {dt:.0f}h parallel window (clock: {par_clock_hours:.0f}h vs {seq_clock_hours:.0f}h sequential)",
            f"Pre-stage spares and crews; parallel needs {machines}x technicians simultaneously",
            f"Accept {overlap*100:.0f}% shared-capacity loss in exchange for {seq_clock_hours-par_clock_hours:.0f}h shorter outage",
        ]
    else:
        recs = [
            f"Stagger the {machines} windows sequentially to keep {100-0:.0f}% of the other lines running",
            f"Total elapsed {seq_clock_hours:.0f}h but only one machine's capacity lost at a time",
            "Choose this when parallel resource contention or safety isolation rules apply",
        ]
    return {
        "impact": f"{'+' if impact_pct>=0 else ''}{impact_pct}% throughput vs worse option",
        "impact_value": impact_pct,
        "confidence": confidence,
        "detail": {
            "sequential_units_lost": round(seq_units_lost, 0),
            "parallel_units_lost": round(par_units_lost, 0),
            "chosen_mode": chosen,
            "units_saved_vs_alt": saved_units,
            "clock_hours": par_clock_hours if chosen == "parallel" else seq_clock_hours,
        },
        "recommendations": recs,
    }


# ── Grade-change transition loss ─────────────────────────────────────────────
def _sim_grade_change(params: Dict) -> Dict:
    """Transition loss when switching product grade.
    Inputs: purge_min, flush_temp_c, batch_rate (units/hr), scrap_floor_pct.
    Higher flush temp + longer purge reduce cross-contamination scrap but cost time.
    """
    purge = _f(params, "purge_min", 30.0)
    flush_t = _f(params, "flush_temp_c", 86.0)
    rate = _f(params, "batch_rate", 90.0)
    scrap_floor = _f(params, "scrap_floor_pct", 4.0)

    # Scrap falls with purge time and flush temperature, asymptoting to a floor.
    # 45 min + 92 degC is the "good" recipe; below that, scrap rises.
    purge_factor = max(0.0, (45.0 - purge)) * 0.18      # %/min short of 45
    temp_factor = max(0.0, (92.0 - flush_t)) * 0.25     # %/degC short of 92
    scrap_pct = round(scrap_floor + purge_factor + temp_factor, 2)

    # Time cost of purge eats into output.
    time_loss_units = round(purge / 60.0 * rate, 0)
    # Transition loss vs a no-care baseline (scrap at ~15%).
    baseline_scrap = 15.0
    loss_reduction = round((baseline_scrap - scrap_pct) / baseline_scrap * 100.0, 1)

    confidence = round(min(0.93, 0.7 + (purge / 60.0) * 0.2), 2)
    return {
        "impact": f"-{loss_reduction}% transition loss (scrap {scrap_pct}%)",
        "impact_value": loss_reduction,
        "confidence": confidence,
        "detail": {
            "predicted_scrap_pct": scrap_pct,
            "purge_time_loss_units": time_loss_units,
            "flush_temp_c": flush_t,
            "purge_min": purge,
        },
        "recommendations": [
            f"Flush at {max(flush_t,92):.0f}degC (raising to 92 cuts scrap ~{temp_factor:.1f} pts)" if flush_t < 92 else "Flush temperature is at the sweet spot (92degC)",
            f"Purge {max(purge,45):.0f} min (extending to 45 cuts scrap ~{purge_factor:.1f} pts)" if purge < 45 else "Purge duration is sufficient",
            "Run one trial batch and assay before committing the full campaign",
        ],
    }


# ── Energy load-shift / peak shaving ─────────────────────────────────────────
def _sim_energy_shift(params: Dict) -> Dict:
    """Shift flexible load to off-peak.
    Inputs: shiftable_kw, peak_tariff, offpeak_tariff, hours_shifted.
    """
    kw = _f(params, "shiftable_kw", 220.0)
    peak = _f(params, "peak_tariff", 9.5)       # Rs/kWh
    off = _f(params, "offpeak_tariff", 5.2)
    hours = _f(params, "hours_shifted", 4.0)

    energy = kw * hours                           # kWh shifted
    saving = round(energy * (peak - off), 0)      # Rs saved
    peak_cut_pct = round(kw / max(1.0, _f(params, "plant_peak_kw", 1300.0)) * 100.0, 1)
    confidence = round(min(0.9, 0.65 + (peak - off) / peak * 0.5), 2)
    return {
        "impact": f"Rs {saving:,.0f} saved, -{peak_cut_pct}% peak demand",
        "impact_value": saving,
        "confidence": confidence,
        "detail": {
            "kwh_shifted": round(energy, 0),
            "tariff_delta": round(peak - off, 2),
            "peak_cut_pct": peak_cut_pct,
        },
        "recommendations": [
            f"Shift {kw:.0f} kW of flexible load (HVAC pre-cool, air compressors) to off-peak",
            f"Window: {hours:.0f}h before the evening peak tariff of Rs {peak}/kWh",
            "Verify night-shift staffing supports the rescheduled load",
        ],
    }


# ── Supply buffer-stock sizing ───────────────────────────────────────────────
def _sim_supply_buffer(params: Dict) -> Dict:
    """Buffer stock to cover supplier lead-time drift.
    Inputs: daily_demand, lead_time_days, lead_time_drift_days, service_level_z.
    """
    demand = _f(params, "daily_demand", 120.0)
    lt = _f(params, "lead_time_days", 21.0)
    drift = _f(params, "lead_time_drift_days", 6.0)
    z = _f(params, "service_level_z", 1.65)       # ~95% service level

    # Safety stock ~ z * demand * sqrt(variance proxy = drift)
    safety = round(z * demand * (drift ** 0.5), 0)
    cycle = round(demand * lt, 0)
    reorder = round(cycle + safety, 0)
    risk_days_cut = round(drift, 1)
    confidence = round(min(0.88, 0.6 + (z - 1.0) * 0.2), 2)
    return {
        "impact": f"-{risk_days_cut}d stockout risk (buffer {safety:.0f} units)",
        "impact_value": risk_days_cut,
        "confidence": confidence,
        "detail": {
            "safety_stock_units": safety,
            "reorder_point_units": reorder,
            "cycle_stock_units": cycle,
        },
        "recommendations": [
            f"Hold {safety:.0f} units safety stock to absorb {drift:.0f}d of lead-time drift",
            f"Set reorder point at {reorder:.0f} units (cycle {cycle:.0f} + safety {safety:.0f})",
            "Re-run weekly as supplier Paydex / lead-time signals update",
        ],
    }


def _sim_failure(params: Dict) -> Dict:
    """Asset failure / degradation prediction.
    Inputs: days_to_event, line_rate (kg/hr), oee_pct, health_pct, rul_days,
            unit_margin (revenue per kg), repair_hours.
    Computes production loss, OEE/yield impact, downtime, and revenue risk if the
    asset is run to failure vs serviced in time. Mirrors the mockup's Impact Summary.
    """
    days = _f(params, "days_to_event", 9.0)
    rate = _f(params, "line_rate", 120.0)           # kg/hr this asset contributes
    oee = _f(params, "oee_pct", 70.0)
    health = _f(params, "health_pct", 50.0)
    rul = _f(params, "rul_days", 9.0)
    margin = _f(params, "unit_margin", 18.0)         # revenue per kg
    repair_h = _f(params, "repair_hours", 18.0)

    # Degradation severity grows as health falls and as we approach RUL.
    severity = max(0.0, (100.0 - health) / 100.0)    # 0..1
    urgency = 1.0 if rul <= 0 else max(0.2, min(1.5, days / max(1.0, rul)))

    # Unplanned downtime if run to failure = repair window + collateral.
    downtime_h = round(repair_h * (1.0 + severity * urgency * 0.4), 1)
    # Production lost = downtime hours x effective rate (rate scaled by current OEE).
    prod_loss_kg = round(downtime_h * rate * (oee / 100.0), 0)
    # OEE impact: availability hit from the outage over a 7-day window.
    oee_impact_pct = round(-min(25.0, downtime_h / (7 * 24) * 100.0 * 1.4), 1)
    # Yield impact: degraded asset produces more off-spec as it fails.
    yield_impact_pct = round(-severity * 6.0, 1)
    # Revenue risk = lost production x margin, rounded to a tidy figure.
    revenue_risk = round(prod_loss_kg * margin, -2)
    confidence = round(min(0.95, 0.65 + severity * 0.3), 2)

    act = ("URGENT — service before failure" if rul <= days
           else f"Schedule maintenance within {max(1,int(rul-2))} days")
    return {
        "impact": f"{prod_loss_kg:,.0f} kg loss, ₹{revenue_risk:,.0f} revenue risk",
        "impact_value": prod_loss_kg,
        "confidence": confidence,
        "detail": {
            "production_loss_kg": prod_loss_kg,
            "oee_impact_pct": oee_impact_pct,
            "yield_impact_pct": yield_impact_pct,
            "downtime_hours": downtime_h,
            "revenue_risk": revenue_risk,
            "days_to_event": days,
            "rul_days": rul,
        },
        "recommendations": [
            act,
            f"Pre-stage spares; expected repair window ~{repair_h:.0f}h",
            f"Failure now would cost ~{prod_loss_kg:,.0f} kg and ₹{revenue_risk:,.0f}",
        ],
    }


_SIMULATORS = {
    "maintenance":  _sim_maintenance,
    "grade_change": _sim_grade_change,
    "energy":       _sim_energy_shift,
    "supply":       _sim_supply_buffer,
    "failure":      _sim_failure,
}


def simulate(scenario_type: str, params: Dict | None = None) -> Dict:
    """Run a parameterised what-if and return a COMPUTED outcome.

    If the scenario_type is unknown, returns a neutral result rather than raising,
    so the endpoint stays robust. Phase E swaps each _sim_* for a discrete-event
    engine; this signature and return shape stay the same.
    """
    params = params or {}
    fn = _SIMULATORS.get((scenario_type or "").lower())
    if not fn:
        return {
            "impact": "no simulator for this scenario type",
            "impact_value": 0.0, "confidence": 0.0,
            "detail": {"scenario_type": scenario_type}, "recommendations": [],
        }
    out = fn(params)
    out["computed"] = True
    out["engine"] = "parameterised-first-order-v1"
    out["params_used"] = params
    return out


def sim_info() -> Dict:
    return {
        "tier": "parameterised-first-order-v1",
        "kind": "transparent OR/physics-lite computations responsive to inputs",
        "swappable_for": "discrete-event simulation (SimPy/FlexSim/AnyLogic) in Phase E",
        "scenario_types": list(_SIMULATORS.keys()),
    }
