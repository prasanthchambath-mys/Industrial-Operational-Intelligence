"""
ManuAI — Digital Twin behavioural model (pragmatic, computed).

This replaces the static "twin_predicted" CSV constants with values COMPUTED
from the asset's operating inputs. Each predictor is a lightweight, transparent
behavioural relationship (heat balance, degradation curve, OEE identity, etc.).

The contract is deliberately the SAME shape a real Azure Digital Twins / Azure ML
surrogate would expose:

    predict(kpi_id: str, inputs: dict) -> float        # expected value now
    expected_band(kpi_id, inputs) -> (low, high)       # tolerance band

So Phase E swaps the BODY of each predictor for an ADT query or an AML scoring
call without changing any caller in main.py. The point of this tier is that the
expected value is now a function of live inputs — which kills the "static constant
causes false divergence when conditions change" failure from the audit (Gap 1).

All coefficients are intentionally simple and documented; they are engineering
first-order models, not the high-fidelity Phase-E twin.
"""
from __future__ import annotations
import math
from typing import Dict, Tuple, Callable

# ── Reference operating point ────────────────────────────────────────────────
# The conditions under which each KPI's CSV baseline was captured. The model
# computes how far the *current* inputs deviate from this reference and adjusts
# the expected value accordingly. In Phase E this reference set comes from the
# ADT twin's commissioned state instead of a dict here.
REFERENCE = {
    "ambient_c":     30.0,   # reference ambient temperature (deg C)
    "feed_flow_pct": 100.0,  # reference feed flow (% of nominal)
    "load_pct":      100.0,  # reference machine load (% of nominal)
    "run_hours":     0.0,    # hours since last maintenance at reference
}


def _get(inputs: Dict, key: str) -> float:
    """Read an input, falling back to the reference operating point."""
    try:
        v = inputs.get(key)
        return float(v) if v is not None else float(REFERENCE[key])
    except Exception:
        return float(REFERENCE[key])


# Per-KPI additive bias correction, learned at recalibration time (see recalibrate).
# Declared here (above predict) so the runtime lookup is always defined.
_BIAS: Dict[str, float] = {}


# ── Per-KPI behavioural predictors ───────────────────────────────────────────
# Each takes (base, inputs) where `base` is the commissioned/nominal value from
# twin_kpis.csv, and returns the EXPECTED value under the current inputs.

def _reactor_temp(base: float, inputs: Dict) -> float:
    # First-order heat balance: expected jacket/reactor temperature rises with
    # ambient and falls as feed flow (which carries heat away) increases.
    #   dT_ambient  ~ 0.35 degC per degC of ambient above reference
    #   dT_flow     ~ +0.6 degC per 1% drop in feed flow below reference
    d_amb = (_get(inputs, "ambient_c") - REFERENCE["ambient_c"]) * 0.35
    d_flow = (REFERENCE["feed_flow_pct"] - _get(inputs, "feed_flow_pct")) * 0.6
    return base + d_amb + d_flow


def _spindle_temp(base: float, inputs: Dict) -> float:
    # Spindle/bearing temperature rises with load and with run-hours since
    # maintenance (lubrication degrades). Ambient contributes a little.
    d_load = (_get(inputs, "load_pct") - REFERENCE["load_pct"]) * 0.18
    d_run = math.log1p(max(0.0, _get(inputs, "run_hours"))) * 1.2
    d_amb = (_get(inputs, "ambient_c") - REFERENCE["ambient_c"]) * 0.15
    return base + d_load + d_run + d_amb


def _vibration(base: float, inputs: Dict) -> float:
    # Bearing vibration grows with cumulative run-hours (wear) and load.
    # A gentle exponential-ish growth captured with a log term keeps it bounded.
    wear = math.log1p(max(0.0, _get(inputs, "run_hours")) / 100.0) * 0.9
    d_load = (_get(inputs, "load_pct") - REFERENCE["load_pct"]) * 0.012
    return base + wear + d_load


def _energy_per_unit(base: float, inputs: Dict) -> float:
    # kWh/unit rises when load drops (fixed overheads spread over fewer units)
    # and with ambient (more cooling). Convex in low-load region.
    load = max(40.0, _get(inputs, "load_pct"))
    overhead = (REFERENCE["load_pct"] / load - 1.0) * base * 0.6
    d_amb = (_get(inputs, "ambient_c") - REFERENCE["ambient_c"]) * 0.004
    return base + overhead + d_amb


def _oee(base: float, inputs: Dict) -> float:
    # OEE expected = Availability x Performance x Quality if those are supplied,
    # else it falls slightly with run-hours (degradation) from the base.
    A = inputs.get("availability_pct")
    P = inputs.get("performance_pct")
    Q = inputs.get("quality_pct")
    if A is not None and P is not None and Q is not None:
        return float(A) * float(P) * float(Q) / 10000.0
    deg = math.log1p(max(0.0, _get(inputs, "run_hours")) / 200.0) * 1.5
    return max(0.0, base - deg)


def _yield_pct(base: float, inputs: Dict) -> float:
    # Yield dips with feed-flow deviation (off-spec residence time) and a small
    # penalty for high ambient (process variability).
    d_flow = -abs(_get(inputs, "feed_flow_pct") - REFERENCE["feed_flow_pct"]) * 0.05
    d_amb = -max(0.0, _get(inputs, "ambient_c") - REFERENCE["ambient_c"]) * 0.02
    return base + d_flow + d_amb


def _passthrough(base: float, inputs: Dict) -> float:
    # Conveyor speed, coolant flow: setpoint-controlled, expected ≈ commissioned
    # value (a real controller holds it). Tiny ambient sensitivity only.
    return base


# Map each KPI id (from twin_kpis.csv) to its predictor.
_PREDICTORS: Dict[str, Callable[[float, Dict], float]] = {
    "REACTOR_TEMP":    _reactor_temp,
    "MCH03_TEMP":      _spindle_temp,
    "MCH06_VIBRATION": _vibration,
    "PLANT_ENERGY":    _energy_per_unit,
    "PLANT_OEE":       _oee,
    "YIELD_PCT":       _yield_pct,
    "LINEDC_SPEED":    _passthrough,
    "COOLANT_FLOW":    _passthrough,
}


def predict(kpi_id: str, base: float, inputs: Dict | None = None) -> float:
    """Expected (twin) value for a KPI under the current operating inputs.

    `base` is the commissioned/nominal value from twin_kpis.csv. With no inputs,
    the prediction equals the base (back-compatible). With inputs, it adjusts.

    Phase E: replace the body with an ADT telemetry query or an AML scoring call;
    the signature stays identical so main.py does not change.
    """
    inputs = inputs or {}
    fn = _PREDICTORS.get(kpi_id, _passthrough)
    try:
        raw = float(fn(float(base), inputs))
        # Apply any calibration bias learned for this KPI (0 until calibrated).
        return round(raw + _BIAS.get(kpi_id, 0.0), 3)
    except Exception:
        return round(float(base), 3)


def expected_band(kpi_id: str, base: float, inputs: Dict | None, threshold_pct: float) -> Tuple[float, float]:
    """Tolerance band around the expected value, from the KPI's divergence
    threshold. A real twin would derive this from model uncertainty; here we use
    the configured threshold so the band and the alarm logic stay consistent."""
    exp = predict(kpi_id, base, inputs)
    tol = abs(exp) * (threshold_pct / 100.0)
    return round(exp - tol, 3), round(exp + tol, 3)


def model_info() -> Dict:
    return {
        "tier": "computed-behavioural-v1",
        "kind": "first-order engineering models (heat balance, degradation, OEE identity)",
        "swappable_for": "Azure Digital Twins query / Azure ML surrogate (same signature)",
        "kpis_modelled": list(_PREDICTORS.keys()),
        "calibration": _calib_info(),
    }


# ── Recalibration ────────────────────────────────────────────────────────────
# A real (if lightweight) re-fit: when the model systematically over- or under-
# predicts a KPI, recalibration learns a per-KPI BIAS correction from recent
# actual-vs-expected residuals and folds it into future predictions. This is the
# pragmatic analogue of re-parameterising a physics model or re-fitting an ML
# surrogate. Phase E replaces this with an Azure ML retraining run; the contract
# (recalibrate -> predictions shift toward observed reality) stays the same.

_LAST_CALIBRATION: Dict = {"at": None, "by": None, "kpis_adjusted": 0, "mean_abs_shift": 0.0}

# Exponential-smoothing factor: how strongly a new calibration pulls the bias
# toward the latest observed residual (0 = ignore, 1 = jump fully). 0.5 = balanced.
_CALIB_ALPHA = 0.5


def recalibrate(observations: list, triggered_by: str | None = None) -> Dict:
    """Re-align the model from recent observations.

    `observations` is a list of dicts: {kpi_id, base, actual, inputs}. For each,
    we compute the residual (actual - current_expected) and smooth it into the
    per-KPI bias so subsequent predict() calls track reality more closely.

    Returns a summary of what moved. Idempotent-ish: repeated calibration on the
    same data converges rather than oscillating, thanks to the smoothing factor.
    """
    adjusted = 0
    shifts = []
    for o in observations or []:
        try:
            kpi = o["kpi_id"]; base = float(o["base"]); actual = float(o["actual"])
            inputs = o.get("inputs") or {}
        except Exception:
            continue
        expected = predict(kpi, base, inputs)            # includes current bias
        residual = actual - expected
        # Only correct meaningful, persistent offsets (ignore tiny noise).
        if abs(residual) < 1e-6:
            continue
        prev = _BIAS.get(kpi, 0.0)
        new_bias = prev + _CALIB_ALPHA * residual
        _BIAS[kpi] = round(new_bias, 4)
        adjusted += 1
        shifts.append(abs(new_bias - prev))
    from datetime import datetime as _dt
    _LAST_CALIBRATION.update({
        "at": _dt.utcnow().isoformat(),
        "by": triggered_by,
        "kpis_adjusted": adjusted,
        "mean_abs_shift": round(sum(shifts) / len(shifts), 4) if shifts else 0.0,
    })
    return dict(_LAST_CALIBRATION)


def _calib_info() -> Dict:
    return {
        "method": "per-KPI residual bias correction (exponential smoothing)",
        "alpha": _CALIB_ALPHA,
        "last": _LAST_CALIBRATION,
        "active_biases": {k: v for k, v in _BIAS.items() if abs(v) > 1e-6},
    }
