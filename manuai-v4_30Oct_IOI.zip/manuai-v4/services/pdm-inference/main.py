"""
ManuAI — PdM Inference Service  v2.1
FastAPI microservice for failure prediction and Remaining Useful Life estimation.

All numeric thresholds are loaded from data/csv/ml_thresholds.csv at startup
via the shared ml_thresholds module. Hardcoded fallbacks preserve behavior if
the CSV is missing. To change a threshold, edit the CSV — no code change.
"""
import os
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import logging
from ml_thresholds import get_threshold, get_category, list_thresholds
from service_health import register_health

logger = logging.getLogger(__name__)
app = FastAPI(title="ManuAI PdM Inference", version="2.1.0")
register_health(app, "pdm-inference", required_files=["ml_thresholds.csv"], model_file="pdm_model.joblib")


class SensorFeatures(BaseModel):
    asset_id: str
    vibration_rms: float
    vibration_peak: float
    temperature_delta: float
    pressure_variance: float
    run_hours_total: float
    run_hours_since_service: float
    load_factor: float
    ambient_temp: float


class PdMResult(BaseModel):
    asset_id: str
    failure_probability: float
    rul_days: float
    rul_low: float
    rul_high: float
    health_score: float
    anomaly_score: float
    failure_mode: str
    action: str


def predict(s: SensorFeatures) -> PdMResult:
    """All thresholds CSV-driven; see data/csv/ml_thresholds.csv (service=pdm)."""
    vib_scale = get_threshold('pdm', 'vibration_scoring', 'scale_factor', 0.071)
    vib_pct = min(100.0, max(0.0, 100.0 - (s.vibration_rms / vib_scale) * 100.0))

    temp_baseline = get_threshold('pdm', 'temperature_scoring', 'baseline_delta', 10.0)
    temp_penalty  = get_threshold('pdm', 'temperature_scoring', 'penalty_per_deg', 2.0)
    temp_pct = min(100.0, max(0.0, 100.0 - max(0.0, s.temperature_delta - temp_baseline) * temp_penalty))

    hours_full   = get_threshold('pdm', 'age_scoring', 'hours_for_full_age', 8760)
    age_exponent = get_threshold('pdm', 'age_scoring', 'exponent', 1.5)
    age_norm = min(1.0, s.run_hours_since_service / hours_full)
    age_pct  = 100.0 * (1.0 - age_norm ** age_exponent)

    weights = get_category('pdm', 'health_weights',
                           {'vibration_weight': 0.50, 'temperature_weight': 0.30, 'age_weight': 0.20})
    health = (weights['vibration_weight']  * vib_pct
              + weights['temperature_weight'] * temp_pct
              + weights['age_weight']      * age_pct)

    failure_health = get_threshold('pdm', 'rul_thresholds', 'failure_health', 30.0)
    if health <= failure_health:
        rul = 0.0
    else:
        rate = max(0.001, (100.0 - health) / max(1.0, s.run_hours_since_service))
        rul = max(0.0, (health - failure_health) / rate / 24.0)

    fm = get_category('pdm', 'failure_modes',
                      {'bearing_vib_min': 5.0, 'bearing_temp_min': 25,
                       'overtemp_min': 35, 'seal_leak_pvar_min': 0.5})
    if s.vibration_rms > fm['bearing_vib_min']:
        mode = "bearing_wear" if s.temperature_delta > fm['bearing_temp_min'] else "imbalance"
    elif s.temperature_delta > fm['overtemp_min']:
        mode = "overtemperature"
    elif s.pressure_variance > fm['seal_leak_pvar_min']:
        mode = "seal_leak"
    else:
        mode = "normal_wear"

    crit_d   = get_threshold('pdm', 'rul_thresholds', 'critical_days', 7)
    urgent_d = get_threshold('pdm', 'rul_thresholds', 'urgent_days', 14)
    plan_d   = get_threshold('pdm', 'rul_thresholds', 'plan_days', 30)
    if rul < crit_d:
        action = f"CRITICAL: Replace immediately. RUL {rul:.1f}d — schedule emergency maintenance."
    elif rul < urgent_d:
        action = f"URGENT: Schedule within 7 days. RUL {rul:.1f}d — auto-WO recommended."
    elif rul < plan_d:
        action = f"PLAN: Next maintenance window. RUL {rul:.1f}d."
    else:
        action = "MONITOR: Continue standard monitoring."

    rul_low_mul  = get_threshold('pdm', 'rul_confidence', 'low_multiplier', 0.75)
    rul_high_mul = get_threshold('pdm', 'rul_confidence', 'high_multiplier', 1.25)
    return PdMResult(
        asset_id=s.asset_id,
        failure_probability=round(max(0.0, 1.0 - health / 100.0), 3),
        rul_days=round(rul, 1),
        rul_low=round(rul * rul_low_mul, 1),
        rul_high=round(rul * rul_high_mul, 1),
        health_score=round(health, 1),
        anomaly_score=round(max(0.0, 1.0 - health / 100.0), 3),
        failure_mode=mode,
        action=action,
    )



_AML_ENDPOINT = os.getenv("AML_PDM_ENDPOINT", "")
_AML_KEY      = os.getenv("AML_API_KEY", "")
MOCK = not bool(_AML_ENDPOINT)
if MOCK:
    import logging as _l; _l.getLogger(__name__).warning(
        "AML_PDM_ENDPOINT not set — PdM Inference running in rule mode")


def _build_features(s: SensorFeatures, health: float) -> dict:
    """Map the service's SensorFeatures to the feature names the model expects."""
    return {
        "vibration_mm_s": s.vibration_rms,
        "temperature_c": s.ambient_temp + s.temperature_delta,
        "pressure_bar": 5.0,                       # minor feature; baseline default
        "pressure_variance": s.pressure_variance,
        "run_hours": s.run_hours_since_service,
        "health_score": health,
        "degrade_rate": 0.05,                      # default; refined in Phase A from asset master
    }


def _map_out(s: SensorFeatures, out: dict, rule: PdMResult) -> PdMResult:
    """Map the model's score.py output dict onto the service's PdMResult contract."""
    return PdMResult(
        asset_id=s.asset_id,
        failure_probability=float(out.get("failure_prob", rule.failure_probability)),
        rul_days=float(out.get("rul_days", rule.rul_days)),
        rul_low=float(out.get("rul_ci_low", rule.rul_low)),
        rul_high=float(out.get("rul_ci_high", rule.rul_high)),
        health_score=rule.health_score,
        anomaly_score=float(out.get("failure_prob", rule.anomaly_score)),
        failure_mode=out.get("failure_mode", rule.failure_mode),
        action=out.get("action", rule.action),
    )


def _aml_predict(s: SensorFeatures) -> PdMResult:
    """Call Azure ML scoring endpoint. Falls back to rule engine on any error."""
    rule = predict(s)
    headers = {"Content-Type": "application/json"}
    if _AML_KEY:
        headers["Authorization"] = f"Bearer {_AML_KEY}"
    try:
        resp = httpx.post(_AML_ENDPOINT, json=_build_features(s, rule.health_score),
                          headers=headers, timeout=10.0)
        resp.raise_for_status()
        return _map_out(s, resp.json(), rule)   # score.py shape → PdMResult
    except Exception as exc:
        logger.warning(f"AML PdM error — rule fallback: {exc}")
        return rule


# ── Local in-process model serving (ML_LOCAL=true) ───────────────────────────
ML_LOCAL = os.getenv("ML_LOCAL", "").lower() in ("1", "true", "yes")
_LOCAL_OK = False
_ml = None
if ML_LOCAL:
    try:
        import ml_score as _ml  # copied from ml/pdm/score.py at build time
        _ml.init()
        _LOCAL_OK = True
        logger.info("[ML] pdm local model loaded — serving in-process")
    except Exception as _e:
        logger.warning(f"[ML] pdm local model unavailable, using rule engine: {_e}")


def _local_predict(s: SensorFeatures) -> PdMResult:
    rule = predict(s)                              # rule engine gives the health baseline
    out = _ml.run(_build_features(s, rule.health_score))
    return _map_out(s, out, rule)


@app.post("/predict", response_model=PdMResult)
def predict_single(req: SensorFeatures):
    try:
        if not MOCK:
            return _aml_predict(req)
        if _LOCAL_OK:
            try:
                return _local_predict(req)
            except Exception as exc:
                logger.warning(f"[ML] local pdm inference failed — rule fallback: {exc}")
        return predict(req)
    except Exception as e:
        logger.error(f"Predict error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/predict/batch", response_model=List[PdMResult])
def predict_batch(assets: List[SensorFeatures]):
    return [predict(a) for a in assets]


@app.get("/thresholds")
def thresholds():
    """Live threshold set used by this service — for transparency."""
    return list_thresholds('pdm')
