<#
.SYNOPSIS
  Provision Phase A DATA: upload CSVs to Azure Files (Python services) and verify
  / count the PostgreSQL seed (API). PowerShell mirror of load-phase-a-data.sh.

.DESCRIPTION
  PART A uploads CSVs to the Azure Files share (idempotent).
  PART B verifies PostgreSQL connectivity and logs row counts per table. It does
  NOT re-implement the seeder (the canonical loader is baked into the API image);
  if the DB is empty it FAILS LOUD with the one-time seed procedure rather than
  faking success. No Mumbai/Pune/supplier/KPI values are referenced.

  Prereqs: az login; psql client on PATH (for PART B). Export PGPASSWORD for PART B.

.EXAMPLE
  $env:PGPASSWORD = '****'
  ./load-phase-a-data.ps1 -StorageAccount manuaidevcsvxxxxxx -ResourceGroup rg-manuai-dev `
    -DbHost manuai-dev-pg.postgres.database.azure.com -DbName manuai -DbUser manuai_admin -SslMode require
#>
[CmdletBinding()]
param(
  [string]$StorageAccount = '',
  [string]$ResourceGroup = '',
  [string]$FileShare = 'csvdata',
  [string]$DbHost = '',
  [string]$DbName = 'manuai',
  [string]$DbUser = '',
  [string]$SslMode = 'require',
  [string]$CsvDir = ''
)
$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrEmpty($CsvDir)) {
  $CsvDir = Join-Path (Resolve-Path (Join-Path $scriptDir '../../../..')) 'data/csv'
}
if (-not (Test-Path $CsvDir)) { throw "CSV directory not found: $CsvDir" }
$csvFiles = Get-ChildItem -Path $CsvDir -Filter '*.csv' -File
if ($csvFiles.Count -eq 0) { throw "No .csv files found in $CsvDir" }
Write-Host "==> Found $($csvFiles.Count) CSV files in $CsvDir"

# ── PART A — upload CSVs to Azure Files ───────────────────────────────────────
if ($StorageAccount -and $ResourceGroup) {
  if (-not (Get-Command az -ErrorAction SilentlyContinue)) { throw 'az not found (needed for PART A).' }
  Write-Host "==> PART A: uploading CSVs to Azure Files share '$FileShare' on '$StorageAccount'"
  $key = az storage account keys list --account-name $StorageAccount --resource-group $ResourceGroup --query '[0].value' -o tsv
  if ([string]::IsNullOrEmpty($key)) { throw "Could not read storage key for $StorageAccount" }
  az storage file upload-batch --account-name $StorageAccount --account-key $key `
    --destination $FileShare --source $CsvDir --pattern '*.csv' --output none
  Write-Host "==> PART A complete: $($csvFiles.Count) CSVs uploaded (idempotent overwrite)."
}
else {
  Write-Host '==> PART A skipped (no -StorageAccount/-ResourceGroup provided).'
}

# ── PART B — PostgreSQL seed verification + counts ────────────────────────────
if ($DbHost -and $DbUser) {
  if (-not (Get-Command psql -ErrorAction SilentlyContinue)) { throw 'psql not found (needed for PART B).' }
  if ([string]::IsNullOrEmpty($env:PGPASSWORD)) { throw 'Set $env:PGPASSWORD before running PART B.' }
  $conn = "host=$DbHost dbname=$DbName user=$DbUser sslmode=$SslMode"

  Write-Host "==> PART B: verifying PostgreSQL connectivity to $DbHost/$DbName"
  $null = psql $conn -v ON_ERROR_STOP=1 -tAc 'SELECT 1;'
  if ($LASTEXITCODE -ne 0) { throw 'Cannot connect to PostgreSQL.' }
  Write-Host '    connection OK.'

  $tableCount = [int](psql $conn -tAc "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';")
  if ($tableCount -eq 0) {
    Write-Host @'
────────────────────────────────────────────────────────────────────────────
TODO (one-time seed not yet performed) — DB has no public tables.
The canonical schema + CSV seeder lives in the API image (data/csv is baked in).
Perform the ONE-TIME seed using the existing loader, then re-run this script:

  az containerapp update -n api -g <rg> `
    --set-env-vars RUN_MIGRATIONS=true SEED_ON_BOOT=true DATA_LOAD_MODE=csv
  # wait for /api/health/ready = ready, confirm counts, then revert:
  az containerapp update -n api -g <rg> `
    --set-env-vars SEED_ON_BOOT=false DATA_LOAD_MODE=db

This script will NOT fake a successful seed.
────────────────────────────────────────────────────────────────────────────
'@
    exit 2
  }

  Write-Host "==> PART B: row counts per public table ($tableCount tables)"
  $tables = psql $conn -tAc "SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name;"
  $total = 0
  foreach ($t in $tables) {
    $t = $t.Trim()
    if (-not $t) { continue }
    $c = [int](psql $conn -tAc "SELECT count(*) FROM `"$t`";")
    '    {0,-40} {1}' -f $t, $c | Write-Host
    $total += $c
  }
  Write-Host "==> PART B complete: $tableCount tables, $total total rows."
}
else {
  Write-Host '==> PART B skipped (no -DbHost/-DbUser provided).'
}

Write-Host '==> load-phase-a-data finished.'
