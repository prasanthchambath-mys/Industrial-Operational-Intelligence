<#
.SYNOPSIS
  Validate a deployed Phase A environment (PowerShell mirror of smoke-test-phase-a.sh).

.DESCRIPTION
  Fails on not_ready, HTTP >= 400, or empty body. Provide URLs directly, or pass
  -ResourceGroup/-Env to read them from the Bicep deployment outputs (needs az login).

.EXAMPLE
  ./smoke-test-phase-a.ps1 -WebUrl https://web... -ApiUrl https://api...
  ./smoke-test-phase-a.ps1 -ResourceGroup rg-manuai-dev -Env dev
#>
[CmdletBinding()]
param(
  [string]$WebUrl = '',
  [string]$ApiUrl = '',
  [hashtable]$PythonUrls = @{},
  [string]$ResourceGroup = '',
  [string]$Env = ''
)
$ErrorActionPreference = 'Continue'

if ($ResourceGroup -and $Env) {
  if (-not (Get-Command az -ErrorAction SilentlyContinue)) { throw 'az not found (needed for -ResourceGroup/-Env mode).' }
  $out = az deployment group show -g $ResourceGroup -n "manuai-phase-a-$Env" --query properties.outputs -o json | ConvertFrom-Json
  $WebUrl = $out.webUrl.value
  $ApiUrl = $out.apiUrl.value
  $PythonUrls = @{}
  foreach ($p in $out.pythonServiceUrls.value) { $PythonUrls[$p.name] = $p.url }
}

if (-not $WebUrl -or -not $ApiUrl) { throw 'web/api URLs not resolved. Pass -WebUrl/-ApiUrl or -ResourceGroup/-Env.' }

$script:Fails = 0
function Pass($m) { Write-Host "  PASS  $m" }
function Fail($m) { Write-Host "  FAIL  $m"; $script:Fails++ }

function Check-Json {
  param([string]$Url, [string]$Label, [string]$Must = '', [string]$MustNot = '')
  try {
    $resp = Invoke-WebRequest -Uri $Url -TimeoutSec 30 -UseBasicParsing -SkipHttpErrorCheck
    $code = [int]$resp.StatusCode
    $body = [string]$resp.Content
    if ($code -ge 400) { Fail "$Label (HTTP $code)"; return }
    if ([string]::IsNullOrWhiteSpace($body)) { Fail "$Label (empty body)"; return }
    if ($MustNot -and $body.Contains($MustNot)) { Fail "$Label (contains '$MustNot')"; return }
    if ($Must -and -not $body.Contains($Must)) { Fail "$Label (missing '$Must')"; return }
    Pass "$Label (HTTP $code)"
  }
  catch { Fail "$Label ($($_.Exception.Message))" }
}

function Check-Web {
  try {
    $resp = Invoke-WebRequest -Uri "$WebUrl/" -TimeoutSec 30 -UseBasicParsing -SkipHttpErrorCheck
    if ([int]$resp.StatusCode -eq 200) { Pass 'web GET / (HTTP 200)' } else { Fail "web GET / (HTTP $([int]$resp.StatusCode))" }
  }
  catch { Fail "web GET / ($($_.Exception.Message))" }
}

Write-Host '== API health =='
Check-Json -Url "$ApiUrl/api/health/live"  -Label 'GET /api/health/live'
Check-Json -Url "$ApiUrl/api/health/ready" -Label 'GET /api/health/ready (ready)' -Must 'ready' -MustNot 'not_ready'
Check-Json -Url "$ApiUrl/api/version"      -Label 'GET /api/version'

Write-Host '== Supply APIs =='
Check-Json -Url "$ApiUrl/api/supply/dashboard-metrics"            -Label 'GET /api/supply/dashboard-metrics'
Check-Json -Url "$ApiUrl/api/supply/risks?plant=All%20Plants"     -Label 'GET /api/supply/risks'
Check-Json -Url "$ApiUrl/api/supply/inventory?plant=All%20Plants" -Label 'GET /api/supply/inventory'

Write-Host '== Web =='
Check-Web

Write-Host '== Python services =='
if ($PythonUrls.Count -gt 0) {
  foreach ($name in $PythonUrls.Keys) {
    $url = $PythonUrls[$name]
    Check-Json -Url "$url/health"  -Label "[$name] /health (live)" -Must 'live'
    Check-Json -Url "$url/ready"   -Label "[$name] /ready (ready)" -Must 'ready' -MustNot 'not_ready'
    Check-Json -Url "$url/version" -Label "[$name] /version"
  }
}
else {
  Write-Host '  (no Python URLs provided — pass -PythonUrls or use -ResourceGroup/-Env)'
}

Write-Host ''
if ($script:Fails -eq 0) { Write-Host '✅ SMOKE TEST PASSED'; exit 0 }
else { Write-Host "❌ SMOKE TEST FAILED ($script:Fails check(s))"; exit 1 }
