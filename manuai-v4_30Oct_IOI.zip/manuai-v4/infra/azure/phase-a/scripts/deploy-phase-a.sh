#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# deploy-phase-a.sh — Provision ManuAI v4 Azure Phase A via Bicep.
#
# PREREQUISITES (run yourself; this script never logs you in):
#   az login
#   az account set --subscription <SUBSCRIPTION_ID>
#
# This script does NOT hardcode any secret. The PostgreSQL admin password is
# read from the PG_ADMIN_PASSWORD environment variable, or prompted securely.
# The optional Azure OpenAI key is read from AZURE_OPENAI_API_KEY (else a
# placeholder Key Vault secret is created and can be set later).
#
# Usage:
#   PG_ADMIN_PASSWORD='****' ./deploy-phase-a.sh -g <rg> -l <location> -e <dev|test|prod>
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PHASE_A_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

RESOURCE_GROUP=""
LOCATION=""
ENV_NAME=""
SUBSCRIPTION=""

usage() {
  echo "Usage: $0 -g <resource-group> -l <location> -e <dev|test|prod> [-s <subscription-id>]"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -g|--resource-group) RESOURCE_GROUP="$2"; shift 2;;
    -l|--location)       LOCATION="$2"; shift 2;;
    -e|--env)            ENV_NAME="$2"; shift 2;;
    -s|--subscription)   SUBSCRIPTION="$2"; shift 2;;
    -h|--help)           usage;;
    *) echo "Unknown argument: $1"; usage;;
  esac
done

[[ -z "$RESOURCE_GROUP" || -z "$LOCATION" || -z "$ENV_NAME" ]] && usage

case "$ENV_NAME" in dev|test|prod) ;; *) echo "ERROR: -e must be dev|test|prod"; exit 1;; esac

PARAM_FILE="$PHASE_A_DIR/parameters.${ENV_NAME}.json"
BICEP_FILE="$PHASE_A_DIR/main.bicep"
[[ -f "$PARAM_FILE" ]] || { echo "ERROR: parameter file not found: $PARAM_FILE"; exit 1; }
[[ -f "$BICEP_FILE" ]] || { echo "ERROR: bicep file not found: $BICEP_FILE"; exit 1; }

command -v az >/dev/null 2>&1 || { echo "ERROR: Azure CLI (az) not found. Install it and run 'az login' first."; exit 1; }

# Secrets — never hardcoded.
if [[ -z "${PG_ADMIN_PASSWORD:-}" ]]; then
  read -r -s -p "PostgreSQL admin password: " PG_ADMIN_PASSWORD; echo
fi
[[ -z "$PG_ADMIN_PASSWORD" ]] && { echo "ERROR: PostgreSQL admin password is required."; exit 1; }
OPENAI_KEY="${AZURE_OPENAI_API_KEY:-}"

[[ -n "$SUBSCRIPTION" ]] && az account set --subscription "$SUBSCRIPTION"

echo "==> Creating resource group '$RESOURCE_GROUP' in '$LOCATION' (idempotent)"
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none

DEPLOYMENT_NAME="manuai-phase-a-${ENV_NAME}"
echo "==> Deploying Bicep ($DEPLOYMENT_NAME) ..."
az deployment group create \
  --resource-group "$RESOURCE_GROUP" \
  --name "$DEPLOYMENT_NAME" \
  --template-file "$BICEP_FILE" \
  --parameters "@$PARAM_FILE" \
  --parameters location="$LOCATION" \
  --parameters postgresAdminPassword="$PG_ADMIN_PASSWORD" \
  --parameters azureOpenAiApiKey="$OPENAI_KEY" \
  --output none

echo "==> Deployment complete. Outputs:"
az deployment group show \
  --resource-group "$RESOURCE_GROUP" \
  --name "$DEPLOYMENT_NAME" \
  --query properties.outputs \
  --output json

cat <<EOF

Next steps:
  1) Build & push images:  ./build-and-push-images.sh -g $RESOURCE_GROUP -r <acrName from outputs> -t latest -e $ENV_NAME
  2) Load Phase A data:    ./load-phase-a-data.sh   (see script header for args)
  3) Smoke test:           ./smoke-test-phase-a.sh -w <webUrl> -a <apiUrl>
  (acrName / webUrl / apiUrl are in the outputs above.)
EOF
