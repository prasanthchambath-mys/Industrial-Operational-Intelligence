#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# smoke-test-phase-a.sh — Validate a deployed Phase A environment.
#
# Checks (FAILS on not_ready, HTTP >=400/500, or empty body):
#   API : /api/health/live, /api/health/ready (must be "ready"), /api/version
#   API : /api/supply/dashboard-metrics, /api/supply/risks?plant=All%20Plants,
#         /api/supply/inventory?plant=All%20Plants  (non-empty)
#   Web : GET / returns HTTP 200
#   Py  : each Python service /health, /ready (must be "ready"), /version
#
# You may either pass URLs directly, or pass -g/-e to fetch them from the Bicep
# deployment outputs (requires az login).
#
# Usage:
#   ./smoke-test-phase-a.sh -w https://web... -a https://api... \
#       [-p "pdm=https://... yield=https://..."]
#   ./smoke-test-phase-a.sh -g <resource-group> -e <dev|test|prod>
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

WEB_URL=""
API_URL=""
PY_URLS=""
RESOURCE_GROUP=""
ENV_NAME=""

usage() {
  echo "Usage: $0 (-w <webUrl> -a <apiUrl> [-p \"name=url ...\"]) | (-g <rg> -e <dev|test|prod>)"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    -w|--web-url)        WEB_URL="$2"; shift 2;;
    -a|--api-url)        API_URL="$2"; shift 2;;
    -p|--python-urls)    PY_URLS="$2"; shift 2;;
    -g|--resource-group) RESOURCE_GROUP="$2"; shift 2;;
    -e|--env)            ENV_NAME="$2"; shift 2;;
    -h|--help)           usage;;
    *) echo "Unknown argument: $1"; usage;;
  esac
done

# Resolve URLs from deployment outputs if requested.
if [[ -n "$RESOURCE_GROUP" && -n "$ENV_NAME" ]]; then
  command -v az >/dev/null 2>&1 || { echo "ERROR: az not found (needed for -g/-e mode)."; exit 1; }
  OUT="$(az deployment group show -g "$RESOURCE_GROUP" -n "manuai-phase-a-${ENV_NAME}" --query properties.outputs -o json)"
  WEB_URL="$(echo "$OUT" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("webUrl",{}).get("value",""))')"
  API_URL="$(echo "$OUT" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("apiUrl",{}).get("value",""))')"
  PY_URLS="$(echo "$OUT" | python3 -c 'import sys,json;d=json.load(sys.stdin).get("pythonServiceUrls",{}).get("value",[]);print(" ".join(f"{x[\"name\"]}={x[\"url\"]}" for x in d))')"
fi

[[ -z "$WEB_URL" || -z "$API_URL" ]] && { echo "ERROR: web/api URLs not resolved."; usage; }

FAILS=0
pass() { echo "  PASS  $1"; }
fail() { echo "  FAIL  $1"; FAILS=$((FAILS+1)); }

# curl helper: prints "HTTP_CODE<TAB>BODY"
fetch() { curl -sS -m 30 -w $'\n%{http_code}' "$1" 2>/dev/null; }

check_json() { # url, label, must_contain (optional), must_not_contain (optional)
  local url="$1" label="$2" must="${3:-}" mustnot="${4:-}"
  local resp code body
  resp="$(fetch "$url")"
  code="$(echo "$resp" | tail -n1)"
  body="$(echo "$resp" | sed '$d')"
  if [[ -z "$code" || "$code" -ge 400 ]]; then fail "$label (HTTP ${code:-none})"; return; fi
  if [[ -z "${body// }" ]]; then fail "$label (empty body)"; return; fi
  if [[ -n "$mustnot" && "$body" == *"$mustnot"* ]]; then fail "$label (contains '$mustnot')"; return; fi
  if [[ -n "$must" && "$body" != *"$must"* ]]; then fail "$label (missing '$must')"; return; fi
  pass "$label (HTTP $code)"
}

check_web() {
  local code
  code="$(curl -sS -m 30 -o /dev/null -w '%{http_code}' "$WEB_URL/" 2>/dev/null)"
  [[ "$code" == "200" ]] && pass "web GET / (HTTP 200)" || fail "web GET / (HTTP ${code:-none})"
}

echo "== API health =="
check_json "$API_URL/api/health/live"    "GET /api/health/live"
check_json "$API_URL/api/health/ready"   "GET /api/health/ready (ready)" "ready" "not_ready"
check_json "$API_URL/api/version"        "GET /api/version"

echo "== Supply APIs =="
check_json "$API_URL/api/supply/dashboard-metrics"             "GET /api/supply/dashboard-metrics"
check_json "$API_URL/api/supply/risks?plant=All%20Plants"      "GET /api/supply/risks"
check_json "$API_URL/api/supply/inventory?plant=All%20Plants"  "GET /api/supply/inventory"

echo "== Web =="
check_web

echo "== Python services =="
if [[ -n "$PY_URLS" ]]; then
  for pair in $PY_URLS; do
    name="${pair%%=*}"; url="${pair#*=}"
    [[ -z "$url" || "$url" == "$name" ]] && continue
    check_json "$url/health"  "[$name] /health (live)" "live"
    check_json "$url/ready"   "[$name] /ready (ready)" "ready" "not_ready"
    check_json "$url/version" "[$name] /version"
  done
else
  echo "  (no Python URLs provided — pass -p or use -g/-e; skipping direct Python checks)"
fi

echo
if [[ "$FAILS" -eq 0 ]]; then
  echo "✅ SMOKE TEST PASSED"
  exit 0
else
  echo "❌ SMOKE TEST FAILED ($FAILS check(s))"
  exit 1
fi
