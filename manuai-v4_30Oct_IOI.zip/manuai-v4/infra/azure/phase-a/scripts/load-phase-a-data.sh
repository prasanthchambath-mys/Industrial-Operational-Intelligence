#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# load-phase-a-data.sh — Provision Phase A DATA (governed CSV extracts). Two parts:
#
#   PART A  Upload CSVs to the Azure Files share consumed by the Python services
#           (they run DATA_SOURCE=csv and mount the share at /app/data/csv).
#           Idempotent: re-uploading overwrites.
#
#   PART B  Seed the API's PostgreSQL database from the same governed CSVs, using
#           the EXISTING migration + seeder baked into the API image. This script
#           does NOT re-implement the seeder (the canonical loader lives in the
#           API). It verifies connectivity, prints the recommended one-time seed
#           procedure, and then logs row counts per table so you can confirm the
#           load. Where a step depends on your deployment choice it FAILS LOUD
#           with a TODO rather than pretending success.
#
# No Mumbai/Pune/supplier/KPI values are referenced here — table names are
# discovered generically from information_schema.
#
# PREREQUISITES: az login; psql client installed (for PART B counts).
#
# Usage:
#   ./load-phase-a-data.sh \
#     --storage-account <acct> --resource-group <rg> \
#     --db-host <pg-fqdn> --db-name manuai --db-user manuai_admin \
#     --ssl-mode require --csv-dir ../../../../data/csv
#
#   PGPASSWORD must be exported for PART B:  export PGPASSWORD='****'
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_CSV_DIR="$(cd "$SCRIPT_DIR/../../../.." && pwd)/data/csv"

STORAGE_ACCOUNT=""
RESOURCE_GROUP=""
FILE_SHARE="csvdata"
DB_HOST=""
DB_NAME="manuai"
DB_USER=""
SSL_MODE="require"
CSV_DIR="$DEFAULT_CSV_DIR"

usage() {
  cat <<EOF
Usage: $0 [options]
  --storage-account <name>   Azure Storage account hosting the CSV file share (PART A)
  --resource-group  <name>   Resource group (to read the storage key)
  --file-share      <name>   File share name (default: csvdata)
  --db-host         <fqdn>   PostgreSQL host (PART B)
  --db-name         <name>   Database name (default: manuai)
  --db-user         <user>   PostgreSQL user
  --ssl-mode        <mode>   SSL mode (default: require)
  --csv-dir         <path>   Local CSV directory (default: repo data/csv)
EOF
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --storage-account) STORAGE_ACCOUNT="$2"; shift 2;;
    --resource-group)  RESOURCE_GROUP="$2"; shift 2;;
    --file-share)      FILE_SHARE="$2"; shift 2;;
    --db-host)         DB_HOST="$2"; shift 2;;
    --db-name)         DB_NAME="$2"; shift 2;;
    --db-user)         DB_USER="$2"; shift 2;;
    --ssl-mode)        SSL_MODE="$2"; shift 2;;
    --csv-dir)         CSV_DIR="$2"; shift 2;;
    -h|--help)         usage;;
    *) echo "Unknown argument: $1"; usage;;
  esac
done

[[ -d "$CSV_DIR" ]] || { echo "ERROR: CSV directory not found: $CSV_DIR"; exit 1; }
CSV_COUNT="$(find "$CSV_DIR" -maxdepth 1 -name '*.csv' | wc -l | tr -d ' ')"
[[ "$CSV_COUNT" -gt 0 ]] || { echo "ERROR: no .csv files found in $CSV_DIR"; exit 1; }
echo "==> Found $CSV_COUNT CSV files in $CSV_DIR"

# ── PART A — upload CSVs to Azure Files (for Python services) ─────────────────
if [[ -n "$STORAGE_ACCOUNT" && -n "$RESOURCE_GROUP" ]]; then
  command -v az >/dev/null 2>&1 || { echo "ERROR: az not found (needed for PART A)."; exit 1; }
  echo "==> PART A: uploading CSVs to Azure Files share '$FILE_SHARE' on '$STORAGE_ACCOUNT'"
  KEY="$(az storage account keys list --account-name "$STORAGE_ACCOUNT" --resource-group "$RESOURCE_GROUP" --query '[0].value' -o tsv)"
  [[ -z "$KEY" ]] && { echo "ERROR: could not read storage key for $STORAGE_ACCOUNT"; exit 1; }
  az storage file upload-batch \
    --account-name "$STORAGE_ACCOUNT" \
    --account-key "$KEY" \
    --destination "$FILE_SHARE" \
    --source "$CSV_DIR" \
    --pattern '*.csv' \
    --output none
  echo "==> PART A complete: $CSV_COUNT CSVs uploaded (idempotent overwrite)."
else
  echo "==> PART A skipped (no --storage-account/--resource-group provided)."
fi

# ── PART B — PostgreSQL seed verification + counts ────────────────────────────
if [[ -n "$DB_HOST" && -n "$DB_USER" ]]; then
  command -v psql >/dev/null 2>&1 || { echo "ERROR: psql not found (needed for PART B)."; exit 1; }
  [[ -n "${PGPASSWORD:-}" ]] || { echo "ERROR: export PGPASSWORD before running PART B."; exit 1; }
  export PGSSLMODE="$SSL_MODE"
  CONN=(psql "host=$DB_HOST dbname=$DB_NAME user=$DB_USER sslmode=$SSL_MODE" -v ON_ERROR_STOP=1 -tAc)

  echo "==> PART B: verifying PostgreSQL connectivity to $DB_HOST/$DB_NAME"
  "${CONN[@]}" "SELECT 1;" >/dev/null || { echo "ERROR: cannot connect to PostgreSQL."; exit 1; }
  echo "    connection OK."

  TABLE_COUNT="$("${CONN[@]}" "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';")"
  if [[ "${TABLE_COUNT:-0}" -eq 0 ]]; then
    cat <<'EOF'
────────────────────────────────────────────────────────────────────────────
TODO (one-time seed not yet performed) — DB has no public tables.
The canonical schema + CSV seeder lives in the API image (data/csv is baked in).
Perform the ONE-TIME seed using the existing loader, then re-run this script:

  # Option 1 (recommended): run a one-time API revision that seeds, then revert
  az containerapp update -n api -g <rg> \
    --set-env-vars RUN_MIGRATIONS=true SEED_ON_BOOT=true DATA_LOAD_MODE=csv
  # ...wait for /api/health/ready = ready, confirm counts below, then revert:
  az containerapp update -n api -g <rg> \
    --set-env-vars SEED_ON_BOOT=false DATA_LOAD_MODE=db

  # Option 2: run the API image once as an ACA Job with the same seed env vars.

This script will NOT fake a successful seed.
────────────────────────────────────────────────────────────────────────────
EOF
    exit 2
  fi

  echo "==> PART B: row counts per public table ($TABLE_COUNT tables)"
  TABLES="$("${CONN[@]}" "SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name;")"
  TOTAL=0
  while IFS= read -r t; do
    [[ -z "$t" ]] && continue
    c="$("${CONN[@]}" "SELECT count(*) FROM \"$t\";")"
    printf "    %-40s %s\n" "$t" "$c"
    TOTAL=$((TOTAL + c))
  done <<< "$TABLES"
  echo "==> PART B complete: $TABLE_COUNT tables, $TOTAL total rows."
else
  echo "==> PART B skipped (no --db-host/--db-user provided)."
fi

echo "==> load-phase-a-data finished."
