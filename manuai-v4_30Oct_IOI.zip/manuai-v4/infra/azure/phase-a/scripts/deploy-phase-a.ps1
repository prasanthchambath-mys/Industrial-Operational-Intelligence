<#
.SYNOPSIS
  Provision ManuAI v4 Azure Phase A via Bicep (PowerShell).

.DESCRIPTION
  Does NOT log you in. Run `az login` (and `az account set --subscription ...`)
  first. No secret is hardcoded: the PostgreSQL admin password is read from the
  PG_ADMIN_PASSWORD environment variable or prompted securely; the optional Azure
  OpenAI key is read from AZURE_OPENAI_API_KEY.

.EXAMPLE
  $env:PG_ADMIN_PASSWORD = '****'
  ./deploy-phase-a.ps1 -ResourceGroup rg-manuai-dev -Location eastus -Env dev
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$ResourceGroup,
  [Parameter(Mandatory = $true)][string]$Location,
  [Parameter(Mandatory = $true)][ValidateSet('dev', 'test', 'prod')][string]$Env,
  [string]$Subscription = ''
)
$ErrorActionPreference = 'Stop'

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$phaseADir = Resolve-Path (Join-Path $scriptDir '..')
$bicep     = Join-Path $phaseADir 'main.bicep'
$paramFile = Join-Path $phaseADir "parameters.$Env.json"

if (-not (Test-Path $bicep))     { throw "Bicep file not found: $bicep" }
if (-not (Test-Path $paramFile)) { throw "Parameter file not found: $paramFile" }
if (-not (Get-Command az -ErrorAction SilentlyContinue)) { throw "Azure CLI (az) not found. Run 'az login' first." }

# Secrets — never hardcoded.
$pgPassword = $env:PG_ADMIN_PASSWORD
if ([string]::IsNullOrEmpty($pgPassword)) {
  $secure = Read-Host -AsSecureString 'PostgreSQL admin password'
  $pgPassword = [System.Net.NetworkCredential]::new('', $secure).Password
}
if ([string]::IsNullOrEmpty($pgPassword)) { throw 'PostgreSQL admin password is required.' }
$openAiKey = if ($env:AZURE_OPENAI_API_KEY) { $env:AZURE_OPENAI_API_KEY } else { '' }

if ($Subscription) { az account set --subscription $Subscription }

Write-Host "==> Creating resource group '$ResourceGroup' in '$Location' (idempotent)"
az group create --name $ResourceGroup --location $Location --output none

$deployment = "manuai-phase-a-$Env"
Write-Host "==> Deploying Bicep ($deployment) ..."
az deployment group create `
  --resource-group $ResourceGroup `
  --name $deployment `
  --template-file $bicep `
  --parameters "@$paramFile" `
  --parameters location=$Location `
  --parameters postgresAdminPassword=$pgPassword `
  --parameters azureOpenAiApiKey=$openAiKey `
  --output none

Write-Host '==> Deployment complete. Outputs:'
az deployment group show --resource-group $ResourceGroup --name $deployment --query properties.outputs --output json

Write-Host @"

Next steps:
  1) Build & push images:  ./build-and-push-images.ps1 -ResourceGroup $ResourceGroup -AcrName <acrName> -Tag latest -Env $Env
  2) Load Phase A data:    ./load-phase-a-data.ps1   (see script header for args)
  3) Smoke test:           ./smoke-test-phase-a.ps1 -WebUrl <webUrl> -ApiUrl <apiUrl>
  (acrName / webUrl / apiUrl are in the outputs above.)
"@
