# Phase A — Deployment Runbook

Audience: program manager / delivery lead coordinating with IT. This is the
end-to-end procedure to stand up ManuAI v4 Phase A on Azure. None of this affects
the local demo, which still runs with `docker compose up --build`.

---

## 1. What you are deploying

A managed-Azure version of the same product: nine Container Apps (web, api, and
seven AI services), a PostgreSQL database, Redis, a private container registry, a
secrets vault, a managed identity, and monitoring. The AI services keep running on
their built-in rule engines using governed CSV data.

## 2. What stays local / synthetic

* The AI agents' data is still **governed CSV / synthetic**, not live plant data.
* The seven AI services do **not** use the database; they read CSVs.
* Pre-trained ML models ship dormant; scoring uses the rule engine.

## 3. What is **not** activated (and why)

| Capability | Status in Phase A | Why |
|---|---|---|
| Live connectors (SAP / PI / LIMS / OPC) | Off | Phase A is a governed-data deployment; connectors are a later phase |
| Azure ML scoring | Off (`ML_LOCAL=false`, `AML_ENABLED=false`) | Rule engine is sufficient and keeps cost/complexity down |
| Azure Digital Twins | Off | Twin service uses its local simulation |
| Python `DATA_SOURCE=db` | Off | Not implemented; `/ready` honestly reports this if forced on |

## 4. Required IT access (request before you start)

| Need | Typical Azure role |
|---|---|
| An Azure **subscription** to deploy into | — |
| Create/use a **resource group** | Contributor on the RG (or ability to create it) |
| **Push images** to the registry | AcrPush on the ACR (the app pulls via Managed Identity automatically) |
| Manage **Container Apps** | Container Apps Contributor |
| **PostgreSQL** admin / connection approval | server admin credentials + firewall/network approval |
| Manage **Key Vault** secrets | Key Vault Secrets Officer (to set the OpenAI key) |
| Assign roles used by the template | the deploying principal needs rights to create role assignments (Owner or User Access Administrator on the RG) |

> The deployment creates role assignments (AcrPull, Key Vault Secrets User) for
> the Managed Identity. If your principal cannot create role assignments, ask IT
> to grant **User Access Administrator** on the resource group, or to create those
> two assignments manually after the resources exist.

## 5. Prerequisites on your machine

* Azure CLI (`az`) + the Bicep extension.
* Docker (for `build-and-push-images`).
* `psql` client (for the data-load verification step).
* Run `az login` and `az account set --subscription <id>` first. **Scripts never
  log you in.**

## 6. Deployment steps

```bash
cd infra/azure/phase-a

# (optional but recommended) validate the template first
az bicep build --file main.bicep
az deployment group validate -g rg-manuai-dev -f main.bicep \
  -p @parameters.dev.json -p postgresAdminPassword='********' -p location=eastus

cd scripts

# 1) Provision all Azure resources
PG_ADMIN_PASSWORD='********' ./deploy-phase-a.sh -g rg-manuai-dev -l eastus -e dev
#    → note the outputs: acrName, webUrl, apiUrl, storageAccountName, postgresFqdn

# 2) Build & push the 9 images from the existing Dockerfiles
./build-and-push-images.sh -g rg-manuai-dev -r <acrName> -t latest -e dev

# 3) Load Phase A data
#    PART A uploads CSVs to Azure Files (for the AI services)
#    PART B verifies/seeds PostgreSQL (see one-time seed below)
export PGPASSWORD='********'
./load-phase-a-data.sh \
  --storage-account <storageAccountName> --resource-group rg-manuai-dev \
  --db-host <postgresFqdn> --db-name manuai --db-user manuai_admin --ssl-mode require

# 4) Validate
./smoke-test-phase-a.sh -g rg-manuai-dev -e dev
```

PowerShell equivalents (`.ps1`) exist for every script with the same behavior.

### One-time database seed

The API image bakes the CSV seed data and contains the canonical migrations +
seeder. On a brand-new database, run the API **once** in seed mode, then revert:

```bash
az containerapp update -n api -g rg-manuai-dev \
  --set-env-vars RUN_MIGRATIONS=true SEED_ON_BOOT=true DATA_LOAD_MODE=csv
# wait until /api/health/ready reports "ready", confirm row counts:
./load-phase-a-data.sh --db-host <pgFqdn> --db-name manuai --db-user manuai_admin --ssl-mode require
# then return to steady state:
az containerapp update -n api -g rg-manuai-dev \
  --set-env-vars SEED_ON_BOOT=false DATA_LOAD_MODE=db
```

`load-phase-a-data` will **fail loudly** (exit 2) if the database is still empty —
it never reports a fake success.

## 7. Validation checklist

Run `smoke-test-phase-a` and confirm every line is `PASS`. Details in
`phase-a-smoke-test-checklist.md`.

## 8. Rollback

See `phase-a-rollback-plan.md`. In short: redeploy the previous image tag, or
delete the resource group to remove everything.

## 9. Known limitations / hardening TODOs (do before production)

* **Database networking**: Phase A uses the "Allow Azure services" firewall rule.
  For production, move PostgreSQL behind a **Private Endpoint / VNet** and remove
  the public rule.
* **Public ingress**: in dev/test the API and AI services are publicly reachable
  (so smoke tests can hit them). For production set
  `exposePythonServicesExternally=false` (already the default in
  `parameters.prod.json`) and consider making the API internal-only behind `web`.
* **CORS**: `CORS_ORIGINS` defaults to `*`. Tighten to the web URL.
* **Azure OpenAI**: the key is a placeholder until you run
  `az keyvault secret set … --name azure-openai-api-key`. Until then, AI chat
  responses will report the key is not configured.
* **Entra values**: `AUTH_*` are placeholders; fill them in `parameters.<env>.json`
  (or via app settings) with your tenant's JWKS URI, issuer, audience, client ID.
* **Python DB mode** is not implemented; the AI services remain CSV-backed.
