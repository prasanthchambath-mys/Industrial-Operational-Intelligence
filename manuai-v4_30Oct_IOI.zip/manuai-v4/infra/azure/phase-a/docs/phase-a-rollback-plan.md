# Phase A — Rollback Plan

Goal: get back to a known-good state quickly if a Phase A deploy goes wrong.
Nothing here touches the local demo, which is always available as a fallback via
`docker compose up --build`.

---

## Severity guide

| Situation | Recommended rollback |
|---|---|
| A new image is bad (app crashes / smoke test fails) | **Roll back the image tag** (fastest) |
| A config/env change broke the app | **Revert the Container App revision** |
| The whole environment is wrong / a clean restart is wanted | **Redeploy** previous parameters, or **delete the resource group** |
| Database data is bad | **Re-seed** from CSV (data is governed/synthetic, so this is safe) |

---

## 1. Roll back a single app to a previous image

Container Apps keep previous revisions. List and re-activate the last good one:

```bash
az containerapp revision list -n api -g <rg> -o table
az containerapp revision activate -n api -g <rg> --revision <previous-good-revision>
```

Or repoint to a previous image tag and let a new revision roll out:

```bash
az containerapp update -n api -g <rg> --image <acrLoginServer>/api:<previous-tag>
```

Repeat for `web` or any AI service as needed. Keep image tags immutable per
release (e.g. `2025-06-30-1`) so "the previous tag" is unambiguous.

## 2. Revert a configuration change

If an environment variable change caused the problem, set it back and a new
revision is created automatically:

```bash
az containerapp update -n api -g <rg> --set-env-vars DATA_LOAD_MODE=db SEED_ON_BOOT=false
```

## 3. Redeploy the whole stack with known-good parameters

`main.bicep` is idempotent. Re-running the deploy with the previous parameter file
and image tag reconciles everything back:

```bash
cd infra/azure/phase-a/scripts
PG_ADMIN_PASSWORD='********' ./deploy-phase-a.sh -g <rg> -l <location> -e <env>
```

## 4. Re-seed the database (data rollback)

Because Phase A data is governed CSV/synthetic, re-seeding is safe:

```bash
az containerapp update -n api -g <rg> \
  --set-env-vars RUN_MIGRATIONS=true SEED_ON_BOOT=true DATA_LOAD_MODE=csv
# wait for /api/health/ready = ready, verify counts, then:
az containerapp update -n api -g <rg> \
  --set-env-vars SEED_ON_BOOT=false DATA_LOAD_MODE=db
```

> If the schema itself is suspect, drop and recreate the `manuai` database (or use
> a fresh database name) and run the one-time seed again. Coordinate with IT/DBA
> since this requires PostgreSQL admin access.

## 5. Full teardown (last resort)

Deleting the resource group removes **all** Phase A resources (registry, database,
Redis, vault, apps, monitoring). Irreversible — back up anything you need first.

```bash
az group delete --name <rg> --yes --no-wait
```

## 6. Always-available fallback

The local demo is unaffected by any Azure change and remains the safe baseline:

```bash
docker compose up --build
```
