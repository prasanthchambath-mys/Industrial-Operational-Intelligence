# Phase A — Smoke Test Checklist

Run after deploy + build/push + data load. Use the script, then eyeball this list.

```bash
cd infra/azure/phase-a/scripts
./smoke-test-phase-a.sh -g rg-manuai-dev -e dev
# or pass URLs directly:
./smoke-test-phase-a.sh -w <webUrl> -a <apiUrl> -p "pdm-inference=<url> yield-optimizer=<url> ..."
```

The script **fails** (non-zero exit) if any endpoint returns `not_ready`, an HTTP
status ≥ 400, or an empty body.

## What it checks

### API
- [ ] `GET /api/health/live` → 200, body present
- [ ] `GET /api/health/ready` → 200 **and** body contains `ready` (not `not_ready`)
- [ ] `GET /api/version` → 200, body present

### Supply APIs (governed data is loaded)
- [ ] `GET /api/supply/dashboard-metrics` → 200, non-empty
- [ ] `GET /api/supply/risks?plant=All%20Plants` → 200, non-empty
- [ ] `GET /api/supply/inventory?plant=All%20Plants` → 200, non-empty

### Web
- [ ] `GET /` → HTTP 200

### Each Python AI service (pdm, yield, energy, quality, supply, twin, safety)
- [ ] `GET /health` → 200, contains `live`
- [ ] `GET /ready` → 200 **and** contains `ready` (CSVs present on the Azure Files mount)
- [ ] `GET /version` → 200, reports `appEnv: azure-phase-a`, `version: phase-a`

## If a check fails

| Symptom | Likely cause | Action |
|---|---|---|
| API `/ready` = `not_ready` | DB empty or unreachable / Redis down | run the one-time seed; check `DATABASE_URL`/`REDIS_URL` secrets; check PostgreSQL firewall |
| Supply APIs empty | DB not seeded | run one-time seed (runbook §6) and re-run `load-phase-a-data` to confirm counts |
| Python `/ready` = `not_ready`, lists missing CSVs | Azure Files share not populated | run `load-phase-a-data` PART A (CSV upload) |
| Python endpoints unreachable | services deployed internal-only | use `exposePythonServicesExternally=true` (dev/test) or validate from inside the environment |
| Web ≠ 200 | image/tag mismatch or app still starting | confirm `build-and-push` ran with the deployed tag; check revision status |
| AI chat says key missing | OpenAI key still placeholder | `az keyvault secret set … --name azure-openai-api-key` |
