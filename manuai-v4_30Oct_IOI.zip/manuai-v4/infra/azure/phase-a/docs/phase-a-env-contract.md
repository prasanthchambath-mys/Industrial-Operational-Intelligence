# Phase A — Environment Variable Contract

This document lists every environment variable each Container App receives in
Phase A, where its value comes from, and (importantly) how the variable names in
the original task brief map to the names the **code actually reads**.

> **Naming note (read this first).** The task brief used short names like
> `JWKS_URI`, `JWT_ISSUER`, `JWT_AUDIENCE`. The API code reads the `AUTH_`-prefixed
> names (`AUTH_JWKS_URI`, `AUTH_ISSUER`, `AUTH_AUDIENCE`). The Bicep wires the
> **code names** so sign-in actually works. The mapping is called out below so
> there is no ambiguity.

---

## API Container App (`api`)

| Variable | Phase A value | Source | Read by |
|---|---|---|---|
| `APP_ENV` | `azure-phase-a` | Bicep literal | informational |
| `NODE_ENV` | `production` | Bicep literal | server |
| `PORT` | `4000` | Bicep literal | server |
| `DB_PROVIDER` | `postgres` | Bicep literal | `database/connection.ts` |
| `DATABASE_URL` | `postgresql://…?sslmode=require` | **Key Vault secret** `database-url` | `database/connection.ts` |
| `PG_POOL_MAX` | *(unset; pool default)* | — | `database/connection.ts` |
| `RUN_MIGRATIONS` | `true` | Bicep literal | `index.ts` |
| `SEED_ON_BOOT` | `false` | Bicep literal | `index.ts` |
| `DATA_LOAD_MODE` | `db` | Bicep literal | `index.ts` / `startup-state.ts` |
| `EVENT_BUS` | `redis` | Bicep literal | `websocket/broadcaster.ts` |
| `REDIS_REQUIRED` | `true` | Bicep literal | `websocket/broadcaster.ts` |
| `REDIS_URL` | `rediss://:<key>@<host>:6380` | **Key Vault secret** `redis-url` | `websocket/broadcaster.ts` |
| `MOCK_AUTH` | `false` | Bicep literal | `middleware/auth.ts` |
| `AUTH_PROVIDER` | `entra` | Bicep literal | informational |
| `AUTH_JWKS_URI` | *(placeholder param)* | `parameters.<env>.json` → `authJwksUri` | `middleware/auth.ts` |
| `AUTH_ISSUER` | *(placeholder param)* | `authIssuer` | `middleware/auth.ts` |
| `AUTH_AUDIENCE` | *(placeholder param)* | `authAudience` | `middleware/auth.ts` |
| `AUTH_CLIENT_ID` | *(placeholder param)* | `authClientId` | `middleware/auth.ts` |
| `AUTH_ROLES_FROM_GROUPS` | `true` | Bicep literal | `middleware/auth.ts` |
| `LLM_PROVIDER` | `azure_openai` | Bicep literal | `ai/llm-client.ts` |
| `AZURE_OPENAI_ENDPOINT` | *(placeholder param)* | `azureOpenAiEndpoint` | `ai/llm-client.ts` |
| `AZURE_OPENAI_DEPLOYMENT` | `gpt-4o` (default) | `azureOpenAiDeployment` | `ai/llm-client.ts` |
| `AZURE_OPENAI_API_KEY` | placeholder until set | **Key Vault secret** `azure-openai-api-key` | `ai/llm-client.ts` |
| `CSV_DATA_DIR` | `/app/data/csv` | Bicep literal | reference reads |
| `CORS_ORIGINS` | `*` (tighten later) | `corsOrigins` | `index.ts` / broadcaster |
| `PDM_SERVICE_URL` … `SAFETY_SERVICE_URL` | each service's internal/public URL | computed in Bicep | API → Python calls |

### Brief → code name mapping

| Brief name | Actual code name (wired) |
|---|---|
| `JWKS_URI` | `AUTH_JWKS_URI` |
| `JWT_ISSUER` | `AUTH_ISSUER` |
| `JWT_AUDIENCE` | `AUTH_AUDIENCE` |
| *(implied)* | `AUTH_CLIENT_ID`, `AUTH_ROLES_FROM_GROUPS` |
| *(implied OpenAI selector)* | `LLM_PROVIDER=azure_openai` (required to use Azure OpenAI) |

---

## Python AI services (all seven)

| Variable | Phase A value | Source | Read by |
|---|---|---|---|
| `APP_ENV` | `azure-phase-a` | Bicep literal | `service_health.py` (`/version`) |
| `DATA_SOURCE` | `csv` | Bicep literal | `service_health.py` (`/ready`) |
| `ML_LOCAL` | `false` | Bicep literal | service ML toggle + `/ready` |
| `AML_ENABLED` | `false` | Bicep literal | `/ready` |
| `SERVICE_VERSION` | `phase-a` | Bicep literal | `/version` |
| `CSV_DATA_DIR` | `/app/data/csv` | Bicep literal | `ml_thresholds.py`, `/ready` |

The CSV files are served from an **Azure Files share** (`csvdata`) mounted
read-only at `/app/data/csv`. Populate it with `load-phase-a-data` (PART A).
`DATA_SOURCE=db` is intentionally **not** implemented for Python services in
Phase A; if set, `/ready` returns `503 not_ready` with a clear reason rather than
pretending to be ready.

---

## Web Container App (`web`)

| Variable | Phase A value | Source |
|---|---|---|
| `APP_ENV` | `azure-phase-a` | Bicep literal |
| `API_UPSTREAM` | the API app's HTTPS URL | computed in Bicep |

The web container is nginx; it serves the built React app and proxies `/api` and
`/socket.io` to `API_UPSTREAM` at runtime (no rebuild needed to repoint it).

---

## Secret sources (never in source control)

| Secret | Where it lives | How to set/rotate |
|---|---|---|
| PostgreSQL admin password | deploy-time `@secure()` param → used to build `database-url` in Key Vault | `PG_ADMIN_PASSWORD` env / prompt at deploy |
| `database-url` | Key Vault secret | assembled by `keyvault.bicep` |
| `redis-url` | Key Vault secret | assembled by `keyvault.bicep` |
| `azure-openai-api-key` | Key Vault secret (placeholder if empty) | `az keyvault secret set --vault-name <kv> --name azure-openai-api-key --value <key>` |

Container Apps reference these via the Managed Identity (`Key Vault Secrets User`),
so no secret is ever stored as a plaintext environment variable.
