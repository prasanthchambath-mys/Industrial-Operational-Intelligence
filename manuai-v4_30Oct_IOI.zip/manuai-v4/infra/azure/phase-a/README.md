# ManuAI v4 — Azure Phase A (Infrastructure & Deployment)

This folder contains everything needed to deploy ManuAI v4 to Azure for **Phase A**.
It is **additive**: it does not change how the product runs locally. The local
demo command is unchanged:

```bash
docker compose up --build
```

Phase A moves the same containers onto managed Azure services, swaps SQLite for a
managed PostgreSQL database, turns on Redis and real sign-in, and keeps the
AI-agent microservices running on their built-in rule engines (no Azure ML yet).

---

## What's in here

```
infra/azure/phase-a/
  README.md                     ← you are here
  main.bicep                    ← top-level deployment (calls the modules)
  parameters.dev/test/prod.json ← per-environment settings (NO secrets)
  modules/
    identity.bicep              ← Managed Identity (pulls images, reads secrets)
    acr.bicep                   ← Azure Container Registry
    monitoring.bicep            ← Log Analytics + Application Insights
    keyvault.bicep              ← Key Vault + the three connection-string secrets
    postgres.bicep              ← Azure PostgreSQL Flexible Server
    redis.bicep                 ← Azure Cache for Redis
    container-apps.bicep        ← Container Apps env + Azure Files + all 9 apps
  scripts/
    deploy-phase-a.{sh,ps1}        ← provision all Azure resources
    build-and-push-images.{sh,ps1} ← build the 9 images, push to ACR
    load-phase-a-data.{sh,ps1}     ← upload CSVs + verify/seed PostgreSQL
    smoke-test-phase-a.{sh,ps1}    ← validate the live deployment
  docs/
    phase-a-env-contract.md        ← every environment variable, and its source
    phase-a-deployment-runbook.md  ← step-by-step deploy + required IT access
    phase-a-smoke-test-checklist.md← what "good" looks like
    phase-a-rollback-plan.md       ← how to undo a bad deploy
```

## What Phase A deploys

Nine Container Apps (`web`, `api`, and the seven AI services
`pdm-inference`, `yield-optimizer`, `energy-optimizer`, `quality-vision`,
`supply-intelligence`, `twin-sync`, `safety-monitor`), plus a Container Registry,
PostgreSQL Flexible Server, Cache for Redis, Key Vault, a Managed Identity, and
Log Analytics / Application Insights.

## What is **not** turned on in Phase A

* **Live connectors** (SAP, PI System, LIMS, OPC) — the data stays governed CSV/synthetic.
* **Azure ML** — the AI services run their built-in rule engines (`ML_LOCAL=false`).
* **Azure Digital Twins** — the twin service runs its local simulation.
* **Python database mode** — the AI services still read CSVs (`DATA_SOURCE=csv`);
  only the API uses PostgreSQL.

See `docs/phase-a-deployment-runbook.md` for the full walkthrough and
`docs/phase-a-env-contract.md` for the exact configuration each service receives.

## Quick start (after `az login`)

```bash
cd infra/azure/phase-a/scripts
PG_ADMIN_PASSWORD='********' ./deploy-phase-a.sh -g rg-manuai-dev -l eastus -e dev
./build-and-push-images.sh  -g rg-manuai-dev -r <acrName-from-outputs> -t latest -e dev
./load-phase-a-data.sh --storage-account <acct> --resource-group rg-manuai-dev \
  --db-host <pgFqdn> --db-name manuai --db-user manuai_admin --ssl-mode require
./smoke-test-phase-a.sh -g rg-manuai-dev -e dev
```

> **Validate the Bicep before deploying** (needs Azure CLI + Bicep):
> `az bicep build --file ../main.bicep` and
> `az deployment group validate -g <rg> -f ../main.bicep -p @../parameters.dev.json -p postgresAdminPassword=...`
