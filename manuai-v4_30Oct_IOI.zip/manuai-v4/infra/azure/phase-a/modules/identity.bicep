// ─────────────────────────────────────────────────────────────────────────────
// identity.bicep — User-Assigned Managed Identity
// Used by Container Apps to: pull images from ACR (AcrPull) and read Key Vault
// secrets (Key Vault Secrets User). No secrets or credentials are defined here.
// ─────────────────────────────────────────────────────────────────────────────
@description('Azure region for the identity.')
param location string

@description('Resource name prefix, e.g. "manuai".')
param namePrefix string

@description('Environment name: dev | test | prod.')
param environmentName string

resource uami 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = {
  name: '${namePrefix}-${environmentName}-id'
  location: location
}

output id string = uami.id
output name string = uami.name
output principalId string = uami.properties.principalId
output clientId string = uami.properties.clientId
