// ─────────────────────────────────────────────────────────────────────────────
// acr.bicep — Azure Container Registry + AcrPull grant to the managed identity.
// Admin user is DISABLED on purpose: image pulls use the managed identity, so no
// registry username/password is ever stored as a secret.
// ─────────────────────────────────────────────────────────────────────────────
@description('Azure region.')
param location string

@description('Globally-unique ACR name (5–50 chars, lowercase alphanumeric, no hyphens).')
param acrName string

@description('SKU for the registry.')
@allowed([ 'Basic', 'Standard', 'Premium' ])
param sku string = 'Standard'

@description('Principal ID (objectId) of the managed identity that pulls images.')
param pullPrincipalId string

resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: acrName
  location: location
  sku: {
    name: sku
  }
  properties: {
    adminUserEnabled: false
  }
}

// Built-in role: AcrPull
var acrPullRoleId = '7f951dda-4ed3-4680-a7ca-43fe172d538d'

resource acrPullAssignment 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(acr.id, pullPrincipalId, acrPullRoleId)
  scope: acr
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', acrPullRoleId)
    principalId: pullPrincipalId
    principalType: 'ServicePrincipal'
  }
}

output loginServer string = acr.properties.loginServer
output name string = acr.name
output id string = acr.id
