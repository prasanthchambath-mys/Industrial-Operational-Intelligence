// ─────────────────────────────────────────────────────────────────────────────
// redis.bicep — Azure Cache for Redis (TLS-only).
// Phase A default: Basic C1. The primary key is emitted as a module output so
// main.bicep can hand it to keyvault.bicep, which assembles the rediss:// URL as
// a Key Vault secret. The key is never placed in a Container App env var in
// plaintext — only referenced via Key Vault.
// ─────────────────────────────────────────────────────────────────────────────
@description('Azure region.')
param location string

@description('Resource name prefix.')
param namePrefix string

@description('Environment name: dev | test | prod.')
param environmentName string

@description('Redis SKU name.')
@allowed([ 'Basic', 'Standard', 'Premium' ])
param skuName string = 'Basic'

@description('Redis SKU family: C (Basic/Standard) or P (Premium).')
@allowed([ 'C', 'P' ])
param skuFamily string = 'C'

@description('Redis capacity (0–6 for C family).')
param skuCapacity int = 1

resource redis 'Microsoft.Cache/redis@2023-08-01' = {
  name: '${namePrefix}-${environmentName}-redis'
  location: location
  properties: {
    sku: {
      name: skuName
      family: skuFamily
      capacity: skuCapacity
    }
    enableNonSslPort: false
    minimumTlsVersion: '1.2'
    redisConfiguration: {}
  }
}

output hostName string = redis.properties.hostName
output sslPort int = redis.properties.sslPort
output name string = redis.name
#disable-next-line outputs-should-not-contain-secrets
output primaryKey string = redis.listKeys().primaryKey
