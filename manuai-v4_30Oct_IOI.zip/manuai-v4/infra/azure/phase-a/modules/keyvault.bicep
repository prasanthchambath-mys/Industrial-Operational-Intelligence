// ─────────────────────────────────────────────────────────────────────────────
// keyvault.bicep — Key Vault (RBAC mode) + secret material for Phase A.
// Secret VALUES are built here from components passed in as @secure() params so
// the connection strings are assembled in exactly one place. Nothing is printed
// to outputs except the (non-secret) versionless secret URIs that Container Apps
// reference. The managed identity is granted "Key Vault Secrets User".
// ─────────────────────────────────────────────────────────────────────────────
@description('Azure region.')
param location string

@description('Globally-unique Key Vault name (3–24 chars, alphanumeric/hyphen).')
param keyVaultName string

@description('Entra tenant ID.')
param tenantId string = subscription().tenantId

@description('Principal ID of the managed identity that reads secrets.')
param readerPrincipalId string

// ── Components used to assemble connection-string secrets ────────────────────
@description('PostgreSQL fully-qualified domain name.')
param postgresFqdn string
@description('PostgreSQL administrator login.')
param postgresLogin string
@secure()
@description('PostgreSQL administrator password.')
param postgresPassword string
@description('PostgreSQL database name.')
param postgresDatabase string

@description('Redis host name.')
param redisHost string
@description('Redis SSL port (usually 6380).')
param redisSslPort int
@secure()
@description('Redis primary access key.')
param redisPrimaryKey string

@secure()
@description('Azure OpenAI API key. Leave empty until provisioned; a placeholder secret is still created so Container Apps can reference it.')
param azureOpenAiApiKey string = ''

resource kv 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: keyVaultName
  location: location
  properties: {
    tenantId: tenantId
    sku: {
      family: 'A'
      name: 'standard'
    }
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
    enabledForTemplateDeployment: true
  }
}

// Built-in role: Key Vault Secrets User
var kvSecretsUserRoleId = '4633458b-17de-408a-b874-0445c86b69e6'

resource kvReader 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(kv.id, readerPrincipalId, kvSecretsUserRoleId)
  scope: kv
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', kvSecretsUserRoleId)
    principalId: readerPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource secretDatabaseUrl 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'database-url'
  properties: {
    value: 'postgresql://${postgresLogin}:${postgresPassword}@${postgresFqdn}:5432/${postgresDatabase}?sslmode=require'
  }
}

resource secretRedisUrl 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'redis-url'
  properties: {
    value: 'rediss://:${redisPrimaryKey}@${redisHost}:${redisSslPort}'
  }
}

resource secretOpenAiKey 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: kv
  name: 'azure-openai-api-key'
  properties: {
    // Placeholder until the real key is provisioned; rotate via:
    //   az keyvault secret set --vault-name <kv> --name azure-openai-api-key --value <key>
    value: empty(azureOpenAiApiKey) ? 'PLACEHOLDER-SET-VIA-AZ-KEYVAULT-SECRET-SET' : azureOpenAiApiKey
  }
}

// Versionless URIs so Container Apps pick up rotated values automatically.
output vaultUri string = kv.properties.vaultUri
output name string = kv.name
output databaseUrlSecretUri string = '${kv.properties.vaultUri}secrets/database-url'
output redisUrlSecretUri string = '${kv.properties.vaultUri}secrets/redis-url'
output openAiKeySecretUri string = '${kv.properties.vaultUri}secrets/azure-openai-api-key'
