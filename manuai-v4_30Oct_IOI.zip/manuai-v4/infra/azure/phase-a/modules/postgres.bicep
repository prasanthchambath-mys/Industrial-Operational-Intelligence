// ─────────────────────────────────────────────────────────────────────────────
// postgres.bicep — Azure Database for PostgreSQL Flexible Server + database.
// Phase A default sizing: Burstable B2ms, 128 GB, no HA (cost-conscious demo).
// The "Allow Azure services" firewall rule lets Container Apps connect without
// VNet integration; tighten to Private Endpoint / VNet for production (see
// docs/phase-a-deployment-runbook.md → Hardening).
// ─────────────────────────────────────────────────────────────────────────────
@description('Azure region.')
param location string

@description('Resource name prefix.')
param namePrefix string

@description('Environment name: dev | test | prod.')
param environmentName string

@description('PostgreSQL administrator login (not "azure_superuser"/"admin"/"root").')
param administratorLogin string

@secure()
@description('PostgreSQL administrator password. Supplied at deploy time; never hardcoded.')
param administratorLoginPassword string

@description('Application database name.')
param databaseName string = 'manuai'

@description('Compute SKU name.')
param skuName string = 'Standard_B2ms'

@description('Compute tier.')
@allowed([ 'Burstable', 'GeneralPurpose', 'MemoryOptimized' ])
param skuTier string = 'Burstable'

@description('Storage size in GB.')
param storageSizeGB int = 128

@description('PostgreSQL major version.')
param postgresVersion string = '16'

resource pg 'Microsoft.DBforPostgreSQL/flexibleServers@2023-06-01-preview' = {
  name: '${namePrefix}-${environmentName}-pg'
  location: location
  sku: {
    name: skuName
    tier: skuTier
  }
  properties: {
    version: postgresVersion
    administratorLogin: administratorLogin
    administratorLoginPassword: administratorLoginPassword
    storage: {
      storageSizeGB: storageSizeGB
    }
    backup: {
      backupRetentionDays: 7
      geoRedundantBackup: 'Disabled'
    }
    highAvailability: {
      mode: 'Disabled'
    }
    authConfig: {
      activeDirectoryAuth: 'Disabled'
      passwordAuth: 'Enabled'
    }
  }
}

resource database 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2023-06-01-preview' = {
  parent: pg
  name: databaseName
  properties: {
    charset: 'UTF8'
    collation: 'en_US.utf8'
  }
}

// Allow other Azure services (Container Apps) to connect. 0.0.0.0/0.0.0.0 is the
// documented "Allow public access from any Azure service" sentinel.
resource fwAllowAzure 'Microsoft.DBforPostgreSQL/flexibleServers/firewallRules@2023-06-01-preview' = {
  parent: pg
  name: 'AllowAllAzureServices'
  properties: {
    startIpAddress: '0.0.0.0'
    endIpAddress: '0.0.0.0'
  }
}

output fqdn string = pg.properties.fullyQualifiedDomainName
output serverName string = pg.name
output databaseName string = databaseName
