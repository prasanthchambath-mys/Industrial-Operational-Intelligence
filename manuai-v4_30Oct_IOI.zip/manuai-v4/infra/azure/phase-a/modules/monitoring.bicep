// ─────────────────────────────────────────────────────────────────────────────
// monitoring.bicep — Log Analytics workspace + Application Insights.
// The workspace backs both the Container Apps Environment log sink and
// Application Insights. No secrets are emitted from this module; the Container
// Apps module reads the workspace shared key itself via listKeys().
// ─────────────────────────────────────────────────────────────────────────────
@description('Azure region.')
param location string

@description('Resource name prefix.')
param namePrefix string

@description('Environment name: dev | test | prod.')
param environmentName string

@description('Log retention in days.')
param retentionInDays int = 30

resource law 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: '${namePrefix}-${environmentName}-law'
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: retentionInDays
  }
}

resource appi 'Microsoft.Insights/components@2020-02-02' = {
  name: '${namePrefix}-${environmentName}-appi'
  location: location
  kind: 'web'
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: law.id
  }
}

output workspaceId string = law.id
output workspaceName string = law.name
output appInsightsName string = appi.name
output appInsightsConnectionString string = appi.properties.ConnectionString
