// ─────────────────────────────────────────────────────────────────────────────
// container-apps.bicep — Container Apps Environment + Azure Files (CSV mount) +
// 9 Container Apps (web, api, 7 Python services).
//
// Key Phase A decisions:
//  • Python services keep DATA_SOURCE=csv. Their images do NOT bake the CSVs
//    (their Docker build context is the service dir), so an Azure Files share
//    ("csvdata") is mounted read-only at /app/data/csv. Populate it with
//    scripts/load-phase-a-data.* before/after first deploy.
//  • The API image DOES bake data/csv, so it can perform the one-time DB seed
//    (RUN with SEED_ON_BOOT=true once — see runbook) before switching to
//    DATA_LOAD_MODE=db / SEED_ON_BOOT=false (the values wired below).
//  • Secrets (DATABASE_URL, REDIS_URL, AZURE_OPENAI_API_KEY) are Key Vault
//    references resolved by the managed identity — never plaintext env values.
//  • Images are pulled from ACR using the same managed identity (AcrPull).
// ─────────────────────────────────────────────────────────────────────────────
@description('Azure region.')
param location string

@description('Resource name prefix.')
param namePrefix string

@description('Environment name: dev | test | prod.')
param environmentName string

@description('Resource ID of the Log Analytics workspace for the env log sink.')
param logAnalyticsWorkspaceId string

@description('ACR login server, e.g. myregistry.azurecr.io.')
param acrLoginServer string

@description('Resource ID of the user-assigned managed identity.')
param managedIdentityId string

@description('Image tag to deploy for every service.')
param imageTag string = 'latest'

@description('Globally-unique storage account name for the CSV file share (3–24 lowercase alphanumeric).')
param storageAccountName string

// ── Key Vault secret URIs (versionless) ──────────────────────────────────────
param databaseUrlSecretUri string
param redisUrlSecretUri string
param openAiKeySecretUri string

// ── Non-secret config / placeholders ─────────────────────────────────────────
param appEnvValue string = 'azure-phase-a'
param llmProvider string = 'azure_openai'
param azureOpenAiEndpoint string = ''
param azureOpenAiDeployment string = 'gpt-4o'
param authJwksUri string = ''
param authIssuer string = ''
param authAudience string = ''
param authClientId string = ''
param corsOrigins string = '*'

@description('When true, wires MOCK_AUTH=true so the API skips Entra JWT validation. Dev/test only; keep false for prod.')
param mockAuth bool = false

@description('Expose Python services with public ingress so smoke tests can reach /health directly. Set false for production (internal-only behind web/api).')
param exposePythonServicesExternally bool = true

// ── The 7 Python services and the API env var that points at each ────────────
var pythonServices = [
  { name: 'pdm-inference', urlVar: 'PDM_SERVICE_URL' }
  { name: 'yield-optimizer', urlVar: 'YIELD_SERVICE_URL' }
  { name: 'energy-optimizer', urlVar: 'ENERGY_SERVICE_URL' }
  { name: 'quality-vision', urlVar: 'QUALITY_SERVICE_URL' }
  { name: 'supply-intelligence', urlVar: 'SUPPLY_SERVICE_URL' }
  { name: 'twin-sync', urlVar: 'TWIN_SERVICE_URL' }
  { name: 'safety-monitor', urlVar: 'SAFETY_SERVICE_URL' }
]

var appIdentity = {
  type: 'UserAssigned'
  userAssignedIdentities: {
    '${managedIdentityId}': {}
  }
}

var registries = [
  {
    server: acrLoginServer
    identity: managedIdentityId
  }
]

var pythonEnvCommon = [
  { name: 'APP_ENV', value: appEnvValue }
  { name: 'DATA_SOURCE', value: 'csv' }
  { name: 'ML_LOCAL', value: 'false' }
  { name: 'AML_ENABLED', value: 'false' }
  { name: 'SERVICE_VERSION', value: 'phase-a' }
  { name: 'CSV_DATA_DIR', value: '/app/data/csv' }
]

// Existing Log Analytics workspace (created by monitoring.bicep) — read keys here
// so no secret crosses a module boundary.
resource law 'Microsoft.OperationalInsights/workspaces@2022-10-01' existing = {
  name: last(split(logAnalyticsWorkspaceId, '/'))
}

// ── Storage account + file share for Python CSV data ─────────────────────────
resource storage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: storageAccountName
  location: location
  sku: {
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
  }
}

resource fileSvc 'Microsoft.Storage/storageAccounts/fileServices@2023-01-01' = {
  parent: storage
  name: 'default'
}

resource csvShare 'Microsoft.Storage/storageAccounts/fileServices/shares@2023-01-01' = {
  parent: fileSvc
  name: 'csvdata'
  properties: {
    shareQuota: 5
  }
}

// ── Container Apps Environment ───────────────────────────────────────────────
resource env 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: '${namePrefix}-${environmentName}-cae'
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: law.properties.customerId
        sharedKey: law.listKeys().primarySharedKey
      }
    }
  }
}

// Register the Azure Files share with the environment so apps can mount it.
resource envStorage 'Microsoft.App/managedEnvironments/storages@2024-03-01' = {
  parent: env
  name: 'csvdata'
  properties: {
    azureFile: {
      accountName: storage.name
      accountKey: storage.listKeys().keys[0].value
      shareName: 'csvdata'
      accessMode: 'ReadOnly'
    }
  }
}

// ── Python service Container Apps (looped) ───────────────────────────────────
resource pythonApps 'Microsoft.App/containerApps@2024-03-01' = [for svc in pythonServices: {
  name: svc.name
  location: location
  identity: appIdentity
  properties: {
    managedEnvironmentId: env.id
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: {
        external: exposePythonServicesExternally
        targetPort: 8000
        transport: 'auto'
        allowInsecure: false
      }
      registries: registries
    }
    template: {
      volumes: [
        {
          name: 'csv'
          storageType: 'AzureFile'
          storageName: 'csvdata'
        }
      ]
      containers: [
        {
          name: svc.name
          image: '${acrLoginServer}/${svc.name}:${imageTag}'
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: pythonEnvCommon
          volumeMounts: [
            {
              volumeName: 'csv'
              mountPath: '/app/data/csv'
            }
          ]
          probes: [
            {
              type: 'Liveness'
              httpGet: { path: '/health', port: 8000 }
              initialDelaySeconds: 10
              periodSeconds: 30
            }
            {
              type: 'Readiness'
              httpGet: { path: '/ready', port: 8000 }
              initialDelaySeconds: 10
              periodSeconds: 30
            }
          ]
        }
      ]
      scale: {
        minReplicas: 1
        maxReplicas: 2
      }
    }
  }
  dependsOn: [
    envStorage
  ]
}]

// ── API Container App ────────────────────────────────────────────────────────
resource apiApp 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'api'
  location: location
  identity: appIdentity
  properties: {
    managedEnvironmentId: env.id
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: {
        external: true
        targetPort: 4000
        transport: 'auto'
        allowInsecure: false
      }
      registries: registries
      secrets: [
        { name: 'database-url', keyVaultUrl: databaseUrlSecretUri, identity: managedIdentityId }
        { name: 'redis-url', keyVaultUrl: redisUrlSecretUri, identity: managedIdentityId }
        { name: 'azure-openai-api-key', keyVaultUrl: openAiKeySecretUri, identity: managedIdentityId }
      ]
    }
    template: {
      containers: [
        {
          name: 'api'
          image: '${acrLoginServer}/api:${imageTag}'
          resources: {
            cpu: json('1.0')
            memory: '2Gi'
          }
          env: concat([
            { name: 'APP_ENV', value: appEnvValue }
            { name: 'NODE_ENV', value: 'production' }
            { name: 'PORT', value: '4000' }
            { name: 'DB_PROVIDER', value: 'postgres' }
            { name: 'DATABASE_URL', secretRef: 'database-url' }
            { name: 'RUN_MIGRATIONS', value: 'true' }
            { name: 'SEED_ON_BOOT', value: 'false' }
            { name: 'DATA_LOAD_MODE', value: 'db' }
            { name: 'EVENT_BUS', value: 'redis' }
            { name: 'REDIS_REQUIRED', value: 'true' }
            { name: 'REDIS_URL', secretRef: 'redis-url' }
            { name: 'MOCK_AUTH', value: mockAuth ? 'true' : 'false' }
            { name: 'AUTH_PROVIDER', value: 'entra' }
            { name: 'AUTH_JWKS_URI', value: authJwksUri }
            { name: 'AUTH_ISSUER', value: authIssuer }
            { name: 'AUTH_AUDIENCE', value: authAudience }
            { name: 'AUTH_CLIENT_ID', value: authClientId }
            { name: 'AUTH_ROLES_FROM_GROUPS', value: 'true' }
            { name: 'LLM_PROVIDER', value: llmProvider }
            { name: 'AZURE_OPENAI_ENDPOINT', value: azureOpenAiEndpoint }
            { name: 'AZURE_OPENAI_DEPLOYMENT', value: azureOpenAiDeployment }
            { name: 'AZURE_OPENAI_API_KEY', secretRef: 'azure-openai-api-key' }
            { name: 'CSV_DATA_DIR', value: '/app/data/csv' }
            { name: 'CORS_ORIGINS', value: corsOrigins }
          ], [for (svc, i) in pythonServices: {
            name: svc.urlVar
            value: 'https://${pythonApps[i].properties.configuration.ingress.fqdn}'
          }])
          probes: [
            {
              type: 'Liveness'
              httpGet: { path: '/api/health/live', port: 4000 }
              initialDelaySeconds: 15
              periodSeconds: 30
            }
            {
              type: 'Readiness'
              httpGet: { path: '/api/health/ready', port: 4000 }
              initialDelaySeconds: 20
              periodSeconds: 30
              failureThreshold: 10
            }
          ]
        }
      ]
      scale: {
        minReplicas: 1
        maxReplicas: 3
      }
    }
  }
}

// ── Web Container App (nginx; proxies /api to the API via runtime upstream) ──
resource webApp 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'web'
  location: location
  identity: appIdentity
  properties: {
    managedEnvironmentId: env.id
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: {
        external: true
        targetPort: 80
        transport: 'auto'
        allowInsecure: false
      }
      registries: registries
    }
    template: {
      containers: [
        {
          name: 'web'
          image: '${acrLoginServer}/web:${imageTag}'
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: [
            { name: 'APP_ENV', value: appEnvValue }
            { name: 'API_UPSTREAM', value: 'https://${apiApp.properties.configuration.ingress.fqdn}' }
          ]
        }
      ]
      scale: {
        minReplicas: 1
        maxReplicas: 2
      }
    }
  }
}

output webFqdn string = webApp.properties.configuration.ingress.fqdn
output apiFqdn string = apiApp.properties.configuration.ingress.fqdn
output environmentName string = env.name
output storageAccount string = storage.name
output pythonFqdns array = [for (svc, i) in pythonServices: {
  name: svc.name
  fqdn: pythonApps[i].properties.configuration.ingress.fqdn
}]
