// ═════════════════════════════════════════════════════════════════════════════
// main.bicep — ManuAI v4 · Azure Phase A
// Resource-group-scoped deployment that provisions the full Phase A estate:
//   managed identity → ACR → Log Analytics/App Insights → Key Vault →
//   PostgreSQL Flexible Server → Azure Cache for Redis → Container Apps (web,
//   api, 7 Python services) with an Azure Files CSV mount.
//
// No secrets are hardcoded. The only sensitive inputs are @secure() parameters
// (PostgreSQL admin password, optional Azure OpenAI key) supplied at deploy time
// by scripts/deploy-phase-a.*. Connection strings are assembled inside
// keyvault.bicep and surfaced to Container Apps only as Key Vault references.
//
// Validate (on a machine with Azure CLI + Bicep):
//   az bicep build --file main.bicep
//   az deployment group validate -g <rg> -f main.bicep -p @parameters.dev.json
// ═════════════════════════════════════════════════════════════════════════════
targetScope = 'resourceGroup'

@description('Azure region. Defaults to the resource group location.')
param location string = resourceGroup().location

@description('Short resource name prefix (lowercase). Used to build resource names.')
param namePrefix string = 'manuai'

@description('Environment name: dev | test | prod.')
@allowed([ 'dev', 'test', 'prod' ])
param environmentName string

@description('Container image tag deployed for every service (matches build-and-push).')
param imageTag string = 'latest'

@description('ACR name. Leave empty to derive a globally-unique name from the RG.')
param acrName string = ''

@description('ACR SKU.')
@allowed([ 'Basic', 'Standard', 'Premium' ])
param acrSku string = 'Standard'

// ── PostgreSQL ───────────────────────────────────────────────────────────────
@description('PostgreSQL administrator login.')
param postgresAdminLogin string

@secure()
@description('PostgreSQL administrator password (supplied at deploy time; never stored in source).')
param postgresAdminPassword string

@description('Application database name.')
param postgresDatabaseName string = 'manuai'

param postgresSkuName string = 'Standard_B2ms'
@allowed([ 'Burstable', 'GeneralPurpose', 'MemoryOptimized' ])
param postgresSkuTier string = 'Burstable'
param postgresStorageGB int = 128

// ── Redis ────────────────────────────────────────────────────────────────────
@allowed([ 'Basic', 'Standard', 'Premium' ])
param redisSkuName string = 'Basic'
param redisSkuCapacity int = 1

// ── Auth (Entra / Azure AD B2C) placeholders ─────────────────────────────────
@description('OIDC JWKS endpoint. Wired to API env AUTH_JWKS_URI.')
param authJwksUri string = ''
@description('Token issuer. Wired to API env AUTH_ISSUER.')
param authIssuer string = ''
@description('Token audience / API app registration ID. Wired to API env AUTH_AUDIENCE.')
param authAudience string = ''
@description('Client/app registration ID. Wired to API env AUTH_CLIENT_ID.')
param authClientId string = ''

// ── Azure OpenAI placeholders ────────────────────────────────────────────────
@description('Azure OpenAI endpoint. Wired to API env AZURE_OPENAI_ENDPOINT.')
param azureOpenAiEndpoint string = ''
@description('Azure OpenAI deployment name. Wired to API env AZURE_OPENAI_DEPLOYMENT.')
param azureOpenAiDeployment string = 'gpt-4o'
@secure()
@description('Azure OpenAI API key. Optional; a placeholder Key Vault secret is created when empty.')
param azureOpenAiApiKey string = ''

@description('When true, the API bypasses Entra JWT validation (MOCK_AUTH=true). Intended for dev/test so smoke tests can reach authenticated data endpoints without a token. MUST be false for prod.')
param mockAuth bool = false

@description('CORS origins for the API. Default permissive; tighten to the web URL for production.')
param corsOrigins string = '*'

@description('Expose Python services publicly (true) so smoke tests can hit /health. Set false for production.')
param exposePythonServicesExternally bool = true

// ── Derived, globally-unique names ───────────────────────────────────────────
var unique = take(uniqueString(resourceGroup().id, environmentName), 6)
var acrNameResolved = empty(acrName) ? toLower('${namePrefix}${environmentName}acr${unique}') : acrName
var keyVaultName = toLower('${namePrefix}${environmentName}kv${unique}')
var storageAccountName = toLower('${namePrefix}${environmentName}csv${unique}')

// ── Modules ──────────────────────────────────────────────────────────────────
module identity 'modules/identity.bicep' = {
  name: 'identity'
  params: {
    location: location
    namePrefix: namePrefix
    environmentName: environmentName
  }
}

module acr 'modules/acr.bicep' = {
  name: 'acr'
  params: {
    location: location
    acrName: acrNameResolved
    sku: acrSku
    pullPrincipalId: identity.outputs.principalId
  }
}

module monitoring 'modules/monitoring.bicep' = {
  name: 'monitoring'
  params: {
    location: location
    namePrefix: namePrefix
    environmentName: environmentName
  }
}

module postgres 'modules/postgres.bicep' = {
  name: 'postgres'
  params: {
    location: location
    namePrefix: namePrefix
    environmentName: environmentName
    administratorLogin: postgresAdminLogin
    administratorLoginPassword: postgresAdminPassword
    databaseName: postgresDatabaseName
    skuName: postgresSkuName
    skuTier: postgresSkuTier
    storageSizeGB: postgresStorageGB
  }
}

module redis 'modules/redis.bicep' = {
  name: 'redis'
  params: {
    location: location
    namePrefix: namePrefix
    environmentName: environmentName
    skuName: redisSkuName
    skuCapacity: redisSkuCapacity
  }
}

module keyvault 'modules/keyvault.bicep' = {
  name: 'keyvault'
  params: {
    location: location
    keyVaultName: keyVaultName
    readerPrincipalId: identity.outputs.principalId
    postgresFqdn: postgres.outputs.fqdn
    postgresLogin: postgresAdminLogin
    postgresPassword: postgresAdminPassword
    postgresDatabase: postgres.outputs.databaseName
    redisHost: redis.outputs.hostName
    redisSslPort: redis.outputs.sslPort
    redisPrimaryKey: redis.outputs.primaryKey
    azureOpenAiApiKey: azureOpenAiApiKey
  }
}

module containerApps 'modules/container-apps.bicep' = {
  name: 'containerApps'
  params: {
    location: location
    namePrefix: namePrefix
    environmentName: environmentName
    logAnalyticsWorkspaceId: monitoring.outputs.workspaceId
    acrLoginServer: acr.outputs.loginServer
    managedIdentityId: identity.outputs.id
    imageTag: imageTag
    storageAccountName: storageAccountName
    databaseUrlSecretUri: keyvault.outputs.databaseUrlSecretUri
    redisUrlSecretUri: keyvault.outputs.redisUrlSecretUri
    openAiKeySecretUri: keyvault.outputs.openAiKeySecretUri
    llmProvider: 'azure_openai'
    azureOpenAiEndpoint: azureOpenAiEndpoint
    azureOpenAiDeployment: azureOpenAiDeployment
    authJwksUri: authJwksUri
    authIssuer: authIssuer
    authAudience: authAudience
    authClientId: authClientId
    corsOrigins: corsOrigins
    mockAuth: mockAuth
    exposePythonServicesExternally: exposePythonServicesExternally
  }
}

// ── Outputs (consumed by scripts: build/push, data-load, smoke-test) ─────────
output acrName string = acr.outputs.name
output acrLoginServer string = acr.outputs.loginServer
output keyVaultName string = keyvault.outputs.name
output postgresFqdn string = postgres.outputs.fqdn
output postgresDatabase string = postgres.outputs.databaseName
output redisHostName string = redis.outputs.hostName
output storageAccountName string = containerApps.outputs.storageAccount
output webUrl string = 'https://${containerApps.outputs.webFqdn}'
output apiUrl string = 'https://${containerApps.outputs.apiFqdn}'
output pythonServiceUrls array = [for s in containerApps.outputs.pythonFqdns: {
  name: s.name
  url: 'https://${s.fqdn}'
}]
output managedIdentityClientId string = identity.outputs.clientId
