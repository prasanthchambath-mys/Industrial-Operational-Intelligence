#!/bin/bash
# ============================================================================
# RUL Trend diagnostic — run on the machine where `docker compose` is up.
# Tells you in 5 seconds whether the NEW build is actually deployed.
#   Usage:  bash diagnose_rul.sh            (defaults to http://localhost:4000)
#           bash diagnose_rul.sh http://HOST:4000
# ============================================================================
API="${1:-http://localhost:4000}"

echo "============================================================"
echo " ManuAI RUL Trend diagnostic   (API: $API)"
echo "============================================================"

echo ""
echo "[1] Is the V74 build live?  (looking for build marker)"
RESP=$(curl -s "$API/api/history/pdm/health-daily/MCH-06?days=14")
echo "$RESP" | python3 -c "
import sys,json
try:
    d=json.load(sys.stdin)
except: print('   ✗ endpoint returned non-JSON or 404 → STALE API BUILD'); sys.exit()
b=d.get('build')
if b=='V74-daily-trend':
    print(f'   ✓ NEW build is live (build={b}, points={d.get(\"points\")})')
else:
    print(f'   ✗ build marker MISSING → API container is STALE. Rebuild --no-cache api.')
"

echo ""
echo "[2] How many DAILY points come back?  (want ~14-15)"
echo "$RESP" | python3 -c "
import sys,json
d=json.load(sys.stdin).get('data',[])
print(f'   rows: {len(d)}')
for r in d[:3]:  print('     ',r.get('day'),'rul=',r.get('rul'))
print('      ...')
for r in d[-2:]: print('     ',r.get('day'),'rul=',r.get('rul'))
if len(d)<2: print('   ✗ Only',len(d),'row(s) → chart will show dots, not a line.')
else:        print(f'   ✓ {len(d)} rows spanning the window → line will render.')
" 2>/dev/null || echo "   ✗ could not parse — API stale or down"

echo ""
echo "[3] Raw health rows for MCH-06 over 30 days  (want thousands)"
curl -s "$API/api/history/pdm/health/MCH-06?days=30" | python3 -c "
import sys,json
d=json.load(sys.stdin).get('data',[])
print(f'   raw rows: {len(d)}')
if d and d[0].get('ts') and d[-1].get('ts'):
    print(f'   span: {(d[-1][\"ts\"]-d[0][\"ts\"])/86400000:.1f} days')
if len(d)<100: print('   ✗ Too few rows → DB was not seeded with history (was isHistorySeeded true on an empty-ish DB?).')
" 2>/dev/null || echo "   ✗ could not parse"

echo ""
echo "============================================================"
echo " VERDICT:"
echo "  • [1] shows STALE  → docker compose down -v && \\"
echo "                       docker compose build --no-cache web api && \\"
echo "                       docker compose up -d   (then Ctrl+Shift+R)"
echo "  • [1] OK but chart still dots → hard-refresh browser (web image"
echo "                       cache) or rebuild web --no-cache."
echo "  • [3] too few rows → docker compose down -v (clears stale DB),"
echo "                       then up so history reseeds."
echo "============================================================"
