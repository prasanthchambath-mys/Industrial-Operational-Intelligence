#!/usr/bin/env python3
"""
ManuAI — PdM Synthetic Training Data Generator
================================================

Replays the EXACT degradation physics used by the live simulation engine
(apps/api/src/simulation/engine.ts) to produce labelled failure episodes for
training a Remaining-Useful-Life / failure-prediction model.

Why synthetic first:
  Real PdM training needs ~30 days of vibration/thermal data AFTER IoT Hub goes
  live, plus recorded failure events. That is calendar-time you cannot compress.
  Pre-training on physically-faithful synthetic episodes gives you a deployable
  baseline model on day one, which you then fine-tune on real data as it arrives.

Physics replicated from engine.ts (per-tick, tick = 10s live; here we step in
configurable minutes and scale the degrade rate accordingly):
    health   -= degrade_rate            (clamp 5..99)
    rul      -= degrade_rate * 0.4      (clamp 1..200)
    vib      += degrade_rate * 0.03     (clamp 0.3..15)
    temp     += degrade_rate * 0.05     (clamp 35..105)
    pressure += degrade_rate * 0.02     (clamp 3..95)
    status:   >=80 good | >=65 caution | >=40 warning | else critical
    auto-maintenance trigger at health < health_maintenance (20%)
    recovery: health -> 60..95, rul -> 60..140, vib/temp reset

Labels emitted per row:
    rul_true_days     — ground-truth remaining days until this episode's failure
    will_fail_7d      — 1 if failure occurs within 7 days, else 0   (classification)
    will_fail_14d     — 1 if failure occurs within 14 days, else 0
    failure_mode      — bearing_wear | overtemperature | seal_leak | imbalance

Output:
    pdm_training_data.parquet   (+ .csv preview)
"""

import os
import csv
import math
import random
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

# ── Constants pulled from ml_thresholds.csv / platform_config.csv ─────────────
HEALTH_MAINTENANCE   = 20.0   # sim_thresholds.health_maintenance
HEALTH_RECOVERY_MIN  = 60.0
HEALTH_RECOVERY_MAX  = 95.0
RUL_RECOVERY_MIN     = 60.0
RUL_RECOVERY_MAX     = 140.0
FAILURE_HEALTH       = 30.0   # pdm.rul_thresholds.failure_health — RUL hits 0 here

# Failure-mode trigger thresholds (ml_thresholds.csv pdm.failure_modes)
BEARING_VIB_MIN      = 5.0
BEARING_TEMP_MIN     = 25.0   # delta above ambient
OVERTEMP_MIN         = 35.0
SEAL_LEAK_PVAR_MIN   = 0.5

AMBIENT_TEMP         = 30.0   # baseline ambient for temp-delta calc

CSV_PATH = Path(__file__).resolve().parents[2] / "data" / "csv" / "machines.csv"


def load_machines():
    """Read machines.csv for per-asset starting condition + degrade_rate."""
    machines = []
    if CSV_PATH.exists():
        with open(CSV_PATH) as f:
            for row in csv.DictReader(f):
                machines.append({
                    "id": row["id"],
                    "name": row["name"],
                    "line": row["line"],
                    "plant": row["plant"],
                    "health": float(row["health"]),
                    "rul": float(row["rul"]),
                    "vib": float(row["vib"]),
                    "temp": float(row["temp"]),
                    "pressure": float(row["pressure"]),
                    "degrade_rate": float(row["degrade_rate"]),
                })
    if not machines:
        # Fallback synthetic fleet if CSV missing
        for i in range(1, 9):
            machines.append({
                "id": f"MCH-{i:02d}", "name": f"Machine {i}", "line": "Line A",
                "plant": "P1" if i <= 4 else "P2",
                "health": 85.0, "rul": 90.0, "vib": 3.0, "temp": 60.0,
                "pressure": 8.0, "degrade_rate": 0.05,
            })
    return machines


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def noise(scale):
    return (random.random() - 0.5) * 2 * scale


def classify_failure_mode(vib, temp, pressure_var):
    """Mirror the failure-mode logic in the PdM service."""
    temp_delta = temp - AMBIENT_TEMP
    if pressure_var >= SEAL_LEAK_PVAR_MIN:
        return "seal_leak"
    if temp_delta >= OVERTEMP_MIN and vib < BEARING_VIB_MIN:
        return "overtemperature"
    if vib >= BEARING_VIB_MIN and temp_delta >= BEARING_TEMP_MIN:
        return "bearing_wear"
    if vib >= BEARING_VIB_MIN:
        return "imbalance"
    return "bearing_wear"  # default degradation mode


def simulate_episode(machine, step_minutes, accel, episode_seed):
    """
    Simulate ONE degrade→fail→repair cycle, return list of per-step feature rows.
    A failure is logged when health crosses FAILURE_HEALTH on the way down.
    """
    random.seed(episode_seed)
    np.random.seed(episode_seed % (2**32 - 1))

    rows = []
    # Start from a healthy-ish random condition so episodes vary
    health = clamp(machine["health"] + noise(15), 55, 99)
    rul    = clamp(machine["rul"] + noise(30), 40, 180)
    vib    = clamp(machine["vib"] + noise(0.5), 0.5, 4.5)
    temp   = clamp(machine["temp"] + noise(5), 40, 75)
    pressure = clamp(machine["pressure"] + noise(1.0), 4, 20)

    # Per-episode degrade rate jitter — different wear-out speeds
    base_rate = machine["degrade_rate"] * (0.6 + random.random() * 1.6)
    # Scale per-step degradation: live engine ticks every 10s; we step in minutes.
    # accel multiplies wear so a full episode spans a realistic number of rows.
    step_rate = base_rate * (step_minutes / (10/60)) * accel * 0.0009

    prev_pressure = pressure
    t_minutes = 0
    failed = False
    fail_minute = None

    # First pass: degrade until failure, collecting raw trajectory
    traj = []
    max_steps = int((180 * 24 * 60) / step_minutes)  # cap at 180 sim-days
    for _ in range(max_steps):
        # Degrade physics (mirrors engine.ts)
        health  = clamp(health  - step_rate + noise(0.05), 5, 99)
        rul     = clamp(rul     - step_rate * 0.4, 0, 200)
        vib     = clamp(vib     + step_rate * 0.03 + noise(0.02), 0.3, 15)
        temp    = clamp(temp    + step_rate * 0.05 + noise(0.15), 35, 105)
        pressure = clamp(pressure + step_rate * 0.02 + noise(0.05), 3, 95)
        pressure_var = abs(pressure - prev_pressure)
        prev_pressure = pressure

        run_hours = t_minutes / 60.0
        traj.append({
            "minute": t_minutes,
            "health": health, "rul_engine": rul,
            "vib": vib, "temp": temp, "pressure": pressure,
            "pressure_var": pressure_var, "run_hours": run_hours,
        })

        if health <= FAILURE_HEALTH and not failed:
            failed = True
            fail_minute = t_minutes
            break
        t_minutes += step_minutes

    if not failed:
        fail_minute = t_minutes  # treat end as censored failure point

    # Second pass: assign ground-truth RUL + classification labels
    mode = classify_failure_mode(traj[-1]["vib"], traj[-1]["temp"], traj[-1]["pressure_var"])
    for r in traj:
        minutes_to_fail = max(0, fail_minute - r["minute"])
        rul_true_days = minutes_to_fail / (24 * 60.0)
        temp_delta = r["temp"] - AMBIENT_TEMP
        rows.append({
            "machine_id": machine["id"],
            "plant_id": machine["plant"],
            "asset_type": machine["name"].split()[0],
            # ── Features ──
            "vibration_mm_s": round(r["vib"], 3),
            "temperature_c": round(r["temp"], 2),
            "temp_delta_c": round(temp_delta, 2),
            "pressure_bar": round(r["pressure"], 2),
            "pressure_variance": round(r["pressure_var"], 4),
            "run_hours": round(r["run_hours"], 1),
            "health_score": round(r["health"], 2),
            "degrade_rate": round(machine["degrade_rate"], 4),
            # ── Labels ──
            "rul_true_days": round(rul_true_days, 3),
            "will_fail_7d": 1 if rul_true_days <= 7 else 0,
            "will_fail_14d": 1 if rul_true_days <= 14 else 0,
            "failure_mode": mode,
        })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--episodes-per-machine", type=int, default=12,
                    help="Failure episodes to simulate per machine (default 12 → ~96 episodes)")
    ap.add_argument("--step-minutes", type=int, default=60,
                    help="Sim resolution in minutes (default 60 = hourly readings)")
    ap.add_argument("--accel", type=float, default=1.0,
                    help="Wear acceleration factor (higher = shorter episodes)")
    ap.add_argument("--out", default=str(Path(__file__).parent / "pdm_training_data.parquet"))
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    machines = load_machines()
    print(f"Loaded {len(machines)} machines from {CSV_PATH.name}")

    all_rows = []
    ep_id = 0
    for m in machines:
        for e in range(args.episodes_per_machine):
            ep_id += 1
            rows = simulate_episode(m, args.step_minutes, args.accel,
                                    args.seed * 10000 + ep_id)
            for r in rows:
                r["episode_id"] = ep_id
            all_rows.extend(rows)

    df = pd.DataFrame(all_rows)
    df.to_parquet(args.out, index=False)
    df.head(2000).to_csv(args.out.replace(".parquet", "_preview.csv"), index=False)

    # Summary
    n_episodes = df["episode_id"].nunique()
    print(f"\nGenerated {len(df):,} labelled rows across {n_episodes} failure episodes")
    print(f"  will_fail_7d  positives: {df['will_fail_7d'].sum():,} ({100*df['will_fail_7d'].mean():.1f}%)")
    print(f"  will_fail_14d positives: {df['will_fail_14d'].sum():,} ({100*df['will_fail_14d'].mean():.1f}%)")
    print(f"  RUL range: {df['rul_true_days'].min():.1f} .. {df['rul_true_days'].max():.1f} days")
    print(f"  Failure modes: {df['failure_mode'].value_counts().to_dict()}")
    print(f"\nWritten: {args.out}")
    print(f"Preview: {args.out.replace('.parquet', '_preview.csv')}")


if __name__ == "__main__":
    main()
