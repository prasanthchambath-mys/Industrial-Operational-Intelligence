# ManuAI — PdM Baseline Model (Synthetic Pre-Train)

Pre-trained Predictive-Maintenance model so you can deploy a real ML endpoint
on **day one of Phase A** instead of waiting 30+ days for real failure data.

## Why this exists
Training a credible PdM model normally needs ~30 days of real vibration/thermal
data **after** IoT Hub goes live, plus recorded failure events. That is calendar
time you cannot compress. This harness pre-trains on physically-faithful
synthetic failure episodes (replaying the exact degradation physics of the live
simulation engine), giving a deployable baseline immediately. You then fine-tune
on real data as it arrives — the model is **off the critical path**.

## Files
| File | Purpose |
|------|---------|
| `generate_training_data.py` | Synthesises labelled failure episodes from `machines.csv` degrade physics |
| `train_pdm_model.py` | Trains RUL regressor + 14-day failure classifier (XGBoost), grouped validation |
| `score.py` | Azure ML scoring entry point — matches pdm-inference service contract |
| `pdm_model.joblib` | Trained ensemble artifact |
| `pdm_metrics.json` | Validation metrics |

## Pipeline
```bash
pip install -r requirements.txt
python generate_training_data.py --episodes-per-machine 14   # ~240K labelled rows
python train_pdm_model.py                                     # trains + validates
python score.py --selftest                                    # sanity check
```

## Baseline metrics (validated on unseen failure episodes)
- RUL regressor: **MAE 7.9 days, R² 0.958**
- Failure classifier (14-day): **F1 0.944, Precision 0.969, Recall 0.921, AUC 0.999**
- Top RUL features: health_score 35%, degrade_rate 25%, run_hours 19%, vibration 11%

> These are synthetic-data metrics. They prove the pipeline and give a deployable
> baseline. Real-world accuracy is established after fine-tuning on live failures.

## Deploy to Phase A
1. Register `pdm_model.joblib` as an Azure ML model.
2. Deploy `score.py` to a managed endpoint (init/run contract).
3. Set in Key Vault:
   ```
   AML_PDM_ENDPOINT=https://<endpoint>/score
   AML_API_KEY=<key>
   ```
4. The `pdm-inference` service (V43) detects the endpoint and calls it; if it
   errors or times out, it falls back to the rule engine automatically.

## Fine-tuning on real data (after ~30 days of IoT Hub)
1. Pull real `machine_health` rows + actual SAP PM failure WOs from the DB/lakehouse.
2. Label rows with time-to-failure from the WO close dates.
3. Re-run `train_pdm_model.py --data real_failures.parquet` (or warm-start from
   `pdm_model.joblib`).
4. A/B test new model vs this baseline for 4 weeks; promote when F1 improves.

## Next models (same pattern)
- **Yield XGBoost** — needs `batches` + `yield_history` param→outcome pairs
- **Safety LSTM** — needs gas-sensor precursor sequences (real data only)
- **Quality ONNX** — needs labelled defect images (real data only — cannot synthesise credibly)
