#!/usr/bin/env python3
"""
ManuAI — PdM Baseline Model Training Harness
=============================================

Trains the baseline PdM ensemble on synthetic failure-episode data, validates
it, and writes a deployable model artifact + scoring wrapper.

Two heads (matches what the PdM service consumes):
  1. RUL regressor      — XGBoost, predicts remaining-useful-life in days
  2. Failure classifier — XGBoost, P(failure within 14 days)

Validation uses GROUPED splitting by episode_id so the model is tested on
failure episodes it never saw — this prevents leakage (rows from the same
degradation curve are highly correlated).

This is the PRE-TRAINED baseline. In Phase A you:
  1. Deploy this artifact to an Azure ML managed endpoint
  2. Set AML_PDM_ENDPOINT in Key Vault  → pdm-inference service calls it
  3. As real IoT Hub data accumulates, fine-tune on real failure events
  4. A/B test real-data model vs this baseline; promote when it wins

Output:
    pdm_model.joblib        — the trained ensemble + feature spec
    pdm_metrics.json        — validation metrics
    score.py                — Azure ML scoring entry point (init/run)
"""

import json
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import (mean_absolute_error, r2_score,
                             f1_score, precision_score, recall_score,
                             roc_auc_score)
import xgboost as xgb

FEATURES = [
    "vibration_mm_s", "temperature_c", "temp_delta_c",
    "pressure_bar", "pressure_variance", "run_hours",
    "health_score", "degrade_rate",
]
RUL_TARGET = "rul_true_days"
CLF_TARGET = "will_fail_14d"
GROUP_COL  = "episode_id"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(Path(__file__).parent / "pdm_training_data.parquet"))
    ap.add_argument("--out-model", default=str(Path(__file__).parent / "pdm_model.joblib"))
    ap.add_argument("--out-metrics", default=str(Path(__file__).parent / "pdm_metrics.json"))
    ap.add_argument("--test-frac", type=float, default=0.25)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    df = pd.read_parquet(args.data)
    print(f"Loaded {len(df):,} rows, {df[GROUP_COL].nunique()} episodes")

    X = df[FEATURES].values
    y_rul = df[RUL_TARGET].values
    y_clf = df[CLF_TARGET].values
    groups = df[GROUP_COL].values

    # Grouped split — test on unseen episodes (no leakage across a curve)
    gss = GroupShuffleSplit(n_splits=1, test_size=args.test_frac, random_state=args.seed)
    train_idx, test_idx = next(gss.split(X, y_rul, groups))
    Xtr, Xte = X[train_idx], X[test_idx]
    print(f"Train: {len(train_idx):,} rows | Test: {len(test_idx):,} rows (grouped by episode)")

    # ── RUL regressor ──────────────────────────────────────────────────────
    rul_model = xgb.XGBRegressor(
        n_estimators=300, max_depth=6, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=args.seed,
        objective="reg:squarederror", n_jobs=-1,
    )
    rul_model.fit(Xtr, y_rul[train_idx])
    rul_pred = np.clip(rul_model.predict(Xte), 0, 200)
    rul_mae = mean_absolute_error(y_rul[test_idx], rul_pred)
    rul_r2  = r2_score(y_rul[test_idx], rul_pred)

    # ── Failure classifier (P fail within 14d) ─────────────────────────────
    pos = y_clf[train_idx].sum()
    neg = len(train_idx) - pos
    spw = float(neg / max(pos, 1))  # handle class imbalance
    clf_model = xgb.XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=args.seed,
        objective="binary:logistic", scale_pos_weight=spw,
        eval_metric="logloss", n_jobs=-1,
    )
    clf_model.fit(Xtr, y_clf[train_idx])
    clf_proba = clf_model.predict_proba(Xte)[:, 1]
    clf_pred  = (clf_proba >= 0.5).astype(int)
    f1   = f1_score(y_clf[test_idx], clf_pred)
    prec = precision_score(y_clf[test_idx], clf_pred, zero_division=0)
    rec  = recall_score(y_clf[test_idx], clf_pred, zero_division=0)
    auc  = roc_auc_score(y_clf[test_idx], clf_proba)

    # Feature importance (RUL head)
    fi = dict(sorted(
        zip(FEATURES, [float(x) for x in rul_model.feature_importances_]),
        key=lambda kv: kv[1], reverse=True))

    metrics = {
        "model": "ManuAI PdM Baseline Ensemble (synthetic pre-train)",
        "trained_on": "synthetic failure episodes (engine-faithful physics)",
        "n_rows": int(len(df)),
        "n_episodes": int(df[GROUP_COL].nunique()),
        "rul_regressor": {"mae_days": round(rul_mae, 3), "r2": round(rul_r2, 4)},
        "failure_classifier_14d": {
            "f1": round(f1, 4), "precision": round(prec, 4),
            "recall": round(rec, 4), "roc_auc": round(auc, 4),
        },
        "feature_importance": {k: round(v, 4) for k, v in fi.items()},
        "features": FEATURES,
        "note": "Baseline for Phase A deployment. Fine-tune on real IoT Hub "
                "failure events before retiring the rule engine.",
    }

    joblib.dump({
        "rul_model": rul_model,
        "clf_model": clf_model,
        "features": FEATURES,
        "version": "baseline-synthetic-v1",
    }, args.out_model)

    with open(args.out_metrics, "w") as f:
        json.dump(metrics, f, indent=2)

    print("\n── Validation (on unseen episodes) ──")
    print(f"  RUL regressor   : MAE {rul_mae:.2f} days | R2 {rul_r2:.4f}")
    print(f"  Failure clf 14d : F1 {f1:.4f} | Precision {prec:.4f} | Recall {rec:.4f} | AUC {auc:.4f}")
    print(f"\n  Top features (RUL): " +
          ", ".join(f"{k} {v*100:.0f}%" for k, v in list(fi.items())[:4]))
    print(f"\nModel:   {args.out_model}")
    print(f"Metrics: {args.out_metrics}")


if __name__ == "__main__":
    main()
