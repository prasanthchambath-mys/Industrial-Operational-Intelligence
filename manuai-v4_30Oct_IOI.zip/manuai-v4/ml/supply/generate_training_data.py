#!/usr/bin/env python3
"""
ManuAI — Supply Intelligence Synthetic Training Data Generator
==============================================================

Generates labelled supplier-risk scenarios for training a stockout model.

WHAT THE MODEL LEARNS (the uplift over the rule engine):
  The rule engine (supply-intelligence/main.py) scores risk ADDITIVELY — it adds
  a flat +20 for single_source, multiplies lead drift by a flat 1.8, adds a fixed
  +25 when stock is below reorder, etc. Each factor is independent and linear.

  Real stockout risk is INTERACTIVE and non-linear:
    • single_source only hurts badly when lead-time is ALSO drifting (no expedite
      fallback to recover) — the two compound, they don't just add.
    • financial stress only matters when stock cover is thin — a financially shaky
      supplier with 60 days of stock is fine; with 5 days it is dangerous.
    • it is lead-time VARIABILITY, not just the mean drift, that causes stockouts —
      a supplier reliably 10 days late can be planned around; one that is 0–40 days
      late at random cannot.

  We synthesise supplier scenarios sampled around the real supply_risks.csv ranges,
  then label each via a MONTE CARLO stockout simulation (200 trials/scenario):
  daily consumption depletes stock; PO replenishment arrives after a lead time
  drawn from a supplier-specific distribution (mean = actual lead, SD grows with
  drift + financial stress); single-source removes the expedite option. The
  fraction of trials that stock out is the ground-truth stockout probability.

  A regressor then learns weeks-to-stockout and a classifier learns P(stockout),
  capturing the interactions the additive rule engine cannot.

Physics anchored to real config (supply_risks.csv, ml_thresholds.csv):
  • risk buckets: critical>=70, high>=45, medium>=25 (rule_engine_score feature)
  • exposure multiplier: 1.5 months
  • high-risk origins: Germany, China, Taiwan, Ukraine, Russia

Output: supply_training_data.parquet
"""

import os
import csv
import random
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
SUPPLY_CSV = BASE / "data" / "csv" / "supply_risks.csv"

# Constants from ml_thresholds.csv (service=supply)
CRIT_MIN, HIGH_MIN, MED_MIN = 70.0, 45.0, 25.0
EXPOSURE_MULT = 1.5
HIGH_RISK_GEO = {"Germany", "China", "Taiwan", "Ukraine", "Russia"}
ORIGINS = ["India", "India", "India", "Germany", "China", "Taiwan", "Sweden",
           "USA", "Japan", "Ukraine", "Russia"]

MC_TRIALS = 200          # Monte Carlo trials per scenario
HORIZON_DAYS = 84        # 12-week planning horizon


def load_seed_suppliers():
    """Load the real suppliers as anchor points for the sampling ranges."""
    seeds = []
    if SUPPLY_CSV.exists():
        with open(SUPPLY_CSV, newline="", encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                seeds.append({
                    "current_stock_days": float(r["current_stock_days"]),
                    "reorder_point_days": float(r["reorder_point_days"]),
                    "lead_contracted": float(r["lead_time_contracted_days"]),
                    "lead_actual": float(r["lead_time_actual_days"]),
                    "monthly_consumption": float(r["monthly_consumption"]),
                    "unit_cost_inr": float(r["unit_cost_inr"]),
                    "single_source": str(r["single_source"]).lower() == "true",
                    "country": r["country_of_origin"],
                    "financial_risk_score": float(r["financial_risk_score"]),
                })
    if not seeds:  # fallback if CSV missing
        seeds = [{"current_stock_days": 20, "reorder_point_days": 14,
                  "lead_contracted": 21, "lead_actual": 30,
                  "monthly_consumption": 10, "unit_cost_inr": 50000,
                  "single_source": False, "country": "India",
                  "financial_risk_score": 25}]
    return seeds


def rule_engine_score(sc):
    """Replicate the additive rule-engine score exactly (the benchmark + a feature)."""
    score = 0.0
    lead_drift = sc["lead_actual"] - sc["lead_contracted"]
    if lead_drift > 0:
        score += min(lead_drift * 1.8, 40)
    if sc["financial_risk_score"] > 50:
        score += (sc["financial_risk_score"] - 50) * 0.8
    if sc["single_source"]:
        score += 20
    if sc["current_stock_days"] < sc["reorder_point_days"]:
        score += 25
    if sc["country"] in HIGH_RISK_GEO and lead_drift > 5:
        score += 12
    return min(score, 100.0)


def monte_carlo_stockout(sc, rng):
    """
    Ground-truth label: simulate the next HORIZON_DAYS day-by-day, MC_TRIALS times.
    Vectorised over trials (each state variable is an array of length MC_TRIALS).

    • Stock depletes at daily_consumption each day.
    • A replenishment PO is placed when stock cover drops below reorder point;
      it arrives after a lead time drawn from a supplier-specific distribution.
    • Lead-time SD grows with observed drift and financial stress (unreliability).
    • Single-source removes the expedite option (no shortened emergency lead).

    Returns (stockout_prob, mean_days_to_stockout_or_horizon).
    """
    daily = sc["monthly_consumption"] / 30.0
    if daily <= 0:
        return 0.0, float(HORIZON_DAYS)

    reorder_units = sc["reorder_point_days"] * daily
    # Order-up-to: cover the lead time + reorder buffer + ~2wk safety. A correctly
    # planned PO bridges the lead time so a RELIABLE supplier never stocks out;
    # stockouts then come from lead VARIABILITY, drift, and thin starting stock —
    # which is exactly the interaction structure we want the model to learn.
    order_up_to_days = sc["lead_actual"] + sc["reorder_point_days"] + 14
    order_qty_units = order_up_to_days * daily

    drift = max(0.0, sc["lead_actual"] - sc["lead_contracted"])
    lead_mean = sc["lead_actual"]
    lead_sd = lead_mean * (0.15 + 0.010 * drift + 0.004 * sc["financial_risk_score"])
    if sc["single_source"]:
        lead_sd *= 1.4
    single = sc["single_source"]

    n = MC_TRIALS
    stock = np.full(n, sc["current_stock_days"] * daily, dtype=float)
    in_transit = np.zeros(n)
    arrival_day = np.full(n, -1, dtype=int)
    stocked_out = np.zeros(n, dtype=bool)
    first_event = np.full(n, HORIZON_DAYS, dtype=int)

    for day in range(HORIZON_DAYS):
        # receive any POs arriving today
        arrived = arrival_day == day
        if arrived.any():
            stock[arrived] += in_transit[arrived]
            in_transit[arrived] = 0.0
            arrival_day[arrived] = -1

        # consume with daily demand noise
        stock -= daily * (1.0 + rng.uniform(-0.15, 0.15, n))

        # record first stockout
        newly_out = (stock <= 0) & ~stocked_out
        first_event[newly_out] = day
        stocked_out |= newly_out

        # place PO where below reorder and none in transit
        can_order = (stock <= reorder_units) & (arrival_day < 0)
        if can_order.any():
            lt = np.maximum(1.0, rng.normal(lead_mean, lead_sd, n))
            if not single:
                expedite = can_order & (stock <= reorder_units * 0.5)
                lt[expedite] *= 0.7
            place = can_order
            arrival_day[place] = day + np.rint(lt[place]).astype(int)
            in_transit[place] = order_qty_units

    return float(stocked_out.mean()), float(first_event.mean())


def sample_scenario(seed, rng):
    """Sample a plausible supplier scenario perturbed around a seed supplier."""
    lead_contracted = max(3, seed["lead_contracted"] * rng.uniform(0.6, 1.5))
    # actual lead drifts from contracted by a random factor (often on time)
    drift_factor = rng.choice([0.0, 0.0, 0.0, 0.2, 0.5, 0.9, 1.4, 2.0],
                              p=[0.32, 0.18, 0.12, 0.14, 0.10, 0.07, 0.05, 0.02])
    lead_actual = lead_contracted * (1.0 + drift_factor * rng.uniform(0.3, 1.0))

    # Reorder point is PLANNED around the contracted lead (+safety). A supplier
    # whose ACTUAL lead drifts beyond what reorder was planned for is the core
    # stockout driver; well-planned + on-time suppliers stay safe. planning_q<1
    # models under-planned suppliers (reorder set too low).
    planning_q = rng.uniform(0.7, 1.6)
    reorder = max(4, lead_contracted * planning_q)
    # stock cover: skewed toward comfortable, with a meaningful thin-stock tail
    stock = max(1, reorder * rng.uniform(0.4, 4.0))

    monthly = max(0.3, seed["monthly_consumption"] * rng.uniform(0.4, 2.5))
    unit_cost = max(500, seed["unit_cost_inr"] * rng.uniform(0.3, 2.5))
    single = bool(rng.random() < 0.35)
    country = rng.choice(ORIGINS)
    fin = float(np.clip(rng.normal(25, 16), 2, 95))

    return {
        "current_stock_days": round(stock, 1),
        "reorder_point_days": round(reorder, 1),
        "lead_contracted": round(lead_contracted, 1),
        "lead_actual": round(lead_actual, 1),
        "monthly_consumption": round(monthly, 2),
        "unit_cost_inr": round(unit_cost, 0),
        "single_source": single,
        "country": country,
        "financial_risk_score": round(fin, 1),
    }


def build_row(sc, rng):
    lead_drift = sc["lead_actual"] - sc["lead_contracted"]
    stockout_prob, days_to_event = monte_carlo_stockout(sc, rng)
    rule_score = rule_engine_score(sc)
    exposure = sc["unit_cost_inr"] * sc["monthly_consumption"] * EXPOSURE_MULT

    return {
        # ── Features ──
        "current_stock_days": sc["current_stock_days"],
        "reorder_point_days": sc["reorder_point_days"],
        "stock_vs_reorder": round(sc["current_stock_days"] - sc["reorder_point_days"], 2),
        "lead_drift_days": round(lead_drift, 1),
        "lead_drift_ratio": round(lead_drift / max(1.0, sc["lead_contracted"]), 3),
        "monthly_consumption": sc["monthly_consumption"],
        "single_source": int(sc["single_source"]),
        "high_risk_geo": int(sc["country"] in HIGH_RISK_GEO),
        "financial_risk_score": sc["financial_risk_score"],
        "exposure_inr": round(exposure, 0),
        "rule_engine_score": round(rule_score, 1),
        # ── Labels ──
        "stockout_prob": round(stockout_prob, 4),
        "did_stockout": int(stockout_prob >= 0.50),
        "weeks_to_stockout": round(days_to_event / 7.0, 2),
        # ── Context (not features) ──
        "_country": sc["country"],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=8000, help="number of scenarios")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=str(Path(__file__).parent / "supply_training_data.parquet"))
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    random.seed(args.seed)
    seeds = load_seed_suppliers()

    rows = []
    for i in range(args.n):
        seed = seeds[i % len(seeds)]
        sc = sample_scenario(seed, rng)
        rows.append(build_row(sc, rng))
        if (i + 1) % 1000 == 0:
            print(f"  ...{i + 1:,}/{args.n:,} scenarios simulated")

    df = pd.DataFrame(rows)
    df.to_parquet(args.out, index=False)
    df.head(2000).to_csv(args.out.replace(".parquet", "_preview.csv"), index=False)

    print(f"\nGenerated {len(df):,} supplier-risk scenarios "
          f"({MC_TRIALS} MC trials each, {HORIZON_DAYS}-day horizon)")
    print(f"  Mean stockout probability : {df['stockout_prob'].mean():.3f}")
    print(f"  Scenarios that stock out  : {100 * df['did_stockout'].mean():.1f}%")
    print(f"  Mean weeks-to-stockout    : {df['weeks_to_stockout'].mean():.1f}")
    print(f"  Single-source share       : {100 * df['single_source'].mean():.1f}%")
    print(f"  High-risk-geo share       : {100 * df['high_risk_geo'].mean():.1f}%")
    print(f"\nWritten: {args.out}")


if __name__ == "__main__":
    main()
