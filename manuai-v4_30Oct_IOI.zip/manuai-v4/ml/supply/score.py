#!/usr/bin/env python3
"""
ManuAI — Supply Model Scoring Entry Point (Azure ML compatible)
===============================================================

Azure ML managed-endpoint scoring script. Matches the RiskAssessment contract the
supply-intelligence service expects, so wiring is:

    AML_SUPPLY_ENDPOINT=https://<endpoint>/score
    AML_API_KEY=<key>

The supply-intelligence service (V43) POSTs a SupplierInput payload here and gets
back a full RiskAssessment. On any error it falls back to the rule engine.

The model predicts P(stockout) and weeks-to-stockout from the supplier's stock,
lead-time drift, financial and sourcing profile — capturing interactions the
additive rule engine misses. Risk score, bucket, action and safety-stock uplift
are then derived from the ML predictions.

Local test:
    python score.py --selftest
"""

import os
import json
import joblib
import numpy as np
from pathlib import Path

_MODEL = None

# Risk thresholds (mirror ml_thresholds.csv service=supply)
CRIT_MIN, HIGH_MIN, MED_MIN = 70.0, 45.0, 25.0
EXPOSURE_MULT = 1.5
EMERGENCY_DAYS = 7
HIGH_RISK_GEO = {"Germany", "China", "Taiwan", "Ukraine", "Russia"}

FEATURES = [
    "current_stock_days", "reorder_point_days", "stock_vs_reorder",
    "lead_drift_days", "lead_drift_ratio", "monthly_consumption",
    "single_source", "high_risk_geo", "financial_risk_score",
    "exposure_inr", "rule_engine_score",
]


def init():
    global _MODEL
    model_dir = os.getenv("AZUREML_MODEL_DIR")
    candidate = (Path(model_dir) / "supply_model.joblib") if model_dir \
        else (Path(__file__).parent / "supply_model.joblib")
    _MODEL = joblib.load(candidate)


def _rule_engine_score(inp, lead_drift):
    """Replicate the additive rule-engine score (used as a model feature)."""
    score = 0.0
    if lead_drift > 0:
        score += min(lead_drift * 1.8, 40)
    fin = float(inp.get("financial_risk_score", 0))
    if fin > 50:
        score += (fin - 50) * 0.8
    if inp.get("single_source"):
        score += 20
    if float(inp.get("current_stock_days", 0)) < float(inp.get("reorder_point_days", 0)):
        score += 25
    if inp.get("country_of_origin") in HIGH_RISK_GEO and lead_drift > 5:
        score += 12
    return min(score, 100.0)


def _derive_features(inp):
    stock = float(inp.get("current_stock_days", 0))
    reorder = float(inp.get("reorder_point_days", 0))
    lead_c = float(inp.get("lead_time_contracted_days", 0))
    lead_a = float(inp.get("lead_time_actual_days", 0))
    lead_drift = lead_a - lead_c
    monthly = float(inp.get("monthly_consumption", 0))
    unit_cost = float(inp.get("unit_cost_inr", 0))
    single = 1 if inp.get("single_source") else 0
    geo = 1 if inp.get("country_of_origin") in HIGH_RISK_GEO else 0
    fin = float(inp.get("financial_risk_score", 0))
    exposure = unit_cost * monthly * EXPOSURE_MULT
    rule_score = _rule_engine_score(inp, lead_drift)
    return {
        "current_stock_days": stock,
        "reorder_point_days": reorder,
        "stock_vs_reorder": stock - reorder,
        "lead_drift_days": lead_drift,
        "lead_drift_ratio": lead_drift / max(1.0, lead_c),
        "monthly_consumption": monthly,
        "single_source": single,
        "high_risk_geo": geo,
        "financial_risk_score": fin,
        "exposure_inr": exposure,
        "rule_engine_score": rule_score,
    }, lead_drift, exposure


def run(raw_data):
    if _MODEL is None:
        init()
    inp = json.loads(raw_data) if isinstance(raw_data, str) else raw_data

    feats, lead_drift, exposure = _derive_features(inp)
    X = np.array([[feats[f] for f in FEATURES]], dtype=float)

    stockout_prob = float(_MODEL["clf_model"].predict_proba(X)[:, 1][0])
    weeks_to_stockout = float(max(0.0, _MODEL["reg_model"].predict(X)[0]))

    # ML-driven risk score (0–100) = stockout probability, blended with the
    # rule-engine score so existing thresholds remain meaningful.
    ml_score = stockout_prob * 100.0
    risk_score = round(0.7 * ml_score + 0.3 * feats["rule_engine_score"], 1)

    if   risk_score >= CRIT_MIN: overall = "critical"
    elif risk_score >= HIGH_MIN: overall = "high"
    elif risk_score >= MED_MIN:  overall = "medium"
    else:                        overall = "low"

    # Risk factors (human-readable drivers)
    factors = []
    if lead_drift > 0:
        factors.append(f"Lead-time drift +{int(lead_drift)}d over contract")
    if feats["financial_risk_score"] > 50:
        factors.append("Elevated supplier financial risk (D&B score)")
    if inp.get("single_source"):
        factors.append("Single-source supplier — no alternate")
    if feats["stock_vs_reorder"] < 0:
        factors.append(f"Stock below reorder point "
                       f"({feats['current_stock_days']:.0f}d < {feats['reorder_point_days']:.0f}d)")
    if feats["high_risk_geo"] and lead_drift > 5:
        factors.append(f"Origin: {inp.get('country_of_origin')} — trade/logistics risk flag")
    factors.append(f"ML stockout probability {stockout_prob*100:.0f}% within ~12 weeks")

    alts = (["Identify alternate source urgently"] if inp.get("single_source")
            else ["Alternate suppliers on panel"])

    # Action + safety-stock uplift brackets (ML-driven)
    stock = feats["current_stock_days"]
    if stock < EMERGENCY_DAYS or stockout_prob >= 0.85:
        action, safety_uplift = "Emergency procurement — expedite now", 50.0
    elif overall == "critical":
        action, safety_uplift = "Dual-source immediately; safety stock +40%", 40.0
    elif overall == "high":
        action, safety_uplift = "Increase safety stock and issue early PO", 20.0
    else:
        action, safety_uplift = "Monitor; no action required", 0.0

    return {
        "supplier_id": inp.get("supplier_id", "?"),
        "supplier_name": inp.get("supplier_name", "?"),
        "sku": inp.get("sku", "?"),
        "description": inp.get("description", ""),
        "overall_risk": overall,
        "risk_score": risk_score,
        "lead_time_drift_days": int(lead_drift),
        "shortfall_probability_pct": round(stockout_prob * 100, 1),
        "weeks_to_stockout": round(weeks_to_stockout, 1),
        "exposure_inr": round(exposure, 0),
        "risk_factors": factors,
        "recommended_action": action,
        "suggested_safety_stock_uplift_pct": safety_uplift,
        "alternate_suppliers": alts,
        "model_source": _MODEL.get("version", "supply-baseline-synthetic-v1"),
    }


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        init()
        # BASF — thin stock, big drift, single source, financially stressed
        basf = run({
            "supplier_id": "SUP-004", "supplier_name": "BASF Chemicals",
            "sku": "CMPD-X12", "description": "Compound X-12 Base Resin",
            "current_stock_days": 6, "reorder_point_days": 14,
            "lead_time_contracted_days": 30, "lead_time_actual_days": 51,
            "monthly_consumption": 12, "unit_cost_inr": 96000,
            "single_source": True, "country_of_origin": "Germany",
            "financial_risk_score": 55})
        # SKF — comfortable stock, on time, multi-source, healthy
        skf = run({
            "supplier_id": "SUP-003", "supplier_name": "SKF India",
            "sku": "BRG-6205", "description": "Deep Groove Ball Bearing 6205",
            "current_stock_days": 45, "reorder_point_days": 10,
            "lead_time_contracted_days": 7, "lead_time_actual_days": 7,
            "monthly_consumption": 30, "unit_cost_inr": 1200,
            "single_source": False, "country_of_origin": "India",
            "financial_risk_score": 12})
        print("BASF (high risk):", json.dumps(basf, indent=2))
        print()
        print("SKF (low risk):", json.dumps(skf, indent=2))
