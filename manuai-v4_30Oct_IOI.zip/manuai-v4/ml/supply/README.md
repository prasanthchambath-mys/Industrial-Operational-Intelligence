# ManuAI — Supply Risk Baseline Model (Synthetic Pre-Train)

Pre-trained supply-risk model so you can deploy a real ML endpoint in **Phase A**
instead of waiting for months of SAP MM stock/PO history + D&B financial scores.

## What the model learns (the uplift over the rule engine)
The live rule engine (`supply-intelligence/main.py`) scores risk **additively** —
a flat **+20** for single-source, lead drift **×1.8**, a fixed **+25** below
reorder point, etc. Each factor is independent and linear.

Real stockout risk is **interactive and non-linear**:
- **single_source** only hurts badly when lead-time is *also* drifting — with no
  expedite fallback to recover, the two **compound**, they don't just add.
- **financial stress** only matters when stock cover is *thin* — a shaky supplier
  with 60 days of stock is fine; with 5 days it is dangerous.
- it is lead-time **variability**, not just the mean drift, that causes stockouts.

The generator labels each scenario with a **Monte Carlo stockout simulation**
(200 trials × 84-day horizon): daily consumption depletes stock, PO replenishment
arrives after a supplier-specific lead-time distribution (SD grows with drift +
financial stress), and single-source removes the expedite option. The fraction of
trials that stock out is the ground-truth probability.

**Measured result on held-out scenarios:**
| Model | Stockout ranking AUC |
|-------|----------------------|
| Rule engine (additive score) | 0.643 |
| **ML stockout classifier** | **0.939** |
| **Uplift** | **+46% relative** |

The rule engine's 0.643 AUC is barely better than chance — as a *ranker* of who
will actually stock out, the additive score is weak precisely because it can't
represent the interactions above. Weeks-to-stockout regressor: **MAE 0.82 weeks,
R² 0.840**.

> **Verified interaction structure (held-out data):** among thin-stock suppliers,
> financial stress drives stockout 78% → 87%; among comfortable-stock suppliers
> the same financial stress is irrelevant (≈no effect). A linear/additive score
> cannot express that conditional — the tree ensemble can.

## Files
| File | Purpose |
|------|---------|
| `generate_training_data.py` | Synthesises supplier scenarios; labels via 200-trial Monte Carlo stockout simulation |
| `train_supply_model.py` | Trains stockout classifier + weeks-to-stockout regressor; benchmarks ranking AUC vs additive rule engine |
| `score.py` | Azure ML scoring entry point — matches supply-intelligence `RiskAssessment` contract |
| `supply_model.joblib` | Trained ensemble artifact |
| `supply_metrics.json` | Validation metrics incl. rule-engine comparison + interaction note |

## Pipeline
```bash
pip install -r requirements.txt
python generate_training_data.py --n 8000     # ~50% stockout balance
python train_supply_model.py                  # trains + benchmarks vs rule engine
python score.py --selftest                    # BASF (critical) vs SKF (low) sanity check
```

## Deploy to Phase A
1. Register `supply_model.joblib` as an Azure ML model.
2. Deploy `score.py` to a managed endpoint.
3. Set in Key Vault:
   ```
   AML_SUPPLY_ENDPOINT=https://<endpoint>/score
   AML_API_KEY=<key>
   ```
4. The `supply-intelligence` service calls it per supplier; on any error it falls
   back to the rule engine automatically (production never goes dark).

## Fine-tuning on real data (after access to SAP MM + D&B)
1. Pull real stock levels, open POs, and realised lead times from SAP MM, plus
   live D&B Paydex financial scores.
2. Label with actual observed stockout events (or re-run the MC simulation
   calibrated to the real lead-time distributions per supplier).
3. Re-run `train_supply_model.py --data real_scenarios.parquet`.
4. A/B test vs this baseline; promote when stockout-ranking AUC improves.

## Anchored constants (from real config)
- Risk buckets: critical ≥ 70, high ≥ 45, medium ≥ 25 (`ml_thresholds.csv`)
- Exposure multiplier: 1.5 months of consumption value
- High-risk origins: Germany, China, Taiwan, Ukraine, Russia
- Sampling anchored to the 5 real suppliers in `supply_risks.csv`
