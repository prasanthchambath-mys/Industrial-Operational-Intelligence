#!/usr/bin/env python3
"""
ManuAI — Supply Intelligence Model Training Harness
===================================================

Trains the supply-risk ensemble on synthetic Monte-Carlo-labelled scenarios:
  1. Stockout classifier      — XGBoost, P(stockout within horizon)
  2. Weeks-to-stockout regr.  — XGBoost, predicts weeks of cover remaining

The Monte Carlo labels encode the INTERACTIONS the additive rule engine misses
(single_source × drift, financial-stress × thin-stock, lead VARIABILITY not just
mean). We benchmark the ML stockout ranking against the rule-engine risk score to
quantify the gap the ML closes.

Output:
    supply_model.joblib
    supply_metrics.json
"""

import json
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import (mean_absolute_error, r2_score, f1_score,
                             accuracy_score, roc_auc_score, precision_score,
                             recall_score)
import xgboost as xgb

FEATURES = [
    "current_stock_days", "reorder_point_days", "stock_vs_reorder",
    "lead_drift_days", "lead_drift_ratio", "monthly_consumption",
    "single_source", "high_risk_geo", "financial_risk_score",
    "exposure_inr", "rule_engine_score",
]
CLS_TARGET = "did_stockout"
REG_TARGET = "weeks_to_stockout"


def rule_engine_ranking_auc(df_test):
    """
    The rule engine outputs a 0–100 risk score. As a stockout predictor, how well
    does that score rank suppliers by actual stockout outcome? AUC of rule_score
    vs did_stockout is the fair benchmark against the ML classifier's AUC.
    """
    try:
        return roc_auc_score(df_test[CLS_TARGET], df_test["rule_engine_score"])
    except ValueError:
        return float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(Path(__file__).parent / "supply_training_data.parquet"))
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=str(Path(__file__).parent / "supply_model.joblib"))
    args = ap.parse_args()

    df = pd.read_parquet(args.data)
    print(f"Loaded {len(df):,} scenarios | stockout rate {100*df[CLS_TARGET].mean():.1f}%")

    X = df[FEATURES]
    y_cls = df[CLS_TARGET]
    y_reg = df[REG_TARGET]

    X_tr, X_te, ycls_tr, ycls_te, yreg_tr, yreg_te, idx_tr, idx_te = train_test_split(
        X, y_cls, y_reg, df.index, test_size=0.2, random_state=args.seed,
        stratify=y_cls)
    df_te = df.loc[idx_te]

    # ── Classifier: P(stockout) ──
    clf = xgb.XGBClassifier(
        n_estimators=400, max_depth=5, learning_rate=0.05,
        subsample=0.85, colsample_bytree=0.85, min_child_weight=3,
        eval_metric="logloss", random_state=args.seed)
    clf.fit(X_tr, ycls_tr)
    p_te = clf.predict_proba(X_te)[:, 1]
    pred_cls = (p_te >= 0.5).astype(int)

    ml_f1   = f1_score(ycls_te, pred_cls)
    ml_acc  = accuracy_score(ycls_te, pred_cls)
    ml_prec = precision_score(ycls_te, pred_cls)
    ml_rec  = recall_score(ycls_te, pred_cls)
    ml_auc  = roc_auc_score(ycls_te, p_te)

    # ── Regressor: weeks-to-stockout ──
    reg = xgb.XGBRegressor(
        n_estimators=500, max_depth=5, learning_rate=0.05,
        subsample=0.85, colsample_bytree=0.85, min_child_weight=3,
        random_state=args.seed)
    reg.fit(X_tr, yreg_tr)
    yhat = reg.predict(X_te)
    reg_mae = mean_absolute_error(yreg_te, yhat)
    reg_r2  = r2_score(yreg_te, yhat)

    # ── Benchmark vs rule engine (ranking AUC) ──
    rule_auc = rule_engine_ranking_auc(df_te)
    auc_uplift = (ml_auc - rule_auc) / rule_auc * 100 if rule_auc == rule_auc else float("nan")

    # ── Feature importance (classifier) ──
    imp = dict(sorted(zip(FEATURES, clf.feature_importances_.tolist()),
                      key=lambda kv: -kv[1]))

    print("\n── Stockout classifier ──")
    print(f"  F1 {ml_f1:.3f} | Acc {ml_acc:.3f} | Prec {ml_prec:.3f} | "
          f"Rec {ml_rec:.3f} | AUC {ml_auc:.3f}")
    print("── Weeks-to-stockout regressor ──")
    print(f"  MAE {reg_mae:.2f} weeks | R² {reg_r2:.3f}")
    print("── Benchmark ──")
    print(f"  Rule-engine ranking AUC {rule_auc:.3f}  →  ML AUC {ml_auc:.3f} "
          f"({auc_uplift:+.1f}% relative)")
    print("── Top features ──")
    for k, v in list(imp.items())[:6]:
        print(f"  {k:24s} {v:.3f}")

    bundle = {
        "clf_model": clf,
        "reg_model": reg,
        "features": FEATURES,
        "version": "supply-baseline-synthetic-v1",
    }
    joblib.dump(bundle, args.out)

    metrics = {
        "model": "ManuAI Supply Risk Baseline Ensemble (synthetic pre-train)",
        "n_scenarios": int(len(df)),
        "mc_trials_per_scenario": 200,
        "horizon_days": 84,
        "stockout_rate_pct": round(100 * float(df[CLS_TARGET].mean()), 1),
        "stockout_classifier": {
            "f1": round(ml_f1, 4), "accuracy": round(ml_acc, 4),
            "precision": round(ml_prec, 4), "recall": round(ml_rec, 4),
            "roc_auc": round(ml_auc, 4),
        },
        "weeks_to_stockout_regressor": {
            "mae_weeks": round(reg_mae, 3), "r2": round(reg_r2, 4),
        },
        "rule_engine_benchmark": {
            "ranking_auc": round(rule_auc, 4),
            "ml_auc": round(ml_auc, 4),
            "auc_uplift_pct": round(auc_uplift, 1),
            "note": ("The rule engine scores risk ADDITIVELY (flat +20 single-source, "
                     "lead-drift ×1.8, +25 below reorder). As a stockout ranker its AUC "
                     "is the benchmark. The ML classifier learns the INTERACTIONS the "
                     "additive engine cannot: single_source compounds with lead drift, "
                     "financial stress only matters when stock cover is thin, and lead "
                     "VARIABILITY (not just mean drift) drives stockouts."),
        },
        "feature_importance": {k: round(v, 4) for k, v in imp.items()},
        "features": FEATURES,
        "note": ("Baseline for Phase A deployment. Fine-tune on real SAP MM stock/PO "
                 "history + D&B financial scores before retiring the rule engine."),
    }
    with open(Path(args.out).parent / "supply_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nWritten: {args.out}")
    print(f"Written: {Path(args.out).parent / 'supply_metrics.json'}")


if __name__ == "__main__":
    main()
