# ManuAI — Energy Baseline Model (Synthetic Pre-Train)

Pre-trained Energy load-dispatch model so you can deploy a real ML endpoint in
**Phase A** instead of waiting for months of smart-meter + grid-tariff history.

## What the model learns (the uplift over the rule engine)
The live rule engine (`energy-optimizer/main.py`) is **greedy and local** — it
fires a fixed action per asset when a threshold trips, independently. It does
not solve the global problem: *given a peak-demand limit and tariff window,
which combination of deferrals minimises total cost without breaching the peak
limit?* The synthetic generator computes the **global optimum** via constrained
enumeration (the ground-truth label), and the model learns to predict it.

**Measured result on held-out scenarios:**
| Model | MAE | R² |
|-------|-----|-----|
| Rule engine (greedy) | Rs 915 | −0.69 |
| **ML saving regressor** | **Rs 271** | **0.852** |
| **Uplift** | **70.4% lower error** | — |

The greedy rule engine's negative R² is informative: it systematically
mis-estimates the achievable saving when the peak-demand constraint binds —
exactly the regime where dispatch matters most. The ML model closes that gap.

> **Honest note on the peak-breach classifier:** it scores ~F1 0.998, but that
> is because `peak_breach_risk` is a near-deterministic function of
> `plant_kw_total` vs `peak_limit_kw` (both inputs) — it's effectively a learned
> threshold, not a hard prediction. The **saving regressor** is the meaningful
> model. We report the classifier metric with this caveat rather than tout it.

## Files
| File | Purpose |
|------|---------|
| `generate_training_data.py` | Synthesises load scenarios; labels with global-optimal dispatch via constrained enumeration |
| `train_energy_model.py` | Trains saving regressor + breach classifier; benchmarks vs greedy rule engine |
| `score.py` | Azure ML scoring entry point — matches energy-optimizer EnergyPrediction contract |
| `energy_model.joblib` | Trained ensemble artifact |
| `energy_metrics.json` | Validation metrics incl. rule-engine comparison + caveat |

## Pipeline
```bash
pip install -r requirements.txt
python generate_training_data.py --n-scenarios 15000
python train_energy_model.py       # trains + benchmarks vs greedy rule engine
python score.py --selftest         # off-peak idle vs peak near-limit sanity check
```

## Deploy to Phase A
1. Register `energy_model.joblib` as an Azure ML model.
2. Deploy `score.py` to a managed endpoint.
3. Set in Key Vault:
   ```
   AML_ENERGY_ENDPOINT=https://<endpoint>/score
   AML_API_KEY=<key>
   ```
4. The `energy-optimizer` service (V43, dispatch bug fixed) calls it; on any
   error it falls back to the rule engine automatically.

## Fine-tuning on real data (after ~60 days of smart meters + grid pricing)
1. Pull real per-asset kW from IoT Hub/smart meters + actual grid tariff feed.
2. Recompute optimal-dispatch labels (or use realised operator-approved savings).
3. Re-run `train_energy_model.py --data real_scenarios.parquet`.
4. A/B test vs this baseline; promote when saving-prediction MAE improves.

## Anchored constants (from real config)
- Tariff: peak Rs 12.0 / off-peak Rs 6.5 per kWh, peak window 18:00–22:00
- Grid carbon: 0.82 kgCO2/kWh
- Peak-demand penalty threshold: 1600 kW
- Hourly base-load curve from `energy_hourly.csv`
