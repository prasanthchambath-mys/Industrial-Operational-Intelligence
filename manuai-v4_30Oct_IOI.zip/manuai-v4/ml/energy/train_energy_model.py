#!/usr/bin/env python3
"""
ManuAI — Energy Baseline Model Training Harness
================================================

Trains the Energy dispatch ensemble on synthetic scenarios:
  1. Saving regressor  — XGBoost, predicts achievable optimal cost saving (INR)
  2. Breach classifier — XGBoost, P(peak-demand breach risk)

The model learns the GLOBAL optimal dispatch saving (computed by constrained
enumeration in the generator) — which the greedy, per-asset rule engine only
approximates. We benchmark the ML predicted-saving against the rule engine's
greedy saving to quantify the gap the ML closes.

Output:
    energy_model.joblib
    energy_metrics.json
"""

import json
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score, f1_score, accuracy_score, roc_auc_score
import xgboost as xgb

FEATURES = [
    "hour", "is_peak", "plant_kw_total", "peak_limit_kw", "peak_headroom_kw",
    "n_assets", "n_idle_assets", "n_shiftable_active", "avg_load_factor",
    "tariff_inr_kwh",
]
SAVING_TARGET = "optimal_cost_saving_inr"
BREACH_TARGET = "peak_breach_risk"


def greedy_rule_saving(df):
    """
    Approximate the rule engine's greedy saving: it fires fixed actions per
    asset independently. We model that as: idle assets shut down + a flat
    per-shiftable-asset saving, WITHOUT the global peak-constraint optimisation.
    This is intentionally simpler than the optimal — that gap is what the ML closes.
    """
    # Greedy: idle shutdown saving + shiftable shift saving, no global optimisation
    tariff = df["tariff_inr_kwh"].values
    # crude greedy estimate: each idle asset ~ avg idle kw * 0.85 * 6h * tariff
    greedy = (df["n_idle_assets"].values * 18 * 0.85 * 6 * tariff +
              df["n_shiftable_active"].values * 5.0 * 6 * tariff * 0.4)
    return greedy


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(Path(__file__).parent / "energy_training_data.parquet"))
    ap.add_argument("--out-model", default=str(Path(__file__).parent / "energy_model.joblib"))
    ap.add_argument("--out-metrics", default=str(Path(__file__).parent / "energy_metrics.json"))
    ap.add_argument("--test-frac", type=float, default=0.25)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    df = pd.read_parquet(args.data)
    print(f"Loaded {len(df):,} scenarios")

    X = df[FEATURES].values
    y_save = df[SAVING_TARGET].values
    y_breach = df[BREACH_TARGET].values

    Xtr, Xte, str_, ste, btr, bte, idx_tr, idx_te = train_test_split(
        X, y_save, y_breach, np.arange(len(df)),
        test_size=args.test_frac, random_state=args.seed)
    print(f"Train: {len(Xtr):,} | Test: {len(Xte):,}")

    # ── Saving regressor ───────────────────────────────────────────────────
    save_model = xgb.XGBRegressor(
        n_estimators=400, max_depth=6, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=args.seed,
        objective="reg:squarederror", n_jobs=-1)
    save_model.fit(Xtr, str_)
    spred = np.clip(save_model.predict(Xte), 0, None)
    ml_mae = mean_absolute_error(ste, spred)
    ml_r2  = r2_score(ste, spred)

    # ── Rule-engine greedy baseline on same test rows ──────────────────────
    df_te = df.iloc[idx_te]
    rule_pred = greedy_rule_saving(df_te)
    rule_mae = mean_absolute_error(ste, rule_pred)
    rule_r2  = r2_score(ste, rule_pred)

    # ── Peak-breach classifier ─────────────────────────────────────────────
    pos = btr.sum(); neg = len(btr) - pos
    spw = float(neg / max(pos, 1))
    breach_model = xgb.XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, random_state=args.seed,
        objective="binary:logistic", scale_pos_weight=spw,
        eval_metric="logloss", n_jobs=-1)
    breach_model.fit(Xtr, btr)
    bproba = breach_model.predict_proba(Xte)[:, 1]
    bpred = (bproba >= 0.5).astype(int)
    b_f1  = f1_score(bte, bpred, zero_division=0)
    b_acc = accuracy_score(bte, bpred)
    b_auc = roc_auc_score(bte, bproba)

    fi = dict(sorted(
        zip(FEATURES, [float(x) for x in save_model.feature_importances_]),
        key=lambda kv: kv[1], reverse=True))

    mae_improvement = round((rule_mae - ml_mae) / rule_mae * 100, 1)

    metrics = {
        "model": "ManuAI Energy Baseline Ensemble (synthetic pre-train)",
        "n_scenarios": int(len(df)),
        "saving_regressor": {"mae_inr": round(ml_mae, 2), "r2": round(ml_r2, 4)},
        "rule_engine_greedy_baseline": {"mae_inr": round(rule_mae, 2), "r2": round(rule_r2, 4)},
        "uplift_vs_rule_engine": {
            "mae_reduction_pct": mae_improvement,
            "note": f"ML predicts the GLOBAL-optimal dispatch saving {mae_improvement}% "
                    f"more accurately than the greedy rule engine, because it accounts "
                    f"for the peak-demand constraint and asset interactions the greedy "
                    f"engine ignores.",
        },
        "peak_breach_classifier": {
            "f1": round(b_f1, 4), "accuracy": round(b_acc, 4), "roc_auc": round(b_auc, 4),
            "caveat": "This classifier scores near-perfectly because peak_breach_risk "
                      "is a near-deterministic function of plant_kw_total vs peak_limit_kw "
                      "(both inputs). It is effectively a learned threshold, not a hard "
                      "prediction task. The SAVING regressor is the meaningful model here.",
        },
        "feature_importance": {k: round(v, 4) for k, v in fi.items()},
        "features": FEATURES,
        "note": "Baseline for Phase A deployment. Fine-tune on real smart-meter + "
                "grid-tariff data before retiring the rule engine.",
    }

    joblib.dump({
        "save_model": save_model,
        "breach_model": breach_model,
        "features": FEATURES,
        "version": "baseline-synthetic-v1",
    }, args.out_model)

    with open(args.out_metrics, "w") as f:
        json.dump(metrics, f, indent=2)

    print("\n── Validation (held-out scenarios) ──")
    print(f"  ML saving regressor  : MAE Rs {ml_mae:.1f} | R2 {ml_r2:.4f}")
    print(f"  Rule-engine greedy   : MAE Rs {rule_mae:.1f} | R2 {rule_r2:.4f}")
    print(f"  → ML is {mae_improvement}% more accurate at the optimal saving")
    print(f"  Peak-breach clf      : F1 {b_f1:.4f} | Acc {b_acc:.4f} | AUC {b_auc:.4f}")
    print(f"\n  Top features: " + ", ".join(f"{k} {v*100:.0f}%" for k, v in list(fi.items())[:4]))
    print(f"\nModel:   {args.out_model}")
    print(f"Metrics: {args.out_metrics}")


if __name__ == "__main__":
    main()
