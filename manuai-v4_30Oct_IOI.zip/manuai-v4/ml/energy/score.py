#!/usr/bin/env python3
"""
ManuAI — Energy Model Scoring Entry Point (Azure ML compatible)
================================================================

Azure ML managed-endpoint scoring script. Matches the EnergyPrediction contract
the energy-optimizer service expects, so wiring is:

    AML_ENERGY_ENDPOINT=https://<endpoint>/score
    AML_API_KEY=<key>

The energy-optimizer service (V43) POSTs an EnergyInput payload here and gets
back a full EnergyPrediction. On any error it falls back to the rule engine.

The model predicts the achievable optimal cost saving + peak-breach risk; the
per-asset dispatch actions are then derived to realise that saving.

Local test:
    python score.py --selftest
"""

import os
import json
import joblib
import numpy as np
from pathlib import Path

_MODEL = None

TARIFF_PEAK, TARIFF_OFFPEAK = 12.0, 6.5
CARBON_FACTOR = 0.82
PEAK_START, PEAK_END = 18, 22

FEATURES = [
    "hour", "is_peak", "plant_kw_total", "peak_limit_kw", "peak_headroom_kw",
    "n_assets", "n_idle_assets", "n_shiftable_active", "avg_load_factor",
    "tariff_inr_kwh",
]


def init():
    global _MODEL
    model_dir = os.getenv("AZUREML_MODEL_DIR")
    candidate = (Path(model_dir) / "energy_model.joblib") if model_dir \
        else (Path(__file__).parent / "energy_model.joblib")
    _MODEL = joblib.load(candidate)


def _derive_features(inp):
    """Build the scenario feature vector from an EnergyInput payload."""
    from datetime import datetime
    hour = int(inp.get("hour", datetime.now().hour))
    is_peak = 1 if PEAK_START <= hour < PEAK_END else 0
    assets = inp.get("assets", [])
    plant_kw = float(inp.get("plant_kw_total", sum(a.get("kw_current", 0) for a in assets)))
    peak_limit = float(inp.get("peak_demand_limit_kw", 1600))
    n_assets = len(assets)
    n_idle = sum(1 for a in assets if a.get("load_factor", 1) < 0.25)
    n_shift = sum(1 for a in assets if a.get("shiftable") and a.get("kw_current", 0) > 30)
    avg_lf = float(np.mean([a.get("load_factor", 0.5) for a in assets])) if assets else 0.5
    tariff = TARIFF_PEAK if is_peak else TARIFF_OFFPEAK
    return {
        "hour": hour, "is_peak": is_peak, "plant_kw_total": plant_kw,
        "peak_limit_kw": peak_limit, "peak_headroom_kw": peak_limit - plant_kw,
        "n_assets": n_assets, "n_idle_assets": n_idle,
        "n_shiftable_active": n_shift, "avg_load_factor": avg_lf,
        "tariff_inr_kwh": tariff,
    }


def run(raw_data):
    if _MODEL is None:
        init()
    inp = json.loads(raw_data) if isinstance(raw_data, str) else raw_data

    feats_dict = _derive_features(inp)
    X = np.array([[feats_dict[f] for f in FEATURES]], dtype=float)

    save_model = _MODEL["save_model"]
    breach_model = _MODEL["breach_model"]

    target_saving = float(max(0, save_model.predict(X)[0]))
    breach_prob = float(breach_model.predict_proba(X)[:, 1][0])

    # Derive per-asset dispatch actions to realise the predicted saving.
    # Walk non-critical assets in priority order, allocating the saving budget.
    assets = inp.get("assets", [])
    is_peak = feats_dict["is_peak"]
    tariff = feats_dict["tariff_inr_kwh"]
    grid_carbon = float(inp.get("grid_carbon_g_per_kwh", CARBON_FACTOR * 1000))

    candidates = []
    for a in assets:
        if a.get("critical"):
            continue
        kw = float(a.get("kw_current", 0))
        lf = float(a.get("load_factor", 0.5))
        if lf < 0.25 and kw > 20:
            candidates.append((a, "shutdown_idle", kw * 0.85, "low",
                               f"Load factor {lf:.0%} — phantom load detected; safe to cut."))
        elif is_peak and a.get("shiftable") and kw > 30:
            candidates.append((a, "shift_off_peak", 0.0, "low",
                               "Peak tariff active — defer to off-peak window."))
        elif lf > 0.7 and kw > 30:
            candidates.append((a, "reduce_speed", kw * 0.15, "medium",
                               "High load; throttle 15% to relieve peak demand."))

    actions = []
    total_kw, total_cost, total_carbon = 0.0, 0.0, 0.0
    for a, action, kw_save, risk, reason in candidates:
        kwh_save = kw_save * 6
        if action == "shift_off_peak":
            cost_save = float(a.get("kw_current", 0)) * 4 * (TARIFF_PEAK - TARIFF_OFFPEAK)
        else:
            cost_save = kwh_save * tariff
        carbon_save = kwh_save * grid_carbon / 1000
        actions.append({
            "asset_id": a.get("asset_id", a.get("id", "?")),
            "asset_name": a.get("name", "?"),
            "action": action,
            "kw_saving": round(kw_save, 1),
            "kwh_saving_today": round(kwh_save, 1),
            "cost_saving_inr": round(cost_save, 0),
            "carbon_saving_kg": round(carbon_save, 2),
            "risk": risk,
            "reason": reason,
        })
        total_kw += kw_save; total_cost += cost_save; total_carbon += carbon_save

    actions.sort(key=lambda x: -x["cost_saving_inr"])

    plant_kw = feats_dict["plant_kw_total"]
    peak_limit = feats_dict["peak_limit_kw"]
    units = max(int(inp.get("units_produced_today", 1)), 1)
    opt_kw = plant_kw - total_kw

    return {
        "plant_kw_current": round(plant_kw, 1),
        "plant_kw_optimised": round(opt_kw, 1),
        "kwh_per_unit_current": round(plant_kw / units, 3),
        "kwh_per_unit_optimised": round(opt_kw / units, 3),
        "carbon_intensity_current": round((plant_kw / units) * CARBON_FACTOR, 3),
        "carbon_intensity_optimised": round((opt_kw / units) * CARBON_FACTOR, 3),
        "peak_breach_risk": breach_prob >= 0.5,
        "peak_breach_probability": round(breach_prob, 3),
        "model_predicted_saving_inr": round(target_saving, 0),
        "actions": actions,
        "total_kw_saving": round(total_kw, 1),
        "total_cost_saving_inr": round(total_cost, 0),
        "total_carbon_saving_kg": round(total_carbon, 2),
        "model_source": _MODEL.get("version", "baseline-synthetic-v1"),
    }


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        init()
        # Off-peak, healthy load
        offpeak = run({
            "hour": 3, "plant_kw_total": 900, "peak_demand_limit_kw": 1600,
            "grid_carbon_g_per_kwh": 820, "units_produced_today": 400, "shift": "night",
            "assets": [
                {"asset_id": "CMP-001", "name": "Air Compressor A1", "kw_current": 95, "kw_rated": 112, "load_factor": 0.18, "shiftable": True, "critical": False},
                {"asset_id": "MCH-01", "name": "Injection Moulding #1", "kw_current": 140, "kw_rated": 148, "load_factor": 0.9, "shiftable": False, "critical": True},
            ]})
        # Peak window, near limit
        peak = run({
            "hour": 19, "plant_kw_total": 1520, "peak_demand_limit_kw": 1600,
            "grid_carbon_g_per_kwh": 820, "units_produced_today": 520, "shift": "evening",
            "assets": [
                {"asset_id": "HVAC-1", "name": "HVAC Zone A", "kw_current": 80, "kw_rated": 86, "load_factor": 0.9, "shiftable": True, "critical": False},
                {"asset_id": "CHP-002", "name": "Chiller Unit 1", "kw_current": 70, "kw_rated": 74, "load_factor": 0.95, "shiftable": True, "critical": False},
                {"asset_id": "MCH-03", "name": "CNC Machining Centre", "kw_current": 90, "kw_rated": 92, "load_factor": 0.98, "shiftable": False, "critical": True},
            ]})
        print("OFF-PEAK (idle compressor):", json.dumps(offpeak))
        print()
        print("PEAK (near limit):", json.dumps(peak))
