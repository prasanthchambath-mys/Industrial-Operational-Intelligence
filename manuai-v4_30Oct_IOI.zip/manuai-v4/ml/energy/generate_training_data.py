#!/usr/bin/env python3
"""
ManuAI — Energy Synthetic Training Data Generator
==================================================

Generates labelled plant-load scenarios for training an Energy dispatch model.

WHAT THE MODEL LEARNS (the uplift over the rule engine):
  The rule engine (energy-optimizer/main.py) is GREEDY and LOCAL — it looks at
  each asset independently and fires a fixed action when a threshold trips. It
  does NOT solve the global problem: "given a peak-demand limit and a tariff
  window, which COMBINATION of deferrals minimises total cost without breaching
  the peak limit, accounting for the fact that shifting load to off-peak hours
  can create a NEW peak later?"

  We synthesise scenarios + compute the OPTIMAL dispatch via a constrained
  search (the ground-truth label), then train a regressor to predict the
  achievable cost saving and a per-asset classifier for the optimal action.
  The model learns the global optimum the greedy rule engine approximates.

Physics anchored to real config (energy_assets.csv, energy_hourly.csv,
ml_thresholds.csv, platform_config.csv):
  • tariff: peak 12.0 / off-peak 6.5 INR/kWh, peak window 18:00–22:00
  • carbon: 0.82 kgCO2/kWh
  • peak demand penalty threshold: 1600 kW
  • hourly base load curve from energy_hourly.csv

Output: energy_training_data.parquet
"""

import os
import csv
import random
import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
ASSETS_CSV = BASE / "data" / "csv" / "energy_assets.csv"
HOURLY_CSV = BASE / "data" / "csv" / "energy_hourly.csv"

# Constants from ml_thresholds.csv / platform_config.csv
TARIFF_PEAK    = 12.0
TARIFF_OFFPEAK = 6.5
CARBON_FACTOR  = 0.82
PEAK_START, PEAK_END = 18, 22
PEAK_LIMIT_KW  = 1600.0


def load_assets():
    assets = []
    if ASSETS_CSV.exists():
        with open(ASSETS_CSV, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                assets.append({
                    "id": row["id"], "name": row["name"],
                    "rated_kw": float(row["rated_kw"]),
                    "shiftable": row["shiftable"].strip().lower() == "true",
                    "critical": row["critical"].strip().lower() == "true",
                    "plant": row["plant"],
                })
    return assets


def load_hourly():
    curve = {}
    if HOURLY_CSV.exists():
        with open(HOURLY_CSV, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                h = int(row["hour"].split(":")[0])
                curve[h] = float(row["kw_base"])
    return curve


def is_peak(hour):
    return PEAK_START <= hour < PEAK_END


def optimal_dispatch(assets_state, hour, peak_limit, plant_base_load=0.0):
    """
    Ground-truth optimal dispatch via constrained enumeration over shiftable/
    non-critical assets. Returns (best_cost_saving_inr, best_kw_saving,
    best_action_mask). This is what the model learns to predict — the GLOBAL
    optimum the greedy rule engine only approximates.

    plant_base_load is the facility baseline (lighting/HVAC/other lines) that
    the controllable assets sit on top of — it determines how much the peak
    limit actually constrains the dispatch.

    Each non-critical asset has up to 3 candidate actions:
      0 = no action
      1 = reduce 15% (if load_factor high)
      2 = shift/shutdown (if idle or shiftable in peak)
    We enumerate combinations and pick the one with max cost saving that keeps
    plant load under the peak limit.
    """
    peak = is_peak(hour)
    tariff = TARIFF_PEAK if peak else TARIFF_OFFPEAK

    candidates = []  # (idx, [(action_id, kw_saving, cost_saving), ...])
    for idx, a in enumerate(assets_state):
        if a["critical"]:
            continue
        opts = [(0, 0.0, 0.0)]
        kw = a["kw_current"]
        lf = a["load_factor"]
        # Idle shutdown
        if lf < 0.25 and kw > 20:
            kw_save = kw * 0.85
            opts.append((2, kw_save, kw_save * 6 * tariff))
        # Shift to off-peak (cost saving only, during peak)
        if peak and a["shiftable"] and kw > 30:
            kwh = kw * 4
            opts.append((2, 0.0, kwh * (TARIFF_PEAK - TARIFF_OFFPEAK)))
        # Reduce 15%
        if lf > 0.7 and kw > 30:
            kw_save = kw * 0.15
            opts.append((1, kw_save, kw_save * 6 * tariff))
        candidates.append((idx, opts))

    if not candidates:
        return 0.0, 0.0, {}

    # Enumerate (cap combinatorics: take top-N assets by potential saving)
    candidates.sort(key=lambda c: -max(o[2] for o in c[1]))
    candidates = candidates[:8]  # 3^8 = 6561 combos max

    plant_total = sum(a["kw_current"] for a in assets_state) + plant_base_load
    best = (0.0, 0.0, {})
    option_lists = [c[1] for c in candidates]
    for combo in itertools.product(*option_lists):
        total_kw_save = sum(o[1] for o in combo)
        total_cost_save = sum(o[2] for o in combo)
        resulting_load = plant_total - total_kw_save
        # Constraint: must not breach peak limit (we WANT to be under it)
        # Reward staying under limit; heavily penalise breach
        if resulting_load > peak_limit:
            # breach penalty proportional to overshoot
            total_cost_save -= (resulting_load - peak_limit) * tariff * 0.5
        if total_cost_save > best[0]:
            mask = {candidates[i][0]: combo[i][0] for i in range(len(candidates))}
            best = (total_cost_save, total_kw_save, mask)
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-scenarios", type=int, default=15000)
    ap.add_argument("--out", default=str(Path(__file__).parent / "energy_training_data.parquet"))
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    assets = load_assets()
    hourly = load_hourly()
    if not assets:
        raise SystemExit("Could not load energy_assets.csv")

    rows = []
    for i in range(args.n_scenarios):
        hour = random.randint(0, 23)
        plant = random.choice(["P1", "P2"])
        plant_assets = [a for a in assets if a["plant"] == plant]
        if not plant_assets:
            continue

        # Randomise per-asset load factor + current draw for this scenario
        state = []
        for a in plant_assets:
            lf = float(np.clip(np.random.beta(2, 2) + random.uniform(-0.1, 0.2), 0.05, 1.0))
            # idle scenarios sometimes
            if random.random() < 0.15:
                lf = random.uniform(0.05, 0.22)
            kw_current = a["rated_kw"] * lf * random.uniform(0.85, 1.05)
            state.append({**a, "load_factor": lf, "kw_current": kw_current})

        plant_total = sum(s["kw_current"] for s in state)
        # Facility base load (lighting, HVAC, other lines) from the hourly curve.
        # This is what makes the peak-demand limit a real constraint — the asset
        # loads sit ON TOP of the facility baseline.
        base_load = hourly.get(hour, 1000)
        plant_total_with_base = plant_total + base_load * random.uniform(0.55, 0.85)

        peak_limit = PEAK_LIMIT_KW * (1.0 if plant == "P1" else 0.95)

        # Ground-truth optimal dispatch
        plant_base = plant_total_with_base - plant_total
        best_cost, best_kw, mask = optimal_dispatch(state, hour, peak_limit, plant_base)

        peak = is_peak(hour)
        carbon_save = best_kw * 6 * CARBON_FACTOR / 1.0  # kg over 6h horizon

        # Scenario-level features
        n_idle = sum(1 for s in state if s["load_factor"] < 0.25)
        n_shiftable_active = sum(1 for s in state if s["shiftable"] and s["kw_current"] > 30)
        avg_lf = float(np.mean([s["load_factor"] for s in state]))
        peak_headroom = peak_limit - plant_total_with_base

        rows.append({
            "scenario_id": i,
            "plant_id": plant,
            "hour": hour,
            "is_peak": int(peak),
            "plant_kw_total": round(plant_total_with_base, 1),
            "peak_limit_kw": round(peak_limit, 1),
            "peak_headroom_kw": round(peak_headroom, 1),
            "n_assets": len(state),
            "n_idle_assets": n_idle,
            "n_shiftable_active": n_shiftable_active,
            "avg_load_factor": round(avg_lf, 3),
            "tariff_inr_kwh": TARIFF_PEAK if peak else TARIFF_OFFPEAK,
            # ── Labels (ground-truth optimal dispatch) ──
            "optimal_cost_saving_inr": round(max(0, best_cost), 1),
            "optimal_kw_saving": round(best_kw, 1),
            "optimal_carbon_saving_kg": round(carbon_save, 2),
            "peak_breach_risk": int(plant_total_with_base > peak_limit * 0.90),
        })

    df = pd.DataFrame(rows)
    df.to_parquet(args.out, index=False)
    df.head(2000).to_csv(args.out.replace(".parquet", "_preview.csv"), index=False)

    print(f"Generated {len(df):,} dispatch scenarios")
    print(f"  Mean optimal cost saving : Rs {df['optimal_cost_saving_inr'].mean():.0f}")
    print(f"  Mean optimal kW saving   : {df['optimal_kw_saving'].mean():.1f} kW")
    print(f"  Peak-breach-risk scenarios: {100*df['peak_breach_risk'].mean():.1f}%")
    print(f"  Peak-window scenarios     : {100*df['is_peak'].mean():.1f}%")
    print(f"\nWritten: {args.out}")


if __name__ == "__main__":
    main()
