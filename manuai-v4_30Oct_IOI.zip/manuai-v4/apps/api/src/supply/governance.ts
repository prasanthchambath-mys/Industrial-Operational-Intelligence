// ─────────────────────────────────────────────────────────────────────────
// Supply-Chain Reorder Governance — semantic/selector layer
//
// This module is the single source of supply-chain governance metrics and the
// rule-engine that converts risk/stock signals into governed reorder decisions
// (Auto-Approval vs Manual-Approval). The UI consumes ONLY these selectors —
// no KPI/count is computed in the React layer.
//
// State model (per the "CSV/DB-seeded, resets on restart" demo choice):
//   • Reference data (suppliers, skus, inventory, alerts, map) is read fresh
//     from the CSV data layer on each call.
//   • Mutable governance state (rules' enabled flag, reorder_requests,
//     auto_approved_orders) is seeded from CSV at first access into an
//     in-process working set and mutated by the POST endpoints. A process
//     restart re-seeds from CSV — nothing persists across restarts.
//   • Phase A can swap this working set for Postgres tables without touching
//     the selector signatures or the UI (the thin-abstraction seam).
// ─────────────────────────────────────────────────────────────────────────
import { normalizePlant } from '../data/plant';
import {
  loadSuppliers, loadSupplierPlantMap, loadSkus, loadInventoryPositions,
  loadExternalRiskAlerts, loadReorderRules, loadReorderRequests, loadAutoApprovedOrders,
  loadSupplyRisks,
  loadSupplierLeadTimeHistory, loadSupplierRiskFactors, loadSupplierPerformanceMetrics,
  loadPlatformConfig,
} from '../data/csv-loader';
import {
  getSuppliers, getSupplierPlantMap, getSkus, getInventoryPositions,
  getExternalRiskAlerts as dbGetExternalRiskAlerts, getReorderRulesDb, getReorderRequestsDb, getAutoApprovedOrdersDb,
  getSupplierRiskFactors, getSupplierLeadTimeHistory, getSupplierPerformanceMetrics,
  getSupplyRisks, getDemandForecast,
  dbBumpRule, dbToggleRule, dbInsertReorderRequest, dbInsertAutoOrder, dbInsertReorderRule, dbUpdateRequestStatus,
} from '../database/db-queries';

// ── DB-authoritative accessors (CSV fallback handled inside db-queries) ─────
// The selector layer now reads supply-chain data through db-queries.ts, which
// is DB-first and falls back to CSV only when a table is empty / query errors.
// `rules()` is read fresh from the DB each call so toggles/bumps are reflected
// without an in-process cache.
const rules       = () => getReorderRulesDb();
const requests    = () => getReorderRequestsDb();
const autoOrders  = () => getAutoApprovedOrdersDb();
const today = () => new Date().toISOString().slice(0, 10);
let _seq = 0;  // monotonic suffix for generated record ids

// ── Plant helpers ──────────────────────────────────────────────────────────
// TODO: Replace hardcoded plant mapping with metadata-driven plant lookup
// before adding additional plants. The plant *topology* (machines, lines, zones,
// codes) is already CSV-derived in data/plant.ts; the small label/scope maps below
// (SCOPE_TO_CODE here and PLANT_LABEL further down) are the remaining hardcoded
// bits. The scalable fix is to derive labels from the CSV topology rather than a
// hardcoded array — deferred now to avoid touching plant resolution across files
// and risking the validated Plant 1 / Plant 2 / All Plants behavior.
const SCOPE_TO_CODE: Record<string, string> = { Mumbai: 'P1', Pune: 'P2' };
/** Selector plant value → CSV plant code, or null for All Plants. */
function plantCode(plant?: string): string | null {
  const c = normalizePlant(plant);
  return c && c !== 'All Plants' ? c : null;
}
function byPlant<T extends { plant_id?: string }>(rows: T[], plant?: string): T[] {
  const c = plantCode(plant);
  return c ? rows.filter(r => r.plant_id === c) : rows;
}
/** A rule applies to the selected plant if All-Plants is selected, the rule is
 *  All-Plants scoped, or its plant_scope maps to the selected plant code. */
function ruleInScope(rule: any, plant?: string): boolean {
  const c = plantCode(plant);
  if (!c) return true;
  if (rule.plant_scope === 'All Plants') return true;
  return SCOPE_TO_CODE[rule.plant_scope] === c;
}

// ── Thresholds parsed from rule conditions (data-driven, not hardcoded) ─────
function numFromRule(rulesArr: any[], re: RegExp, fallback: number): number {
  for (const r of rulesArr) { const m = re.exec(r.conditions || ''); if (m) return Number(m[1]); }
  return fallback;
}

const SEV_RANK: Record<string, number> = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
function highestSeverity(sevs: string[]): string | null {
  let best: string | null = null;
  for (const s of sevs) if ((SEV_RANK[s] ?? 0) > (best ? SEV_RANK[best] : 0)) best = s;
  return best;
}

// ── Reorder candidate built from a supply_risks row + reference data ────────
async function buildCandidate(row: any) {
  const sku = (await getSkus() as any[]).find(s => s.sku_code === row.sku);
  const supplier = (await getSuppliers() as any[]).find(s => s.supplier_id === row.supplier_id);
  const leadDrift = Number(row.lead_time_actual_days ?? 0) - Number(row.lead_time_contracted_days ?? 0);
  const openAlerts = (await dbGetExternalRiskAlerts() as any[]).filter(
    a => a.status !== 'Closed' && (a.supplier_id === row.supplier_id || (sku && a.sku_id === sku.sku_id)));
  const qty = Math.max(1, Math.round(Number(row.monthly_consumption ?? 1)));
  const orderValue = qty * Number(row.unit_cost_inr ?? 0);
  return {
    sku_id: sku?.sku_id ?? row.sku,
    sku_code: row.sku,
    plant_id: row.plant,
    supplier_id: row.supplier_id,
    supplierRisk: supplier?.risk_level ?? 'MEDIUM',
    skuCriticality: sku?.criticality ?? 'MEDIUM',
    alternateSupplier: sku?.alternate_supplier_id ?? null,
    leadDrift,
    qty,
    orderValue,
    externalSeverity: highestSeverity(openAlerts.map(a => a.severity)),
    financialRiskHigh: Number(supplier?.risk_score ?? 0) >= 60,
    stockBelowReorder: Number(row.current_stock_days ?? 0) < Number(row.reorder_point_days ?? 0),
    semanticConflict: false,
    triggerReason: `Stock cover ${row.current_stock_days}d vs reorder point ${row.reorder_point_days}d`,
  };
}

function readinessFor(decision: 'Auto' | 'Manual', c: any): string {
  if (decision === 'Auto') return 'Ready for Auto Approval';
  if (c.supplierRisk === 'CRITICAL' || c.externalSeverity === 'CRITICAL') return 'Blocked by Risk';
  if (c.alternateSupplier) return 'Waiting for Supplier Validation';
  return 'Manual Approval Required';
}

// ── Rule engine: the governance decision ────────────────────────────────────
export interface ReorderDecision {
  decision: 'Auto' | 'Manual';
  ruleId: string; ruleName: string; reason: string; readiness: string;
}
export async function evaluateReorderDecision(c: any, plant?: string): Promise<ReorderDecision> {
  const allRules = await rules();
  const orderValueThreshold = () => numFromRule(allRules, /order_value\s*[<>=]+\s*(\d+)/, 500000);
  const leadDriftThreshold  = () => numFromRule(allRules, /lead_time_drift_days\s*>\s*(\d+)/, 10);
  const on = (id: string) => allRules.some(r => r.rule_id === id && r.enabled && ruleInScope(r, plant));
  const name = (id: string) => allRules.find(r => r.rule_id === id)?.rule_name ?? id;
  const manual = (id: string, reason: string): ReorderDecision =>
    ({ decision: 'Manual', ruleId: id, ruleName: name(id), reason, readiness: readinessFor('Manual', c) });
  const auto = (id: string, reason: string): ReorderDecision =>
    ({ decision: 'Auto', ruleId: id, ruleName: name(id), reason, readiness: 'Ready for Auto Approval' });

  // Manual-approval gates (highest precedence first)
  if (on('RULE-07') && c.semanticConflict) return manual('RULE-07', 'Blocked by active semantic-layer conflict');
  if (on('RULE-02') && c.supplierRisk === 'CRITICAL') return manual('RULE-02', 'Supplier risk is CRITICAL');
  if (on('RULE-03') && c.orderValue > orderValueThreshold())
    return manual('RULE-03', `Order value \u20b9${c.orderValue.toLocaleString('en-IN')} exceeds threshold`);
  if (on('RULE-05') && (c.externalSeverity === 'HIGH' || c.externalSeverity === 'CRITICAL'))
    return manual('RULE-05', `External risk severity ${c.externalSeverity}`);
  if (on('RULE-06') && c.leadDrift > leadDriftThreshold())
    return manual('RULE-06', `Lead-time drift ${c.leadDrift}d exceeds ${leadDriftThreshold()}d`);
  if (on('RULE-08') && c.alternateSupplier) return manual('RULE-08', 'Alternate supplier recommendation exists');
  if (c.financialRiskHigh) return manual('RULE-02', 'Supplier financial risk is high');

  // Auto-approval paths
  if (on('RULE-04') && c.skuCriticality === 'CRITICAL' && (c.supplierRisk === 'LOW' || c.supplierRisk === 'MEDIUM'))
    return auto('RULE-04', 'Business-critical SKU with low/medium supplier risk');
  if (on('RULE-01') && c.stockBelowReorder && (c.supplierRisk === 'LOW' || c.supplierRisk === 'MEDIUM') && c.orderValue <= orderValueThreshold())
    return auto('RULE-01', 'Stock below reorder point; supplier risk low/medium; value within threshold');

  return manual('RULE-02', 'No auto-approval rule satisfied — routed for manual approval');
}

// ── Supplier risk detail (popup / modal) — single semantic selector ─────────
// Consumes ONLY reference + popup CSVs and the rule engine. The modal renders
// exactly this output; no business logic lives in the UI. Resolves the
// supplier/SKU/plant/risk-event tuple to a full intelligence bundle.
const RISK_RANK: Record<string, number> = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
const PLANT_LABEL: Record<string, string> = { P1: 'Plant 1', P2: 'Plant 2' };

export async function getSupplierRiskDetail(args: {
  supplierId?: string; skuId?: string; skuCode?: string; plantId?: string; riskEventId?: string;
}) {
  const { supplierId, plantId, riskEventId } = args;
  const skus = await getSkus() as any[];
  // Resolve the SKU from sku_id, sku_code, or the risk-event id (supplier-skuCode).
  let sku = args.skuId ? skus.find(s => s.sku_id === args.skuId) : undefined;
  if (!sku && args.skuCode) sku = skus.find(s => s.sku_code === args.skuCode);
  if (!sku && riskEventId) {
    const code = riskEventId.replace(`${supplierId}-`, '');
    sku = skus.find(s => s.sku_code === code);
  }
  const skuId = sku?.sku_id ?? args.skuId ?? null;
  const skuCode = sku?.sku_code ?? args.skuCode ?? null;

  const supplier = (await getSuppliers() as any[]).find(s => s.supplier_id === supplierId) ?? null;
  const plant = plantId ?? sku?.plant_id ?? null;

  // The matching supply_risks row carries live stock/lead-time/exposure signals.
  const riskRow = (await getSupplyRisks() as any[]).find(
    r => r.supplier_id === supplierId && (skuCode ? r.sku === skuCode : true));

  // Exposure / order-value from the per-plant supplier map.
  const map = (await getSupplierPlantMap() as any[]).find(
    m => m.supplier_id === supplierId && m.plant_id === plant);

  // Risk factors (plant + supplier + sku scoped), sorted most-severe first.
  const riskFactors = (await getSupplierRiskFactors() as any[])
    .filter(f => f.supplier_id === supplierId && (skuId ? f.sku_id === skuId : true) && (plant ? f.plant_id === plant : true))
    .sort((a, b) => (RISK_RANK[b.severity] ?? 0) - (RISK_RANK[a.severity] ?? 0));

  // Lead-time trend (already carries derived drift_days from the loader).
  const leadTimeTrend = (await getSupplierLeadTimeHistory() as any[])
    .filter(h => h.supplier_id === supplierId && (skuId ? h.sku_id === skuId : true) && (plant ? h.plant_id === plant : true));

  const historicalPerformance = (await getSupplierPerformanceMetrics() as any[])
    .filter(p => p.supplier_id === supplierId && (skuId ? p.sku_id === skuId : true) && (plant ? p.plant_id === plant : true));

  // ── Supplier Reliability Score: now a DERIVED, governed KPI ──────────────────
  // semantic_kpi_definitions:supplier_reliability_score. Previously a static figure
  // seeded in supplier_performance_metrics.csv that could drift from the metrics
  // shown beside it. Now computed as a config-weighted composite (platform_config
  // supply_reliability) of on-time delivery, quality acceptance, fill rate, and a
  // disruption-free index. Weights are read from config — never hardcoded.
  const relCfg = (loadPlatformConfig() as any).supplyReliability ?? {};
  const wOnTime = Number(relCfg.on_time_weight ?? 0.35);
  const wQuality = Number(relCfg.quality_weight ?? 0.35);
  const wFill = Number(relCfg.fill_rate_weight ?? 0.20);
  const wDisruption = Number(relCfg.disruption_weight ?? 0.10);
  const disruptionPenalty = Number(relCfg.disruption_penalty_per_event ?? 20);
  const perfVal = (name: string): number | null => {
    const row = historicalPerformance.find(
      (p: any) => String(p.metric_name).toLowerCase() === name.toLowerCase());
    if (!row) return null;
    const n = Number(row.metric_value);
    return Number.isFinite(n) ? n : null;
  };
  const onTime = perfVal('On-Time Delivery');
  const quality = perfVal('Quality Acceptance Rate');
  const fillRate = perfVal('Fill Rate');
  const disruptions = perfVal('Disruption Incidents');
  let reliabilityScore: number | null = null;
  if (onTime != null && quality != null && fillRate != null) {
    const disruptionFreeIndex = Math.max(0, 100 - (disruptions ?? 0) * disruptionPenalty);
    reliabilityScore = Math.max(0, Math.min(100, Math.round(
      wOnTime * onTime + wQuality * quality + wFill * fillRate + wDisruption * disruptionFreeIndex)));
  }
  // Replace the (formerly static) Supplier Reliability Score row with the derived
  // value — build a new array so cached metric objects are never mutated. If no
  // seeded row exists for this supplier/SKU, surface the derived KPI anyway.
  let sawReliabilityRow = false;
  const historicalPerformanceOut = historicalPerformance.map((p: any) => {
    if (String(p.metric_name).toLowerCase() === 'supplier reliability score') {
      sawReliabilityRow = true;
      return reliabilityScore != null
        ? { ...p, metric_value: reliabilityScore, is_derived: true }
        : { ...p, is_derived: false };
    }
    return p;
  });
  if (!sawReliabilityRow && reliabilityScore != null) {
    historicalPerformanceOut.push({
      metric_id: `REL-${supplierId ?? 'NA'}-${skuId ?? 'NA'}`,
      supplier_id: supplierId, sku_id: skuId, plant_id: plant,
      metric_name: 'Supplier Reliability Score', metric_value: reliabilityScore,
      metric_unit: '/100', period: 'Current', trend_direction: 'flat', is_derived: true,
    });
  }

  // External alerts impacting this supplier or SKU (open/monitoring only).
  const externalAlerts = (await dbGetExternalRiskAlerts() as any[])
    .filter(a => a.status !== 'Closed' && (a.supplier_id === supplierId || (skuId && a.sku_id === skuId)));

  // Risk score: supplier base risk_score, escalated by active external severity
  // and lead-time drift. Bounded 0-100. Never hardcoded.
  const baseScore = Number(supplier?.risk_score ?? 0);
  const extBoost = externalAlerts.reduce(
    (m, a) => Math.max(m, ({ CRITICAL: 16, HIGH: 10, MEDIUM: 4, LOW: 1 } as any)[a.severity] ?? 0), 0);
  const latestDrift = leadTimeTrend.length ? leadTimeTrend[leadTimeTrend.length - 1].drift_days : 0;
  const driftBoost = Math.max(0, Math.min(15, Math.round(latestDrift * 0.6)));
  const profileScore = Math.max(0, Math.min(100, baseScore + extBoost + driftBoost));

  // ── Severity must match the Risk Monitor card this popup was opened from ──
  // The card severity (/api/supply/risks) is the stock-cover tier: it is driven
  // by current_stock_days vs the stock_critical_days / stock_high_days thresholds
  // in platform_config — NOT by the supplier's financial profile. Previously the
  // detail derived severity purely from the financial profile score, so a CRITICAL
  // stock-cover card could open to a LOW badge (e.g. 29/100). Use the same tier
  // logic + thresholds here so the popup can never contradict its card. The
  // numeric score is then floored into the tier's band so the bar colour and the
  // badge always agree. profileScore still wins when the financial risk is worse.
  const supTh = (loadPlatformConfig() as any).supplyThreshold ?? {};
  const stockCriticalDays = Number(supTh.stock_critical_days ?? 14);
  const stockHighDays = Number(supTh.stock_high_days ?? 30);
  const cardTier = riskRow
    ? (Number(riskRow.current_stock_days ?? 0) < stockCriticalDays ? 'CRITICAL'
      : Number(riskRow.current_stock_days ?? 0) < stockHighDays ? 'HIGH'
      : 'MEDIUM')
    : null;
  const BAND_FLOOR: Record<string, number> = { CRITICAL: 75, HIGH: 50, MEDIUM: 30, LOW: 0 };
  // Authoritative severity: the active risk-event tier when present; otherwise
  // fall back to the supplier-profile-derived band (popup opened without an event).
  const riskSeverity = cardTier
    ?? (profileScore >= 75 ? 'CRITICAL' : profileScore >= 50 ? 'HIGH' : profileScore >= 30 ? 'MEDIUM' : 'LOW');
  const riskScore = Math.max(profileScore, BAND_FLOOR[riskSeverity] ?? 0);

  // Reorder governance decision via the same rule engine the risk cards use.
  let reorderDecision: any = null;
  let recommendedActions: string[] = [];
  if (riskRow) {
    const cand = await buildCandidate(riskRow);
    const d = await evaluateReorderDecision(cand, plant ?? undefined);
    reorderDecision = {
      approval_mode: d.decision === 'Auto' ? 'Auto Approval' : 'Manual Approval Required',
      readiness_status: d.readiness, reason: d.reason,
      triggered_rule_id: d.ruleId, triggered_rule_name: d.ruleName,
      decision: d.decision, order_value: cand.orderValue, qty: cand.qty,
    };
    // Recommended actions are derived from the decision + signals (not static).
    if (d.decision === 'Auto') {
      recommendedActions.push('Create SAP MM reorder (auto-approved)');
    } else {
      recommendedActions.push('Route reorder for manual approval');
      recommendedActions.push('Create SAP MM reorder');
    }
    if (cand.alternateSupplier) recommendedActions.push('Evaluate alternate supplier');
    if (cand.stockBelowReorder) recommendedActions.push('Increase safety stock buffer');
    if (externalAlerts.length) recommendedActions.push('Monitor external risk alerts');
    if (cand.supplierRisk === 'CRITICAL' || cand.financialRiskHigh) recommendedActions.push('Escalate to procurement team');
  }

  const fmtExposure = (v: number) => `\u20b9${(v / 100000).toFixed(1)}L`;

  return {
    supplier: supplier ? {
      supplier_id: supplier.supplier_id, supplier_name: supplier.supplier_name,
      region: supplier.supplier_region, country: supplier.supplier_country,
      credit_rating: supplier.credit_rating, payment_terms: supplier.payment_terms,
      risk_score: riskScore, risk_level: riskSeverity,
    } : null,
    sku: sku ? {
      sku_id: sku.sku_id, sku_code: sku.sku_code, sku_name: sku.sku_name,
      category: sku.category, criticality: sku.criticality,
    } : (skuCode ? { sku_id: skuId, sku_code: skuCode, sku_name: riskRow?.description ?? null, category: null, criticality: null } : null),
    plant: plant ? { plant_id: plant, plant_name: PLANT_LABEL[plant] ?? plant } : null,
    riskScore, riskSeverity,
    exposure: {
      monthly_exposure: map ? fmtExposure(Number(map.monthly_exposure ?? 0)) : null,
      ytd_order_value: map ? fmtExposure(Number(map.ytd_order_value ?? 0)) : null,
      mtd_order_value: map ? fmtExposure(Number(map.mtd_order_value ?? 0)) : null,
      last_updated: riskRow ? today() : null,
    },
    riskFactors, leadTimeTrend, historicalPerformance: historicalPerformanceOut, externalAlerts,
    reliabilityScore,
    recommendedActions, reorderDecision,
  };
}

async function bumpRule(ruleId: string) {
  await dbBumpRule(ruleId, today());
}

// ── Mutating workflow actions ───────────────────────────────────────────────
/** SAP MM reorder simulation: risk event → semantic decision → routed record. */
export async function createReorderRequestFromRiskEvent(riskId: string, plant?: string) {
  const row = (await getSupplyRisks() as any[]).find(r => `${r.supplier_id}-${r.sku}` === riskId);
  if (!row) return { ok: false, error: 'risk event not found' };
  const c = await buildCandidate(row);
  const d = await evaluateReorderDecision(c, plant);
  await bumpRule(d.ruleId);
  const stamp = `${Date.now()}-${++_seq}`;
  if (d.decision === 'Auto') {
    const order = {
      order_id: `AUTO-${stamp}`, plant_id: row.plant, sku_id: c.sku_id, supplier_id: row.supplier_id,
      approved_qty: c.qty, approved_value: c.orderValue, approved_date: today(),
      rule_id: d.ruleId, rule_name: d.ruleName, sap_status: 'PR Created', status: 'Sent to SAP MM', reason: d.reason,
      source_system: 'SAP_MM',
    };
    await dbInsertAutoOrder(order);
    return { ok: true, decision: d, readiness: d.readiness, record: order };
  }
  const req = {
    request_id: `REQ-${stamp}`, plant_id: row.plant, sku_id: c.sku_id, supplier_id: row.supplier_id,
    requested_qty: c.qty, requested_value: c.orderValue, requested_date: today(),
    trigger_reason: c.triggerReason, approval_reason: d.reason, approval_mode: 'Manual',
    triggered_by_rule_id: d.ruleId, status: 'Pending', created_by: 'AI Agent',
  };
  await dbInsertReorderRequest(req);
  return { ok: true, decision: d, readiness: d.readiness, record: req };
}

export async function approveRequest(requestId: string) {
  const upd = await dbUpdateRequestStatus(requestId, 'Approved');
  if (!upd.ok) return { ok: false, error: upd.error ?? 'request not found' };
  const r = upd.row;
  // Approved manual request becomes a SAP MM PR in the order history.
  await dbInsertAutoOrder({
    order_id: `ORD-${Date.now()}-${++_seq}`, plant_id: r.plant_id, sku_id: r.sku_id, supplier_id: r.supplier_id,
    approved_qty: r.requested_qty, approved_value: r.requested_value, approved_date: today(),
    rule_id: r.triggered_by_rule_id, rule_name: 'Manual approval', sap_status: 'PR Created',
    status: 'Sent to SAP MM', reason: `Manually approved \u2014 ${r.approval_reason}`, source_system: 'SAP_MM',
  });
  return { ok: true, status: 'Approved' };
}
export async function declineRequest(requestId: string) {
  const upd = await dbUpdateRequestStatus(requestId, 'Declined');
  if (!upd.ok) return { ok: false, error: upd.error ?? 'request not found' };
  return { ok: true, status: 'Declined' };
}
export async function toggleRule(ruleId: string, enabled?: boolean) {
  return await dbToggleRule(ruleId, enabled);
}

/** Create a governance rule from the UI form. rule_id and created_date are set
 *  server-side; the rule is enabled by default and starts with trigger_count 0. */
export async function createReorderRule(input: {
  rule_name?: string; category?: string; description?: string;
  conditions?: string; approval_mode?: string; plant_scope?: string;
}): Promise<{ ok: boolean; rule_id?: string; error?: string }> {
  const name = (input.rule_name ?? '').trim();
  if (!name) return { ok: false, error: 'rule_name is required' };
  const mode = (input.approval_mode ?? '').trim();
  if (mode !== 'Auto Approval' && mode !== 'Manual Approval') {
    return { ok: false, error: 'approval_mode must be "Auto Approval" or "Manual Approval"' };
  }
  const rule_id = `RULE-U${Date.now().toString().slice(-7)}`;
  const rule = {
    rule_id, rule_name: name,
    category: (input.category ?? 'General').trim() || 'General',
    description: (input.description ?? '').trim(),
    conditions: (input.conditions ?? '').trim(),
    approval_mode: mode,
    enabled: 1,
    plant_scope: (input.plant_scope ?? 'All Plants').trim() || 'All Plants',
    created_date: today(),
  };
  const out = await dbInsertReorderRule(rule);
  return out.ok ? { ok: true, rule_id } : { ok: false, error: out.error };
}

// ── List selectors (plant-filtered) ─────────────────────────────────────────
export async function getReorderRules(plant?: string) { return (await rules()).filter(r => ruleInScope(r, plant)); }
export async function getActiveRulesCount(plant?: string) {
  return (await rules()).filter(r => r.enabled && ruleInScope(r, plant)).length;
}
export async function getManualApprovalRequests(plant?: string, includeResolved = false) {
  const rows = byPlant(await requests(), plant);
  return includeResolved ? rows : rows.filter(r => r.status === 'Pending');
}
export async function getAutoApprovedOrders(plant?: string) { return byPlant(await autoOrders(), plant); }
export async function getExternalRiskAlerts(plant?: string) {
  return byPlant(await dbGetExternalRiskAlerts() as any[], plant).filter(a => a.status !== 'Closed');
}

// ── Active-risk summary (supplier risk events + external alerts) ────────────
export async function getActiveRiskSummary(plant?: string) {
  const c = plantCode(plant);
  // Severity thresholds come from platform_config (the SAME source /risks and the
  // Risk Monitor use) so the dashboard Active-Risks buckets can never diverge from
  // the Risk Monitor's — was hardcoded 14/30 here.
  const supTh = (loadPlatformConfig() as any).supplyThreshold ?? {};
  const stockCriticalDays = Number(supTh.stock_critical_days ?? 14);
  const stockHighDays = Number(supTh.stock_high_days ?? 30);
  const risks = (await getSupplyRisks() as any[]).filter(r => !c || r.plant === c);
  const counts: Record<string, number> = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 };
  for (const r of risks) {
    const days = Number(r.current_stock_days ?? 0);
    const sev = days < stockCriticalDays ? 'CRITICAL' : days < stockHighDays ? 'HIGH' : 'MEDIUM';
    counts[sev]++;
  }
  const supplierCount = risks.length;                 // supplier risk rows (= Risk Monitor "All")
  const externalAlerts = await getExternalRiskAlerts(plant);
  for (const a of externalAlerts) counts[(a.severity as string) ?? 'LOW']++;
  const externalCount = externalAlerts.length;        // external alerts (= External Alerts panel)
  const total = counts.CRITICAL + counts.HIGH + counts.MEDIUM + counts.LOW;
  // total === supplierCount + externalCount, by construction.
  return { total, critical: counts.CRITICAL, high: counts.HIGH, medium: counts.MEDIUM, low: counts.LOW, supplierCount, externalCount };
}

// The monitored-SKU universe — the union of the SKU master, supply-risk SKUs, and
// inventory positions, enriched with stock/supplier detail. getSkuMonitoredCount
// returns this list's length, so the dashboard count and any listing can never
// disagree. Everything is DB-authoritative (getSkus/getSupplyRisks/getInventoryPositions).
export async function getMonitoredSkus(plant?: string) {
  const c = plantCode(plant);
  const allSkus = await getSkus() as any[];
  const idToCode = new Map(allSkus.map(s => [s.sku_id, s.sku_code]));
  const skuByCode = new Map(allSkus.map(s => [s.sku_code, s]));
  const risks = await getSupplyRisks() as any[];
  const riskByCode = new Map(risks.map(r => [r.sku, r]));
  const inv = await getInventoryPositions() as any[];
  const invByCode = new Map(inv.map(i => [idToCode.get(i.sku_id) ?? i.sku_id, i]));
  const supNameById = new Map((await getSuppliers() as any[]).map(s => [s.supplier_id, s.supplier_name]));

  // Union of SKU codes (plant-filtered), mirroring the count logic exactly.
  const set = new Set<string>();
  allSkus.filter(s => !c || s.plant_id === c).forEach(s => set.add(s.sku_code));
  risks.filter(r => !c || r.plant === c).forEach(r => set.add(r.sku));
  inv.filter(i => !c || i.plant_id === c).forEach(i => set.add(idToCode.get(i.sku_id) ?? i.sku_id));

  return Array.from(set).map(code => {
    const sk = skuByCode.get(code) as any;
    const rk = riskByCode.get(code) as any;
    const iv = invByCode.get(code) as any;
    const currentStockDays = Number(iv?.current_stock_days ?? rk?.current_stock_days ?? 0);
    const reorderPointDays = Number(iv?.reorder_point_days ?? rk?.reorder_point_days ?? 0);
    const supplier = (sk?.preferred_supplier_id && supNameById.get(sk.preferred_supplier_id))
      || rk?.supplier_name || '\u2014';
    return {
      sku: code,
      sku_name: sk?.sku_name ?? rk?.description ?? code,
      criticality: sk?.criticality ?? null,
      plant: sk?.plant_id ?? rk?.plant ?? iv?.plant_id ?? null,
      supplier,
      currentStockDays,
      reorderPointDays,
      inAlert: reorderPointDays > 0 && currentStockDays < reorderPointDays,
    };
  }).sort((a, b) => a.sku.localeCompare(b.sku));
}

export async function getSkuMonitoredCount(plant?: string) {
  return (await getMonitoredSkus(plant)).length;
}

// ── Forecast accuracy improvement: AI forecast vs naive persistence baseline ─
// baseline = previous-week actual (standard naive forecast). Fully data-driven
// from demand_forecast.csv — no invented baseline column needed.
async function forecastAccuracy(plant?: string) {
  const c = plantCode(plant);
  // DB-authoritative: read via getDemandForecast (trx_demand_forecast) instead of
  // the CSV loader directly. Rows are shaped {plant, product, week, actual, forecast};
  // the reader falls back to CSV (shape {w, ...}) only if the table is unseeded.
  const rows = ((await getDemandForecast()) as any[]).filter(r => !c || r.plant === c);
  // group by plant+product, order by week
  const groups = new Map<string, any[]>();
  for (const r of rows) {
    const k = `${r.plant}|${r.product}`;
    (groups.get(k) ?? groups.set(k, []).get(k)!).push(r);
  }
  let aiErr = 0, baseErr = 0, n = 0, accSum = 0, accN = 0;
  for (const g of groups.values()) {
    // DB reader returns `week`; CSV fallback returns `w`. Sort on whichever exists.
    const seq = g.slice().sort((a, b) => String(a.week ?? a.w).localeCompare(String(b.week ?? b.w)));
    for (let i = 0; i < seq.length; i++) {
      const actual = Number(seq[i].actual);
      if (!Number.isFinite(actual) || actual <= 0) continue;
      const ai = Number(seq[i].forecast);
      if (Number.isFinite(ai)) { accSum += 1 - Math.abs(actual - ai) / actual; accN++; }
      if (i > 0) {
        const prev = Number(seq[i - 1].actual);
        if (Number.isFinite(prev) && Number.isFinite(ai)) {
          aiErr += Math.abs(actual - ai) / actual;
          baseErr += Math.abs(actual - prev) / actual;
          n++;
        }
      }
    }
  }
  const aiMape = n ? (aiErr / n) * 100 : 0;
  const baseMape = n ? (baseErr / n) * 100 : 0;
  const improvementPct = baseMape > 0 ? ((baseMape - aiMape) / baseMape) * 100 : 0;
  const accuracyPct = accN ? (accSum / accN) * 100 : 0;
  return { accuracyPct: +accuracyPct.toFixed(1), improvementPct: +improvementPct.toFixed(1), aiMape: +aiMape.toFixed(2), baseMape: +baseMape.toFixed(2) };
}

// ── The unified dashboard metrics object the UI consumes ────────────────────
export async function getSupplyChainDashboardMetrics(plant?: string) {
  const c = plantCode(plant);
  // Severity threshold (stock-days) — the SAME source the Risk Monitor,
  // getActiveRiskSummary, and the /supply/risks route use. highRiskSuppliers is
  // computed from the active supply-risks below (not the static supplier.risk_level
  // attribute) so the KPI reconciles with the Shortfall Predictions list.
  const supTh = (loadPlatformConfig() as any).supplyThreshold ?? {};
  const stockHighDays = Number(supTh.stock_high_days ?? 30);

  // Inventory carrying-cost reduction
  const inv = (await getInventoryPositions() as any[]).filter(i => !c || i.plant_id === c);
  const baseCost = inv.reduce((a, i) => a + Number(i.baseline_inventory_cost ?? 0), 0);
  const curCost = inv.reduce((a, i) => a + Number(i.current_inventory_cost ?? 0), 0);
  const inventoryCostReductionPct = baseCost > 0 ? +(((baseCost - curCost) / baseCost) * 100).toFixed(1) : 0;

  // Lead-time drift (avg + count drifting) from supply_risks
  const risks = (await getSupplyRisks() as any[]).filter(r => !c || r.plant === c);
  const drifts = risks.map(r => Number(r.lead_time_actual_days ?? 0) - Number(r.lead_time_contracted_days ?? 0));
  const avgLeadTimeDrift = drifts.length ? +(drifts.reduce((a, d) => a + d, 0) / drifts.length).toFixed(1) : 0;
  const suppliersDrifting = new Set(risks.filter(r => Number(r.lead_time_actual_days ?? 0) > Number(r.lead_time_contracted_days ?? 0)).map(r => r.supplier_id)).size;
  const suppliersTracked = new Set(risks.map(r => r.supplier_id)).size;

  // High-risk suppliers = unique suppliers with an ACTIVE high/critical supply-risk
  // (current_stock_days < stockHighDays → 'high' or 'critical' severity). This is the
  // exact set the Shortfall Predictions list and the "High-risk suppliers" signal row
  // render, so the KPI count now reconciles with them. (Previously it counted the
  // static supplier.risk_level attribute — a different, smaller set that showed 1
  // while the shortfall list showed 2 suppliers at high/critical.)
  const highRiskSuppliers = new Set(
    risks.filter(r => Number(r.current_stock_days ?? 0) < stockHighDays).map(r => r.supplier_id)
  ).size;

  const fa = await forecastAccuracy(plant);
  const activeRisks = await getActiveRiskSummary(plant);

  return {
    plant_id: c ?? 'All Plants',
    highRiskSuppliers,
    skusMonitored: await getSkuMonitoredCount(plant),
    activeRisks,                          // {total, critical, high, medium, low}
    inventoryCostReductionPct,
    forecastAccuracyPct: fa.accuracyPct,
    forecastAccuracyImprovementPct: fa.improvementPct,
    leadTimeDriftDays: avgLeadTimeDrift,
    suppliersDrifting,
    suppliersTracked,
    // governance roll-ups
    safetyStockAlerts: risks.filter(r => Number(r.current_stock_days ?? 0) < Number(r.reorder_point_days ?? 0)).length,
    manualApprovalPending: (await getManualApprovalRequests(plant)).length,
    autoApprovedOrders: (await getAutoApprovedOrders(plant)).length,
    activeRules: await getActiveRulesCount(plant),
  };
}
