/**
 * ManuAI — AI Context Builder Validation Tests  V44
 * ==================================================
 *
 * Confirms the Unified AI is grounded in LIVE DATA, not static KPI definitions.
 *
 * For each of the 8 agents we run a representative business question through the
 * context builder and assert the resulting packet contains:
 *   • matched the correct agent
 *   • live records (recordCount > 0)
 *   • calculated KPI values (not empty)
 *   • a ranked result (so "which X is highest/lowest" can be answered)
 *   • a freshness timestamp
 * and DOES NOT collapse to "definition only".
 *
 * Run:  cd apps/api && npx ts-node src/ai/ai-context-builder.test.ts
 * (Seeds master data into the configured DB first; uses SQLite by default.)
 *
 * Exit code 0 = all pass, 1 = any failure (CI-friendly).
 */

import { runMigrations, runPlantMigration } from '../database/schema';
import { seedMasterData } from '../database/seed-master';
import { buildGroundedContext, renderContextPacket, AgentId } from './ai-context-builder';

interface Case {
  name: string;
  question: string;
  expectAgent: AgentId;
  filters?: { plant?: string; line?: string; asset?: string };
  // A field that must be present & non-empty in the matched agent's calculated block
  expectCalcKey: string;
}

const CASES: Case[] = [
  { name: 'Supply — highest risk supplier',
    question: 'Which supplier has the highest risk?',
    expectAgent: 'supply', expectCalcKey: 'highest_risk_supplier' },
  { name: 'PdM — which asset fails first',
    question: 'Which asset may fail first?',
    expectAgent: 'pdm', expectCalcKey: 'first_to_fail' },
  { name: 'OEE — lowest OEE line',
    question: 'Which line has the lowest OEE?',
    expectAgent: 'oee', expectCalcKey: 'lowest_line' },
  { name: 'Quality — highest defect risk',
    question: 'Which line has the highest defect risk today?',
    expectAgent: 'quality', expectCalcKey: 'worst_line' },
  { name: 'Yield — parameter hurting yield',
    question: 'Which process parameter is hurting yield the most?',
    expectAgent: 'yield', expectCalcKey: 'biggest_drag' },
  { name: 'Energy — abnormal energy consumption',
    question: 'Which asset is consuming abnormal energy?',
    expectAgent: 'energy', expectCalcKey: 'highest_draw' },
  { name: 'Safety — permit blocking maintenance',
    question: 'Which safety permit is blocking maintenance?',
    expectAgent: 'safety', expectCalcKey: 'blocked_count' },
  { name: 'Twin — projected impact',
    question: 'What is the digital twin projected impact?',
    expectAgent: 'twin', expectCalcKey: 'top_scenario' },
];

interface Result { case: string; pass: boolean; reasons: string[]; }

async function check(c: Case): Promise<Result> {
  const reasons: string[] = [];
  const ctx = await buildGroundedContext(c.question, c.filters ?? { plant: 'P1' });

  // 1. correct agent matched
  if (!ctx.matchedAgents.includes(c.expectAgent))
    reasons.push(`expected agent '${c.expectAgent}' not matched (got: ${ctx.matchedAgents.join(',')})`);

  const agentCtx = ctx.agentContexts.find(a => a.agent === c.expectAgent);
  if (!agentCtx) {
    reasons.push(`no agent context produced for '${c.expectAgent}'`);
    return { case: c.name, pass: false, reasons };
  }

  // 2. live records present (NOT definition-only)
  if (agentCtx.recordCount <= 0)
    reasons.push(`recordCount is ${agentCtx.recordCount} — no live records retrieved (definition-only failure)`);

  // 3. calculated values present
  if (!agentCtx.calculated || Object.keys(agentCtx.calculated).length === 0)
    reasons.push('calculated block is empty — no dynamic KPI calculation');
  else if (agentCtx.calculated[c.expectCalcKey] == null)
    reasons.push(`expected calculated key '${c.expectCalcKey}' missing or null`);

  // 4. ranked results present (so "which X" is answerable)
  if (!agentCtx.ranked || agentCtx.ranked.length === 0)
    reasons.push('ranked results empty — cannot answer ranking question');

  // 5. freshness timestamp
  if (!ctx.freshness || isNaN(Date.parse(ctx.freshness)))
    reasons.push('missing/invalid freshness timestamp');

  // 6. rendered packet does not falsely claim "definition only" / "no live feed"
  //    when records exist
  const packet = renderContextPacket(ctx).toLowerCase();
  if (agentCtx.recordCount > 0 &&
      (packet.includes('csv definition only') || packet.includes('no live feed')))
    reasons.push('packet still says "definition only/no live feed" despite live records');

  return { case: c.name, pass: reasons.length === 0, reasons };
}

async function main() {
  console.log('Seeding master data for validation...');
  try {
    await runMigrations();
    await runPlantMigration();
    await seedMasterData();
  } catch (e) {
    console.error('Seed failed (continuing — builder has CSV fallback):', String(e));
  }

  console.log('\n=== AI Context Builder Validation — 8 agents ===\n');
  const results = await Promise.all(CASES.map(check));

  let passCount = 0;
  for (const r of results) {
    const tag = r.pass ? 'PASS' : 'FAIL';
    console.log(`[${tag}] ${r.case}`);
    if (!r.pass) for (const reason of r.reasons) console.log(`        ↳ ${reason}`);
    if (r.pass) passCount++;
  }

  console.log(`\n${passCount}/${results.length} agent questions grounded in live data.`);

  // Show one full packet as evidence the AI receives real records + rankings
  console.log('\n=== SAMPLE PACKET: "Which supplier has the highest risk?" ===\n');
  console.log(renderContextPacket(await buildGroundedContext('Which supplier has the highest risk?', { plant: 'P1' })));

  process.exit(passCount === results.length ? 0 : 1);
}

void main();
