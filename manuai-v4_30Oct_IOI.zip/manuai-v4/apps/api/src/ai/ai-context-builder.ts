/**
 * ManuAI — AI Context Builder  V44
 * =================================
 *
 * The Unified AI chat used to answer from KPI *definitions* only — the context
 * was built client-side and dominated by the governed-KPI dictionary tagged
 * "CSV definition only — no live feed". It never retrieved current records,
 * never calculated KPI values, never ranked, never joined cross-agent context.
 *
 * This module fixes that GLOBALLY for all 8 agents. For every question it:
 *   1. Detects the relevant domain/agent(s)
 *   2. Pulls governed KPI definitions for those agents
 *   3. Retrieves CURRENT records from the DB (Tier 2/3 tables via db-queries)
 *   4. Calculates KPI values dynamically from the records
 *   5. Applies filters (plant / line / asset / period from dashboard state)
 *   6. Ranks results (highest risk, lowest OEE, etc.)
 *   7. Adds cross-agent context (PdM risk → OEE impact + parts + permit + twin)
 *   8. Emits a grounded context packet with a freshness timestamp
 *
 * The packet is what the LLM answers from — so "which supplier has highest
 * risk?" returns a real ranked supplier with a computed score, not a dictionary
 * entry.
 */

import {
  getMachines, getYieldParams, getEnergyAssets, getSupplyRisks,
  getQualityLines, getQualityDefects, getWorkOrders, getProductionOrders,
  getSafetyPermits, getSafetyZones, getPartsOrders, getTwinScenarios,
  getTwinKPIs, getEnergyDispatch, getEnergyWaste, getLimsResults,
} from '../database/db-queries';
import { loadSemanticKpiDefs, loadPlatformConfig } from '../data/csv-loader';
import { getDb } from '../database/connection';
import { getPlantState } from '../simulation/engine';
import { logger } from '../middleware/logger';
import { getSafetyEventHistory } from '../database/queries';
import { applySafetyEventOverrides } from '../state/runtime-overrides';
import { reconcileCalculated, resolverMode } from '../semantic/resolver';
import { buildGovernedHistory, type GovernedHistory } from './semantic-history';

export type AgentId =
  | 'oee' | 'pdm' | 'quality' | 'energy' | 'supply'
  | 'twin' | 'yield' | 'safety' | 'semantic';

export interface ContextFilters {
  plant?: string;   // 'P1' | 'P2' | 'All Plants'
  line?: string;    // 'Line A' ...
  asset?: string;   // 'MCH-03'
  period?: string;  // 'today' | '7d' | '30d'
}

// ── Domain detection ──────────────────────────────────────────────────────────
// Keyword → agent mapping. A question can match multiple agents (cross-agent).
const AGENT_KEYWORDS: Record<AgentId, RegExp> = {
  oee:     /\b(oee|availability|performance|utilization|utilisation|six (big )?losses|downtime|line.*(efficien|output)|overall equipment)\b/i,
  pdm:     /\b(pdm|predictive|maintenance|rul|remaining useful|fail|failure|breakdown|bearing|vibration|health|asset.*risk|which (asset|machine).*(fail|risk|down))\b/i,
  quality: /\b(quality|defect|scrap|reject|escape|ncr|inspection|vision|surface crack|misalignment|which batch)\b/i,
  energy:  /\b(energy|power|kwh|kw\b|consumption|tariff|peak|carbon|emission|compressor|chiller|hvac|load|abnormal.*(energy|power)|consuming)\b/i,
  supply:  /\b(supply|supplier|vendor|stock|inventory|reorder|lead time|paydex|procure|shortage|spare|risk.*(supplier|supply)|which supplier)\b/i,
  twin:    /\b(twin|digital twin|divergence|simulat|scenario|projected|what.?if|recalibrat)\b/i,
  yield:   /\b(yield|recipe|setpoint|set.point|reactor temp|process param|dcs|grade|batch yield|which.*(param|parameter).*(yield|hurt))\b/i,
  safety:  /\b(safety|permit|ptw|gas|h2s|co\b|ch4|methane|precursor|hot.?work|zone|hazard|incident|near.?miss|osha|iso 45001|blocking maintenance)\b/i,
  semantic:/\b(semantic|governed|kpi definition|conflict rule|lineage|cross.?agent|orchestrat)\b/i,
};

export function detectAgents(question: string): AgentId[] {
  const matched: AgentId[] = [];
  for (const [agent, rx] of Object.entries(AGENT_KEYWORDS) as [AgentId, RegExp][]) {
    if (rx.test(question)) matched.push(agent);
  }
  // Default: if nothing matched, give a broad cross-agent overview
  if (matched.length === 0) return ['oee', 'pdm', 'quality', 'supply'];
  return matched;
}

// ── Helpers ────────────────────────────────────────────────────────────────────
const num = (v: unknown, d = 0): number => {
  const n = Number(v); return Number.isFinite(n) ? n : d;
};
const plantOf = (line: string): string => (['Line A', 'Line B'].includes(line) ? 'P1' : 'P2');

function applyPlantFilter<T extends Record<string, any>>(rows: T[], plant?: string, key = 'plant_id'): T[] {
  if (!plant || plant === 'All Plants') return rows;
  return rows.filter(r => (r[key] ?? r.plant ?? '').toString() === plant);
}

// ── Live-state merge (RC-2 fix) ──────────────────────────────────────────────
// The dashboard reads LIVE machine/energy/yield KPIs from getPlantState() (the
// simulation engine). The reference getters (getMachines etc.) return only the
// STATIC reference master — ref_machines has no oee/rul/health/vib/status, and
// ref_energy_assets has no live current draw. Reading those gave the AI zeros.
// These helpers merge the live sim values onto the static reference rows by id,
// producing the SAME data the dashboard shows, with a canonical plant_id so
// applyPlantFilter works. All fall back to the reference getter if sim is cold.

export async function liveMachines(): Promise<any[]> {
  let sim: any[] = [];
  try { sim = (getPlantState().machines ?? []) as any[]; } catch { /* sim not ready */ }
  if (!sim.length) return await getMachines();                 // cold start → reference/CSV
  const ref = new Map((await getMachines()).map(r => [r.id, r]));
  return sim.map(m => ({
    ...ref.get(m.id),                                    // static: rated_kw, asset_type
    ...m,                                                // live: oee, rul, health, vib, temp, status, line, name
    plant_id: m.plant ?? (ref.get(m.id) as any)?.plant_id, // canonical code for applyPlantFilter
  }));
}

export async function liveEnergyAssets(): Promise<any[]> {
  let sim: any[] = [];
  try { sim = (getPlantState().energyAssets ?? []) as any[]; } catch { /* sim not ready */ }
  const simById = new Map(sim.map(s => [s.id, s]));
  return (await getEnergyAssets()).map(a => {
    const s = simById.get(a.id);                         // sim has live kw + anomaly flag
    return s ? { ...a, current_kw: s.kw, sim_anomaly: !!s.anomaly } : a;
  });
}

export async function liveYieldParams(): Promise<any[]> {
  let sim: any[] = [];
  try { sim = (getPlantState().yieldParams ?? []) as any[]; } catch { /* sim not ready */ }
  if (!sim.length) return await getYieldParams();              // cold start → reference/CSV
  const ref = new Map((await getYieldParams()).map(r => [r.id, r]));
  return sim.map(p => ({
    ...ref.get(p.id),                                    // static attrs (drift_rate, pi_tag)
    id: p.id, name: p.name, unit: p.unit, plant_id: p.plant,
    value: p.val, target: p.tgt, min_val: p.min, max_val: p.max, // map sim → builder field names
    warn: p.warn,
  }));
}

// ── Per-agent context builders ──────────────────────────────────────────────────
// Each returns { records, calculated, ranked, summary } so the packet is uniform.

interface AgentContext {
  agent: AgentId;
  summary: string;
  calculated: Record<string, unknown>;
  ranked: Array<Record<string, unknown>>;
  recordCount: number;
  missing?: string;
}

async function buildOEE(f: ContextFilters): Promise<AgentContext> {
  let machines = applyPlantFilter(await liveMachines(), f.plant);
  if (f.line) machines = machines.filter(m => (m.line ?? '') === f.line);
  if (f.asset) machines = machines.filter(m => m.id === f.asset);
  if (!machines.length) return { agent: 'oee', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'ref_machines (no machines match the filter)' };

  const avgOee = +(machines.reduce((s, m) => s + num(m.oee), 0) / machines.length).toFixed(1);
  // Rank lines by avg OEE (lowest first — "which line has lowest OEE")
  const byLine: Record<string, { line: string; plant: string; oees: number[] }> = {};
  for (const m of machines) {
    const k = m.line ?? 'unknown';
    (byLine[k] = byLine[k] || { line: k, plant: m.plant_id ?? m.plant ?? plantOf(k), oees: [] }).oees.push(num(m.oee));
  }
  const lineRank = Object.values(byLine)
    .map(l => ({ line: l.line, plant: l.plant, avg_oee: +(l.oees.reduce((a, b) => a + b, 0) / l.oees.length).toFixed(1) }))
    .sort((a, b) => a.avg_oee - b.avg_oee);
  const machineRank = machines
    .map(m => ({ asset: m.id, name: m.name, line: m.line, plant: m.plant_id ?? m.plant, oee: +num(m.oee).toFixed(1), status: m.status }))
    .sort((a, b) => a.oee - b.oee);

  return {
    agent: 'oee',
    summary: `Fleet avg OEE ${avgOee}% across ${machines.length} machines. Lowest line: ${lineRank[0]?.line} @ ${lineRank[0]?.avg_oee}%. Lowest machine: ${machineRank[0]?.name} (${machineRank[0]?.asset}) @ ${machineRank[0]?.oee}%.`,
    calculated: { avg_oee_pct: avgOee, lowest_line: lineRank[0], lowest_machine: machineRank[0] },
    ranked: [...lineRank.map(l => ({ type: 'line', ...l })), ...machineRank.slice(0, 5).map(m => ({ type: 'machine', ...m }))],
    recordCount: machines.length,
  };
}

async function buildPdM(f: ContextFilters): Promise<AgentContext> {
  let machines = applyPlantFilter(await liveMachines(), f.plant);
  if (f.asset) machines = machines.filter(m => m.id === f.asset);
  if (!machines.length) return { agent: 'pdm', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'ref_machines' };

  // Rank by RUL ascending — "which asset may fail first"
  const rank = machines
    .map(m => ({
      asset: m.id, name: m.name, line: m.line, plant: m.plant_id ?? m.plant,
      rul_days: Math.round(num(m.rul, 999)),
      health_pct: +num(m.health).toFixed(1),
      vibration_mm_s: +num(m.vib).toFixed(1),
      temp_c: +num(m.temp).toFixed(1),
      status: m.status,
    }))
    .sort((a, b) => a.rul_days - b.rul_days);

  const worst = rank[0];
  const critCount = machines.filter(m => m.status === 'critical').length;

  return {
    agent: 'pdm',
    summary: `${critCount} critical asset(s). First to fail: ${worst?.name} (${worst?.asset}) — RUL ${worst?.rul_days}d, health ${worst?.health_pct}%, vibration ${worst?.vibration_mm_s} mm/s.`,
    calculated: { first_to_fail: worst, critical_count: critCount, min_rul_days: worst?.rul_days },
    ranked: rank.slice(0, 6),
    recordCount: machines.length,
  };
}

async function buildQuality(f: ContextFilters): Promise<AgentContext> {
  let lines = applyPlantFilter(await getQualityLines(f.plant), f.plant);
  let defects = applyPlantFilter(await getQualityDefects(f.plant, f.line, 200), f.plant);
  if (f.line) lines = lines.filter(l => (l.line ?? l.line_id) === f.line);
  if (!lines.length && !defects.length) return { agent: 'quality', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'ref_quality_lines + trx_quality_defects' };

  // Defects per line — "which batch/line has highest defect risk"
  const byLine: Record<string, number> = {};
  for (const d of defects) { const k = d.line ?? 'unknown'; byLine[k] = (byLine[k] || 0) + 1; }
  const lineRank = Object.entries(byLine)
    .map(([line, count]) => {
      const lm = lines.find(l => (l.line ?? l.line_id) === line);
      const rate = lm ? num(lm.quality_rate_pct) : null;
      return { line, plant: plantOf(line), defect_count: count, quality_rate_pct: rate };
    })
    .sort((a, b) => b.defect_count - a.defect_count);

  // Top defect types
  const byType: Record<string, number> = {};
  for (const d of defects) { const t = d.defect_type ?? 'unknown'; byType[t] = (byType[t] || 0) + 1; }
  const typeRank = Object.entries(byType).map(([type, count]) => ({ defect_type: type, count })).sort((a, b) => b.count - a.count);

  return {
    agent: 'quality',
    summary: `${defects.length} defects today. Worst line: ${lineRank[0]?.line} (${lineRank[0]?.defect_count} defects, quality ${lineRank[0]?.quality_rate_pct ?? '?'}%). Top defect: ${typeRank[0]?.defect_type} (${typeRank[0]?.count}).`,
    calculated: { total_defects: defects.length, worst_line: lineRank[0], top_defect_type: typeRank[0] },
    ranked: lineRank,
    recordCount: defects.length,
  };
}

async function buildEnergy(f: ContextFilters): Promise<AgentContext> {
  let assets = applyPlantFilter(await liveEnergyAssets(), f.plant);
  const waste = applyPlantFilter(await getEnergyWaste(f.plant), f.plant);
  if (f.asset) assets = assets.filter(a => a.id === f.asset);
  if (!assets.length) return { agent: 'energy', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'ref_energy_assets' };

  // Abnormal consumption: use the SAME live anomaly flag the dashboard shows
  // (sim sets a.anomaly = kw > baseKw × 1.12). Recomputing here against rated_kw
  // gave a different abnormal count than the Energy dashboard.
  const rank = assets
    .map(a => {
      const rated = num(a.rated_kw);
      const current = num(a.current_kw, rated);
      const pctOfRated = rated ? +(current / rated * 100).toFixed(1) : 0;
      const anomaly = !!a.sim_anomaly;
      return { asset: a.id, name: a.name, plant: a.plant_id ?? a.plant, rated_kw: rated, current_kw: current, pct_of_rated: pctOfRated, anomaly, shiftable: !!a.shiftable };
    })
    .sort((a, b) => b.pct_of_rated - a.pct_of_rated);

  const wasteRs = waste.reduce((s, w) => s + num(w.cost_inr), 0);
  const abnormal = rank.filter(r => r.anomaly);

  return {
    agent: 'energy',
    summary: `${abnormal.length} asset(s) with abnormal consumption. Highest draw: ${rank[0]?.name} @ ${rank[0]?.current_kw}kW (${rank[0]?.pct_of_rated}% of rated). Waste flagged: Rs${wasteRs.toLocaleString()}/day across ${waste.length} patterns.`,
    calculated: { abnormal_count: abnormal.length, highest_draw: rank[0], daily_waste_inr: wasteRs },
    ranked: rank.slice(0, 6),
    recordCount: assets.length,
  };
}

async function buildSupply(f: ContextFilters): Promise<AgentContext> {
  const risks = applyPlantFilter(await getSupplyRisks(f.plant), f.plant);
  if (!risks.length) return { agent: 'supply', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'ref_supply_risks' };

  // Severity thresholds from platform_config — the SAME source the Supply
  // dashboard uses (governance.ts): stock cover below stock_critical_days = CRITICAL,
  // below stock_high_days = HIGH. The dashboard's "high-risk suppliers" tile counts
  // UNIQUE suppliers at high/critical, so we compute the identical bucket + count
  // here instead of only our internal leadDrift×financial×geo score.
  const supTh = (loadPlatformConfig() as any).supplyThreshold ?? {};
  const stockCriticalDays = Number(supTh.stock_critical_days ?? 14);
  const stockHighDays = Number(supTh.stock_high_days ?? 30);

  // Compute governed supply_risk_score = lead drift × financial × geo
  // (formula: lead drift x financial x geo risk — semantic_kpi_definitions.csv)
  const scored = risks.map(r => {
    const contracted = num(r.lead_time_contracted_days, 1);
    const actual = num(r.lead_time_actual_days, contracted);
    const leadDrift = contracted ? actual / contracted : 1;            // >1 = slipping
    const financial = num(r.financial_risk_score, 0) / 100 + 0.5;       // normalise to ~0.5–1.5
    const geo = (r.single_source === 'true' || r.single_source === true) ? 1.3 : 1.0;
    const stockDays = num(r.current_stock_days, 999);
    const reorderDays = num(r.reorder_point_days, 0);
    const score = +(leadDrift * financial * geo * 100).toFixed(1);
    const belowReorder = stockDays < reorderDays;
    const severity = stockDays < stockCriticalDays ? 'critical' : stockDays < stockHighDays ? 'high' : 'medium';
    return {
      supplier_id: r.supplier_id, supplier: r.supplier_name, sku: r.sku,
      plant: r.plant_id ?? r.plant,
      lead_contracted_days: contracted, lead_actual_days: actual,
      lead_drift_ratio: +leadDrift.toFixed(2),
      financial_risk: num(r.financial_risk_score),
      single_source: geo > 1,
      stock_days: stockDays, reorder_point_days: reorderDays,
      below_reorder: belowReorder,
      severity,
      risk_score: score,
    };
  }).sort((a, b) => b.risk_score - a.risk_score);

  // High-risk suppliers = UNIQUE suppliers at high/critical severity (dashboard tile).
  const highRiskSuppliers = new Set(scored.filter(s => s.severity !== 'medium').map(s => s.supplier_id));
  const criticalSuppliers = new Set(scored.filter(s => s.severity === 'critical').map(s => s.supplier_id));

  const top = scored[0];
  return {
    agent: 'supply',
    summary: `${highRiskSuppliers.size} high-risk supplier(s) (${criticalSuppliers.size} critical) by stock cover (<${stockHighDays}d high, <${stockCriticalDays}d critical). Highest internal risk score: ${top?.supplier} (${top?.sku}) — score ${top?.risk_score}, lead ${top?.lead_actual_days}d vs ${top?.lead_contracted_days}d contracted, stock ${top?.stock_days}d${top?.below_reorder ? ' (BELOW reorder point)' : ''}.`,
    calculated: {
      high_risk_supplier_count: highRiskSuppliers.size,
      critical_supplier_count: criticalSuppliers.size,
      below_reorder_count: scored.filter(s => s.below_reorder).length,
      highest_risk_supplier: top,
      stock_high_days: stockHighDays,
      stock_critical_days: stockCriticalDays,
    },
    ranked: scored.slice(0, 6),
    recordCount: risks.length,
  };
}

async function buildYield(f: ContextFilters): Promise<AgentContext> {
  const params = applyPlantFilter(await liveYieldParams(), f.plant);
  if (!params.length) return { agent: 'yield', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'ref_yield_params' };

  // Rank by deviation from target relative to operating span — "which param is hurting yield"
  const rank = params.map(p => {
    const val = num(p.value); const tgt = num(p.target);
    const span = Math.max(num(p.max_val) - num(p.min_val), 1e-6);
    const devPct = +(Math.abs(val - tgt) / span * 100).toFixed(1);
    return {
      param_id: p.id, name: p.name, plant: p.plant_id ?? p.plant, unit: p.unit,
      value: val, target: tgt, deviation: +(val - tgt).toFixed(2), deviation_pct_of_span: devPct,
      // Use the live warn flag (engine/CSV flag it at 6% of span — see engine.ts
      // and csv-loader). Recomputing at a different threshold here made the AI
      // report a different "params off-target" count than the Yield dashboard.
      warn: (typeof p.warn === 'boolean' ? p.warn : devPct > 6),
    };
  }).sort((a, b) => b.deviation_pct_of_span - a.deviation_pct_of_span);

  const worst = rank[0];
  const warnCount = rank.filter(r => r.warn).length;
  return {
    agent: 'yield',
    summary: `${warnCount} param(s) off-target. Biggest yield drag: ${worst?.name} at ${worst?.value}${worst?.unit} vs target ${worst?.target}${worst?.unit} (${worst?.deviation_pct_of_span}% of span off).`,
    calculated: { biggest_drag: worst, params_in_warning: warnCount },
    ranked: rank,
    recordCount: params.length,
  };
}

async function buildSafety(f: ContextFilters): Promise<AgentContext> {
  const permits = applyPlantFilter(await getSafetyPermits(f.plant), f.plant);
  const zones = applyPlantFilter(await getSafetyZones(f.plant), f.plant);

  // Open safety EVENTS — built from the SAME source + override logic the Safety
  // dashboard uses (safety_events WHERE resolved_at IS NULL, then runtime ack/
  // resolve overrides). Previously this section reported ONLY PTW permit counts
  // and silently discarded events, so the AI answered "no safety event records"
  // while the dashboard showed open critical events. Now the packet's open/critical
  // counts match the dashboard's "N OPEN CRITICAL".
  const rawEvents = applyPlantFilter(await getSafetyEventHistory(30, f.plant), f.plant);
  const events = applySafetyEventOverrides(
    rawEvents.map((e: any) => ({ ...e, status: e.resolved_at ? 'resolved' : 'open' })),
  );
  const sevRank: Record<string, number> = { critical: 3, high: 2, medium: 1, low: 0 };
  const openEvents = events
    .filter((e: any) => (e.status ?? 'open') !== 'resolved')
    .map((e: any) => ({
      id: e.id, zone: e.zone, event_type: e.event_type, severity: e.severity,
      h2s: e.h2s, co: e.co, ch4: e.ch4, ts: e.ts, status: e.status ?? 'open',
      plant: e.plant_id ?? e.plant,
    }))
    .sort((a, b) =>
      (sevRank[(b.severity ?? '').toLowerCase()] ?? 0) - (sevRank[(a.severity ?? '').toLowerCase()] ?? 0)
      || (b.ts ?? 0) - (a.ts ?? 0));
  const openCritical = openEvents.filter(e => (e.severity ?? '').toLowerCase() === 'critical');

  if (!permits.length && !zones.length && !events.length) {
    return { agent: 'safety', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'safety_events + trx_safety_permits + ref_safety_zones' };
  }

  const blocked = permits.filter(p => (p.status ?? '').toLowerCase() === 'blocked');
  const pending = permits.filter(p => (p.status ?? '').toLowerCase() === 'pending');
  const blockedRank = blocked.map(p => ({
    ptw_id: p.ptw_id, asset: p.asset_id, work_type: p.work_type,
    technician: p.technician, status: p.status, blocked_by_rule: p.blocked_by_rule, plant: p.plant_id ?? p.plant,
  }));

  const top = openEvents[0];
  const eventSummary = openEvents.length
    ? `${openEvents.length} OPEN safety event(s), ${openCritical.length} critical. Most severe: ${top?.event_type} in ${top?.zone} (${top?.severity}, id ${top?.id}). Safety events do not carry a maintenance-window link directly — the Semantic Layer relates critical safety events to maintenance by blocking affected work orders.`
    : 'No open safety events.';
  const permitSummary = `${blocked.length} permit(s) BLOCKED, ${pending.length} pending.${blocked.length ? ` Blocking: ${blockedRank[0]?.ptw_id} (${blockedRank[0]?.work_type} on ${blockedRank[0]?.asset}) — rule ${blockedRank[0]?.blocked_by_rule ?? 'safety precursor'}.` : ''}`;

  return {
    agent: 'safety',
    summary: `${eventSummary} ${permitSummary}`,
    calculated: {
      open_event_count: openEvents.length,
      open_critical_count: openCritical.length,
      most_severe_open_event: top ?? null,
      blocked_permit_count: blocked.length,
      pending_permit_count: pending.length,
      first_blocked_permit: blockedRank[0],
      zone_count: zones.length,
    },
    ranked: openEvents,
    recordCount: openEvents.length + permits.length,
  };
}

async function buildTwin(f: ContextFilters): Promise<AgentContext> {
  const scenarios = applyPlantFilter(await getTwinScenarios(f.plant), f.plant);
  const kpis = applyPlantFilter(await getTwinKPIs(f.plant), f.plant);
  if (!scenarios.length && !kpis.length) return { agent: 'twin', summary: '', calculated: {}, ranked: [], recordCount: 0, missing: 'trx_twin_scenarios + trx_twin_kpis' };

  // Divergence: abs(actual - twin)/twin × 100 — "which KPI diverging"
  const divRank = kpis.map(k => {
    const actual = num(k.actual); const pred = num(k.twin_predicted, actual);
    const divPct = pred ? +(Math.abs(actual - pred) / pred * 100).toFixed(2) : 0;
    return { kpi: k.kpi_name, plant: k.plant_id ?? k.plant, actual, twin_predicted: pred, divergence_pct: divPct, threshold_pct: num(k.divergence_threshold_pct, 3), diverging: divPct > num(k.divergence_threshold_pct, 3) };
  }).sort((a, b) => b.divergence_pct - a.divergence_pct);

  const scenarioRank = scenarios.map(s => ({ id: s.id, name: s.name, status: s.status, impact: s.impact, confidence: num(s.confidence), horizon: s.horizon, plant: s.plant_id ?? s.plant }));
  const topScenario = scenarioRank.find(s => s.status === 'complete') ?? scenarioRank[0];

  return {
    agent: 'twin',
    summary: `${divRank.filter(d => d.diverging).length} KPI(s) diverging from twin. Top scenario: ${topScenario?.name} — ${topScenario?.impact} (confidence ${topScenario?.confidence}, ${topScenario?.horizon}).`,
    calculated: { diverging_count: divRank.filter(d => d.diverging).length, top_divergence: divRank[0], top_scenario: topScenario },
    ranked: [...divRank.slice(0, 4).map(d => ({ type: 'divergence', ...d })), ...scenarioRank.slice(0, 3).map(s => ({ type: 'scenario', ...s }))],
    recordCount: scenarios.length + kpis.length,
  };
}

const AGENT_BUILDERS: Record<AgentId, (f: ContextFilters) => Promise<AgentContext>> = {
  oee: buildOEE, pdm: buildPdM, quality: buildQuality, energy: buildEnergy,
  supply: buildSupply, yield: buildYield, safety: buildSafety, twin: buildTwin,
  semantic: async (_f) => ({ agent: 'semantic', summary: 'Semantic Layer governs all KPI definitions and cross-agent conflict rules.', calculated: {}, ranked: [], recordCount: 0 }),
};

// ── Cross-agent enrichment ──────────────────────────────────────────────────────
// When PdM flags an asset, attach its OEE impact, parts availability, blocking
// permit, and any twin scenario for that asset — the cross-agent picture.
async function crossAgentForAsset(assetId: string, plant?: string): Promise<Record<string, unknown>> {
  const out: Record<string, unknown> = {};
  try {
    const m = (await liveMachines()).find(x => x.id === assetId);
    if (m) out.oee_impact = { oee: num(m.oee), status: m.status, line: m.line };
    const parts = (await getPartsOrders(plant)).filter(p => p.asset_id === assetId);
    if (parts.length) out.spare_parts = parts.map(p => ({ sku: p.sku, status: p.status, stock_qty: num(p.stock_qty), lead_days: num(p.lead_days) }));
    const permits = (await getSafetyPermits(plant)).filter(p => p.asset_id === assetId);
    if (permits.length) out.safety_permits = permits.map(p => ({ ptw_id: p.ptw_id, status: p.status, work_type: p.work_type }));
    const scenarios = (await getTwinScenarios(plant)).filter(s => (s.description ?? '').includes(assetId) || (s.name ?? '').includes(assetId));
    if (scenarios.length) out.twin_scenarios = scenarios.map(s => ({ id: s.id, impact: s.impact, confidence: num(s.confidence) }));
    const wos = (await getWorkOrders(plant)).filter(w => w.asset_id === assetId);
    if (wos.length) out.work_orders = wos.map(w => ({ id: w.id, priority: w.priority, status: w.status }));
  } catch (e) { logger.warn('[AIContext] cross-agent enrich failed', { error: String(e) }); }
  return out;
}

// ── KPI definitions for matched agents — DB-backed, single merged set ─────────
// All KPIs (business/tile + Semantic Layer) live in ONE table:
// semantic_kpi_definition, seeded from semantic_kpi_definitions.csv at boot.
// We read from the DB at runtime (single source of truth). Derived KPIs (those
// computed from other KPIs, e.g. OEE = A×P×Q) carry is_derived=1 — the only
// grouping the answer makes. Falls back to the CSV loader if the DB read fails.
async function kpiDefsForAgents(agents: AgentId[]): Promise<Array<Record<string, unknown>>> {
  const want = new Set(agents);
  const matchesAgent = (agentsField: string) =>
    String(agentsField ?? '').split(/[;,]/).map(s => s.trim()).some(a => want.has(a as AgentId));
  // 1) DB read (runtime source of truth)
  try {
    const rows = await getDb().prepare(
      `SELECT kpi_id, kpi_name, formula, unit, agents, source_system, governance, is_derived
         FROM semantic_kpi_definition ORDER BY is_derived ASC, kpi_name ASC`
    ).all() as any[];
    if (rows.length) {
      return rows.filter(r => matchesAgent(r.agents)).map(r => ({
        kpi_id: r.kpi_id, name: r.kpi_name, formula: r.formula, unit: r.unit,
        agents: r.agents, source: r.source_system, governance: r.governance,
        is_derived: !!r.is_derived,
      }));
    }
  } catch { /* fall through to CSV */ }
  // 2) CSV fallback (single-source-of-truth principle: every DB read has a CSV fallback)
  let defs: any[] = [];
  try { defs = loadSemanticKpiDefs(); } catch { return []; }
  return defs.filter(d => matchesAgent(Array.isArray(d.agents) ? d.agents.join(';') : d.agents))
    .map(d => ({ kpi_id: d.id ?? d.kpi_id, name: d.name, formula: d.formula, unit: d.unit,
                 agents: d.agents, source: d.src ?? d.source_system, governance: d.governance,
                 is_derived: !!d.is_derived }));
}


// ── Public API ────────────────────────────────────────────────────────────────
export interface GroundedContext {
  question: string;
  matchedAgents: AgentId[];
  filters: ContextFilters;
  kpiDefinitions: Array<Record<string, unknown>>;
  agentContexts: AgentContext[];
  crossAgent: Record<string, unknown>;
  freshness: string;
  missingDatasets: string[];
  governedHistory?: GovernedHistory;   // trends from the governed semantic layer (SEMANTIC_RESOLVER != off)
}

export async function buildGroundedContext(question: string, filters: ContextFilters = {}): Promise<GroundedContext> {
  const matchedAgents = detectAgents(question);
  const agentContexts: AgentContext[] = [];
  const missingDatasets: string[] = [];

  for (const agent of matchedAgents) {
    if (agent === 'semantic') continue;
    const ctx = await AGENT_BUILDERS[agent](filters);
    // Semantic resolver: off = untouched; shadow = compare + log, legacy wins; on = governed value wins, legacy is fallback.
    if (resolverMode() !== 'off' && ctx.calculated && Object.keys(ctx.calculated).length) {
      try { ctx.calculated = (await reconcileCalculated(agent, ctx.calculated, filters)).calculated; }
      catch (error) { logger.warn('[Semantic] reconcile failed; legacy values retained', { agent, error: String(error) }); }
    }
    agentContexts.push(ctx);
    if (ctx.missing) missingDatasets.push(`${agent}: ${ctx.missing}`);
  }

  // Cross-agent: if PdM flagged a first-to-fail asset, enrich it. crossAgentForAsset
  // is async, so it MUST be awaited — the enrichment has to be fully resolved before
  // the grounded context (and the final chatbot response) is built. Previously it was
  // spread without await, so the Promise contributed no fields and the cross-agent
  // enrichment silently went missing from responses. Safe fallback: if enrichment
  // fails, continue with base context instead of failing the whole response.
  let crossAgent: Record<string, unknown> = {};
  const pdmCtx = agentContexts.find(c => c.agent === 'pdm');
  const firstToFail = (pdmCtx?.calculated?.first_to_fail as any)?.asset;
  if (firstToFail) {
    try {
      crossAgent = { asset: firstToFail, ...(await crossAgentForAsset(firstToFail, filters.plant)) };
    } catch (error) {
      logger.warn('[AIContext] Cross-agent enrichment failed. Continuing with base context.', { error: String(error) });
      crossAgent = { asset: firstToFail };
    }
  }

  let governedHistory: GovernedHistory | undefined;
  try { governedHistory = await buildGovernedHistory(matchedAgents.filter(a => a !== 'semantic'), filters, question); }
  catch (error) { logger.warn('[AIContext] governed history failed; continuing without it', { error: String(error) }); }

  return {
    question,
    matchedAgents,
    filters,
    governedHistory,
    kpiDefinitions: await kpiDefsForAgents(matchedAgents),
    agentContexts,
    crossAgent,
    freshness: new Date().toISOString(),
    missingDatasets,
  };
}

// ── Render packet as the text block the LLM answers from ─────────────────────────
export function renderContextPacket(ctx: GroundedContext): string {
  const L: string[] = [];
  L.push('=== GROUNDED CONTEXT PACKET (answer ONLY from this) ===');
  L.push(`Data freshness: ${ctx.freshness}`);
  L.push(`Matched agents: ${ctx.matchedAgents.join(', ')}`);
  const f = ctx.filters;
  L.push(`Active filters: plant=${f.plant ?? 'All Plants'}${f.line ? ` line=${f.line}` : ''}${f.asset ? ` asset=${f.asset}` : ''}${f.period ? ` period=${f.period}` : ''}`);
  L.push('');

  if (ctx.kpiDefinitions.length) {
    L.push('-- KPIs for the matched agents (derived KPIs are marked):');
    for (const k of ctx.kpiDefinitions) {
      const tag = k.is_derived ? ' [derived]' : '';
      L.push(`  • ${k.name} = ${k.formula} [${k.unit}]${tag} (source: ${k.source})`);
    }
    L.push('');
  }

  for (const a of ctx.agentContexts) {
    L.push(`-- ${a.agent.toUpperCase()} (live, ${a.recordCount} records):`);
    if (a.missing) { L.push(`  MISSING DATASET: ${a.missing}`); L.push(''); continue; }
    L.push(`  Summary: ${a.summary}`);
    if (Object.keys(a.calculated).length) L.push(`  Calculated: ${JSON.stringify(a.calculated)}`);
    if (a.ranked.length) L.push(`  Ranked: ${JSON.stringify(a.ranked)}`);
    L.push('');
  }

  if (Object.keys(ctx.crossAgent).length) {
    L.push('-- Cross-agent impact (for the flagged asset):');
    L.push(`  ${JSON.stringify(ctx.crossAgent)}`);
    L.push('');
  }

  if (ctx.governedHistory?.lines.length) {
    L.push(`-- GOVERNED HISTORY (semantic layer, production-day basis, last ${ctx.governedHistory.windowDays} days). Use for trend questions; live sections above are current state.`);
    for (const line of ctx.governedHistory.lines) L.push(line);
    L.push('');
  }

  if (ctx.missingDatasets.length) {
    L.push('-- Missing datasets (state these clearly if relevant to the answer):');
    for (const m of ctx.missingDatasets) L.push(`  • ${m}`);
    L.push('');
  }

  return L.join('\n');
}
