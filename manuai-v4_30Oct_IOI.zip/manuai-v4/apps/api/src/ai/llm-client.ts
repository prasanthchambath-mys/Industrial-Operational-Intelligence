/**
 * ManuAI — Unified LLM Client
 *
 * Phase 1: LLM_PROVIDER=stargate  → StargateAI (free, internal)
 * Phase 2: LLM_PROVIDER=azure_openai → Azure OpenAI
 * Fallback: LLM_PROVIDER=anthropic  → Anthropic Claude
 *
 * Switch by changing LLM_PROVIDER in .env.local — no code changes.
 */

import axios from 'axios';
import { logger } from '../middleware/logger';
import { agentPrompt } from '../semantic/governance-runtime';

export interface ChatMessage { role: 'user' | 'assistant'; content: string; }

const PROVIDER = process.env.LLM_PROVIDER ?? 'stargate';

// V40: anything that looks like a copy-paste of the .env.example template gets
// rejected up front so the operator sees a useful error rather than "AI
// service unavailable" after the call fails at the upstream auth gate.
function isPlaceholderKey(key: string | undefined | null): boolean {
  if (!key) return true;
  const k = key.trim();
  if (k.length === 0) return true;
  if (k.length < 8) return true; // real keys are always longer
  const placeholderPatterns = [
    /^YOUR_/i, /^REPLACE_/i, /KEY_HERE$/i, /^xxx+$/i, /^todo$/i, /^changeme$/i, /<.+>/, /^sk-test/i,
  ];
  return placeholderPatterns.some(p => p.test(k));
}

// V40: diagnostic export — what is the api container actually using right now?
// Used by GET /api/ai/diagnostic to verify routing without exposing the key.
export function getLlmStatus() {
  const isStargate = PROVIDER === 'stargate';
  const isAzure    = PROVIDER === 'azure_openai';
  const isAnthropic = PROVIDER === 'anthropic';
  const apiKey = isStargate ? process.env.STARGATE_API_KEY
                : isAzure    ? process.env.AZURE_OPENAI_API_KEY
                : isAnthropic ? process.env.ANTHROPIC_API_KEY
                : '';
  const baseUrl = isStargate ? (process.env.STARGATE_BASE_URL ?? 'https://api-stargate.infocepts.com/')
                : isAzure    ? (process.env.AZURE_OPENAI_ENDPOINT ?? '(not set)')
                : isAnthropic ? 'https://api.anthropic.com/'
                : '(not set)';
  const model = isStargate ? (process.env.STARGATE_MODEL ?? 'gptoss-20b')
              : isAzure    ? (process.env.AZURE_OPENAI_DEPLOYMENT ?? '(not set)')
              : isAnthropic ? (process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-4-20250514')
              : '(not set)';
  const keyState: 'missing' | 'placeholder' | 'set' = !apiKey
    ? 'missing'
    : isPlaceholderKey(apiKey)
      ? 'placeholder'
      : 'set';
  return {
    provider:    PROVIDER,
    baseUrl,
    model,
    keyState,
    // Mask: first 3 + last 4 chars so the operator can confirm which key is in
    // place without us leaking the full secret.
    keyMasked:   apiKey ? `${apiKey.slice(0, 3)}…${apiKey.slice(-4)}` : '(empty)',
    keyLength:   apiKey?.length ?? 0,
    ready:       keyState === 'set',
  };
}

const SYSTEM_9_AGENT = `You are the Industrial Operational Intelligence Unified Platform AI with context across all 8 agents:
OEE Visibility, Yield Optimisation, Predictive Maintenance, Quality Vision,
Energy Optimisation, Supply Chain Resilience, Digital Twin, Safety & Compliance.

You answer business questions using the GROUNDED CONTEXT PACKET supplied below.
The packet contains live records, dynamically calculated KPI values, ranked
results, and cross-agent impacts — all filtered to the user's current plant/
line/asset selection, with a data-freshness timestamp.

ANSWER RULES (HARD):
- Answer ONLY from the GROUNDED CONTEXT PACKET. Do not invent numbers.
- When the packet contains live records and calculated values, USE THEM. Never
  say "CSV definition only" or "no live feed" when the packet shows live data.
- If a required dataset is listed under "Missing datasets", say exactly which
  dataset is missing — do not guess around it.
- Structure every business answer as:
    1. Direct answer (the specific asset/line/supplier/batch/param + its value)
    2. KPI value (the calculated metric, with its governed formula if relevant)
    3. Drivers (what's causing it, from the ranked/record data)
    4. Impacted plant / line / asset / batch / supplier
    5. Cross-agent impact (if the packet's cross-agent section has data)
    6. Recommended action
    7. Source data used (which agent records + freshness timestamp)
- Be specific and concise. Lead with the answer. Max 200 words unless asked for more.
- Respect the active filters shown in the packet (plant/line/asset/period).
- When asked which KPIs govern or belong to an agent, list ALL the agent's KPIs
  from the packet's KPI section as ONE merged set — do not split into "main" vs
  "additional". The only distinction to surface is that KPIs marked [derived] are
  computed from other KPIs (e.g. OEE = Availability x Performance x Quality).`;

const AGENT_PROMPTS: Record<string, string> = {
  yield:   'You are the Yield Optimisation agent. Recommend DCS set-point adjustments. Max 80 words.',
  pdm:     'You are the Predictive Maintenance agent. RUL < 14d = critical, RUL < 30d = urgent. Max 80 words.',
  oee:     'You are the OEE Visibility agent. Identify top Six Big Losses. Max 80 words.',
  quality: 'You are the Quality Vision agent. Analyse defect patterns. Max 80 words.',
  energy:  'You are the Energy Optimisation agent. Recommend demand response actions. Max 80 words.',
  supply:  'You are the Supply Chain agent. Analyse supplier risk 4-8 weeks ahead. Max 80 words.',
  safety:  'You are the Safety agent. Never understate risk severity. Max 80 words.',
  twin:    'You are the Digital Twin agent. Flag KPI divergence from twin predictions. Max 80 words.',
};

async function openAICompatibleChat(
  messages: Array<{ role: string; content: string }>,
  systemPrompt: string,
  maxTokens = 1500
): Promise<string> {
  const isStargate = PROVIDER === 'stargate';
  const isAzure = PROVIDER === 'azure_openai';

  const baseUrl = isStargate
    ? (process.env.STARGATE_BASE_URL ?? 'https://api-stargate.infocepts.com/')
    : (process.env.AZURE_OPENAI_ENDPOINT ?? '');

  const apiKey = isStargate
    ? (process.env.STARGATE_API_KEY ?? '')
    : (process.env.AZURE_OPENAI_API_KEY ?? '');

  const model = isStargate
    ? (process.env.STARGATE_MODEL ?? 'gptoss-20b')
    : (process.env.AZURE_OPENAI_DEPLOYMENT ?? 'gpt-4o');

  // V40: reject placeholder keys with a clear message. Previously a value like
  // `YOUR_STARGATE_API_KEY_HERE` passed the `if (!apiKey)` check, the call
  // failed at Stargate's auth gate, and the user saw a generic "AI service
  // unavailable" without learning the key was the problem.
  if (isPlaceholderKey(apiKey)) {
    logger.warn(`[LLM] ${PROVIDER} key is missing or still a placeholder`);
    return `AI service not configured: ${PROVIDER} API key is still a placeholder. Edit .env.local to add the real key, then run \`docker compose down && docker compose up -d\` so the new env is picked up by the api container.`;
  }

  // Stargate is OpenAI-compatible and exposes /chat/completions at the BASE_URL
  // root (per Infocepts docs: the OpenAI SDK is used with base_url=
  // https://api-stargate.infocepts.com/ , which posts to {base}/chat/completions
  // — NOT /v1/chat/completions). Normalise trailing slashes so the path is right
  // whether or not STARGATE_BASE_URL ends in '/'.
  const cleanBase = baseUrl.replace(/\/+$/, '');
  const url = isAzure
    ? `${cleanBase}/openai/deployments/${model}/chat/completions?api-version=2024-02-01`
    : `${cleanBase}/chat/completions`;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(isAzure ? { 'api-key': apiKey } : { 'Authorization': `Bearer ${apiKey}` }),
  };

  try {
    const res = await axios.post(url, {
      model,
      max_tokens: maxTokens,
      messages: [{ role: 'system', content: systemPrompt }, ...messages],
    }, { headers, timeout: 20000 });
    const content = res.data?.choices?.[0]?.message?.content;
    if (!content) {
      logger.warn(`[LLM] ${PROVIDER} returned empty content`, {
        status: res.status,
        finish_reason: res.data?.choices?.[0]?.finish_reason,
        raw: JSON.stringify(res.data).slice(0, 300),
      });
      return 'No response from model (empty content). Check docker compose logs api for the raw response.';
    }
    return content;
  } catch (err: any) {
    // V40: log the upstream response body. Was just throwing — operator had to
    // read container logs and decode axios stack traces to diagnose a bad key.
    const status = err?.response?.status;
    const body = err?.response?.data;
    logger.error(`[LLM] ${PROVIDER} call failed`, {
      url, model, status,
      body: typeof body === 'string' ? body.slice(0, 500) : JSON.stringify(body)?.slice(0, 500),
      message: err?.message,
    });
    if (status === 401 || status === 403) {
      return `AI service rejected the ${PROVIDER} API key (HTTP ${status}). Verify the key in .env.local and restart: \`docker compose down && docker compose up -d\`.`;
    }
    if (status === 404) {
      return `AI service returned 404 — model "${model}" not found on ${PROVIDER}. Check STARGATE_MODEL / AZURE_OPENAI_DEPLOYMENT in .env.local.`;
    }
    // No HTTP status → the request never reached the endpoint (DNS failure,
    // connection refused, TLS error, or timeout). This is almost always a
    // network-reachability problem, not a key/model problem. Surface it clearly
    // instead of throwing (which the route turned into an opaque 503 → the UI's
    // generic "Connection error.").
    if (!status) {
      const code = err?.code ?? (/timeout/i.test(String(err?.message)) ? 'ETIMEDOUT' : 'NETWORK');
      return `Can't reach the ${PROVIDER} endpoint at ${url} (${code}). The API server has no network route to it — the key and model look fine, but the host is unreachable from the api container. Check: (1) the machine is on the network/VPN that can reach ${baseUrl}; (2) STARGATE_BASE_URL is correct; (3) any required proxy is set (HTTPS_PROXY). Test from inside the container: \`docker compose exec api wget -qO- ${baseUrl}\`.`;
    }
    throw err;
  }
}

async function anthropicChat(
  messages: ChatMessage[],
  systemPrompt: string,
  maxTokens = 600
): Promise<string> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (isPlaceholderKey(apiKey)) {
    logger.warn('[LLM] anthropic key is missing or still a placeholder');
    return 'AI service not configured: ANTHROPIC_API_KEY is missing or still a placeholder. Edit .env.local then `docker compose down && docker compose up -d`.';
  }

  const res = await axios.post('https://api.anthropic.com/v1/messages', {
    model: process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-4-20250514',
    max_tokens: maxTokens,
    system: systemPrompt,
    messages,
  }, {
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    timeout: 30000,
  });

  return res.data?.content?.find((b: any) => b.type === 'text')?.text ?? 'No response.';
}

export interface ChatFilters { plant?: string; line?: string; asset?: string; period?: string; }

export async function unifiedChat(
  messages: ChatMessage[],
  liveContext?: string,
  filters?: ChatFilters,
): Promise<string> {
  // V44: build the grounded context packet SERVER-SIDE from live DB records.
  // The last user message drives domain detection + record retrieval + KPI
  // calculation + ranking + cross-agent enrichment. This replaces the old
  // client-supplied dictionary-only context that made the AI answer from KPI
  // definitions instead of current data.
  let grounded = '';
  try {
    const lastUser = [...messages].reverse().find(m => m.role === 'user');
    if (lastUser) {
      // Lazy import to avoid a circular dependency at module load
      const { buildGroundedContext, renderContextPacket } = await import('./ai-context-builder');
      const packet = await buildGroundedContext(lastUser.content, filters ?? {});
      grounded = renderContextPacket(packet);
    }
  } catch (err) {
    logger.warn('[LLM] grounded context build failed — falling back to client context', { error: String(err) });
  }

  // Prefer the server-built grounded packet; append any client liveContext as
  // clearly-labelled SUPPLEMENTARY state (e.g. running scenarios) so it can
  // never override the authoritative grounded packet above it.
  const supplement = liveContext
    ? `-- Supplementary dashboard state (non-authoritative; the GROUNDED CONTEXT PACKET above is the source of truth) --\n${liveContext}`
    : '';
  const contextBlock = [grounded, supplement].filter(Boolean).join('\n\n');
  const system = contextBlock
    ? `${SYSTEM_9_AGENT}\n\n${contextBlock}`
    : SYSTEM_9_AGENT;
  try {
    if (PROVIDER === 'anthropic') return await anthropicChat(messages, system);
    return await openAICompatibleChat(messages, system);
  } catch (err) {
    logger.error('[LLM] Chat error', { provider: PROVIDER, error: String(err) });
    throw new Error('AI service temporarily unavailable');
  }
}

export async function agentRecommendation(agent: string, context: string, question: string): Promise<string> {
  // Step 5: agent prompt from semantic_prompt_template with thresholds substituted; falls back to the literal map.
  const promptText = AGENT_PROMPTS[agent] ? await agentPrompt(agent, AGENT_PROMPTS[agent]) : SYSTEM_9_AGENT;
  const system = `${promptText}\n\nContext:\n${context}`;
  try {
    if (PROVIDER === 'anthropic') return await anthropicChat([{ role: 'user', content: question }], system, 300);
    return await openAICompatibleChat([{ role: 'user', content: question }], system, 300);
  } catch (err) {
    logger.error('[LLM] Agent error', { agent, error: String(err) });
    return 'AI recommendation temporarily unavailable.';
  }
}

export async function semanticQuery(question: string, kpiContext: string): Promise<string> {
  const system = `You are the Industrial Operational Intelligence Semantic Layer. Answer using only the KPI data provided. Max 200 words.\n\nKPIs:\n${kpiContext}`;
  try {
    if (PROVIDER === 'anthropic') return await anthropicChat([{ role: 'user', content: question }], system, 500);
    return await openAICompatibleChat([{ role: 'user', content: question }], system, 500);
  } catch (err) {
    logger.error('[LLM] Semantic error', { error: String(err) });
    return 'Query temporarily unavailable.';
  }
}

logger.info(`[LLM] Provider: ${PROVIDER}`);
