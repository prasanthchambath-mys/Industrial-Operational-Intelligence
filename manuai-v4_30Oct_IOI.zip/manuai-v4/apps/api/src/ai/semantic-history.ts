/**
 * Governed history for the AI assistant: trends from analytics_semantic KPI views (production-day basis), so the
 * assistant answers "how has X trended?" from governed figures. Deliberate second chat-output change (decided 23 Sep).
 * Active only when SEMANTIC_RESOLVER != off on PostgreSQL. Read-only constant SQL; never fails a chat; cached 5 min.
 */
import { getDb, type DbAdapter } from '../database/connection';
import { logger } from '../middleware/logger';
import { normalizePlant } from '../data/plant';
import type { AgentId, ContextFilters } from './ai-context-builder';
import { resolverMode } from '../semantic/resolver';

type Metric = { col: string; label: string; decimals: number };
type Source = { view: string; dateCol: string; metrics: Metric[] };
const SOURCES: Partial<Record<AgentId, Source[]>> = {
  oee: [{ view: 'kpi_oee_by_day', dateCol: 'production_date', metrics: [{ col: 'oee', label: 'OEE %', decimals: 1 }, { col: 'availability', label: 'Availability %', decimals: 1 }, { col: 'performance', label: 'Performance %', decimals: 1 }, { col: 'quality_rate', label: 'Quality %', decimals: 1 }, { col: 'loss_minutes', label: 'Six Big Losses (min)', decimals: 0 }] }],
  quality: [{ view: 'kpi_quality_by_day', dateCol: 'production_date', metrics: [{ col: 'defect_rate', label: 'Defect rate %', decimals: 2 }, { col: 'defect_escape_rate', label: 'Defect escape rate %', decimals: 2 }] }],
  yield: [{ view: 'kpi_yield_by_day', dateCol: 'production_date', metrics: [{ col: 'yield_pct', label: 'Yield %', decimals: 1 }, { col: 'scrap_rate', label: 'Scrap rate %', decimals: 1 }] }],
  pdm: [{ view: 'kpi_asset_health_by_day', dateCol: 'production_date', metrics: [{ col: 'asset_health_pct', label: 'Fleet health %', decimals: 1 }, { col: 'rul_days_min', label: 'Minimum RUL (days)', decimals: 1 }, { col: 'mttr_hours', label: 'MTTR (h)', decimals: 1 }] }],
  energy: [{ view: 'kpi_energy_by_day', dateCol: 'production_date', metrics: [{ col: 'kwh_per_unit', label: 'kWh per unit', decimals: 2 }, { col: 'carbon_intensity', label: 'Carbon kgCO2/kWh', decimals: 3 }, { col: 'peak_demand_kw', label: 'Peak demand (kW)', decimals: 0 }] }],
  supply: [{ view: 'kpi_supply_position_by_day', dateCol: 'production_date', metrics: [{ col: 'safety_stock_alerts', label: 'Safety stock alerts', decimals: 0 }, { col: 'skus_at_shortfall_risk', label: 'SKUs at shortfall risk', decimals: 0 }] }],
  twin: [{ view: 'kpi_twin_divergence_by_day', dateCol: 'production_date', metrics: [{ col: 'twin_divergence_pct', label: 'Twin divergence %', decimals: 1 }] }],
  safety: [{ view: 'kpi_safety_plant_by_day', dateCol: 'production_date', metrics: [{ col: 'near_miss_rate', label: 'Near-miss rate per 1,000 h', decimals: 2 }, { col: 'permit_compliance', label: 'Permit compliance %', decimals: 1 }] }],
};
const TTL_MS = 5 * 60_000, TIMEOUT_MS = 2_500;
const cache = new Map<string, { at: number; rows: Record<string, unknown>[] }>();
export interface GovernedHistory { windowDays: number; lines: string[] }
export function isEnabled(db: Pick<DbAdapter, 'backend'>): boolean { return resolverMode() !== 'off' && db.backend === 'postgres'; }
export function windowDays(question: string, period?: string): number {
  if (period === 'today') return 7; const m = period?.match(/^(\d+)d$/); if (m) return Math.min(90, Math.max(1, Number(m[1])));
  const q = question.toLowerCase(); if (/\b(quarter|90 ?days?)\b/.test(q)) return 90; if (/\b(month|30 ?days?|last 4 weeks)\b/.test(q)) return 30; if (/\b(week|7 ?days?)\b/.test(q)) return 7; return 14;
}
const fmt = (v: unknown, d: number) => (v == null || Number.isNaN(Number(v))) ? 'n/a' : Number(v).toFixed(d);
export function summarise(src: Source, rows: Record<string, unknown>[], days: number): string[] {
  const out: string[] = []; const byPlant = new Map<string, Record<string, unknown>[]>();
  for (const r of rows) { const k = String(r.plant ?? 'All plants'); if (!byPlant.has(k)) byPlant.set(k, []); byPlant.get(k)!.push(r); }
  for (const [plant, rs] of byPlant) {
    rs.sort((a, b) => String(a.d).localeCompare(String(b.d)));
    for (const m of src.metrics) {
      const pts = rs.map(r => ({ d: String(r.d).slice(0, 10), v: r[m.col] })).filter(p => p.v != null && !Number.isNaN(Number(p.v)));
      if (!pts.length) continue; const vals = pts.map(p => Number(p.v)); const first = pts[0], last = pts[pts.length - 1]; const delta = Number(last.v) - Number(first.v);
      out.push(`  • ${m.label} — ${plant}, last ${days} production days: latest ${fmt(last.v, m.decimals)} (${last.d}), start ${fmt(first.v, m.decimals)} (${first.d}), change ${delta >= 0 ? '+' : ''}${delta.toFixed(m.decimals)}, range ${fmt(Math.min(...vals), m.decimals)}–${fmt(Math.max(...vals), m.decimals)}; recent daily: ${pts.slice(-7).map(p => fmt(p.v, m.decimals)).join(', ')}`);
    }
  }
  return out;
}
async function withTimeout<T>(p: Promise<T>): Promise<T> { return Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(new Error('timeout')), TIMEOUT_MS))]); }
export async function buildGovernedHistory(agents: AgentId[], filters: ContextFilters, question: string, db: DbAdapter = getDb()): Promise<GovernedHistory> {
  const days = windowDays(question, filters.period); const empty: GovernedHistory = { windowDays: days, lines: [] };
  if (!isEnabled(db)) return empty;
  const code = normalizePlant(filters.plant); const lines: string[] = [];
  for (const agent of agents) for (const src of SOURCES[agent] ?? []) {
    const key = `${src.view}|${code ?? '*'}|${days}`; const c = cache.get(key); let rows = c && Date.now() - c.at < TTL_MS ? c.rows : undefined;
    if (!rows) {
      const sql = `SELECT plant, CAST(${src.dateCol} AS text) AS d, ${src.metrics.map(m => m.col).join(', ')} FROM analytics_semantic.${src.view}
                   WHERE ${src.dateCol} >= current_date - CAST(? AS integer) AND (CAST(? AS text) IS NULL OR plant = (SELECT plant_name FROM analytics_core.dim_plant WHERE plant_id = CAST(? AS text))) ORDER BY plant, d`;
      try { rows = await withTimeout(db.all(sql, [days, code, code])); cache.set(key, { at: Date.now(), rows }); }
      catch (error) { logger.debug('[AIContext] governed history skipped', { view: src.view, error: String(error) }); continue; }
    }
    lines.push(...summarise(src, rows, days));
  }
  return { windowDays: days, lines };
}
export function _clearGovernedHistoryCache(): void { cache.clear(); }
