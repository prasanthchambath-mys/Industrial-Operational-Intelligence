/**
 * ManuAI — WebSocket Broadcaster  V43
 *
 * SCALING: With the Redis adapter enabled (REDIS_URL set), socket.io events
 * fan out across ALL API replicas. Without it (Phase 1 / dev), events only
 * reach clients on the same process — fine for 1 replica, broken for N.
 *
 * To scale Azure Container Apps / AKS past 1 replica:
 *   1. Set REDIS_URL=rediss://...        (Azure Cache for Redis)
 *   2. Set max-replicas > 1
 * Cross-agent events then reach every connected client regardless of which
 * replica fired them — no code change, just the env var.
 */

import { Server } from 'socket.io';
import { Server as HttpServer } from 'http';
import { logger } from '../middleware/logger';

let io: Server;

export type AgentChannel = 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety' | 'semantic' | 'alerts';

export function initWebSocket(httpServer: HttpServer): void {
  io = new Server(httpServer, {
    cors: { origin: process.env.CORS_ORIGINS?.split(',') ?? ['http://localhost:5173'], methods: ['GET', 'POST'] },
    transports: ['websocket', 'polling'],
  });

  // ── Event-bus mode ──────────────────────────────────────────────────────────
  // EVENT_BUS = memory | redis | auto (default auto)
  //   memory → never touch Redis (local default; no errors even if REDIS_URL set)
  //   redis  → use Redis adapter (Azure)
  //   auto   → redis iff REDIS_URL is set, else memory
  // REDIS_REQUIRED only affects log severity on failure — Redis NEVER crashes the
  // process. On any connection failure we log ONCE, release the clients, and fall
  // back to the in-memory bus. This is what makes local Docker safe when the
  // compose `redis` service isn't running.
  const redisUrl = process.env.REDIS_URL;
  const busMode = (process.env.EVENT_BUS ?? 'auto').toLowerCase();
  const useRedis = busMode === 'redis' || (busMode === 'auto' && !!redisUrl);

  if (useRedis && redisUrl) {
    (async () => {
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const { createAdapter } = require('@socket.io/redis-adapter');
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const Redis = require('ioredis');
      // Bounded retry: give up after 3 attempts (retryStrategy → null stops
      // reconnection). maxRetriesPerRequest:1 + enableOfflineQueue:false make
      // commands fail fast instead of throwing MaxRetriesPerRequestError later.
      const opts: Record<string, unknown> = {
        lazyConnect: true,
        maxRetriesPerRequest: 1,
        enableOfflineQueue: false,
        retryStrategy: (times: number) => (times > 3 ? null : Math.min(times * 200, 1000)),
        reconnectOnError: () => false,
      };

      // ── Entra ID (managed identity) auth for Azure Managed Redis ──────────────
      // When REDIS_AUTH_MODE=entra, we authenticate with an AAD access token
      // instead of an access key. The token is the ioredis `password`; the
      // `username` is the identity's object id (supplied via REDIS_USERNAME, or
      // parsed from the userinfo part of REDIS_URL). Tokens expire (~24h) so we
      // refresh on a timer and re-AUTH both clients before the old token lapses.
      const authMode = (process.env.REDIS_AUTH_MODE ?? '').toLowerCase();
      let tokenRefresh: NodeJS.Timeout | undefined;
      if (authMode === 'entra') {
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { DefaultAzureCredential } = require('@azure/identity');
        const credential = new DefaultAzureCredential();
        const scope = 'https://redis.azure.com/.default';
        const tok = await credential.getToken(scope);
        // username: explicit env wins, else the userinfo before '@' in the URL
        let username = process.env.REDIS_USERNAME;
        if (!username) {
          const m = /\/\/([^@:]+)(?::[^@]*)?@/.exec(redisUrl);
          username = m ? m[1] : undefined;
        }
        opts.username = username;
        opts.password = tok.token;
        opts.tls = { servername: new URL(redisUrl).hostname };

        // Refresh ~5 min before expiry; re-AUTH both live connections.
        const scheduleRefresh = (expiresOnMs: number) => {
          const lead = 5 * 60 * 1000;
          const delay = Math.max(30 * 1000, expiresOnMs - Date.now() - lead);
          tokenRefresh = setTimeout(async () => {
            try {
              const t = await credential.getToken(scope);
              await Promise.all([
                pubClient.auth(username, t.token),
                subClient.auth(username, t.token),
              ]);
              logger.info('[WS] Redis Entra token refreshed');
              scheduleRefresh(t.expiresOnTimestamp);
            } catch (e) {
              logger.error('[WS] Redis Entra token refresh failed', { error: String(e) });
              scheduleRefresh(Date.now() + 5 * 60 * 1000); // retry in 5 min
            }
          }, delay);
          if (tokenRefresh.unref) tokenRefresh.unref();
        };
        // scheduled after clients are constructed (see below)
        (opts as Record<string, unknown>).__scheduleRefresh = () => scheduleRefresh(tok.expiresOnTimestamp);
      }

      const pubClient = new Redis(redisUrl, opts);
      const subClient = pubClient.duplicate();
      // Kick off token refresh loop now that both clients exist.
      const __sched = (opts as Record<string, unknown>).__scheduleRefresh as (() => void) | undefined;
      if (__sched) __sched();

      let degraded = false;
      const degrade = (where: string) => (e: Error) => {
        if (degraded) return;              // log ONCE, not on every retry
        degraded = true;
        const msg = `[WS] Redis unavailable (${where}) — falling back to in-memory bus`;
        if ((process.env.REDIS_REQUIRED ?? 'false').toLowerCase() === 'true') logger.error(msg, { error: e.message });
        else logger.warn(msg, { error: e.message });
        try { pubClient.disconnect(); subClient.disconnect(); } catch { /* noop */ }
      };
      pubClient.on('error', degrade('pub'));
      subClient.on('error', degrade('sub'));

      // Connect explicitly (lazyConnect). If either fails, we stay on the default
      // in-memory adapter — the adapter is only installed after both connect.
      Promise.all([pubClient.connect(), subClient.connect()])
        .then(() => {
          if (degraded) return;
          io.adapter(createAdapter(pubClient, subClient));
          logger.info('[WS] Redis adapter active — multi-replica fan-out enabled');
        })
        .catch(degrade('connect'));
    } catch (err) {
      logger.warn('[WS] Redis adapter module unavailable — in-memory bus', { error: String(err) });
    }
    })();
  } else {
    logger.info(`[WS] In-memory WebSocket bus (EVENT_BUS=${busMode}${redisUrl ? '' : ', no REDIS_URL'})`);
  }

  io.on('connection', (socket) => {
    socket.on('subscribe', (channels: AgentChannel[]) =>
      channels.forEach(ch => socket.join(ch)));

    socket.on('subscribe_plant', (plantId: string) => {
      socket.join(`plant:${plantId}`);
      socket.data.plantId = plantId;
    });

    socket.on('subscribe_tenant', (tenantId: string) => {
      socket.join(`tenant:${tenantId}`);
      socket.data.tenantId = tenantId;
    });

    socket.on('disconnect', () => logger.debug('WS disconnect', { id: socket.id }));
  });

  logger.info('WebSocket server ready');
}

export function broadcast(channel: AgentChannel, data: unknown, plantId = 'P1'): void {
  io?.to(channel).emit('update', { channel, ts: Date.now(), data, plant_id: plantId });
}

export function broadcastEvent(event: Record<string, unknown>): void {
  const plantId = event.plant_id as string | undefined;
  if (plantId) {
    io?.to(`plant:${plantId}`).emit('cross_agent_event', event);
    io?.except(`plant:${plantId}`).emit('cross_agent_event', event);
  } else {
    io?.emit('cross_agent_event', event);
  }
}

export function broadcastToPlant(plantId: string, channel: AgentChannel, data: unknown): void {
  io?.to(`plant:${plantId}`).to(channel).emit('update', { channel, ts: Date.now(), data, plant_id: plantId });
}
