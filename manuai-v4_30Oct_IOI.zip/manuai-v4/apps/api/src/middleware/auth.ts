import { Request, Response, NextFunction } from 'express';
import { createRemoteJWKSet, jwtVerify, type JWTPayload } from 'jose';
import { logger } from './logger';

declare global {
  namespace Express {
    interface Request {
      user?: { oid: string; name: string; preferred_username?: string; roles: string[] };
    }
  }
}

export const ROLES = {
  OPERATOR: 'operator', SUPERVISOR: 'supervisor', MAINTENANCE: 'maintenance',
  ENGINEER: 'engineer', EXECUTIVE: 'executive', ADMIN: 'admin',
} as const;
export type Role = typeof ROLES[keyof typeof ROLES];

// ── Remote JWKS (Entra ID / B2C) ─────────────────────────────────────────────
// Built once and cached; jose handles key rotation and caching internally.
// AUTH_JWKS_URI examples:
//   Entra:  https://login.microsoftonline.com/<tenant>/discovery/v2.0/keys
//   B2C:    https://<tenant>.b2clogin.com/<tenant>.onmicrosoft.com/<policy>/discovery/v2.0/keys
let _jwks: ReturnType<typeof createRemoteJWKSet> | null = null;
function getJwks(): ReturnType<typeof createRemoteJWKSet> {
  if (!_jwks) {
    const uri = process.env.AUTH_JWKS_URI;
    if (!uri) throw new Error('AUTH_JWKS_URI is required when MOCK_AUTH=false');
    _jwks = createRemoteJWKSet(new URL(uri));
  }
  return _jwks;
}

// Roles come from the Entra app-roles "roles" claim. The "groups" claim is used
// ONLY when AUTH_ROLES_FROM_GROUPS=true is explicitly set (documented opt-in),
// because group object-IDs are not human role names and must be mapped deliberately.
function extractRoles(payload: JWTPayload): string[] {
  const roles = (payload as Record<string, unknown>).roles;
  if (Array.isArray(roles) && roles.length) return roles as string[];
  if (process.env.AUTH_ROLES_FROM_GROUPS === 'true') {
    const groups = (payload as Record<string, unknown>).groups;
    if (Array.isArray(groups)) return groups as string[];
  }
  return [];
}

export const authMiddleware = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  // ── Local / demo bypass ──
  if (process.env.MOCK_AUTH === 'true') {
    req.user = { oid: 'dev-user', name: 'Dev User', roles: [ROLES.ADMIN] };
    return next();
  }

  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) { res.status(401).json({ error: 'Unauthorized' }); return; }
  const token = header.slice(7);

  try {
    // jwtVerify enforces: cryptographic SIGNATURE (via JWKS), ISSUER, AUDIENCE,
    // and EXPIRY/not-before — in one call. A failure on any throws → 401.
    const audience = process.env.AUTH_AUDIENCE || process.env.AUTH_CLIENT_ID || undefined;
    const issuer = process.env.AUTH_ISSUER || undefined;
    const { payload } = await jwtVerify(token, getJwks(), {
      ...(audience ? { audience } : {}),
      ...(issuer ? { issuer } : {}),
    });

    // Subject is required; reject tokens missing it.
    const oid = (payload.oid as string) || (payload.sub as string);
    if (!oid) throw new Error('missing subject claim (oid/sub)');

    req.user = {
      oid,
      name: (payload.name as string) || (payload.preferred_username as string) || 'User',
      preferred_username: payload.preferred_username as string | undefined,
      roles: extractRoles(payload),
    };
    next();
  } catch (err) {
    logger.warn('[auth] token rejected', { error: err instanceof Error ? err.message : String(err) });
    res.status(401).json({ error: 'Invalid token' });
  }
};

export const requireRole = (...allowed: Role[]) =>
  (req: Request, res: Response, next: NextFunction): void => {
    const roles = req.user?.roles ?? [];
    if (allowed.some(r => roles.includes(r)) || roles.includes(ROLES.ADMIN)) return next();
    res.status(403).json({ error: `Requires role: ${allowed.join(' or ')}` });
  };
