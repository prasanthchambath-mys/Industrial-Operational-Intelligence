/**
 * ManuAI — Synthetic Data Engine
 *
 * Simulates a live manufacturing plant. Runs inside the API process —
 * no extra service needed. Auto-starts when MOCK_DATA_ENGINE=true (default).
 *
 * Every 4 seconds it:
 *   • Degrades machine health, vibration, temperature
 *   • Triggers maintenance when health is critical, restores after
 *   • Cycles batches: planned → in_process → completed → new batch
 *   • Drifts yield parameters away from target, slowly self-corrects
 *   • Follows a real 24-hour energy demand curve
 *   • Fires occasional safety gas spikes and resolves them
 *   • Emits cross-agent events via WebSocket in real time
 *
 * Routes call getPlantState() instead of hardcoded constants.
 * When real connectors are wired, the engine is disabled — no code changes.
 */

import { broadcast, broadcastEvent } from '../websocket/broadcaster';
import { computeKPIs, persistKPIs } from '../kpi/engine';
import { triggerDegradationScenario } from '../orchestration/scenario-engine';
import { semanticLayer } from '../semantic/service';
import { logger } from '../middleware/logger';
import { writeStateToDB, writeAlertToDB, writeSafetyEventToDB, resolveSafetyEventInDB } from '../database/writer';
import { loadMachines, loadUtilities, loadYieldParams, loadEnergyAssets, loadEnergyHourly, loadSafetyZones, loadPlatformConfig } from '../data/csv-loader';
import { resolvePlantFromAny, getPlantCodes } from '../data/plant';
import { getLatest as iotGetLatest, type SensorReading } from '../connectors/iot-hub';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MachineSim {
  id: string; name: string; line: string; plant: string;
  oee: number; avail: number; perf: number; qual: number;
  health: number; rul: number;
  status: 'good' | 'caution' | 'warning' | 'critical';
  loss: string; lossMin: number;
  vib: number; temp: number; pressure: number;
  _degradeRate: number;
  _inMaintenance: boolean;
  _maintenanceTicksLeft: number;
  _rulK?: number; // seed rul:health ratio — keeps RUL consistent with live health
}

export interface UtilitySim {
  id: string; name: string;
  health: number; rul: number; status: string;
  vib: number; temp: number; press: number;
  oeeLink: string | null;
  plant: string;
  _degradeRate: number;
  _rulK?: number; // seed rul:health ratio — keeps RUL consistent with live health
}

export interface BatchSim {
  id: string; product: string; qty: number;
  plan: number; actual: number | null;
  status: 'planned' | 'in_process' | 'completed';
  startedAt: number; durationMs: number;
}

export interface YieldParamSim {
  id: string; name: string; unit: string;
  val: number; tgt: number; min: number; max: number;
  warn: boolean; blocked: boolean;
  plant: string;
  _driftRate: number; _driftDir: 1 | -1;
}

export interface EnergyAssetSim {
  id: string; name: string; kw: number; anomaly: boolean; _baseKw: number;
}

export interface SafetyZoneSim {
  zone: string; h2s: number; co: number; ch4: number;
  _spiking: boolean;               // alert-active flag (set on rising edge of a gas anomaly)
  _activeSafetyEventId?: string;   // DB id of the open event for the current alert
}

export interface PlantState {
  machines: MachineSim[];
  utilities: UtilitySim[];
  plantOEE: number;
  batch: BatchSim;
  yieldParams: YieldParamSim[];
  energyKw: number;
  energyTrend: Array<{ h: string; kw: number }>;
  energyAssets: EnergyAssetSim[];
  safetyZones: SafetyZoneSim[];
  tickCount: number;
  lastTick: string;
}

// ─── Initial state ────────────────────────────────────────────────────────────

function initMachines(): MachineSim[] { return loadMachines() as MachineSim[]; }

function initUtilities(): UtilitySim[] { return loadUtilities() as UtilitySim[]; }

function initYieldParams(): YieldParamSim[] { return loadYieldParams() as YieldParamSim[]; }

function initEnergyAssets(): EnergyAssetSim[] { return loadEnergyAssets() as EnergyAssetSim[]; }

function initSafetyZones(): SafetyZoneSim[] { return loadSafetyZones() as SafetyZoneSim[]; }

import { loadDemandCurve } from '../data/csv-loader';
const DEMAND_CURVE = loadDemandCurve(); // 24-hour energy demand profile from demand_curve.csv

function buildEnergyTrend(): Array<{ h: string; kw: number }> { return loadEnergyHourly(); }

// ─── Engine ───────────────────────────────────────────────────────────────────

class SimulationEngine {
  private state: PlantState;
  private timer: ReturnType<typeof setInterval> | null = null;
  private evtCounter = 100;
  // Sim thresholds — read from platform_config.csv (sim_thresholds section).
  // Replaces a scatter of hardcoded numbers (health<20, health<40, RUL bounce
  // 60..140, etc.) so plant operators / consultants can tune the demo
  // behaviour by editing a CSV instead of touching the code.
  private thresholds: {
    healthCritical: number;
    healthMaintenance: number;
    healthRecoveryMin: number;
    healthRecoveryMax: number;
    rulRecoveryMin: number;
    rulRecoveryMax: number;
    heartbeatIntervalTicks: number;
  };

  constructor() {
    // Load thresholds from CSV with safe fallbacks for any missing keys.
    let cfg: any = {};
    try { cfg = (loadPlatformConfig() as any)?.simThresholds ?? {}; } catch { /* CSV not ready */ }
    this.thresholds = {
      healthCritical:         Number.isFinite(cfg.health_critical)         ? cfg.health_critical         : 40,
      healthMaintenance:      Number.isFinite(cfg.health_maintenance)      ? cfg.health_maintenance      : 20,
      healthRecoveryMin:      Number.isFinite(cfg.health_recovery_min)     ? cfg.health_recovery_min     : 60,
      healthRecoveryMax:      Number.isFinite(cfg.health_recovery_max)     ? cfg.health_recovery_max     : 95,
      rulRecoveryMin:         Number.isFinite(cfg.rul_recovery_min)        ? cfg.rul_recovery_min        : 60,
      rulRecoveryMax:         Number.isFinite(cfg.rul_recovery_max)        ? cfg.rul_recovery_max        : 140,
      heartbeatIntervalTicks: Number.isFinite(cfg.heartbeat_interval_ticks)? cfg.heartbeat_interval_ticks: 3,
    };
    this.state = {
      machines: initMachines(), utilities: initUtilities(),
      plantOEE: 76.8,
      batch: { id:'PP-88414',product:'Compound X-12 Grade A',qty:2400,plan:91.0,actual:null,
               status:'in_process',startedAt:Date.now()-3*3600000,durationMs:8*3600000 },
      yieldParams: initYieldParams(),
      energyKw: 1547, energyTrend: buildEnergyTrend(),
      energyAssets: initEnergyAssets(), safetyZones: initSafetyZones(),
      tickCount: 0, lastTick: new Date().toISOString(),
    };
  }

  getState(): PlantState { return this.state; }

  // Track which machines were critical at last tick so we only fire the
  // cross-agent cascade on transition (not every tick of an already-critical
  // machine). Without this the scenario would re-fire every 10s for the
  // same asset.
  private wasCritical = new Set<string>();

  start(ms = 10000): void {
    if (this.timer) return;
    // Register faults for machines already in critical state from CSV data
    // Ensures Semantic Layer shows blocked recs from first page load
    for (const m of this.state.machines) {
      if ((m as any).health < this.thresholds.healthCritical && (m as any).status === 'critical') {
        semanticLayer.registerFault('CR-001', (m as any).id);
        logger.info(`[SIM] Initial fault registered for ${(m as any).id} (health ${(m as any).health})`);
        // Fire the cross-agent cascade for already-critical machines.
        // Without this, Plant 1 (where MCH-03 starts critical from CSV) never
        // produces cross-agent events until something else triggers them.
        // Async-fire; we don't await because start() must be synchronous.
        triggerDegradationScenario(
          (m as any).id, (m as any).name, (m as any).rul, (m as any).health
        ).catch(err => logger.error('[SIM] Initial scenario failed', { err }));
        this.wasCritical.add((m as any).id);
      }
    }
    // ── Recover orphan safety event IDs from previous session ──────────────
    // If the container restarted mid-spike, _activeSafetyEventId is lost but
    // the DB row still has resolved_at = NULL. Re-attach it so the falling
    // edge (tickSafety when !anomaly) can call resolveSafetyEventInDB.
    // Only recover events newer than 4h (the auto-close migration handles older ones).
    try {
      const db = require('../database/connection').getDb();
      const recentCutoff = Date.now() - 4 * 60 * 60 * 1000;
      const orphansRaw = db.prepare(
        `SELECT id, zone FROM safety_events WHERE resolved_at IS NULL AND ts > ? ORDER BY ts DESC`
      ).all(recentCutoff) as Array<{ id: string; zone: string }> | undefined | null;
      // Defensive: depending on the DB adapter, .all() may return undefined/null
      // instead of [] when there are no rows — guard so the for…of below never
      // throws "orphans is not iterable". Real errors still surface via catch.
      const orphans = Array.isArray(orphansRaw) ? orphansRaw : [];
      // Keep only the most-recent orphan per zone (latest spike for that zone)
      const seen = new Set<string>();
      for (const row of orphans) {
        if (!seen.has(row.zone)) {
          seen.add(row.zone);
          const z = this.state.safetyZones.find((z: SafetyZoneSim) => z.zone === row.zone);
          if (z && !z._activeSafetyEventId) {
            z._activeSafetyEventId = row.id;
            z._spiking = true;   // mark as spiking so falling edge resolves it
            logger.info(`[SIM] Recovered orphan safety event ${row.id} for ${row.zone}`);
          }
        }
      }
      if (seen.size > 0) logger.info(`[SIM] Safety event recovery: ${seen.size} zone(s) re-attached`);
    } catch (e) {
      logger.warn('[SIM] Safety event orphan recovery failed', { error: String(e) });
    }

    this.timer = setInterval(() => { void this.tick(); }, ms);
    logger.info(`[SIM] Simulation engine started — tick every ${ms}ms`);
    // Fire one heartbeat for each plant immediately so the Insights panel
    // has visible cross-agent activity from second one, not after the first
    // tick interval. Otherwise users switching to Plant 2 in the first 30s
    // see an empty panel.
    setTimeout(() => this.tickHeartbeat(), 200);
  }

  stop(): void { if (this.timer) { clearInterval(this.timer); this.timer = null; } }

  private n(s = 1): number { return (Math.random() - 0.5) * 2 * s; }
  private cl(v: number, a: number, b: number): number { return Math.max(a, Math.min(b, v)); }

  private _ticking = false;
  // Overlap guard: on Postgres a tick's writes are real async round-trips. If a
  // tick is still flushing when the next interval fires, skip rather than pile up.
  private async tick(): Promise<void> {
    if (this._ticking) return;
    this._ticking = true;
    try { await this.tickBody(); }
    catch (err) { logger.warn('[SIM] tick error', { error: String(err) }); }
    finally { this._ticking = false; }
  }

  private async tickBody(): Promise<void> {
    const st = this.state;
    st.tickCount++;
    st.lastTick = new Date().toISOString();
    this.tickMachines();
    this.tickUtilities();
    this.tickBatch();
    this.tickYieldParams();
    this.tickEnergy();
    await this.tickSafety();
    // Periodic cross-agent heartbeat — fires every 3 ticks (~30s).
    // Emits ONE event per plant on each beat so both panels stay populated
    // independently. Without this, the Insights panel went silent after the
    // seed-critical machines completed their maintenance cycle.
    if (st.tickCount % this.thresholds.heartbeatIntervalTicks === 0) this.tickHeartbeat();
    st.plantOEE = +(st.machines.reduce((a,m)=>a+m.oee,0)/st.machines.length).toFixed(1);
    // KPI engine: compute + persist every 75 ticks (~5 min). Was imported but never
    // invoked — found during Issue 2/4 regression (entire pipeline was dead).
    if (st.tickCount % 75 === 1) {
      try {
        // Portfolio aggregate (gated by KPI_WRITE_INTERVAL_MS dedup)
        await persistKPIs(computeKPIs(), null);
        // Per-plant rows — CSV-driven topology so adding a third plant requires no code change
        const { getTopology } = require('../data/plant');
        for (const code of getTopology().plantCodes) {
          await persistKPIs(computeKPIs(code), code);
        }
      } catch { /* KPI persistence must never break the sim */ }
    }
    // Round machine values before broadcast to avoid excessive decimals in UI
    const roundedMachines = st.machines.map(m => ({
      ...m,
      oee:   +Number(m.oee).toFixed(1),
      avail: +Number(m.avail).toFixed(1),
      perf:  +Number(m.perf).toFixed(1),
      qual:  +Number(m.qual).toFixed(1),
      health: +Number(m.health).toFixed(1),
      rul:    Math.round(Number(m.rul)),
      lossMin: Math.round(Number(m.lossMin ?? 0)),
      temp:   Math.round(Number(m.temp ?? 0)),
    }));
    broadcast('oee', {
      type:'live', machines:roundedMachines,
      // Utilities travel with the oee tick so the live fleet-critical badge can
      // union them with machines; plantOEE still reflects machines only.
      utilities: st.utilities.map(u => ({
        id:u.id, name:u.name, health:Math.round(u.health),
        rul:Math.round(u.rul), status:u.status, plant:u.plant,
      })),
      plantOEE:+st.plantOEE.toFixed(1),
      source_mode:'Synthetic', ts:st.lastTick,
    });
    // Broadcast all agent channels so every dashboard receives live updates
    broadcast('quality', {
      type:'live', zones:st.safetyZones, defectRate:+(100 - (st.machines.reduce((s,m)=>s+m.qual,0)/st.machines.length)).toFixed(2),
      source_mode:'Synthetic', ts:st.lastTick,
    });
    broadcast('supply', {
      type:'live', energyKw:st.energyKw, batch:st.batch,
      source_mode:'Synthetic', ts:st.lastTick,
    });
    broadcast('twin', {
      type:'live', machines:st.machines, plantOEE:st.plantOEE,
      source_mode:'Synthetic', ts:st.lastTick,
    });
    broadcast('safety', {
      type:'live', zones:st.safetyZones,
      source_mode:'Synthetic', ts:st.lastTick,
    });
    await writeStateToDB(st);
  }

  // ── Machines ─────────────────────────────────────────────────────────────────

  private tickMachines(): void {
    for (const m of this.state.machines) {
      // Capture each asset's seed rul:health ratio once, so RUL can be derived from
      // live health every tick and never contradicts it. Previously health and RUL
      // decayed independently (and maintenance reset RUL at random), producing states
      // like MCH-06 @ 19.7% health but 76-day RUL.
      if (m._rulK == null) m._rulK = m.rul / Math.max(1, m.health);
      if (m._inMaintenance) {
        m._maintenanceTicksLeft--;
        if (m._maintenanceTicksLeft <= 0) {
          m._inMaintenance = false;
          m.health = this.cl(m.health + 35 + this.n(5), this.thresholds.healthRecoveryMin, this.thresholds.healthRecoveryMax);
          m.rul    = this.cl(Math.round(m.health * (m._rulK ?? 1)), 1, 200); // RUL follows restored health
          m.vib    = +(1.0 + Math.random() * 1.5).toFixed(1);
          m.temp   = Math.floor(45 + Math.random() * 15);
          // Pressure resets to ~nominal for the asset class. Keep within sane band.
          m.pressure = +(this.cl(m.pressure * 0.98 + this.n(0.3), 3, 95)).toFixed(1);
          m.qual   = this.cl(95 + this.n(2), 94, 99.5);
          m.avail  = this.cl(85 + this.n(3), 80, 98);
          m.perf   = this.cl(85 + this.n(3), 80, 96);
          m.lossMin= Math.floor(10 + Math.random() * 30);
          this.updateStatus(m);
          this.fireEv('pdm','oee','MAINTENANCE_COMPLETE',
            `${m.name} maintenance complete. Health restored to ${m.health.toFixed(0)}%.`,
            `OEE recovery +${(5+Math.random()*4).toFixed(1)}%`,m.id,'info');
          semanticLayer.resolveFault('CR-001', m.id);
        }
        continue;
      }
      m.health = this.cl(m.health - m._degradeRate + this.n(0.05), 5, 99);
      m.rul    = this.cl(Math.round(m.health * (m._rulK ?? 1)), 1, 200); // RUL derived from health — stays consistent
      m.vib    = this.cl(m.vib    + m._degradeRate * 0.03 + this.n(0.08), 0.3, 15);
      m.temp   = this.cl(m.temp   + m._degradeRate * 0.05 + this.n(0.5), 35, 105);
      // Pressure drifts up as condition degrades (worn seals, fouling). Small noise
      // keeps the live tile visibly ticking. Clamped within sane operating band.
      m.pressure = +(this.cl(m.pressure + m._degradeRate * 0.02 + this.n(0.15), 3, 95)).toFixed(1);
      const hf = m.health / 100;
      m.avail  = this.cl(m.avail * (0.9998 + hf * 0.0002) + this.n(0.1), 40, 99.9);
      m.perf   = this.cl(m.perf  * (0.9998 + hf * 0.0002) + this.n(0.1), 40, 99.9);
      m.qual   = this.cl(m.qual  * 0.9999 + this.n(0.08), 94, 99.9);
      m.oee    = +(m.avail * m.perf * m.qual / 10000).toFixed(1);
      m.lossMin = Math.floor(this.cl(m.lossMin + (1-hf)*0.5 + this.n(0.3), 0, 300));
      this.updateStatus(m);

      if (m.health < this.thresholds.healthMaintenance && !m._inMaintenance) {
        m._inMaintenance = true;
        m._maintenanceTicksLeft = Math.floor(30 + Math.random() * 20);
        this.fireEv('pdm','oee','MAINTENANCE_STARTED',
          `Auto-maintenance triggered: ${m.name}. Health ${m.health.toFixed(0)}%. WO auto-raised.`,
          'Production halted for maintenance window', m.id, 'warning');
        semanticLayer.registerFault('CR-001', m.id);
        logger.info(`[SIM] ${m.id} maintenance triggered`);
      }

      // Fire the full cross-agent cascade on transition to critical state.
      // This is what generates the 8-step cross-agent event sequence visible
      // in the right-panel Insights feed. Without this hook, the scenario
      // engine was dead code (imported but never invoked).
      const isCritNow = m.status === 'critical' && m.health < this.thresholds.healthRecoveryMin;
      const wasCrit = this.wasCritical.has(m.id);
      if (isCritNow && !wasCrit) {
        this.wasCritical.add(m.id);
        // Also register the CR-001 fault so getActiveBlocks() Source 1 picks it
        // up explicitly (rather than only via the Source 2 fallback path).
        // This makes the counter increment in lockstep with the visible blocks.
        semanticLayer.registerFault('CR-001', m.id);
        triggerDegradationScenario(m.id, m.name, Math.round(m.rul), m.health)
          .catch(err => logger.error('[SIM] Scenario trigger failed', { err, asset: m.id }));
        logger.info(`[SIM] ${m.id} crossed into critical — cross-agent cascade firing`);
      } else if (!isCritNow && wasCrit) {
        // Asset recovered (health rose above critical threshold)
        this.wasCritical.delete(m.id);
      }
    }
  }

  private updateStatus(m: MachineSim): void {
    m.status = m.health >= 80 ? 'good' : m.health >= 65 ? 'caution' : m.health >= 40 ? 'warning' : 'critical';
    m.loss = m.avail < 80 ? 'Unplanned Breakdown' : m.perf < 85 ? 'Speed Loss' : m.qual < 96 ? 'In-process Defects' : 'Minor Stops';
          m.lossMin= Math.max(0, Math.floor((1 - m.oee/100) * 30 + this.n(2)));
  }

  // ── Utilities ─────────────────────────────────────────────────────────────────

  private tickUtilities(): void {
    for (const u of this.state.utilities) {
      if (u._rulK == null) u._rulK = u.rul / Math.max(1, u.health); // seed ratio, once
      u.health = this.cl(u.health - u._degradeRate + this.n(0.05), 5, 99);
      u.rul    = this.cl(Math.round(u.health * (u._rulK ?? 1)), 1, 200); // RUL follows health
      u.vib    = this.cl(u.vib    + u._degradeRate * 0.02 + this.n(0.06), 0.3, 12);
      u.temp   = this.cl(u.temp   + u._degradeRate * 0.04 + this.n(0.4), 10, 110);
      u.status = u.health >= 75 ? 'good' : u.health >= 55 ? 'caution' : u.health >= 35 ? 'warning' : 'critical';
      if (u.health < 15) { u.health = this.cl(u.health + 30, 15, 70); u.rul = this.cl(Math.round(u.health * (u._rulK ?? 1)), 1, 200); }
    }
  }

  // ── Batch ─────────────────────────────────────────────────────────────────────

  private tickBatch(): void {
    const b = this.state.batch;
    if (b.status !== 'in_process') return;
    const progress = this.cl((Date.now() - b.startedAt) / b.durationMs, 0, 1);
    b.actual = +(b.plan * (0.96 + progress * 0.06) + this.n(0.3)).toFixed(1);
    if (progress >= 1) {
      b.status = 'completed';
      this.fireEv('yield','oee','BATCH_COMPLETED',
        `Batch ${b.id} complete. Yield ${b.actual}% vs plan ${b.plan}%.`,
        `${(b.actual??0) >= b.plan ? '+' : ''}${((b.actual??0) - b.plan).toFixed(1)}% vs plan`, b.id,'info');
      setTimeout(() => {
        const products = ['Compound X-12 Grade A','Compound Y-07 Grade B','Compound Z-04 Grade S'];
        this.state.batch = {
          id:`PP-${88414+this.state.tickCount}`,
          product:products[Math.floor(Math.random()*3)],
          qty:[900,1800,2400][Math.floor(Math.random()*3)],
          plan:+(87+Math.random()*4).toFixed(1), actual:null, status:'in_process',
          startedAt:Date.now(), durationMs:(6+Math.floor(Math.random()*4))*3600000,
        };
        logger.info(`[SIM] New batch: ${this.state.batch.id}`);
      }, 4500);
    }
  }

  // ── Yield params ──────────────────────────────────────────────────────────────

  private tickYieldParams(): void {
    // Live Process Parameters are held at their steady-state values — no random walk.
    // Previously each tick applied a random drift + noise (this.n) plus random
    // direction flips, which made the DCS "Live Process Parameters" panel jitter with
    // random numbers on every sim tick. Real PI process readings at steady state are
    // stable, and the panel's value comes from the semantic-layer BLOCKED story
    // (deterministic) and the seeded offsets — not from randomised numbers. So we keep
    // each param at its seeded value and only recompute warn/blocked deterministically.
    for (const p of this.state.yieldParams) {
      p.warn = Math.abs(p.val - p.tgt) / (p.max - p.min) > 0.06;
    }
    // Enrich params with semantic conflict status + plant before broadcasting
    // This ensures liveParams in UI always has accurate blocked+plant fields
    const enriched = this.state.yieldParams.map((p: YieldParamSim) => {
      const conflict = semanticLayer.checkConflict({ agent:'yield', type:'dcs_write', tagId:p.id });
      return { ...p, blocked: conflict.blocked, blockedReason: conflict.reason };
    });
    broadcast('yield', { type:'params', params: enriched });
  }

  // ── Energy ────────────────────────────────────────────────────────────────────

  private tickEnergy(): void {
    const h = new Date().getHours();
    this.state.energyKw = +(1520 * DEMAND_CURVE[h] + this.n(30)).toFixed(0);
    for (const a of this.state.energyAssets) {
      a.kw = +(a._baseKw * DEMAND_CURVE[h] + this.n(a._baseKw * 0.05)).toFixed(0);
      a.anomaly = a.kw > a._baseKw * 1.12;
    }
    // Update the rolling trend for current hour slot.
    // In DB mode the CSV-seeded trend may be empty, so ensure the slot exists
    // before writing to it (guards against 'Cannot set properties of undefined').
    const slot = Math.floor(h / 2);
    if (!this.state.energyTrend[slot]) {
      this.state.energyTrend[slot] = { h: `${slot * 2}:00`, kw: this.state.energyKw };
    }
    this.state.energyTrend[slot].kw = this.state.energyKw;
    broadcast('energy', { type:'load', kw:this.state.energyKw, assets:this.state.energyAssets });
  }

  // ── Safety ────────────────────────────────────────────────────────────────────

  private async tickSafety(): Promise<void> {
    // Consumer of the IoT Hub gas stream. Phase 1: readings come from the
    // connector's mock generator; Phase A: identical reads, but the gas_ppm
    // readings arrive from real detectors via Azure IoT Hub (IOT_HUB_CONNECTION_
    // STRING set). The detection + Semantic-Layer cascade below is the SAME in
    // both — only the reading SOURCE changes. This mirrors how every other sensor
    // (vibration/temp/pressure) already flows through iot-hub.ts.
    for (const z of this.state.safetyZones) {
      const r = iotGetLatest(z.zone, 'gas_ppm') as (SensorReading & { co?: number; ch4?: number }) | null;
      if (r) {
        z.h2s = r.value;
        if (typeof r.co  === 'number') z.co  = r.co;
        if (typeof r.ch4 === 'number') z.ch4 = r.ch4;
      }
      const anomaly = r?.anomaly ?? false;
      if (anomaly && !z._spiking) {
        // Rising edge — gas precursor detected → fire event + block hot-work.
        z._spiking = true;
        this.fireEv('safety','oee','GAS_PRECURSOR_DETECTED',
          `Gas precursor in ${z.zone}. H\u2082S: ${z.h2s.toFixed(1)} ppm. Investigate immediately.`,
          'Hot-work permits auto-blocked', z.zone, 'critical');
        semanticLayer.registerFault('CR-002', z.zone, z.zone);
        semanticLayer.registerFault('CR-003', z.zone, z.zone);
        try {
          const seId = `SE-${Date.now()}-${z.zone.replace(/\s/g,'')}`;
          z._activeSafetyEventId = seId;
          await writeSafetyEventToDB({
            id: seId, zone: z.zone, type: 'GAS_PRECURSOR_DETECTED', severity: 'critical',
            h2s: +z.h2s.toFixed(1), co: +z.co.toFixed(1), ch4: +z.ch4.toFixed(1), ts: Date.now(),
          });
        } catch { /* persistence must never break the sim */ }
        logger.warn(`[SIM] Gas precursor detected in ${z.zone}`);
      } else if (!anomaly && z._spiking) {
        // Falling edge — readings normalised → clear the alert + unblock.
        z._spiking = false;
        this.fireEv('safety','oee','GAS_PRECURSOR_CLEARING',
          `${z.zone} gas readings normalising. Evacuation alert can be lifted.`,
          'Resume work after zone certification', z.zone, 'warning');
        if (z._activeSafetyEventId) { await resolveSafetyEventInDB(z._activeSafetyEventId); z._activeSafetyEventId = undefined; }
        semanticLayer.resolveFault('CR-002', z.zone);
        semanticLayer.resolveFault('CR-003', z.zone);
      }
    }
  }

  // ── Event helper ──────────────────────────────────────────────────────────────

  // Per-plant heartbeat counter so each plant rotates through the variety pool
  // independently. Plant codes are discovered from CSV — adding a new plant in
  // machines.csv automatically gets its own counter and heartbeat events.
  private heartbeatIdxByPlant: Map<string, number> = new Map();

  private tickHeartbeat(): void {
    // Fire one event for EACH discovered plant on every heartbeat tick.
    // Both plant viewers see fresh cross-agent activity every ~30 seconds.
    for (const code of getPlantCodes()) {
      this.emitHeartbeatForPlant(code);
    }
  }

  private emitHeartbeatForPlant(plant: string): void {
    // Pick an asset that exists in the chosen plant
    const machines = this.state.machines.filter((m: any) => m.plant === plant);
    if (!machines.length) return;
    const idx = (this.heartbeatIdxByPlant.get(plant) ?? 0);
    this.heartbeatIdxByPlant.set(plant, idx + 1);
    const machine: any = machines[idx % machines.length];

    // Derive plant-specific narrative bits from CSV-loaded state (not hardcoded).
    // - tempSource: first yield param name for this plant (e.g. 'Reactor Temp', 'Jacket Temp')
    // - loadAsset: first utility / non-machine asset name in this plant
    const tempParam = (this.state.yieldParams as any[]).find(
      (p: any) => (p.plant === plant) && /temp/i.test(String(p.name ?? ''))
    );
    const tempSource = tempParam?.name ?? `${plant} primary`;
    const utilityHere = (this.state.utilities as any[]).find((u: any) => u.plant === plant);
    const loadAsset = utilityHere?.name ?? machine.name;

    // Pool of realistic routine cross-agent exchanges. Picked round-robin so the
    // panel shows variety, not the same message repeating.
    const beats = [
      { from:'pdm',    to:'oee',    type:'HEALTH_SAMPLE',
        msg:`${machine.name} health sample: ${Number(machine.health).toFixed(0)}% (vibration ${Number(machine.vib).toFixed(1)} mm/s)`,
        impact:`RUL ${Math.round(machine.rul)}d`, sev:'info' as const },
      { from:'yield',  to:'oee',    type:'PI_TAG_READ',
        msg:`OSIsoft PI tag read complete — ${tempSource} within ±0.5°C of target`,
        impact:'no drift', sev:'info' as const },
      { from:'supply', to:'pdm',    type:'LEAD_TIME_CHECK',
        msg:`D&B Paydex refresh — spare-parts lead time check for ${machine.name}: within contracted window`,
        impact:'on-plan', sev:'info' as const },
      { from:'energy', to:'oee',    type:'TARIFF_SAMPLE',
        msg:`Grid tariff sample — ${new Date().getHours() >= 18 && new Date().getHours() < 22 ? 'PEAK window active' : 'off-peak'}; ${loadAsset} load nominal`,
        impact:`${Math.round(machine.health > 80 ? -2 : 1)}% ENPI`, sev:'info' as const },
      { from:'twin',   to:'pdm',    type:'DIVERGENCE_CHECK',
        msg:`Digital twin sync — ${machine.name} model vs sensor delta within 2% tolerance`,
        impact:'no drift', sev:'info' as const },
      { from:'quality',to:'yield',  type:'INSPECTION_SAMPLE',
        msg:`Quality vision check — ${machine.line} batch sample: ${Number(machine.qual).toFixed(1)}% pass rate`,
        impact:`${machine.qual >= 98 ? 'on-target' : 'below target'}`, sev:'info' as const },
    ];
    const beat = beats[idx % beats.length];
    this.fireEv(beat.from, beat.to, beat.type, beat.msg, beat.impact, machine.id, beat.sev);
  }

  private fireEv(from:string,to:string,type:string,msg:string,impact:string,asset:string,sev:'critical'|'warning'|'info'): void {
    // Resolve line_id for asset from machine state
    const m = this.state.machines.find(m => m.id === asset)
           || this.state.utilities.find(u => u.id === asset);
    const ev = {
      id:          `XEV-${this.evtCounter++}`,
      from, to, type, sev, msg, impact,
      asset,
      asset_id:    asset,
      // Plant resolution order:
      //   1. machine/utility row from current sim state (already loaded from CSV)
      //   2. CSV-derived topology lookup (machines / utilities / zones)
      //   3. safe default 'P1'
      // Note: previous code used asset?.startsWith('Zone C') etc. — that worked
      // only for two specific zone names. The topology helper handles any zone
      // defined in safety_zones.csv automatically.
      plant_id:    (m as any)?.plant ?? resolvePlantFromAny(asset) ?? 'P1',
      line_id:     (m as any)?.line ?? null,
      scenario_id: null,
      source_mode: 'Synthetic' as const,
      ts:          new Date().toISOString(),
    };
    void semanticLayer.publishEvent(ev as any);
    // publishEvent handles persistence + WebSocket — no duplicate broadcastEvent
  }
}

export const simulationEngine = new SimulationEngine();
export function getPlantState(): PlantState { return simulationEngine.getState(); }
