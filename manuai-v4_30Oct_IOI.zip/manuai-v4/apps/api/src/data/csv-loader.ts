/**
 * ManuAI — CSV Data Loader
 *
 * Reads all CSV files from data/csv/ and returns typed objects.
 * Every connector and route that needs seed data calls this loader.
 *
 * HOW TO SWAP TO REAL DATA:
 * --------------------------
 * Each function below has a comment: // REPLACE WITH: <connector>
 * When you're ready, delete the CSV read and replace with the connector call.
 * Nothing else in the codebase needs to change.
 *
 * EDITING MOCK DATA:
 * ------------------
 * Open any file in data/csv/ in Excel, edit values, save as CSV.
 * Restart the API — changes take effect immediately.
 */

import fs from 'fs';
import path from 'path';
import { logger } from '../middleware/logger';

// ── CSV path resolver ─────────────────────────────────────────────────────────
const CSV_DIR = process.env.CSV_DATA_DIR
  ?? path.resolve(__dirname, '../../../../data/csv');

function csvPath(filename: string): string {
  return path.join(CSV_DIR, filename);
}

// ── Generic CSV parser (no external dependency) ───────────────────────────────
function parseCSV(filename: string): Record<string, string>[] {
  const fullPath = csvPath(filename);
  if (!fs.existsSync(fullPath)) {
    logger.warn(`CSV not found: ${fullPath}`);
    return [];
  }
  const raw = fs.readFileSync(fullPath, 'utf-8');
  const lines = raw.trim().split('\n').filter(l => l.trim());
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.trim());
  return lines.slice(1).map(line => {
    // Handle commas inside quoted fields
    const values: string[] = [];
    let current = '';
    let inQuotes = false;
    for (const ch of line) {
      if (ch === '"') { inQuotes = !inQuotes; continue; }
      if (ch === ',' && !inQuotes) { values.push(current.trim()); current = ''; continue; }
      current += ch;
    }
    values.push(current.trim());
    return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
  });
}

function num(v: string | undefined, fallback = 0): number {
  const n = parseFloat(v ?? '');
  return isNaN(n) ? fallback : n;
}
function bool(v: string | undefined): boolean {
  return (v ?? '').toLowerCase() === 'true';
}
// Alias used by appended loader functions
const loadCsv = parseCSV;
// Raw row accessor for config sections (Issue 9/13 fix)
export const loadCsvRaw = parseCSV;


// ── Loaders ───────────────────────────────────────────────────────────────────

export function loadMachines() {
  // REPLACE WITH: PI Historian getTagsBatch() + SAP MES data
  return parseCSV('machines.csv').map(r => ({
    id:          r.id,
    name:        r.name,
    line:        r.line,
    plant:       r.plant,
    oee:         num(r.oee),
    avail:       num(r.avail),
    perf:        num(r.perf),
    qual:        num(r.qual),
    health:      num(r.health),
    rul:         num(r.rul),
    status:      r.status as 'good' | 'caution' | 'warning' | 'critical',
    loss:        r.loss,
    lossMin:     num(r.loss_min),
    vib:         num(r.vib),
    temp:        num(r.temp),
    pressure:    num(r.pressure, 0),
    _degradeRate:num(r.degrade_rate, 0.05),
    _inMaintenance: false,
    _maintenanceTicksLeft: 0,
  }));
}

export function loadUtilities() {
  // REPLACE WITH: PI Historian + IoT Hub sensor readings
  return parseCSV('utilities.csv').map(r => ({
    id:          r.id,
    name:        r.name,
    health:      num(r.health),
    rul:         num(r.rul),
    status:      r.status,
    vib:         num(r.vib),
    temp:        num(r.temp),
    press:       num(r.pressure),
    oeeLink:     r.oee_link || null,
    plant:       r.plant || 'P1',
    _degradeRate:num(r.degrade_rate, 0.05),
  }));
}

export function loadYieldParams() {
  // REPLACE WITH: PI Historian getTagsBatch() for process tags
  return parseCSV('yield_params.csv').map(r => ({
    id:           r.id,
    name:         r.name,
    unit:         r.unit,
    val:          num(r.value),
    tgt:          num(r.target),
    min:          num(r.min),
    max:          num(r.max),
    warn:         Math.abs(num(r.value) - num(r.target)) / (num(r.max) - num(r.min)) > 0.06,
    blocked:      false,
    plant:        r.plant || 'P1',
    _driftRate:   num(r.drift_rate, 0.05),
    _driftDir:    (num(r.drift_direction, 1) >= 0 ? 1 : -1) as 1 | -1,
    // Per-param warn band as fraction of target. Falls back to platform_config
    // yield.warn_threshold_pct_default if empty in CSV. Phase 2 will replace
    // with statistical control limits from PI historian.
    warnThresholdPct: r.warn_threshold_pct ? num(r.warn_threshold_pct) : null,
  }));
}

/**
 * Tag mapping registry — maps internal param IDs to vendor-specific
 * PI Web API tag paths and OPC-UA node IDs. Was previously hardcoded as
 * a synthesized pattern in yield.ts; externalizing here makes plant-by-plant
 * commissioning a config exercise rather than a code change.
 *
 * REPLACE WITH: PI AF / OPC-UA tag registry service in Phase 3
 */
export function loadTagMappings(): Map<string, { piTag: string; opcNodeId: string; plant: string; description?: string }> {
  const map = new Map<string, { piTag: string; opcNodeId: string; plant: string; description?: string }>();
  try {
    for (const r of parseCSV('tag_mappings.csv')) {
      if (!r.param_id) continue;
      map.set(r.param_id, {
        piTag:       r.pi_tag,
        opcNodeId:   r.opc_node_id,
        plant:       r.plant || 'P1',
        description: r.description,
      });
    }
  } catch (e) { /* fallback path applies when CSV missing */ }
  return map;
}

export function loadProductionOrders() {
  // REPLACE WITH: SAP OData getProductionOrders()
  return parseCSV('production_orders.csv').map(r => ({
    id:       r.id,
    product:  r.product,
    qty:      `${r.qty_kg} kg`,
    plan:     num(r.plan_yield),
    actual:   r.actual_yield ? num(r.actual_yield) : null,
    status:   r.status,
    start:    r.start_date,
    end:      r.end_date,
    plant:    r.plant || 'P1',
  }));
}

export function loadLimsResults() {
  // REPLACE WITH: LIMS connector getTodayResults()
  return parseCSV('lims_results.csv').map(r => ({
    id:       r.id,
    batch:    r.batch,
    test:     r.test,
    result:   r.result,
    limit:    r.limit,
    status:   r.status as 'pass' | 'fail',
    analyst:  r.analyst,
    time:     r.time,
    plant:    r.plant || 'P1',
  }));
}

export function loadWorkOrders() {
  // REPLACE WITH: SAP PM getMaintenanceOrders()
  return parseCSV('work_orders.csv').map(r => ({
    id:          r.id,
    asset:       r.asset_id,
    name:        r.asset_name,
    type:        r.type,
    pri:         r.priority,
    desc:        r.description,
    status:      r.status,
    assigned:    r.assigned_to,
    oeeLink:     bool(r.oee_link),
    // New: enables per-plant filtering + Avg Response KPI on Shift Schedule
    plant:       r.plant || null,
    created_at:  r.created_at || null,
    closed_at:   r.closed_at  || null,
    // SAP PM order metadata — surfaced in the WO expanded view. Was previously
    // synthesized in the frontend (`PM01 Preventive` / `MNT-OEE` etc). Now sourced
    // from real CSV columns so an integrator can map these 1:1 to SAP fields.
    sapOrderType:       r.sap_order_type || null,
    plannerGroup:       r.planner_group || null,
    workCentre:         r.work_centre || null,
    functionalLocation: r.functional_location || null,
  }));
}

export function loadSupplyRisks() {
  // REPLACE WITH: SAP MM getMaterialStock() + D&B API for financial scores
  return parseCSV('supply_risks.csv').map(r => ({
    supplier_id:                r.supplier_id,
    supplier_name:              r.supplier_name,
    sku:                        r.sku,
    description:                r.description,
    current_stock_days:         num(r.current_stock_days),
    reorder_point_days:         num(r.reorder_point_days),
    lead_time_contracted_days:  num(r.lead_time_contracted_days),
    lead_time_actual_days:      num(r.lead_time_actual_days),
    monthly_consumption:        num(r.monthly_consumption),
    unit_cost_inr:              num(r.unit_cost_inr),
    single_source:              bool(r.single_source),
    country_of_origin:          r.country_of_origin,
    financial_risk_score:       num(r.financial_risk_score),
    plant:                      r.plant || 'Both',
  }));
}

// ── Supply-chain governance data layer (Increment 1 entities) ──────────────
// All follow the existing loadX(parseCSV) pattern. REPLACE WITH real ERP/SAP/
// supplier/logistics APIs in Phase A — the selector layer is the seam.
export function loadSuppliers() {
  return parseCSV('suppliers.csv').map(r => ({
    supplier_id: r.supplier_id, supplier_name: r.supplier_name,
    supplier_region: r.supplier_region, supplier_country: r.supplier_country,
    credit_rating: r.credit_rating, payment_terms: r.payment_terms,
    risk_score: num(r.risk_score), risk_level: r.risk_level,
    financial_status: r.financial_status, primary_contact: r.primary_contact,
    is_active: bool(r.is_active),
  }));
}
export function loadSupplierPlantMap() {
  return parseCSV('supplier_plant_map.csv').map(r => ({
    supplier_id: r.supplier_id, plant_id: r.plant_id, relationship_type: r.relationship_type,
    monthly_exposure: num(r.monthly_exposure), ytd_order_value: num(r.ytd_order_value),
    mtd_order_value: num(r.mtd_order_value), supplier_status: r.supplier_status,
  }));
}
export function loadSkus() {
  return parseCSV('skus.csv').map(r => ({
    sku_id: r.sku_id, sku_code: r.sku_code, sku_name: r.sku_name, category: r.category,
    unit_of_measure: r.unit_of_measure, criticality: r.criticality, plant_id: r.plant_id,
    preferred_supplier_id: r.preferred_supplier_id, alternate_supplier_id: r.alternate_supplier_id || null,
  }));
}
export function loadInventoryPositions() {
  return parseCSV('inventory_positions.csv').map(r => ({
    inventory_id: r.inventory_id, plant_id: r.plant_id, sku_id: r.sku_id, supplier_id: r.supplier_id,
    current_stock_days: num(r.current_stock_days), reorder_point_days: num(r.reorder_point_days),
    safety_stock_days: num(r.safety_stock_days), monthly_consumption: num(r.monthly_consumption),
    current_inventory_cost: num(r.current_inventory_cost), baseline_inventory_cost: num(r.baseline_inventory_cost),
    last_updated_date: r.last_updated_date,
  }));
}
export function loadExternalRiskAlerts() {
  return parseCSV('external_risk_alerts.csv').map(r => ({
    alert_id: r.alert_id, plant_id: r.plant_id, supplier_id: r.supplier_id, sku_id: r.sku_id,
    alert_type: r.alert_type, severity: r.severity, region: r.region, source: r.source,
    description: r.description, recommended_action: r.recommended_action,
    alert_date: r.alert_date, status: r.status,
  }));
}
// ── Supplier-detail popup data (lead-time history, risk factors, perf) ──────
// Synthetic but data-layer-resident, P1/P2 only. REPLACE WITH: PI/SAP PM WO
// history + supplier scorecard APIs in Phase A.
export function loadSupplierLeadTimeHistory() {
  return parseCSV('supplier_lead_time_history.csv').map(r => {
    const lead = num(r.lead_time_days), sla = num(r.sla_lead_time_days);
    return {
      record_id: r.record_id, supplier_id: r.supplier_id, sku_id: r.sku_id, plant_id: r.plant_id,
      week: r.week, lead_time_days: lead, sla_lead_time_days: sla,
      drift_days: lead - sla,   // derived, not stored
    };
  });
}
export function loadSupplierRiskFactors() {
  return parseCSV('supplier_risk_factors.csv').map(r => ({
    factor_id: r.factor_id, supplier_id: r.supplier_id, sku_id: r.sku_id, plant_id: r.plant_id,
    factor_type: r.factor_type, factor_description: r.factor_description,
    severity: r.severity, created_date: r.created_date,
  }));
}
export function loadSupplierPerformanceMetrics() {
  return parseCSV('supplier_performance_metrics.csv').map(r => ({
    metric_id: r.metric_id, supplier_id: r.supplier_id, sku_id: r.sku_id, plant_id: r.plant_id,
    metric_name: r.metric_name, metric_value: r.metric_value, metric_unit: r.metric_unit,
    period: r.period, trend_direction: r.trend_direction,
  }));
}
export function loadReorderRules() {
  return parseCSV('reorder_rules.csv').map(r => ({
    rule_id: r.rule_id, rule_name: r.rule_name, category: r.category, description: r.description,
    conditions: r.conditions, approval_mode: r.approval_mode, enabled: bool(r.enabled),
    plant_scope: r.plant_scope, created_date: r.created_date,
    last_triggered_date: r.last_triggered_date || null, trigger_count: num(r.trigger_count),
  }));
}
export function loadReorderRequests() {
  return parseCSV('reorder_requests.csv').map(r => ({
    request_id: r.request_id, plant_id: r.plant_id, sku_id: r.sku_id, supplier_id: r.supplier_id,
    requested_qty: num(r.requested_qty), requested_value: num(r.requested_value),
    requested_date: r.requested_date, trigger_reason: r.trigger_reason, approval_reason: r.approval_reason,
    approval_mode: r.approval_mode, triggered_by_rule_id: r.triggered_by_rule_id,
    status: r.status, created_by: r.created_by,
  }));
}
export function loadAutoApprovedOrders() {
  return parseCSV('auto_approved_orders.csv').map(r => ({
    order_id: r.order_id, plant_id: r.plant_id, sku_id: r.sku_id, supplier_id: r.supplier_id,
    approved_qty: num(r.approved_qty), approved_value: num(r.approved_value), approved_date: r.approved_date,
    rule_id: r.rule_id, rule_name: r.rule_name, sap_status: r.sap_status, status: r.status, reason: r.reason,
  }));
}

export function loadEnergyAssets() {
  // REPLACE WITH: Smart meter API / Azure IoT Hub energy telemetry
  return parseCSV('energy_assets.csv').map(r => ({
    id:                     r.id,
    name:                   r.name,
    kw:                     num(r.current_kw),
    anomaly:                false,
    _baseKw:                num(r.rated_kw),
    shiftable:              bool(r.shiftable),
    critical:               bool(r.critical),
    anomalyThresholdPct:    num(r.anomaly_threshold_pct, 12),
    plant:                  r.plant || 'P1',
  }));
}

export function loadEnergyHourly() {
  // REPLACE WITH: Smart meter historical data API
  return parseCSV('energy_hourly.csv').map(r => ({
    h:  r.hour,
    kw: num(r.kw_base),
  }));
}

export function loadSafetyZones() {
  // REPLACE WITH: IoT Hub gas sensor stream
  return parseCSV('safety_zones.csv').map(r => ({
    zone:        r.zone_id,
    h2s:         num(r.h2s_ppm_baseline),
    co:          num(r.co_ppm_baseline),
    ch4:         num(r.ch4_pct_lel_baseline),
    thresholds: {
      h2s: { alarm1: num(r.h2s_alarm1), alarm2: num(r.h2s_alarm2), evac: num(r.h2s_evac) },
      co:  { alarm1: num(r.co_alarm1),  alarm2: num(r.co_alarm2),  evac: num(r.co_evac)  },
      ch4: { alarm1: num(r.ch4_alarm1), alarm2: num(r.ch4_alarm2), evac: num(r.ch4_evac) },
    },
    personnelNormal: num(r.personnel_normal),
    amrEnabled:      bool(r.amr_enabled),
    _spiking:        false,
    plant:           r.plant || 'P1',
  }));
}

export function loadSafetyPermits() {
  // REPLACE WITH: CMMS / PTW system API
  return parseCSV('safety_permits.csv').map(r => ({
    id:                 r.ptw_id,
    asset:              r.asset_id,
    type:               r.work_type,
    tech:               r.technician,
    status:             r.status,
    jha:                bool(r.jha_complete),
    isolation:          bool(r.isolation_verified),
    competency:         bool(r.competency_valid),
    plant:              r.plant || 'P1',
  }));
}

let _qualityDefectsCache: any[] | null = null;
export function loadQualityDefects() {
  if (_qualityDefectsCache) return _qualityDefectsCache;
  _qualityDefectsCache = _loadQualityDefectsImpl();
  return _qualityDefectsCache;
}
function _loadQualityDefectsImpl() {
  // REPLACE WITH: Vision AI service / MES quality module
  return parseCSV('quality_defects.csv').map(r => ({
    id:         r.id,
    time:       r.time,
    line:       r.line,
    component:  r.component,
    type:       r.defect_type,
    severity:   r.severity as 'major' | 'minor' | 'cosmetic',
    action:     r.action,
    confidence: num(r.confidence),
  }));
}

export function loadQualityLines() {
  // REPLACE WITH: Vision AI model status API
  // ── Single source of truth ──
  // `defects_today` and `escapes_today` used to live in quality_lines.csv as
  // hand-typed aggregates, but those values could drift from the actual
  // quality_defects.csv records (the per-defect log). Now we count from the
  // defect log directly so the tile, chart, and defect log can never disagree.
  // What's actually a "line-state" fact (quality_rate_pct, model_version)
  // stays in quality_lines.csv since those aren't derivable from defects.
  const defects = loadQualityDefects() as any[];
  // Tally per-line defects from the log. Lower-cased line name as key to
  // tolerate whitespace / casing inconsistencies between CSVs.
  const tally: Record<string, { defects: number; escapes: number }> = {};
  for (const d of defects) {
    const key = String(d.line ?? '').toLowerCase().trim();
    if (!key) continue;
    if (!tally[key]) tally[key] = { defects: 0, escapes: 0 };
    tally[key].defects++;
    // Escape = a defect that the AI didn't reject (i.e. let through). The
    // dashboard's "escapes" tile counts these. Acceptance + minor without
    // rejection both count as escapes in real MES semantics.
    const action = String(d.action ?? '').toLowerCase();
    if (action === 'accept' || action === 'accepted') tally[key].escapes++;
  }
  return parseCSV('quality_lines.csv').map(r => {
    const key = String(r.line ?? '').toLowerCase().trim();
    const t = tally[key] ?? { defects: 0, escapes: 0 };
    return {
      line:     r.line,
      rate:     num(r.quality_rate_pct),
      defects:  t.defects,
      escapes:  t.escapes,
      model:    r.model_version,
    };
  });
}

export function loadTwinKPIs() {
  // REPLACE WITH: Azure Digital Twins API
  return parseCSV('twin_kpis.csv').map(r => ({
    kpi_id:               r.kpi_id,
    kpi_name:             r.kpi_name,
    unit:                 r.unit,
    actual:               num(r.actual),
    twin_predicted:       num(r.twin_predicted),
    threshold_pct:        num(r.divergence_threshold_pct),
    asset_id:             r.asset_id || null,
    plant:                r.plant || 'Both',
  }));
}

// ── Reload all (call on file-change watch if needed) ──────────────────────────
export function reloadAll() {
  logger.info('[CSV] Reloading all CSV data files');
  return {
    machines:         loadMachines(),
    utilities:        loadUtilities(),
    yieldParams:      loadYieldParams(),
    productionOrders: loadProductionOrders(),
    limsResults:      loadLimsResults(),
    workOrders:       loadWorkOrders(),
    supplyRisks:      loadSupplyRisks(),
    energyAssets:     loadEnergyAssets(),
    energyHourly:     loadEnergyHourly(),
    safetyZones:      loadSafetyZones(),
    safetyPermits:    loadSafetyPermits(),
    qualityDefects:   loadQualityDefects(),
    qualityLines:     loadQualityLines(),
    twinKPIs:         loadTwinKPIs(),
  };
}

export function loadTwinComponents(): Record<string, any[]> {
  const rows = loadCsv('twin_components.csv');
  const result: Record<string, any[]> = {};
  for (const r of rows) {
    if (!result[r.asset_id]) result[r.asset_id] = [];
    result[r.asset_id].push({
      c: r.component,
      h: Number(r.health),
      t: Number(r.temp),
      v: Number(r.vib),
      a: r.alert === 'true',
    });
  }
  return result; // REPLACE WITH: CMMS component registry API
}

export function loadParts(): { orders: any[]; inventory: any[] } {
  const rows = loadCsv('parts.csv');
  const orders = rows.map(r => ({
    id: r.order_id, sku: r.sku, part: r.part_name,
    asset: r.asset_id, qty: Number(r.qty),
    cost: Number(r.unit_cost_inr) * Number(r.qty),
    status: r.status, rules: r.rules,
    rul: Number(r.rul_days), lead: Number(r.lead_days),
  }));
  const inventory = rows.map(r => ({
    sku: r.sku, name: r.part_name, asset: r.asset_id,
    stock: Number(r.stock), reorder: Number(r.reorder_qty),
    lead: Number(r.lead_days), cost: Number(r.unit_cost_inr),
    autoOrder: r.auto_order === 'true',
  }));
  return { orders, inventory }; // REPLACE WITH: ERP/CMMS spare parts API
}

// 6-month parts spend trend (planned vs unplanned) per plant. Used by the
// Parts Spend chart on the PdM Parts Ordering tab. Story: AI-driven PdM cuts
// unplanned spend month-over-month from the Nov 2025 pre-agent baseline.
// REPLACE WITH: SAP MM aggregate query by GL account + posting period.
export function loadPartsSpendHistory() {
  return parseCSV('parts_spend_history.csv').map((r:any) => ({
    m:         r.month,
    planned:   Number(r.planned_inr),
    unplanned: Number(r.unplanned_inr),
    plant:     r.plant,
  }));
}

let _platformConfigCache: ReturnType<typeof _loadPlatformConfigImpl> | null = null;
export function loadPlatformConfig() {
  if (_platformConfigCache) return _platformConfigCache;
  _platformConfigCache = _loadPlatformConfigImpl();
  return _platformConfigCache;
}
function _loadPlatformConfigImpl() {
  const rows = loadCsv('platform_config.csv');

  const get = (section: string) => rows.filter(r => r.section === section);

  // Benchmark trend
  const benchmarkTrend = get('benchmark_trend').map(r => ({
    day: r.label, p1: Number(r.value), p2: Number(r.extra1), bench: Number(r.extra2),
  }));

  // Benchmarks
  const benchmarks: Record<string, number> = {};
  for (const r of get('benchmark')) benchmarks[r.key] = Number(r.value);

  // Plant-keyed grouping helper. Rows with no `plant` value are treated as
  // Plant 1 (the platform's primary line); explicitly-tagged rows (e.g. P2)
  // form their own slice. This is what makes the ML Model view change when
  // the plant selector changes — see modelYieldByPlant / yieldFeatsByPlant.
  const byPlant = <T extends { plant?: string }>(rows: T[]) => {
    const m: Record<string, T[]> = {};
    for (const r of rows) { const k = (r.plant || 'P1'); (m[k] ||= []).push(r); }
    return m;
  };

  // Feature importance
  const yieldFeats = get('yield_feature').map(r => ({ f: r.label, v: Number(r.value), plant: r.plant || 'P1' }));
  const yieldFeatsByPlant = byPlant(yieldFeats);
  const pdmFeats   = get('pdm_feature').map(r => ({ f: r.label, v: Number(r.value) }));

  // Model history
  const modelYield = get('model_yield').map(r => ({
    version: r.key, date: r.label, r2: Number(r.value), mse: Number(r.extra1),
    samples: Number(r.extra2), status: r.extra3, plant: r.plant || 'P1',
  }));
  const modelYieldByPlant = byPlant(modelYield);
  const modelPdm = get('model_pdm').map(r => ({
    date: r.label, f1: Number(r.value), prec: Number(r.extra1),
    rec: Number(r.extra2), samples: Number(r.extra3), status: r.extra4,
  }));

  // Adoption trend
  const adoptionTrend = get('adoption').map(r => ({
    day: r.label, accepted: Number(r.value), rejected: Number(r.extra1),
  }));

  // Semantic KPIs
  const semanticKpi: Record<string, any> = {};
  for (const r of get('semantic_kpi')) {
    semanticKpi[r.key] = {
      name:    r.label,
      value:   r.value,
      unit:    r.unit,
      formula: r.extra1,
      src:     r.extra2,
      agents:  r.extra3 ? r.extra3.split(';') : [],
    };
  }

  const qualityModel = get('quality_model').map(r => ({
    date: r.label, mAP: Number(r.value), precision: Number(r.extra1),
    recall: Number(r.extra2), samples: Number(r.extra3), status: r.extra4,
  }));
  const qualityFeats = get('quality_feature').map(r => ({ f: r.label, v: Number(r.value) }));
  // Issue fix: keep the sub/notes column (was dropped — UI hardcoded the notes)
  const qualityKpis: Record<string, any> = {};
  for (const r of get('quality_kpi')) qualityKpis[r.key] = { value: r.value, sub: r.extra1 ?? '' };
  const retraining: Record<string, any> = {};
  const retrainingByPlant: Record<string, Record<string, any>> = {};
  for (const r of get('retraining')) {
    const obj = { version: r.value, date: r.extra1, sub: r.extra2, algo: r.extra3, nextVersion: r.extra4 };
    const pk = r.plant || 'P1';
    (retrainingByPlant[pk] ||= {})[r.key] = obj;
    // Untagged rows remain the global default so PdM/Quality model views
    // (which are not yet plant-scoped) keep working unchanged.
    if (!r.plant) retraining[r.key] = obj;
  }

  // Issue fix: OEE economics factors (were hardcoded *48000 and *1.03 in the UI)
  const oeeEconomics: Record<string, number> = {};
  for (const r of get('oee_economics')) oeeEconomics[r.key] = Number(r.value);
  // Issue fix: energy thresholds/targets (were render-layer literals)
  const energyConfig: Record<string, any> = {};
  for (const r of get('energy_config')) energyConfig[r.key] = { value: r.value, unit: r.unit };
  // Issue fix: PdM roadmap (was a static array in the UI)
  const pdmRoadmap = get('pdm_roadmap').map(r => ({ ver: r.label, status: r.value, desc: r.extra1 }));
  // Issue fix: twin sync settings (was a '30s' literal in the Calibration tab)
  const twinConfig: Record<string, any> = {};
  for (const r of get('twin_config')) twinConfig[r.key] = { value: r.value, unit: r.unit };

  // Simulation thresholds (was scattered hardcoded numbers in engine.ts and scenario-engine.ts)
  const simThresholds: Record<string, number> = {};
  for (const r of get('sim_thresholds')) simThresholds[r.key] = Number(r.value);

  // Yield agent tuning knobs (warn band default, impact heuristic bounds).
  // Was scattered as magic numbers in yield.ts — externalised here per Phase A prep.
  const yieldThreshold: Record<string, number> = {};
  for (const r of get('yield_threshold')) yieldThreshold[r.key] = Number(r.value);

  // PdM agent thresholds — RUL stages, vibration/temp alarm limits, parts cost.
  // Was scattered as magic numbers across PdmAssets/PdmSensors/PdmRul/PdmParts.
  // Centralized so the engineering team can re-tune without code change.
  const pdmThreshold: Record<string, number> = {};
  for (const r of get('pdm_threshold')) pdmThreshold[r.key] = Number(r.value);

  // Energy: monitored waste categories — the AI watches for these patterns even
  // before any are detected. Was a hardcoded 7-type narrative in EnergyWaste banner.
  const energyWasteMonitored = get('energy_waste_monitored').map(r => ({
    id:       r.key,
    label:    r.label,
    desc:     r.value,
    category: r.unit,
  }));

  // Energy: dispatch type → color map. Was all hardcoded T.energy.
  const energyDispatchTypes: Record<string, { color: string; label: string; note?: string }> = {};
  for (const r of get('energy_dispatch_type')) energyDispatchTypes[r.key] = {
    color: r.value,
    label: r.label,
    note:  (r as any).extra1,
  };

  // OEE loss categories — single source of truth for the 6 Big Losses, used by
  // both the six-losses + loss-trend backend routes AND the OeeLosses bar chart
  // colors. Was a hardcoded CAT array in history.ts + parallel inline colors in App.tsx.
  // Ordered by `extra2` (stack order). Each row: key=bar_key (brk/chg/...), label=category name, value=color, extra2=order.
  const oeeLossCategories = get('oee_loss_category')
    .map(r => ({
      barKey: r.key,
      name:   r.label,
      color:  r.value,
      order:  Number((r as any).extra2 ?? 99),
    }))
    .sort((a: any, b: any) => a.order - b.order);

  // OEE alert routing — drives both server-side `routed` field and the frontend
  // Contextual Routing 4-card banner. Single source of truth.
  // Each row: key=routing id, label=trigger, value=destination text, extra2=color token.
  const oeeAlertRouting = get('oee_alert_routing').map(r => ({
    id:       r.key,
    trigger:  r.label,
    dest:     r.value,
    colorTok: (r as any).extra2 ?? 'oee', // 'red'|'amber'|'orange'|'blue' → resolved to T.X in frontend
  }));

  // Supply Chain thresholds — stock days tiers, lead-drift bands, financial risk
  // score, home country. Was scattered as magic numbers across backend supply
  // route + 2 frontend dashboards.
  const supplyThreshold: Record<string, any> = {};
  for (const r of get('supply_threshold')) {
    const n = Number(r.value);
    supplyThreshold[r.key] = Number.isFinite(n) ? n : r.value;
  }

  // Supply: signal categories that drive the dashboard signal counter. Each row
  // identifies a counting rule (resolved in frontend) with label + color.
  const supplySignal = get('supply_signal').map(r => ({
    id:       r.key,
    label:    r.label,
    metric:   r.value,  // metric key the frontend resolves to a count
    unit:     r.unit,
    colorTok: (r as any).extra2 ?? 'red',
  }));

  // Supply: economics formatting — currency symbol + divisor + unit suffix.
  // Was hardcoded ₹ / 100000 / L/mo server-side.
  const supplyEconomics: Record<string, any> = {};
  for (const r of get('supply_economics')) supplyEconomics[r.key] = r.value;

  // Supply: action label per risk tier (critical / high / medium).
  // Was hardcoded 'Emergency PO required' / 'Expedite delivery' server-side.
  const supplyAction: Record<string, string> = {};
  for (const r of get('supply_action')) supplyAction[r.key] = r.label;

  // Supply: weights for the derived Supplier Reliability Score KPI
  // (semantic_kpi_definitions: supplier_reliability_score). Externalised here so
  // the composite is governed/config-driven rather than a static per-supplier figure.
  const supplyReliability: Record<string, any> = {};
  for (const r of get('supply_reliability')) {
    const n = Number(r.value);
    supplyReliability[r.key] = Number.isFinite(n) ? n : r.value;
  }

  // Quality Vision thresholds — confidence_high, line_rate tiers, defects_today_warn.
  // Was scattered across 3 hardcoded literals (0.95, 99/98, 10) in App.tsx.
  const qualityThreshold: Record<string, any> = {};
  for (const r of get('quality_threshold')) {
    const n = Number(r.value);
    qualityThreshold[r.key] = Number.isFinite(n) ? n : r.value;
  }

  // Quality defect types — registry of known defect classifications with color
  // + severity tier. Drives the Defect Types Detected card and the per-defect
  // chip colors. Was an 8-entry hardcoded `colMap` inline. Each row: key=normalized
  // id (snake_case), label=display name as it appears in quality_defects.csv,
  // value=color, extra1=severity_tier, extra3=order (lower = higher priority).
  // quality_defect_type_alias rows carry additional display-name variants
  // (plurals, generic categories like "Weld joint") that appear in the log
  // but don't have a snake_case canonical entry.
  // Canonical classes first, then aliases. Several alias KEYS are the exact
  // same display string as a canonical label (they exist to give variant log
  // strings a color, not to define a new class) — without dedup the merged
  // list carries e.g. "Surface crack" twice, and the Defect Types Detected
  // panel renders every registry entry, so each class appeared twice (and the
  // duplicated React row keys corrupted percentage updates between refreshes).
  // Keep the FIRST entry per lowercase display name: canonical rows are spread
  // before aliases, so canonical color/severity/order always win.
  const qualityDefectTypeAll = [
    ...get('quality_defect_type').map(r => ({
      id:           r.key,
      name:         r.label,    // exact display string in quality_defects.csv
      color:        r.value,
      severityTier: (r as any).extra1 ?? 'minor',
      order:        Number((r as any).extra3 ?? 99),
    })),
    ...get('quality_defect_type_alias').map(r => {
      // Alias extra3 holds a legacy color token (e.g. "red"), not a number —
      // Number('red') is NaN, which made the sort comparator unstable.
      const o = Number((r as any).extra3);
      return {
        id:           r.key,      // display name doubles as the id for aliases
        name:         r.key,      // CSV log uses the display name (alias key)
        color:        r.value,
        severityTier: 'alias',
        order:        Number.isFinite(o) ? o : 99,
      };
    }),
  ];
  const seenDefectName = new Set<string>();
  const qualityDefectType = qualityDefectTypeAll
    .filter(d => {
      const k = String(d.name).toLowerCase();
      if (seenDefectName.has(k)) return false;
      seenDefectName.add(k);
      return true;
    })
    .sort((a: any, b: any) => a.order - b.order);

  // Quality severity → color. Was duplicated inline in 2 components.
  const qualitySeverity: Record<string, { color: string; note?: string }> = {};
  for (const r of get('quality_severity')) qualitySeverity[r.key] = {
    color: r.value,
    note:  (r as any).extra1,
  };

  // Safety event signatures — the "Safety Event Signatures Detected" card on
  // SafetyDash. Was a 6-entry hardcoded inline array. Each row: key=signature id,
  // label=display title, value=description, extra2=color token (red/amber/etc),
  // extra3=display order.
  const safetySignature = get('safety_signature').map(r => ({
    id:       r.key,
    title:    r.label,
    desc:     r.value,
    colorTok: (r as any).extra2 ?? 'safety',
    order:    Number((r as any).extra3 ?? 99),
  })).sort((a: any, b: any) => a.order - b.order);

  // Safety severity → color. Used by SafetyEvents card border + chip + SafetyDash
  // timeline. Was inline {critical/high/medium} with NO fallback (undefined for
  // anything else). New rows: critical/high/medium/low all explicit, plus grey
  // default for unknown severities.
  const safetySeverity: Record<string, { color: string; colorTok?: string }> = {};
  for (const r of get('safety_severity')) safetySeverity[r.key] = {
    color:    r.value,
    colorTok: (r as any).extra2 ?? 'gray',
  };

  // Safety PTW status → color. Was inline {approved/pending/rejected} with no
  // fallback. Same shape as severity.
  const safetyPtwStatus: Record<string, { color: string; colorTok?: string }> = {};
  for (const r of get('safety_ptw_status')) safetyPtwStatus[r.key] = {
    color:    r.value,
    colorTok: (r as any).extra2 ?? 'gray',
  };

  // Safety compliance frameworks — drives the Compliance tab cards. Each row:
  // key=framework id (osha_300/iso_45001/...), label=display title,
  // value=framework key passed to /compliance/report endpoint,
  // extra1=description, extra2=color token, extra3=order.
  const safetyCompliance = get('safety_compliance').map(r => ({
    id:          r.key,
    title:       r.label,
    framework:   r.value,
    description: (r as any).extra1 ?? '',
    colorTok:    (r as any).extra2 ?? 'green',
    order:       Number((r as any).extra3 ?? 99),
  })).sort((a: any, b: any) => a.order - b.order);

  // Twin Multi-Agent Hub connections — was 4 hardcoded inline tuples on
  // TwinDash with only 4 of 8 agents represented (V25 added all 8 inline).
  // Now CSV-driven with template substitution. Each row: key=agent id,
  // label=display name, value=flow template with {n} and {m} placeholders,
  // extra1=primary metric key, extra2=secondary metric key (optional, for
  // multi-count rows like Safety), extra3=display order.
  // AgChip resolves color from agent id, so no explicit color token needed.
  const twinHubConnection = get('twin_hub_connection').map(r => ({
    id:           r.key,
    agentName:    r.label,
    flowTemplate: r.value,
    metricKey:    (r as any).extra1 ?? '',
    metricKey2:   (r as any).extra2 ?? '',
    order:        Number((r as any).extra3 ?? 99),
  })).sort((a: any, b: any) => a.order - b.order);

  // Twin scenario status registry — was inline color map in 2 places
  // (TwinDash Active Scenarios card + TwinScenarios) with grey fallback added
  // in V25. Now CSV-driven. Each row: key=status name, label=display name,
  // value=hex color, extra2=color token (theme name), extra3=order.
  const twinScenarioStatus: Record<string, { color: string; label: string; description?: string; colorTok?: string }> = {};
  for (const r of get('twin_scenario_status')) twinScenarioStatus[r.key] = {
    color:       r.value,
    label:       r.label,
    description: (r as any).extra1,
    colorTok:    (r as any).extra2 ?? 'gray',
  };

  // Twin divergence status registry — was inline color map in TwinDivergence
  // (V25 added fallbacks via statusCol helper). Same shape as scenario_status.
  const twinDivergenceStatus: Record<string, { color: string; label: string; description?: string; colorTok?: string }> = {};
  for (const r of get('twin_divergence_status')) twinDivergenceStatus[r.key] = {
    color:       r.value,
    label:       r.label,
    description: (r as any).extra1,
    colorTok:    (r as any).extra2 ?? 'gray',
  };

  // Twin threshold tunables. Currently just critical_multiplier — used by
  // /api/twin/divergence to decide 'critical' vs 'diverging' tier
  // (pct > threshold_pct * multiplier). Was hardcoded `* 2` in the backend.
  const twinThreshold: Record<string, number> = {};
  for (const r of get('twin_threshold')) twinThreshold[r.key] = Number(r.value ?? 0);

  // Governed KPI thresholds — was inline magic numbers in /api/semantic/core/
  // kpis/summary (e.g. `oee < 80 ? 'warn' : 'ok'`, `target: 85`). Now CSV-
  // driven. Each row: key=kpi_id, label=display name, value=target (number
  // or empty for "no target"), extra1=direction (higher_is_better |
  // lower_is_better), extra3=warn threshold, extra4=critical threshold.
  const semanticKpiThreshold: Record<string, { target: number | null; direction: 'higher_is_better' | 'lower_is_better'; warn: number | null; critical: number | null }> = {};
  for (const r of get('semantic_kpi_threshold')) {
    const target = r.value === '' || r.value == null ? null : Number(r.value);
    const warn = (r as any).extra3 == null || (r as any).extra3 === '' ? null : Number((r as any).extra3);
    const critical = (r as any).extra4 == null || (r as any).extra4 === '' ? null : Number((r as any).extra4);
    const direction = ((r as any).extra1 ?? 'higher_is_better') === 'lower_is_better' ? 'lower_is_better' : 'higher_is_better';
    semanticKpiThreshold[r.key] = {
      target:    Number.isFinite(target as number) ? (target as number) : null,
      direction,
      warn:      Number.isFinite(warn as number) ? (warn as number) : null,
      critical:  Number.isFinite(critical as number) ? (critical as number) : null,
    };
  }

  // KPI formula constants — was inline magic numbers in kpi/engine.ts
  // (`stock < 14 ? 6 : < 30 ? 3 : 1`, `fin/20 * 4`, `*1000` near-miss normalisation,
  // `cap at 10`). Now CSV-driven so finance / safety teams can tune without code.
  const kpiFormula: Record<string, number> = {};
  for (const r of get('kpi_formula')) kpiFormula[r.key] = Number(r.value ?? 0);

  // Semantic Layer marketing/narrative banner — was 4 hardcoded tuples in
  // App.tsx ("One number everywhere", "Conflict resolution", "Causal
  // attribution", "NL query layer"). Now CSV-driven so the positioning
  // statement evolves without a frontend rebuild.
  const semanticOverview = get('semantic_overview').map(r => ({
    id:    r.key,
    title: r.label,
    body:  r.value,
    note:  (r as any).extra1 ?? '',
    order: Number((r as any).extra2 ?? 99),
  })).sort((a: any, b: any) => a.order - b.order);

  // Agent registry — central enumeration of the 8 agents. Was the magic
  // number "8 agents" hardcoded in the Semantic Layer header badge and the
  // Insights side-panel. Now derivable: `agentRegistry.length`. Adding a
  // 9th agent = one CSV row. Each row: key=agent id, label=display name,
  // value=color token, unit=category, extra1=display order, extra2=quarter.
  const agentRegistry = get('agent_registry').map(r => ({
    id:       r.key,
    name:     r.label,
    colorTok: r.value,
    // V41: column mapping fix. Was reading extra1/extra2/extra3 here, but the
    // CSV stores category in `unit`, order in `extra1`, quarter in `extra2`
    // (header is `section,key,label,value,unit,extra1..extra5`). The off-by-one
    // meant category="1", order=NaN, quarter="" — visible bug was a non-issue
    // because rows happened to be CSV-ordered, but quarter was always empty.
    category: r.unit ?? '',
    order:    Number((r as any).extra1 ?? 99),
    quarter:  String((r as any).extra2 ?? ''),
  })).sort((a: any, b: any) => a.order - b.order);

  // V31 Tier 2: Unified Overview KPI tiles — was an 8-entry hardcoded AGS
  // array in App.tsx. Each row: key=tile id, label=display label, value=metric
  // resolver key, unit=color token, extra1=sub-text template (with {placeholder}
  // substitutions resolved on the frontend), extra2=display order.
  const unifiedOverviewKpi = get('unified_overview_kpi').map(r => ({
    id:       r.key,
    label:    r.label,
    metric:   r.value,
    // V41: column mapping fix. Was reading extra1/extra2/extra3, but the CSV
    // stores colorTok in `unit` and subTpl in `extra1`. The off-by-one meant
    // subTpl picked up the order number (1..8), which rendered visibly as
    // "1", "2", "3"... underneath each KPI tile.
    colorTok: r.unit ?? 'oee',
    subTpl:   (r as any).extra1 ?? '',
    order:    Number((r as any).extra2 ?? 99),
  })).sort((a: any, b: any) => a.order - b.order);

  // V31 Tier 2: Unified AI welcome message — single row, supports {agentCount}
  // placeholder so the wording stays in sync with the agent registry.
  const unifiedAiWelcomeRow = get('unified_ai_welcome')[0];
  const unifiedAiWelcome = unifiedAiWelcomeRow?.value ?? '';

  // V31 Tier 2: Unified AI suggested questions — each row carries both the long
  // form (used in the welcome message bullets) and the short form (used in the
  // quick-tap chip row below the chat). Two text variants per question because
  // the existing inline arrays diverged.
  const unifiedAiSuggestions = get('unified_ai_suggestion').map(r => ({
    id:    r.key,
    long:  r.value,
    // V41: column mapping fix. Was reading extra1/extra2, but the CSV stores
    // short text in `unit` and order in `extra1`. The off-by-one meant short
    // picked up the order number, which rendered visibly as "1 2 3 4"
    // underneath the quick-tap chip row.
    short: r.unit ?? r.value,
    order: Number((r as any).extra1 ?? 99),
  })).sort((a: any, b: any) => a.order - b.order);

  // V31 Tier 2: System prompt scaffolding. The intro template carries the
  // {agentCount} / {plant} / {maxWords} placeholders so the AI's framing stays
  // in sync with the agent registry and any future plant-context changes.
  const unifiedAiPromptRows = get('unified_ai_prompt');
  const unifiedAiPrompt = {
    intro:    unifiedAiPromptRows.find(r => r.key === 'intro')?.value ?? '',
    maxWords: Number(unifiedAiPromptRows.find(r => r.key === 'max_words')?.value ?? 130),
  };

  return { benchmarkTrend, benchmarks, yieldFeats, yieldFeatsByPlant, pdmFeats, modelYield, modelYieldByPlant, modelPdm,
           adoptionTrend, semanticKpi, qualityModel, qualityFeats, qualityKpis, retraining, retrainingByPlant,
           oeeEconomics, energyConfig, pdmRoadmap, twinConfig, simThresholds, yieldThreshold, pdmThreshold,
           energyWasteMonitored, energyDispatchTypes, oeeLossCategories, oeeAlertRouting,
           supplyThreshold, supplySignal, supplyEconomics, supplyAction, supplyReliability,
           qualityThreshold, qualityDefectType, qualitySeverity,
           safetySignature, safetySeverity, safetyPtwStatus, safetyCompliance,
           twinHubConnection, twinScenarioStatus, twinDivergenceStatus, twinThreshold,
           semanticKpiThreshold, kpiFormula, semanticOverview, agentRegistry,
           unifiedOverviewKpi, unifiedAiWelcome, unifiedAiSuggestions, unifiedAiPrompt };
}

export function loadEnergyWaste() {
  return loadCsv('energy_waste.csv').map(r => ({
    id: r.id,
    type: r.type, kwh: Number(r.kwh),
    cost: Number(r.cost_inr), asset: r.asset, desc: r.description,
    plant: r.plant || 'Both',
    // Period column added so the UI can label costs honestly ("today" / "week" /
    // "current"). Phase A: real meter data will carry a real timestamp instead.
    period: r.period || 'current',
  })); // REPLACE WITH: Energy anomaly detection API
}

export function loadCarbonTrend() {
  return loadCsv('carbon_trend.csv').map(r => ({
    m: r.month.slice(0,3), v: Number(r.carbon_intensity), unit: r.unit,
    plant: r.plant || 'Both',
  })); // REPLACE WITH: Carbon accounting API / smart meter data
}

// Agent-header "Target:" strings — CSV-driven so they stay consistent with the
// real baselines.csv targets instead of being hardcoded in the React JSX (where
// they had drifted, e.g. header "-40%" vs baseline target "-38%").
export function loadAgentTargets(): Record<string, string> {
  const out: Record<string, string> = {};
  try {
    for (const r of loadCsv('agent_targets.csv')) {
      if (r.agent) out[String(r.agent).trim()] = r.target_text;
    }
  } catch { /* empty map → frontend falls back to its default label */ }
  return out;
}

export function loadDemandForecast() {
  return loadCsv('demand_forecast.csv').map(r => ({
    w: r.week,
    actual: r.actual_kg ? Number(r.actual_kg) : null,
    forecast: r.forecast_kg ? Number(r.forecast_kg) : null,
    plant: r.plant || 'Both',
    // Product column added so the chart title can read from data instead of
    // a hardcoded literal. Phase A: multi-product CSVs with a product selector.
    product: r.product || null,
  })); // REPLACE WITH: SAP PP demand planning API
}

export function loadTwinScenarios() {
  return loadCsv('twin_scenarios.csv').map(r => ({
    id: r.id, name: r.name, status: r.status, type: r.type, desc: r.description,
    impact: r.impact, confidence: Number(r.confidence), horizon: r.horizon,
    plant: r.plant || 'Both',
  })); // REPLACE WITH: Azure Digital Twins scenario API
}

export function loadEnergyDispatch() {
  return loadCsv('energy_dispatch.csv').map(r => ({
    id: r.id, asset: r.asset, action: r.action,
    saving: `${r.saving_kwh} kWh - Rs${r.saving_inr}`,
    status: r.status, type: r.type, plant: r.plant || 'P1',
  })); // REPLACE WITH: SCADA demand response API
}

export function loadTechStack(): Record<string, any[]> {
  const rows = loadCsv('tech_stack.csv');
  const result: Record<string, any[]> = {};
  for (const r of rows) {
    if (!result[r.agent]) result[r.agent] = [];
    result[r.agent].push({
      label: r.label,
      col:   r.color_token,
      items: r.items.split('|'),
    });
  }
  return result;
  // Phase 2: REPLACE WITH Azure App Configuration — az appconfig kv list
}

export function loadSemanticKpiDefs(): any[] {
  return loadCsv('semantic_kpi_definitions.csv').map(r => ({
    id:         r.kpi_id,
    name:       r.name,
    formula:    r.formula,
    unit:       r.unit,
    agents:     r.agents.split(';'),
    src:        r.source_system,
    governance: r.governance,
    is_derived: String(r.is_derived ?? '0').trim() === '1',
  }));
  // Phase 2: REPLACE WITH Azure SQL — SELECT * FROM semantic_kpi_definitions
}


export function loadPersonas(): Record<string, any> {
  const colorMap: Record<string, string> = {
    blue: '#2563eb', oee: '#f59e0b', pdm: '#8b5cf6', yield: '#10b981',
  };
  const result: Record<string, any> = {};
  for (const r of loadCsv('personas.csv')) {
    const kpis: [string, string][] = [];
    for (let i = 1; i <= 4; i++) {
      const label = r[`kpi_${i}_label`];
      const key   = r[`kpi_${i}_key`];
      if (label) kpis.push([label, key]);
    }
    result[r.persona_id] = {
      label: r.label,
      col:   colorMap[r.color_token] ?? r.color_token,
      kpis,
    };
  }
  return result;
  // Phase 2: REPLACE WITH Azure SQL + Azure AD role mapping
}

export function loadBaselines(plant?: string): Record<string, any> {
  const result: Record<string, any> = {};
  // Normalize plant selector via CSV-driven topology helper
  const { normalizePlant } = require('./plant');
  const plantCode = normalizePlant(plant);

  // Bucket rows by metric_id so we can aggregate across plants when no filter set
  const buckets: Record<string, any[]> = {};
  for (const r of loadCsv('baselines.csv')) {
    const rowPlant = r.plant || 'Both';
    // When a plant is selected: skip rows that don't match (keep 'Both' rows always)
    if (plantCode && rowPlant !== 'Both' && rowPlant !== plantCode) continue;
    if (!buckets[r.metric_id]) buckets[r.metric_id] = [];
    buckets[r.metric_id].push({ ...r, _rowPlant: rowPlant });
  }

  for (const metricId of Object.keys(buckets)) {
    const rows = buckets[metricId];
    if (rows.length === 1) {
      // Single row — common path (plant selected, or metric only defined for 'Both')
      const r = rows[0];
      result[metricId] = {
        agent: r.agent, label: r.label,
        baseline: Number(r.baseline_value), unit: r.baseline_unit, date: r.baseline_date,
        target: Number(r.target_value), targetLabel: r.target_label,
        current: Number(r.current_value), note: r.measurement_note, plant: r._rowPlant,
        delta: +(((Number(r.baseline_value) - Number(r.current_value)) /
                  Number(r.baseline_value)) * 100).toFixed(1),
      };
    } else {
      // Multiple rows (no plant filter, e.g. P1+P2 rows for energy_cost) — aggregate.
      // current and baseline averaged; target taken from any row (same across plants by convention);
      // note replaced with portfolio summary; plant marker = 'Aggregate'.
      const avg = (key: string) => rows.reduce((s: number, r: any) => s + Number(r[key] || 0), 0) / rows.length;
      const sample = rows[0];
      const avgBaseline = avg('baseline_value');
      const avgCurrent  = avg('current_value');
      result[metricId] = {
        agent: sample.agent, label: sample.label,
        baseline: +avgBaseline.toFixed(2), unit: sample.baseline_unit, date: sample.baseline_date,
        target: Number(sample.target_value), targetLabel: sample.target_label,
        current: +avgCurrent.toFixed(2),
        note: `Portfolio average across ${rows.map((r: any) => r._rowPlant).join(' + ')}`,
        plant: 'Aggregate',
        delta: +(((avgBaseline - avgCurrent) / avgBaseline) * 100).toFixed(1),
      };
    }
  }
  return result;
  // Phase 2: REPLACE WITH Azure SQL — compute delta vs actual live data
}

export function loadTechnicians() {
  return loadCsv('technicians.csv').map(r => ({
    id: r.id, name: r.name, role: r.role,
    shift: r.shift, spec: r.specialisation, plant: r.plant || 'P1',
  })); // REPLACE WITH: HR system / CMMS technician registry
}

export function loadShifts() {
  return loadCsv('shifts.csv').map(r => ({
    id:      r.shift_id,
    name:    r.name,
    role:    r.role,
    start:   r.start_time,
    end:     r.end_time,
    assets:  Number(r.assets_managed),
    wos:     Number(r.open_wos),
    plant:   r.plant || 'Both',
  })); // REPLACE WITH: HR shift management system
}

export function loadPdmRules() {
  return loadCsv('pdm_rules.csv').map(r => ({
    id:   r.rule_id,
    cond: r.condition,
    act:  r.action,
    sev:  r.severity,
    desc: r.description,
  })); // REPLACE WITH: Business rules engine / Azure App Configuration
}

export function loadConflictRules(): ConflictRule[] {
  return loadCsv('conflict_rules.csv').map(r => ({
    id:              r.rule_id,
    description:     r.description,
    triggerAgent:    r.trigger_agent,
    blockAgent:      r.block_agent,
    blockActionType: r.block_action_type,
    assetScope:      r.asset_scope as 'asset' | 'zone' | 'global',
    reason:          r.reason,
  }));
  // REPLACE WITH: CMMS conflict rule API or config service
}

export interface ConflictRule {
  id:              string;
  description:     string;
  triggerAgent:    string;
  blockAgent:      string;
  blockActionType: string;
  assetScope:      'asset' | 'zone' | 'global';
  reason:          string;
}

export function loadScenarioSteps(): ScenarioStepConfig[] {
  return loadCsv('scenario_steps.csv').map(r => ({
    stepNum:          Number(r.step_num),
    agent:            r.agent,
    actionType:       r.action_type,
    delayMs:          Number(r.delay_ms),
    impactType:       r.impact_type,
    impactUnit:       r.impact_unit,
    descriptionTpl:   r.description_template,
    actionLabelOk:    r.action_label_if_ok,
    actionLabelNotOk: r.action_label_if_not_ok,
    eventType:        r.event_type,
    severity:         r.severity as 'critical' | 'warning' | 'info',
  }));
  // REPLACE WITH: config service / admin UI in Phase 2
}

export interface ScenarioStepConfig {
  stepNum:          number;
  agent:            string;
  actionType:       string;
  delayMs:          number;
  impactType:       string;
  impactUnit:       string;
  descriptionTpl:   string;
  actionLabelOk:    string;
  actionLabelNotOk: string;
  eventType:        string;
  severity:         'critical' | 'warning' | 'info';
}

export function loadDemandCurve(): number[] {
  const rows = parseCSV('demand_curve.csv');
  const curve = new Array(24).fill(1.0);
  for (const r of rows) {
    const h = Number(r.hour);
    if (h >= 0 && h < 24 && r.factor !== undefined) curve[h] = Number(r.factor);
  }
  return curve;
}
