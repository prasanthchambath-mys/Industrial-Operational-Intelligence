// ─────────────────────────────────────────────────────────────────────────────
// Plant topology — single source of truth, derived from CSV at startup.
//
// Every list below (machines, utilities, lines, zones, plant codes) is computed
// from data/csv/* — NOT hardcoded. To add a new machine, new line, new plant,
// or move an asset between plants, edit the corresponding CSV. No code change.
//
// CSV sources:
//   • machines.csv         — id, line, plant  (drives machines + lines)
//   • energy_assets.csv    — id, plant         (drives utilities, dedup vs machines)
//   • safety_zones.csv     — zone_id, plant    (drives zones)
//   • shifts.csv           — plant column      (extra plant code discovery)
//
// Loaded once at module load. Re-derive on file change via reloadTopology().
// ─────────────────────────────────────────────────────────────────────────────

import {
  loadMachines, loadEnergyAssets, loadSafetyZones, loadShifts,
} from './csv-loader';

export type PlantCode = string;

interface Topology {
  plantCodes: PlantCode[];
  machinesByPlant: Map<PlantCode, string[]>;
  utilitiesByPlant: Map<PlantCode, string[]>;
  linesByPlant: Map<PlantCode, string[]>;
  zonesByPlant: Map<PlantCode, string[]>;
  plantByAsset: Map<string, PlantCode>;
  plantByLine: Map<string, PlantCode>;
  plantByZone: Map<string, PlantCode>;
}

function deriveTopology(): Topology {
  const machinesByPlant   = new Map<PlantCode, string[]>();
  const utilitiesByPlant  = new Map<PlantCode, string[]>();
  const linesByPlant      = new Map<PlantCode, string[]>();
  const zonesByPlant      = new Map<PlantCode, string[]>();
  const plantByAsset      = new Map<string, PlantCode>();
  const plantByLine       = new Map<string, PlantCode>();
  const plantByZone       = new Map<string, PlantCode>();
  const plantCodesSet     = new Set<PlantCode>();
  const linesSeen         = new Set<string>();

  try {
    for (const m of loadMachines() as any[]) {
      const code = String(m.plant ?? '').trim();
      const id   = String(m.id ?? '').trim();
      const line = String(m.line ?? '').trim();
      if (!code || !id) continue;
      plantCodesSet.add(code);
      if (!machinesByPlant.has(code)) machinesByPlant.set(code, []);
      machinesByPlant.get(code)!.push(id);
      plantByAsset.set(id, code);
      if (line) {
        const key = `${code}::${line}`;
        if (!linesSeen.has(key)) {
          linesSeen.add(key);
          if (!linesByPlant.has(code)) linesByPlant.set(code, []);
          linesByPlant.get(code)!.push(line);
          plantByLine.set(line, code);
        }
      }
    }
  } catch { /* CSV not ready */ }

  try {
    for (const a of loadEnergyAssets() as any[]) {
      const code = String(a.plant ?? '').trim();
      const id   = String(a.id ?? '').trim();
      if (!code || !id) continue;
      plantCodesSet.add(code);
      if (!plantByAsset.has(id)) {
        if (!utilitiesByPlant.has(code)) utilitiesByPlant.set(code, []);
        utilitiesByPlant.get(code)!.push(id);
        plantByAsset.set(id, code);
      }
    }
  } catch { /* CSV not ready */ }

  try {
    for (const z of loadSafetyZones() as any[]) {
      const code = String(z.plant ?? '').trim();
      const zone = String(z.zone ?? z.zone_id ?? z.id ?? '').trim();
      if (!code || !zone) continue;
      plantCodesSet.add(code);
      if (!zonesByPlant.has(code)) zonesByPlant.set(code, []);
      zonesByPlant.get(code)!.push(zone);
      plantByZone.set(zone, code);
    }
  } catch { /* CSV not ready */ }

  try {
    for (const s of loadShifts() as any[]) {
      const code = String(s.plant ?? '').trim();
      if (code) plantCodesSet.add(code);
    }
  } catch { /* CSV not ready */ }

  return {
    plantCodes: Array.from(plantCodesSet).sort(),
    machinesByPlant, utilitiesByPlant, linesByPlant, zonesByPlant,
    plantByAsset, plantByLine, plantByZone,
  };
}

let _topology: Topology = deriveTopology();

export function reloadTopology(): void { _topology = deriveTopology(); }
export function getTopology(): Topology { return _topology; }

export function getPlantCodes(): PlantCode[] { return [..._topology.plantCodes]; }
export function machinesFor(code: PlantCode): string[]  { return [...(_topology.machinesByPlant.get(code)  ?? [])]; }
export function utilitiesFor(code: PlantCode): string[] { return [...(_topology.utilitiesByPlant.get(code) ?? [])]; }
export function assetsFor(code: PlantCode): string[]    { return [...machinesFor(code), ...utilitiesFor(code)]; }
export function linesFor(code: PlantCode): string[]     { return [...(_topology.linesByPlant.get(code)     ?? [])]; }
export function zonesFor(code: PlantCode): string[]     { return [...(_topology.zonesByPlant.get(code)     ?? [])]; }

export function plantForAsset(assetId: string | undefined | null): PlantCode | null {
  if (!assetId) return null;
  return _topology.plantByAsset.get(String(assetId)) ?? null;
}
export function plantForLine(line: string | undefined | null): PlantCode | null {
  if (!line) return null;
  return _topology.plantByLine.get(String(line)) ?? null;
}
export function plantForZone(zone: string | undefined | null): PlantCode | null {
  if (!zone) return null;
  return _topology.plantByZone.get(String(zone)) ?? null;
}
export function resolvePlantFromAny(idOrName: string | undefined | null): PlantCode | null {
  if (!idOrName) return null;
  const v = String(idOrName);
  return plantForAsset(v) ?? plantForLine(v) ?? plantForZone(v) ?? null;
}

/**
 * Normalize a raw ?plant= query value into a canonical plant code, or null
 * for "all plants" / unspecified. Accepts 'Plant 1', 'P1', 'plant 1', etc.
 * 'Plant N' → 'PN' for any N — works automatically when a new plant is added
 * via CSV.
 */
export function normalizePlant(raw: unknown): PlantCode | null {
  if (raw == null) return null;
  const s = String(raw).trim();
  if (!s || s === 'All Plants') return null;
  if (_topology.plantCodes.includes(s)) return s;
  const m = s.match(/^Plant\s+(\d+)$/i);
  if (m) {
    const code = `P${m[1]}`;
    if (_topology.plantCodes.includes(code)) return code;
  }
  return null;
}

export function hasPlantFilter(raw: unknown): boolean {
  return normalizePlant(raw) !== null;
}

export function filterByPlantColumn<T extends { plant?: string }>(rows: T[], raw: unknown): T[] {
  const code = normalizePlant(raw);
  if (!code) return rows;
  return rows.filter((r) => !r.plant || r.plant === code || r.plant === 'Both');
}

export function filterByAsset<T>(rows: T[], raw: unknown, key: keyof T): T[] {
  const code = normalizePlant(raw);
  if (!code) return rows;
  const ids = new Set(assetsFor(code));
  return rows.filter((r) => {
    const v = r[key] as unknown as string;
    return !v || ids.has(v);
  });
}

export function filterByLine<T>(rows: T[], raw: unknown, key: keyof T): T[] {
  const code = normalizePlant(raw);
  if (!code) return rows;
  const lines = linesFor(code);
  return rows.filter((r) => {
    const v = r[key] as unknown as string;
    return !v || lines.some((l) => String(v).includes(l));
  });
}

// Backward-compat — read once at module load from the derived topology.
// New code should prefer machinesFor()/assetsFor()/linesFor() so it adapts
// when CSVs change.
export const P1_MACHINES  = machinesFor('P1');
export const P2_MACHINES  = machinesFor('P2');
export const P1_UTILITIES = utilitiesFor('P1');
export const P2_UTILITIES = utilitiesFor('P2');
export const P1_LINES     = linesFor('P1');
export const P2_LINES     = linesFor('P2');
export const P1_ASSETS    = assetsFor('P1');
export const P2_ASSETS    = assetsFor('P2');
