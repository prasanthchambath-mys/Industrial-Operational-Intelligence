/**
 * Runtime state overrides
 *
 * CSV files (work_orders.csv, parts.csv) act as the immutable seed for
 * operational state. Operator actions (Start Work, Complete, Approve PO,
 * Reject PO) need to mutate state but should not write back to CSV — that
 * would corrupt the demo seed and lose audit history.
 *
 * This module provides in-memory override maps keyed by row ID. The GET
 * routes layer overrides on top of CSV data. Transitions are published
 * to the Semantic Layer so cross-agent events fire correctly.
 *
 * Phase A: replace with SQLite tables `wo_state_override` and
 * `parts_order_override`. The shape here matches the future schema.
 */

export interface WoOverride {
  status: 'open' | 'in_progress' | 'completed';
  startedAt?: string;
  completedAt?: string;
  updatedBy?: string;
}

export interface PartsOverride {
  status: 'pending_approval' | 'escalated' | 'ordered' | 'rejected' | 'delivered';
  poNumber?: string;
  approvedAt?: string;
  approvedBy?: string;
  rejectedReason?: string;
}

const woOverrides = new Map<string, WoOverride>();
const partsOverrides = new Map<string, PartsOverride>();

// ── Work Orders ─────────────────────────────────────────────────────────────

export function getWoOverride(id: string): WoOverride | undefined {
  return woOverrides.get(id);
}

export function setWoOverride(id: string, ov: WoOverride): WoOverride {
  woOverrides.set(id, ov);
  return ov;
}

export function applyWoOverrides<T extends { id: string; status: string; created_at?: string | null; closed_at?: string | null }>(
  rows: T[],
): T[] {
  return rows.map(r => {
    const ov = woOverrides.get(r.id);
    if (!ov) return r;
    return {
      ...r,
      status: ov.status,
      closed_at: ov.completedAt ?? r.closed_at,
    };
  });
}

// Allowed status transitions enforced server-side so a misbehaving client
// can't skip from 'open' directly to 'completed'.
const WO_TRANSITIONS: Record<string, string[]> = {
  open: ['in_progress'],
  in_progress: ['completed'],
  completed: [], // terminal
};

export function isValidWoTransition(from: string, to: string): boolean {
  return (WO_TRANSITIONS[from] ?? []).includes(to);
}

// ── Parts Orders ────────────────────────────────────────────────────────────

export function getPartsOverride(id: string): PartsOverride | undefined {
  return partsOverrides.get(id);
}

export function setPartsOverride(id: string, ov: PartsOverride): PartsOverride {
  partsOverrides.set(id, ov);
  return ov;
}

export function applyPartsOverrides<T extends { id: string; status: string }>(rows: T[]): T[] {
  return rows.map(r => {
    const ov = partsOverrides.get(r.id);
    if (!ov) return r;
    return {
      ...r,
      status: ov.status,
      // Surface PO number for ordered status so UI can render PO-XXXX
      ...(ov.poNumber ? { poNumber: ov.poNumber } : {}),
    };
  });
}

// Allowed parts transitions
const PARTS_TRANSITIONS: Record<string, string[]> = {
  pending_approval: ['ordered', 'rejected'],
  escalated: ['ordered', 'rejected'],
  ordered: ['delivered'],
  rejected: [], // terminal
  delivered: [], // terminal
};

export function isValidPartsTransition(from: string, to: string): boolean {
  return (PARTS_TRANSITIONS[from] ?? []).includes(to);
}

// ── Energy Dispatch ─────────────────────────────────────────────────────────

export interface DispatchOverride {
  status: 'pending' | 'dispatched' | 'scheduled';
  dispatchedAt?: string;
  scheduledFor?: string;
  updatedBy?: string;
}

const dispatchOverrides = new Map<string, DispatchOverride>();

export function getDispatchOverride(id: string): DispatchOverride | undefined {
  return dispatchOverrides.get(id);
}

export function setDispatchOverride(id: string, ov: DispatchOverride): DispatchOverride {
  dispatchOverrides.set(id, ov);
  return ov;
}

export function applyDispatchOverrides<T extends { id: string; status: string }>(rows: T[]): T[] {
  return rows.map(r => {
    const ov = dispatchOverrides.get(r.id);
    if (!ov) return r;
    return {
      ...r,
      status: ov.status,
      ...(ov.scheduledFor ? { scheduledFor: ov.scheduledFor } : {}),
      ...(ov.dispatchedAt ? { dispatchedAt: ov.dispatchedAt } : {}),
    };
  });
}

// pending → (dispatched | scheduled); scheduled → (dispatched); dispatched is terminal
const DISPATCH_TRANSITIONS: Record<string, string[]> = {
  pending: ['dispatched', 'scheduled'],
  scheduled: ['dispatched'],
  dispatched: [],
};

export function isValidDispatchTransition(from: string, to: string): boolean {
  return (DISPATCH_TRANSITIONS[from] ?? []).includes(to);
}

// ── Supply Chain Reorders ───────────────────────────────────────────────────
// Operator triggers reorder on a supply risk row (supplier × SKU). State
// machine: pending → ordered. Ordered is terminal for Phase 1 (PR raised in
// SAP MM is then SAP's lifecycle, not ManuAI's).

export interface SupplyReorderOverride {
  status: 'pending' | 'ordered';
  prNumber?: string;        // SAP MM PurchaseRequisition id
  reorderedAt?: string;
  reorderedBy?: string;
  quantity?: number;
  reason?: string;
}

const supplyReorderOverrides = new Map<string, SupplyReorderOverride>();

export function getSupplyReorderOverride(id: string): SupplyReorderOverride | undefined {
  return supplyReorderOverrides.get(id);
}

export function setSupplyReorderOverride(id: string, ov: SupplyReorderOverride): SupplyReorderOverride {
  supplyReorderOverrides.set(id, ov);
  return ov;
}

export function applySupplyReorderOverrides<T extends { risk_id?: string; id?: string }>(rows: T[]): (T & { reorderStatus?: string; prNumber?: string; reorderedAt?: string })[] {
  return rows.map(r => {
    const key = r.risk_id ?? r.id;
    if (!key) return r as any;
    const ov = supplyReorderOverrides.get(key);
    if (!ov) return r as any;
    return { ...r, reorderStatus: ov.status, prNumber: ov.prNumber, reorderedAt: ov.reorderedAt };
  });
}

// V34: enumerate every supply reorder override (riskId → override metadata) so
// the Supply Inventory tab can show a real list of auto-reorders raised in the
// last N days. Was only addressable by riskId one-at-a-time which made
// reporting impossible.
export function listAllSupplyReorders(): Array<{ riskId: string } & SupplyReorderOverride> {
  return Array.from(supplyReorderOverrides.entries()).map(([riskId, ov]) => ({ riskId, ...ov }));
}

// ── Permit-to-Work approvals/rejections ────────────────────────────────────
// PTW lifecycle: pending → approved | rejected. Both terminal for Phase 1
// (a revoked permit is a new permit number; SAP PTW handles re-issuance).
// CSV seed carries the initial status; runtime overrides record operator
// decisions on `pending` rows.

export interface PtwOverride {
  status:      'approved' | 'rejected';
  decidedBy:   string;
  decidedAt:   string;
  reason?:     string;   // required for rejection, optional for approval
}

const ptwOverrides = new Map<string, PtwOverride>();
const PTW_TRANSITIONS: Record<string, string[]> = {
  pending:  ['approved', 'rejected'],
  approved: [],  // terminal
  rejected: [],  // terminal
};

export function getPtwOverride(id: string): PtwOverride | undefined {
  return ptwOverrides.get(id);
}

export function setPtwOverride(id: string, ov: PtwOverride): PtwOverride {
  ptwOverrides.set(id, ov);
  return ov;
}

export function isValidPtwTransition(from: string, to: string): boolean {
  return (PTW_TRANSITIONS[from] ?? []).includes(to);
}

export function applyPtwOverrides<T extends { id?: string; ptw_id?: string; status?: string }>(rows: T[]): (T & { decidedBy?: string; decidedAt?: string; reason?: string })[] {
  return rows.map(r => {
    const key = r.id ?? r.ptw_id;
    if (!key) return r as any;
    const ov = ptwOverrides.get(key);
    if (!ov) return r as any;
    return { ...r, status: ov.status, decidedBy: ov.decidedBy, decidedAt: ov.decidedAt, reason: ov.reason };
  });
}

// ── Safety event acknowledgement / resolution ───────────────────────────────
// SQLite safety_events already has resolved_at; for Phase 1 we layer operator
// actions (ack, resolve) via runtime overrides so the demo keeps the seeded
// synthetic events while still recording operator workflow. Phase A migrates
// these to a real `safety_event_actions` table.

export interface SafetyEventOverride {
  status:       'acked' | 'resolved';
  ackedBy?:     string;
  ackedAt?:     string;
  resolvedBy?:  string;
  resolvedAt?:  string;
  notes?:       string;
}

const safetyEventOverrides = new Map<string, SafetyEventOverride>();
const SE_TRANSITIONS: Record<string, string[]> = {
  open:     ['acked', 'resolved'],
  acked:    ['resolved'],
  resolved: [],
};

export function getSafetyEventOverride(id: string): SafetyEventOverride | undefined {
  return safetyEventOverrides.get(id);
}

export function setSafetyEventOverride(id: string, ov: SafetyEventOverride): SafetyEventOverride {
  safetyEventOverrides.set(id, ov);
  return ov;
}

export function isValidSafetyEventTransition(from: string, to: string): boolean {
  return (SE_TRANSITIONS[from] ?? []).includes(to);
}

export function applySafetyEventOverrides<T extends { id?: string; status?: string }>(rows: T[]): (T & { ackedBy?: string; ackedAt?: string; resolvedBy?: string; resolvedAt?: string; notes?: string })[] {
  return rows.map(r => {
    if (!r.id) return r as any;
    const ov = safetyEventOverrides.get(r.id);
    if (!ov) return r as any;
    return { ...r, status: ov.status, ackedBy: ov.ackedBy, ackedAt: ov.ackedAt, resolvedBy: ov.resolvedBy, resolvedAt: ov.resolvedAt, notes: ov.notes };
  });
}

// ── Twin Scenario Runs ──────────────────────────────────────────────────────
// Scenario lifecycle: pending → running → complete | cancelled. The CSV seed
// carries pending/running/complete as initial state; runtime overrides capture
// operator-triggered runs and cancellations. Completion is lazy — the apply
// projection auto-promotes 'running' to 'complete' once durationSec has
// elapsed since startedAt, so no background timer is required. Phase A
// migrates this to a real Azure Digital Twins scenario API.

export interface TwinScenarioRun {
  status:           'pending' | 'running' | 'complete' | 'cancelled';
  startedAt?:       string;
  startedBy?:       string;
  completedAt?:     string;
  cancelledAt?:     string;
  durationSec?:     number;    // simulated run duration (default 30s for demo)
  resultImpact?:    string;
  resultConfidence?:number;
}

const twinScenarioRuns = new Map<string, TwinScenarioRun>();

const SCENARIO_TRANSITIONS: Record<string, string[]> = {
  pending:   ['running'],
  running:   ['complete', 'cancelled'],
  complete:  ['running'],    // re-run
  cancelled: ['running'],    // run again after cancel
};

export function getTwinScenarioRun(id: string): TwinScenarioRun | undefined {
  return twinScenarioRuns.get(id);
}

export function setTwinScenarioRun(id: string, run: TwinScenarioRun): TwinScenarioRun {
  twinScenarioRuns.set(id, run);
  return run;
}

export function isValidScenarioTransition(from: string, to: string): boolean {
  return (SCENARIO_TRANSITIONS[from] ?? []).includes(to);
}

// Lazy completion: a 'running' override whose startedAt+durationSec has passed
// is promoted to 'complete' on read. Avoids background timers entirely.
export function applyTwinScenarioRunOverrides<T extends { id?: string; status?: string; impact?: string; confidence?: number }>(rows: T[]): (T & { startedAt?: string; startedBy?: string; completedAt?: string; cancelledAt?: string })[] {
  const now = Date.now();
  return rows.map(r => {
    if (!r.id) return r as any;
    let ov = twinScenarioRuns.get(r.id);
    if (!ov) return r as any;
    // Lazy auto-complete
    if (ov.status === 'running' && ov.startedAt) {
      const elapsed = (now - new Date(ov.startedAt).getTime()) / 1000;
      if (elapsed >= (ov.durationSec ?? 30)) {
        ov = setTwinScenarioRun(r.id, {
          ...ov,
          status:      'complete',
          completedAt: new Date(new Date(ov.startedAt).getTime() + (ov.durationSec ?? 30) * 1000).toISOString(),
        });
      }
    }
    return {
      ...r,
      status:      ov.status,
      // Surface the result impact/confidence from override when complete (lets a
      // re-run reveal new numbers without touching the CSV seed)
      impact:      ov.resultImpact     ?? r.impact,
      confidence:  ov.resultConfidence ?? r.confidence,
      startedAt:   ov.startedAt,
      startedBy:   ov.startedBy,
      completedAt: ov.completedAt,
      cancelledAt: ov.cancelledAt,
    };
  });
}

// ── Quality Vision Retraining ──────────────────────────────────────────────
// Federated retraining runs add new entries to the model history. CSV history
// is the seed; runtime entries are session-state for the Phase 1 demo (Phase A
// migrates this to MLflow runs table). Each retrain returns metrics so the UI
// reflects what the backend says rather than a hardcoded improvement curve.

export interface QualityRetrainEntry {
  date:      string;
  version:   string;
  mAP:       number;
  precision: number;
  recall?:   number;
  samples:   number;
  status:    'deployed' | 'archived' | 'failed';
  outcome:   'improved' | 'no_change' | 'regression' | 'failed';
  triggeredAt: string;
  triggeredBy: string;
}

const qualityRetrainEntries: QualityRetrainEntry[] = [];

export function appendQualityRetrain(entry: QualityRetrainEntry): QualityRetrainEntry {
  // Archive any prior deployed entries; the new one is the live model.
  if (entry.status === 'deployed') {
    for (const e of qualityRetrainEntries) if (e.status === 'deployed') e.status = 'archived';
  }
  qualityRetrainEntries.unshift(entry);
  return entry;
}

export function getQualityRetrainEntries(): QualityRetrainEntry[] {
  return [...qualityRetrainEntries];
}

export function applyQualityRetrainEntries(seed: any[]): any[] {
  if (!qualityRetrainEntries.length) return seed;
  // Runtime entries are newer than the CSV seed — newest first.
  // First, archive any CSV `deployed` rows since the live model is whichever
  // runtime entry currently has status='deployed' (the most recent).
  const adjustedSeed = seed.map(r => ({ ...r, status: r.status === 'deployed' ? 'archived' : r.status }));
  return [...qualityRetrainEntries, ...adjustedSeed];
}

// ── OEE Alerts ──────────────────────────────────────────────────────────────
// Alerts have three independent operator actions (ack / create-WO / escalate)
// rather than a single state machine — operators can ack and escalate the same
// alert. The shape mirrors what the OeeAlerts UI tracks per row.
// rather than a single state machine — operators can ack and escalate the same
// alert. The shape mirrors what the OeeAlerts UI tracks per row.

export interface AlertOverride {
  acked?: boolean;
  ackedAt?: string;
  ackedBy?: string;
  woId?: string;          // SAP PM notification id once Create WO succeeds
  woCreatedAt?: string;
  woCreatedBy?: string;
  woNote?: string;        // human-readable confirmation line
  escalated?: boolean;
  escalatedAt?: string;
  escalatedBy?: string;
  escalatedTo?: string;   // e.g. "shift supervisor", "plant manager"
  escalateNote?: string;
}

const alertOverrides = new Map<string, AlertOverride>();

export function getAlertOverride(id: string): AlertOverride | undefined {
  return alertOverrides.get(id);
}

export function setAlertOverride(id: string, patch: Partial<AlertOverride>): AlertOverride {
  const current = alertOverrides.get(id) ?? {};
  const merged = { ...current, ...patch };
  alertOverrides.set(id, merged);
  return merged;
}

export function applyAlertOverrides<T extends { id: string }>(rows: T[]): (T & AlertOverride & { note?: string })[] {
  return rows.map(r => {
    const ov = alertOverrides.get(r.id);
    if (!ov) return r as any;
    // Surface a single `note` line for the UI — escalation supersedes WO ack
    const note = ov.escalateNote ?? ov.woNote ?? undefined;
    return { ...r, ...ov, note };
  });
}

// ── Diagnostics ─────────────────────────────────────────────────────────────

export function getOverrideStats() {
  return {
    woOverrides: woOverrides.size,
    partsOverrides: partsOverrides.size,
    dispatchOverrides: dispatchOverrides.size,
    alertOverrides: alertOverrides.size,
    supplyReorderOverrides: supplyReorderOverrides.size,
    qualityRetrainEntries: qualityRetrainEntries.length,
    ptwOverrides: ptwOverrides.size,
    safetyEventOverrides: safetyEventOverrides.size,
    twinScenarioRuns: twinScenarioRuns.size,
  };
}
