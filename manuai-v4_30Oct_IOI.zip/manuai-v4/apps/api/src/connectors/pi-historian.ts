import axios, { AxiosInstance } from 'axios';
import { logger } from '../middleware/logger';

// ── Mock data used when PI_WEB_API_URL is not configured ─────────────────────
const MOCK_PI_VALUES: Record<string, number> = {
  'Plant.LineA.MCH01.Availability': 88.4, 'Plant.LineA.MCH01.Performance': 83.6, 'Plant.LineA.MCH01.Quality': 96.3,
  'Plant.LineA.MCH02.Availability': 94.1, 'Plant.LineA.MCH02.Performance': 91.2, 'Plant.LineA.MCH02.Quality': 98.5,
  'Plant.LineB.MCH03.Availability': 78.3, 'Plant.LineB.MCH03.Performance': 82.4, 'Plant.LineB.MCH03.Quality': 96.1,
  'Plant.LineB.MCH04.Availability': 96.2, 'Plant.LineB.MCH04.Performance': 94.1, 'Plant.LineB.MCH04.Quality': 98.8,
  'Plant.LineC.MCH05.Availability': 91.3, 'Plant.LineC.MCH05.Performance': 86.2, 'Plant.LineC.MCH05.Quality': 97.4,
  'Plant.LineC.MCH06.Availability': 72.1, 'Plant.LineC.MCH06.Performance': 80.3, 'Plant.LineC.MCH06.Quality': 96.8,
  'Plant.LineD.MCH07.Availability': 97.4, 'Plant.LineD.MCH07.Performance': 95.3, 'Plant.LineD.MCH07.Quality': 98.3,
  'Plant.LineD.MCH08.Availability': 89.7, 'Plant.LineD.MCH08.Performance': 90.4, 'Plant.LineD.MCH08.Quality': 97.5,
  // Synthesized-fallback keys (used only when tag_mappings.csv row is missing).
  'Plant.Reactor.TIC101.PV': 182,   'Plant.Reactor.PIC102.PV': 8.4,
  'Plant.Reactor.SIC204.PV': 420,   'Plant.Reactor.FIC301.PV': 142,
  'Plant.Reactor.TIC205.PV': 45.2,  'Plant.Reactor.FIC401.PV': 28.6,
  // Registry keys matching tag_mappings.csv pi_tag (the intended production path).
  // Without these, getTagsBatch missed on the mapped tag and returned its 50
  // default, so the Live Process Parameters panel flickered to 50 on refresh.
  'Plant1.LineA.Reactor1.TIC101.PV': 182, 'Plant1.LineA.Reactor1.PIC102.PV': 8.4,
  'Plant1.LineB.Mixer1.SIC204.PV': 420,   'Plant1.LineB.Feeder1.FIC301.PV': 142,
  'Plant2.LineC.Reactor2.TIC205.PV': 45.2, 'Plant2.LineD.Cooler1.FIC401.PV': 28.6,
};

function mockNoise(base: number, pct = 0.01): number {
  return +(base * (1 + (Math.random() - 0.5) * pct)).toFixed(2);
}

// ── Multi-plant PI support ───────────────────────────────────────────────────
// Per-plant env vars: PI_WEB_API_URL_P1, PI_WEB_API_URL_P2 (recommended)
// Global fallback:    PI_WEB_API_URL applies to all plants
function getPiUrl(plantId = 'P1'): string | undefined {
  return process.env[`PI_WEB_API_URL_${plantId}`] ?? process.env.PI_WEB_API_URL;
}
function getPiCred(plantId = 'P1'): string {
  const u = process.env[`PI_USERNAME_${plantId}`] ?? process.env.PI_USERNAME ?? '';
  const p = process.env[`PI_PASSWORD_${plantId}`] ?? process.env.PI_PASSWORD ?? '';
  return Buffer.from(`${u}:${p}`).toString('base64');
}

const MOCK_MODE = !process.env.PI_WEB_API_URL && !process.env.PI_WEB_API_URL_P1;
if (MOCK_MODE) logger.warn('PI_WEB_API_URL not set — PI historian running in mock mode');

// ── Per-plant live clients ────────────────────────────────────────────────────
const clients = new Map<string, AxiosInstance>();

function getClient(plantId = 'P1'): AxiosInstance {
  if (clients.has(plantId)) return clients.get(plantId)!;
  const url = getPiUrl(plantId);
  if (!url) throw new Error(`No PI URL configured for plant ${plantId}`);
  const c = axios.create({
    baseURL: url,
    headers: { Authorization: `Basic ${getPiCred(plantId)}`, 'X-Requested-With': 'XMLHttpRequest' },
    httpsAgent: new (require('https').Agent)({ rejectUnauthorized: process.env.NODE_ENV === 'production' }),
    timeout: 8000,
  });
  clients.set(plantId, c);
  return c;
}

const webIdCache = new Map<string, string>();

async function resolveWebId(tagPath: string, plantId = 'P1'): Promise<string> {
  const cacheKey = `${plantId}:${tagPath}`;
  if (webIdCache.has(cacheKey)) return webIdCache.get(cacheKey)!;
  const res = await getClient(plantId).get('/points', {
    params: { path: `\\\\${process.env.PI_SERVER_NAME}\\${tagPath}` },
  });
  webIdCache.set(cacheKey, res.data.WebId);
  return res.data.WebId as string;
}

export async function getTagValue(tagPath: string): Promise<{ value: number; timestamp: string; good: boolean }> {
  if (MOCK_MODE) {
    const base = MOCK_PI_VALUES[tagPath] ?? 0;
    return { value: mockNoise(base), timestamp: new Date().toISOString(), good: true };
  }
  try {
    const webId = await resolveWebId(tagPath);
    const res = await getClient().get(`/streams/${webId}/value`);
    return { value: res.data.Value, timestamp: res.data.Timestamp, good: res.data.Good };
  } catch (err) {
    logger.warn(`PI read failed: ${tagPath}`, { error: String(err) });
    throw err;
  }
}

export async function getTagsBatch(tagPaths: string[]): Promise<Record<string, number>> {
  if (MOCK_MODE) {
    return Object.fromEntries(tagPaths.map(t => [t, mockNoise(MOCK_PI_VALUES[t] ?? 50)]));
  }
  try {
    const batch: Record<string, { Method: string; Resource: string }> = {};
    tagPaths.forEach((tag, i) => {
      batch[`r${i}`] = { Method: 'GET', Resource: `/piwebapi/streams/${encodeURIComponent(tag)}/value` };
    });
    const res = await getClient().post('/batch', batch);
    const result: Record<string, number> = {};
    tagPaths.forEach((tag, i) => {
      if (res.data[`r${i}`]?.Status === 200) result[tag] = res.data[`r${i}`].Content.Value;
    });
    return result;
  } catch {
    return {};
  }
}

export async function getTagHistory(tagPath: string, startTime = '*-24h', endTime = '*', maxCount = 1440) {
  if (MOCK_MODE) {
    const base = MOCK_PI_VALUES[tagPath] ?? 50;
    return Array.from({ length: 24 }, (_, i) => ({
      Timestamp: new Date(Date.now() - (23 - i) * 3600000).toISOString(),
      Value: mockNoise(base, 0.04),
    }));
  }
  try {
    const webId = await resolveWebId(tagPath);
    const res = await getClient().get(`/streams/${webId}/recorded`, {
      params: { startTime, endTime, maxCount },
    });
    return (res.data.Items ?? []) as Array<{ Timestamp: string; Value: number }>;
  } catch {
    return [];
  }
}

export async function checkPIHealth(): Promise<boolean> {
  if (MOCK_MODE) return true; // mock always "healthy"
  try { await getClient().get('/system/versions'); return true; } catch { return false; }
}
