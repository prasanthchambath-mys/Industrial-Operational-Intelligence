/**
 * ManuAI — Azure IoT Hub Connector  (V42 → Phase A ready)
 *
 * Phase 1:  IOT_HUB_CONNECTION_STRING absent → simulation mode
 * Phase A:  IOT_HUB_CONNECTION_STRING set    → real Event Hub consumer
 *
 * Multi-plant: supports per-plant connection strings:
 *   IOT_HUB_CONNECTION_STRING_P1=...  (Plant 1 Mumbai)
 *   IOT_HUB_CONNECTION_STRING_P2=...  (Plant 2 Pune)
 *   IOT_HUB_CONNECTION_STRING=...     (single shared hub fallback)
 *
 * Device → plant mapping: deviceId prefix determines plant.
 *   MCH-01..04 → P1,  MCH-05..08 → P2  (CSV-driven via loadMachines())
 */

import { EventHubConsumerClient } from '@azure/event-hubs';
import { broadcast } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { loadMachines, loadSafetyZones, loadPlatformConfig } from '../data/csv-loader';

export interface SensorReading {
  deviceId: string; plantId: string;
  sensorType: 'vibration' | 'temperature' | 'pressure' | 'gas_ppm' | 'current';
  value: number; unit: string; timestamp: string;
  anomaly?: boolean; anomalyScore?: number;
  co?: number; ch4?: number;   // gas_ppm readings carry the secondary gases (H₂S in `value`)
}

// Ring buffer: last 1440 readings per device+sensor combo (= 24 h at 1/min)
const buffers = new Map<string, SensorReading[]>();
const MAX_BUF = 1440;

const key = (deviceId: string, sensorType: string) => `${deviceId}::${sensorType}`;

export function getLatest(deviceId: string, sensorType: string): SensorReading | null {
  const buf = buffers.get(key(deviceId, sensorType));
  return buf?.[buf.length - 1] ?? null;
}

export function getHistory(deviceId: string, sensorType: string, count = 24): SensorReading[] {
  return (buffers.get(key(deviceId, sensorType)) ?? []).slice(-count);
}

// ── Plant resolution (CSV-driven, not hardcoded) ──────────────────────────────
let _plantMap: Map<string, string> | null = null;
function getPlantForDevice(deviceId: string): string {
  if (!_plantMap) {
    _plantMap = new Map();
    try {
      const machines = loadMachines() as Array<{ id: string; plant?: string }>;
      for (const m of machines) {
        if (m.id && m.plant) _plantMap.set(m.id, m.plant);
      }
    } catch { /* fallback below */ }
  }
  return _plantMap.get(deviceId) ?? (deviceId <= 'MCH-04' ? 'P1' : 'P2');
}

// ── Connection string resolution (multi-plant aware) ─────────────────────────
function getConnString(plantId?: string): string | undefined {
  if (plantId) {
    const perPlant = process.env[`IOT_HUB_CONNECTION_STRING_${plantId}`];
    if (perPlant) return perPlant;
  }
  return process.env.IOT_HUB_CONNECTION_STRING;
}

const consumers: EventHubConsumerClient[] = [];

// ── Start ingestion ───────────────────────────────────────────────────────────
export async function startIngestion(): Promise<void> {
  // Collect unique connection strings across all plants
  const connStrings = new Map<string, string>();  // connStr → label
  for (const plantId of ['P1', 'P2']) {
    const cs = getConnString(plantId);
    if (cs) connStrings.set(cs, plantId);
  }
  const shared = process.env.IOT_HUB_CONNECTION_STRING;
  if (shared && !connStrings.has(shared)) connStrings.set(shared, 'shared');

  if (connStrings.size === 0) {
    logger.warn('IOT_HUB_CONNECTION_STRING not set — using simulated sensor data');
    startSimulation();
    return;
  }

  for (const [connStr, label] of connStrings) {
    try {
      const cg = process.env.IOT_HUB_CONSUMER_GROUP ?? '$Default';
      const client = new EventHubConsumerClient(cg, connStr);
      consumers.push(client);
      await client.subscribe({
        processEvents: async (events) => {
          for (const ev of events) {
            const msg = ev.body as SensorReading;
            if (!msg?.deviceId) continue;
            // Resolve plantId from device topology if not in message
            if (!msg.plantId) msg.plantId = getPlantForDevice(msg.deviceId);
            const k = key(msg.deviceId, msg.sensorType);
            const buf = buffers.get(k) ?? [];
            buf.push(msg);
            if (buf.length > MAX_BUF) buf.shift();
            buffers.set(k, buf);
            broadcast('pdm', { type: 'sensor', data: msg });
            if (msg.sensorType === 'gas_ppm' && msg.anomaly) {
              broadcast('safety', { type: 'precursor', data: msg });
            }
          }
        },
        processError: async (err) => {
          logger.error(`IoT Hub [${label}] error`, { error: err.message });
        },
      });
      logger.info(`IoT Hub ingestion started [${label}]`);
    } catch (err) {
      logger.error(`IoT Hub [${label}] connect failed — falling back to simulation`, { error: String(err) });
      startSimulation();
    }
  }
}

// ── Simulation (Phase 1 / fallback) ──────────────────────────────────────────
function startSimulation(): void {
  const allMachines = loadMachines();
  // Simulate all machines (not just critical) so both plants show sensor data
  const assets = allMachines.map((m: any) => ({ id: m.id, plant: m.plant ?? 'P1', vib: Number(m.vib ?? 3.0), temp: Number(m.temp ?? 65), pressure: Number(m.pressure ?? 8.0) }));

  setInterval(() => {
    for (const a of assets) {
      const addNoise = (v: number, pct = 0.03) => +(v + v * (Math.random() - 0.5) * pct).toFixed(2);
      const readings: SensorReading[] = [
        { deviceId: a.id, plantId: a.plant, sensorType: 'vibration',    value: addNoise(a.vib),      unit: 'mm/s',  timestamp: new Date().toISOString(), anomaly: a.vib > 8 },
        { deviceId: a.id, plantId: a.plant, sensorType: 'temperature',  value: addNoise(a.temp),     unit: '°C',    timestamp: new Date().toISOString() },
        { deviceId: a.id, plantId: a.plant, sensorType: 'pressure',     value: addNoise(a.pressure), unit: 'bar',   timestamp: new Date().toISOString() },
      ];
      for (const r of readings) {
        const k = key(r.deviceId, r.sensorType);
        const buf = buffers.get(k) ?? [];
        buf.push(r);
        if (buf.length > MAX_BUF) buf.shift();
        buffers.set(k, buf);
      }
    }
  }, 3500);
  logger.info('IoT Hub simulation mode active (all machines, 3 sensor types)');
  startGasSimulation();
}

// ── Gas detector simulation (per zone) ───────────────────────────────────────
// Emits gas_ppm readings into the SAME ring buffer real detectors would feed via
// Event Hub, so the engine's safety detection consumes one uniform stream. The
// gas excursion (the "spike") is modelled HERE — i.e. in the sensor/physical
// layer — exactly as a real detector would observe it; the engine only DETECTS.
// Spike rate is config-driven (platform_config.csv → sim_thresholds).
function startGasSimulation(): void {
  let zones: any[] = [];
  try { zones = loadSafetyZones() as any[]; } catch { zones = []; }
  if (!zones.length) return;
  let rate = 0.0001;
  try {
    const v = Number((loadPlatformConfig() as any)?.simThresholds?.gas_precursor_rate_per_zone_tick);
    if (Number.isFinite(v)) rate = v;
  } catch { /* fallback */ }
  const ZONE_PLANT: Record<string,string> = {'Zone A':'P1','Zone B':'P1','Zone C':'P2','Zone D':'P2'};
  const cl = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
  const nz = (s: number) => (Math.random() - 0.5) * s;
  type GS = { spiking: boolean; ticks: number; h2s: number; co: number; ch4: number; alarm1: number };
  const st = new Map<string, GS>();
  for (const z of zones) {
    st.set(z.zone, { spiking: false, ticks: 0, h2s: Number(z.h2s) || 1, co: Number(z.co) || 5,
      ch4: Number(z.ch4) || 2, alarm1: Number(z.thresholds?.h2s?.alarm1) || 5 });
  }
  const emit = () => {
    for (const z of zones) {
      const s = st.get(z.zone); if (!s) continue;
      if (s.spiking) {
        s.h2s = cl(s.h2s + nz(0.15) - 0.05, 0, 15);
        s.co  = cl(s.co  + nz(1.0)  - 0.3,  0, 150);
        s.ch4 = cl(s.ch4 + nz(0.5)  - 0.2,  0, 30);
        if (--s.ticks <= 0) { s.spiking = false; s.h2s = cl(s.h2s * 0.4, 0, 3); s.co = cl(s.co * 0.4, 0, 20); s.ch4 = cl(s.ch4 * 0.4, 0, 8); }
      } else {
        s.h2s = cl(s.h2s + nz(0.05), 0, 3);
        s.co  = cl(s.co  + nz(0.8),  0, 30);
        s.ch4 = cl(s.ch4 + nz(0.3),  0, 10);
        if (Math.random() < rate) { s.spiking = true; s.ticks = Math.floor(8 + Math.random() * 10); s.h2s += 1.5 + Math.random() * 2; s.co += 15 + Math.random() * 20; s.ch4 += 5 + Math.random() * 8; }
      }
      const reading: SensorReading = {
        deviceId: z.zone, plantId: ZONE_PLANT[z.zone] ?? 'P1', sensorType: 'gas_ppm',
        value: +s.h2s.toFixed(2), co: +s.co.toFixed(2), ch4: +s.ch4.toFixed(2),
        unit: 'ppm', timestamp: new Date().toISOString(), anomaly: s.spiking || s.h2s >= s.alarm1,
      };
      const k = key(z.zone, 'gas_ppm');
      const buf = buffers.get(k) ?? [];
      buf.push(reading);
      if (buf.length > MAX_BUF) buf.shift();
      buffers.set(k, buf);
      if (reading.anomaly) broadcast('safety', { type: 'precursor', data: reading });
    }
  };
  emit();                                  // seed immediately so the engine has data on its first tick
  setInterval(emit, 10000);                // 10s cadence — matches the rate's calibration
  logger.info(`IoT Hub gas simulation active (${zones.length} zones, rate ${rate}/zone/tick)`);
}

export async function stopIngestion(): Promise<void> {
  for (const c of consumers) await c.close().catch(() => {});
  consumers.length = 0;
}
