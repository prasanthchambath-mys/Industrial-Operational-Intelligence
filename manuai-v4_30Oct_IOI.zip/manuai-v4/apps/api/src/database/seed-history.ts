/**
 * ManuAI — Historical Data Generator
 *
 * Runs ONCE at startup when the database is empty.
 * Generates 30 days of realistic synthetic history backwards from now.
 * History is internally consistent with the live simulation state.
 *
 * Generates ~300,000 records in ~30 seconds.
 */

import { getDb } from './connection';
import { loadMachines, loadUtilities, loadYieldParams, loadEnergyAssets, loadSafetyZones, loadTechnicians } from '../data/csv-loader';
import { logger } from '../middleware/logger';

const DAYS = 30;
// Months 2-6 use coarse daily synthetic data so the 6-Month OEE scorecard,
// loss trend, and other monthly aggregates have real numbers to chart without
// inflating the SQLite file. ~1,440 extra OEE rows total (180 days * 8
// machines, one per machine per day) versus the 70k rows the recent-30-day
// 5-min stream produces.
const EXTENDED_DAYS = 180;
const COARSE_INTERVAL_MS = 24 * 60 * 60 * 1000; // 1 reading per day per machine
const OEE_INTERVAL_MS    = 5  * 60 * 1000;  // every 5 min
const ENERGY_INTERVAL_MS = 30 * 60 * 1000;  // every 30 min
const YIELD_INTERVAL_MS  = 5  * 60 * 1000;  // every 5 min

function noise(scale = 1): number {
  return (Math.random() - 0.5) * 2 * scale;
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

// Epoch-ms timestamps written to the DB must be integers: Postgres BIGINT rejects
// fractional values (e.g. 1780354724290.9558) that SQLite silently tolerated.
// Round to the nearest millisecond — keeps ms precision, only strips the fraction.
// Preserve nulls at call sites (never wrap a nullable value directly — Math.round(null) is 0).
const epochMs = (v: number): number => Math.trunc(v);

// 24-hour demand curve for energy
const DEMAND_CURVE = [
  0.55,0.50,0.46,0.74,0.97,1.02,0.98,1.01,
  1.06,0.91,0.72,0.60,0.55,0.50,0.46,0.74,
  0.97,1.02,0.98,1.01,1.06,0.91,0.72,0.60,
];

export async function seedHistory(): Promise<void> {
  const db = getDb();
  const now = Date.now();
  const startMs = now - DAYS * 24 * 3600 * 1000;

  logger.info('[DB] Seeding 30 days of historical data — this takes ~30 seconds...');

  const machines = loadMachines();
  const utilities = loadUtilities();
  const techName = loadTechnicians()[0]?.name ?? 'Technician';
  const yieldParams = loadYieldParams();
  const energyAssets = loadEnergyAssets();

  // ── Batched multi-row inserters ─────────────────────────────────────────────
  // The 30-day seed produces ~300k rows. On SQLite (in-process) single-row inserts
  // are fine, but on Postgres every insert is a network round-trip, so 300k
  // sequential inserts stall the boot for many minutes. We buffer rows and flush
  // them as multi-row INSERTs (~1000 rows per round-trip), keeping both engines
  // fast. Epoch-ms columns are truncated to integers at the source here, because
  // multi-row inserts bypass the single-row param normalizer in the DB driver.
  await db.transaction(async (tx) => {
    const makeInserter = (table: string, cols: string[], epochIdx: number[], orIgnore = false) => {
      const colSql = cols.join(', ');
      const tuple = '(' + cols.map(() => '?').join(', ') + ')';
      // Cap rows/statement so we stay well under Postgres' 65535-parameter limit.
      const chunkRows = Math.min(1000, Math.max(1, Math.floor(60000 / cols.length)));
      const prefix = orIgnore ? 'INSERT OR IGNORE INTO' : 'INSERT INTO';
      let buf: unknown[] = [];
      let pending = 0;
      let n = 0;
      const flush = async () => {
        if (pending === 0) return;
        const sql = `${prefix} ${table} (${colSql}) VALUES ${Array(pending).fill(tuple).join(', ')}`;
        await tx.run(sql, buf);
        buf = [];
        pending = 0;
      };
      return {
        push: async (row: unknown[]) => {
          for (const i of epochIdx) {
            const v = row[i];
            if (typeof v === 'number' && Number.isFinite(v)) row[i] = Math.trunc(v);
          }
          for (let k = 0; k < row.length; k++) buf.push(row[k]);
          pending++; n++;
          if (pending >= chunkRows) await flush();
        },
        flush,
        get count() { return n; },
      };
    };

    const oeeIns    = makeInserter('oee_readings',    ['plant_id','machine_id','machine_name','line','ts','oee','avail','perf','qual','loss_type','loss_min'], [4]);
    const healthIns = makeInserter('machine_health',  ['plant_id','machine_id','ts','health','rul','vib','temp','pressure','status'], [2]);
    const batchIns  = makeInserter('batches',         ['plant_id','id','product','qty_kg','plan_yield','actual_yield','status','started_at','completed_at'], [7, 8], true);
    const yieldIns  = makeInserter('yield_history',   ['plant_id','param_id','param_name','ts','value','target','warn'], [3]);
    const energyIns = makeInserter('energy_readings', ['plant_id','asset_id','asset_name','ts','kw','anomaly'], [3]);
    const alertIns  = makeInserter('alerts',          ['plant_id','id','machine_id','machine_name','line','type','severity','message','ts','acked','acked_by','acked_at'], [8, 11], true);
    const safetyIns = makeInserter('safety_events',   ['plant_id','id','zone','event_type','severity','h2s','co','ch4','ts','resolved_at'], [8, 9], true);

    logger.info('[DB] seeding time-series: oee_readings, machine_health, alerts (dense 30-day 5-min series)...');

    // ── 1. Machine OEE + Health ────────────────────────────────────────────────
    for (const m of machines) {
      // Each machine starts healthier 30 days ago, degrades to current state
      let health = clamp(m.health + 30 + Math.random() * 20, 40, 99);
      let rul    = clamp(m.rul    + 40 + Math.random() * 30, 10, 200);
      let vib    = clamp(m.vib * 0.5 + Math.random() * 0.5, 0.3, 5);
      let temp   = clamp(m.temp * 0.85 + Math.random() * 5, 35, 75);
      // Pressure starts near current value (30 days back was similar) with mild noise.
      // Walks slowly upward as condition degrades.
      let pressure = clamp(((m as any).pressure ?? 0) * (0.92 + Math.random() * 0.04), 3, 95);

      let ts = startMs;
      let alertCounter = 0;
      let maintenanceUntil = 0;

      while (ts < now) {
        const inMaint = ts < maintenanceUntil;

        if (!inMaint) {
          // Degrade gradually
          health = clamp(health - m._degradeRate * 0.15 + noise(0.08), 5, 99);
          rul    = clamp(rul    - m._degradeRate * 0.06, 1, 200);
          vib    = clamp(vib    + m._degradeRate * 0.004 + noise(0.06), 0.3, 15);
          temp   = clamp(temp   + m._degradeRate * 0.005 + noise(0.4), 35, 105);
          pressure = clamp(pressure + m._degradeRate * 0.003 + noise(0.12), 3, 95);
        } else {
          // During maintenance — recovering
          health = clamp(health + 0.5, 5, 99);
        }

        // OEE components
        const hf   = health / 100;
        const avail = clamp(m.avail * (0.85 + hf * 0.15) + noise(0.4), 40, 99.9);
        const perf  = clamp(m.perf  * (0.88 + hf * 0.12) + noise(0.3), 40, 99.9);
        const qual  = clamp(m.qual  * 0.999 + noise(0.04), 85, 99.9);
        const oee   = +(avail * perf * qual / 10000).toFixed(1);
        const status = health >= 80 ? 'good' : health >= 65 ? 'caution' : health >= 40 ? 'warning' : 'critical';
        // Loss per reading = fraction of reading interval lost to downtime/inefficiency
        // Reading interval ~13 min (30 days of data / 3360 readings per machine)
        // This gives realistic monthly totals (not inflated by 60-min multiplier per tick)
        const readingIntervalMin = (30 * 24 * 60) / 3360; // ~12.9 min
        const lossMin = Math.floor(clamp((1 - hf) * readingIntervalMin + noise(0.5), 0, readingIntervalMin));

        await oeeIns.push([(m as any).plant ?? 'P1', m.id, m.name, m.line, ts, oee, +avail.toFixed(1), +perf.toFixed(1), +qual.toFixed(1), m.loss, lossMin]);
        await healthIns.push([(m as any).plant ?? 'P1', m.id, ts, +health.toFixed(1), +rul.toFixed(1), +vib.toFixed(1), +temp.toFixed(0), +pressure.toFixed(1), status]);

        // Auto-maintenance trigger at low health
        if (health < 20 && ts > maintenanceUntil + 48 * 3600000) {
          maintenanceUntil = ts + (2 + Math.random() * 3) * 3600000;
          health = clamp(health + 35 + noise(5), 55, 90);
          rul    = Math.floor(50 + Math.random() * 60);

          // Alert for maintenance trigger
          const alertId = `ALT-${m.id}-${alertCounter++}`;
          const acked = Math.random() > 0.2;
          const ackedAt = acked ? ts + Math.floor(Math.random() * 3600000) : null;
          await alertIns.push([
            (m as any).plant ?? 'P1', alertId, m.id, m.name, m.line,
            'Unplanned Breakdown', 'critical',
            `${m.name}: Health ${health.toFixed(0)}%, RUL ${rul.toFixed(0)}d. Auto-maintenance triggered.`,
            ts, acked ? 1 : 0, acked ? techName : null, ackedAt
          ]);
        }

        // Occasional warning alerts
        if (status === 'warning' && Math.random() < 0.002) {
          const alertId = `ALT-${m.id}-W${alertCounter++}`;
          await alertIns.push([
            (m as any).plant ?? 'P1', alertId, m.id, m.name, m.line,
            'Speed Loss', 'warning',
            `${m.name}: Speed loss detected. OEE ${oee}%.`,
            ts, 1, 'Supervisor', ts + 1800000
          ]);
        }

        ts += OEE_INTERVAL_MS;
      }
    }

    // ── 1a. Utility health history ───────────────────────────────────────────
    // Utilities (compressors, chillers) are monitored PdM assets and can be
    // critical (e.g. Air Compressor A1). They were previously omitted from the
    // health table, so a critical utility appeared in the RUL cards/legend but
    // its trend line had no data and never rendered. Seed the same 5-min health
    // series machines get (no OEE — utilities have no OEE) so the line plots and
    // aligns index-for-index with the machine series the chart merges against.
    for (const u of utilities) {
      let uHealth = clamp(u.health + 30 + Math.random() * 20, 40, 99);
      let uRul    = clamp(u.rul    + 40 + Math.random() * 30, 10, 200);
      let uVib    = clamp(u.vib * 0.5 + Math.random() * 0.5, 0.3, 5);
      let uTemp   = clamp(u.temp * 0.85 + Math.random() * 5, 35, 105);
      let uPress  = clamp((u.press ?? 5) * (0.92 + Math.random() * 0.04), 3, 95);
      let ts = startMs;
      let uMaintUntil = 0;
      while (ts < now) {
        if (ts >= uMaintUntil) {
          uHealth = clamp(uHealth - u._degradeRate * 0.15 + noise(0.08), 5, 99);
          uRul    = clamp(uRul    - u._degradeRate * 0.06, 1, 200);
          uVib    = clamp(uVib    + u._degradeRate * 0.004 + noise(0.06), 0.3, 15);
          uTemp   = clamp(uTemp   + u._degradeRate * 0.005 + noise(0.4), 35, 110);
          uPress  = clamp(uPress  + u._degradeRate * 0.003 + noise(0.12), 3, 95);
        } else {
          uHealth = clamp(uHealth + 0.5, 5, 99);
        }
        const uStatus = uHealth >= 80 ? 'good' : uHealth >= 65 ? 'caution' : uHealth >= 40 ? 'warning' : 'critical';
        await healthIns.push([u.plant ?? 'P1', u.id, ts, +uHealth.toFixed(1), +uRul.toFixed(1), +uVib.toFixed(1), +uTemp.toFixed(0), +uPress.toFixed(1), uStatus]);
        // Recover after deep degradation so the series mirrors the live engine
        if (uHealth < 20 && ts > uMaintUntil + 48 * 3600000) {
          uMaintUntil = ts + (2 + Math.random() * 3) * 3600000;
        }
        ts += OEE_INTERVAL_MS;
      }
    }

    // Generates one synthetic OEE reading per machine per day, covering the
    // 150 days BEFORE the recent 30-day window. Gives the 6-Month OEE Trend
    // scorecard real monthly aggregates without inflating the DB.
    // Story: pre-agent baseline (Dec/Jan) is lower; OEE trends upward as the
    // AI platform gets deployed (Feb onward) reaching the current 30-day
    // average. Random walk between months keeps the chart visually interesting.
    const extendedStartMs = startMs - (EXTENDED_DAYS - DAYS) * 24 * 3600 * 1000;
    const extendedEndMs = startMs - COARSE_INTERVAL_MS; // stop just before recent window starts
    for (const m of machines) {
      // Each machine's monthly trajectory: 5-8% below current at start, rising
      // toward current OEE by the time we hit the recent-30-day window.
      const targetOee = Number(m.oee);
      const startOeeDelta = -(5 + Math.random() * 3); // start 5-8% below
      let curOee = clamp(targetOee + startOeeDelta + noise(2), 40, 99);
      let ts = extendedStartMs;
      let dayIdx = 0;
      const totalDays = EXTENDED_DAYS - DAYS;
      while (ts < extendedEndMs) {
        // Linear interpolation toward target with noise — gives smooth trend
        const progress = dayIdx / Math.max(1, totalDays);
        const driftToTarget = (targetOee - curOee) * 0.04; // slow drift
        curOee = clamp(curOee + driftToTarget + noise(0.8), 40, 99);
        const seasonalOee = curOee + (progress < 0.5 ? -1 : 0.5); // pre-agent slightly worse
        // A, P, Q derived to multiply ~= OEE
        const avail = clamp(Math.sqrt(seasonalOee / 100) * 95 + noise(1), 60, 99);
        const perf  = clamp(Math.sqrt(seasonalOee / 100) * 96 + noise(1), 60, 99);
        const qual  = clamp(98 + noise(0.5), 94, 99.9);
        const oee   = +(avail * perf * qual / 10000).toFixed(1);
        const status = oee >= 80 ? 'good' : oee >= 65 ? 'caution' : oee >= 40 ? 'warning' : 'critical';
        const health = clamp(50 + progress * 40 + noise(5), 25, 95);
        const rul    = clamp(40 + progress * 80 + noise(10), 5, 200);
        // Loss is small daily-aggregate value (not 12.9min like the dense seed)
        const lossMin = Math.floor(clamp((1 - oee/100) * 20 + noise(3), 0, 25));
        await oeeIns.push([(m as any).plant ?? 'P1', m.id, m.name, m.line, ts, oee, +avail.toFixed(1), +perf.toFixed(1), +qual.toFixed(1), m.loss, lossMin]);
        await healthIns.push([(m as any).plant ?? 'P1', m.id, ts, +health.toFixed(1), +rul.toFixed(1), 1.5, 60, ((m as any).pressure ?? 5), status]);
        ts += COARSE_INTERVAL_MS;
        dayIdx++;
      }
    }

    await oeeIns.flush(); await healthIns.flush(); await alertIns.flush();
    logger.info(`[DB]   done oee_readings: ${oeeIns.count} rows`);
    logger.info(`[DB]   done machine_health: ${healthIns.count} rows`);
    logger.info(`[DB]   done alerts: ${alertIns.count} rows`);
    logger.info('[DB] seeding batches...');
    // ── 2. Production batches ─────────────────────────────────────────────────
    // Products keyed by plant — P1: reactor-based, P2: polymer-based
    const P1_PRODUCTS = [
      { name: 'Compound X-12 Grade A', plant: 'P1', plan_base: 91 },
      { name: 'Compound Y-07 Grade B', plant: 'P1', plan_base: 89.5 },
    ];
    const P2_PRODUCTS = [
      { name: 'Compound Z-04 Grade S', plant: 'P2', plan_base: 87 },
      { name: 'Polymer Blend PB-7',    plant: 'P2', plan_base: 85.5 },
    ];
    const ALL_PRODUCTS = [...P1_PRODUCTS, ...P2_PRODUCTS];
    const durations = [6, 7, 8, 4]; // hours
    let batchTs = startMs;
    let batchCounter = 88300;
    // Round-robin product index so every plant gets daily batch coverage.
    // Random selection caused some days to have zero batches from one plant,
    // returning NULL avg_yield for that day → broken Yield line in the cross-agent
    // correlation chart when the plant filter was applied.
    let prodIdx = 0;

    while (batchTs < now) {
      const prod = ALL_PRODUCTS[prodIdx % ALL_PRODUCTS.length];
      prodIdx++;
      const qty = [900, 1800, 2400][Math.floor(Math.random() * 3)];
      const plan = +(prod.plan_base + (Math.random() - 0.5) * 2).toFixed(1);
      const durationMs = durations[Math.floor(Math.random() * durations.length)] * 3600000;
      const completedAt = epochMs(batchTs + durationMs);
      const isCompleted = completedAt < now;
      const actual = isCompleted ? +(plan * (0.94 + Math.random() * 0.08)).toFixed(1) : null;

      await batchIns.push([
        prod.plant, `PP-${batchCounter++}`, prod.name, qty, plan, actual,
        isCompleted ? 'completed' : 'in_process',
        epochMs(batchTs), isCompleted ? epochMs(completedAt) : null
      ]);

      // Gap between batches (30min to 2hr). The gap term is fractional, so
      // normalise the running cursor back to integer ms each iteration — otherwise
      // started_at/completed_at drift into decimals that Postgres BIGINT rejects.
      batchTs = epochMs(batchTs + durationMs + (0.5 + Math.random() * 1.5) * 3600000);
    }

    await batchIns.flush();
    logger.info(`[DB]   done batches: ${batchIns.count} rows`);
    logger.info('[DB] seeding yield_history...');
    // ── 3. Yield parameters ───────────────────────────────────────────────────
    for (const p of yieldParams) {
      let val = p.tgt + noise((p.max - p.min) * 0.05);
      let ts = startMs;

      while (ts < now) {
        const correction = (val - p.tgt) * -0.015;
        val = clamp(val + p._driftRate * p._driftDir * 0.08 + correction + noise(p._driftRate * 0.04), p.min, p.max);
        const warn = Math.abs(val - p.tgt) / (p.max - p.min) > 0.06;

        await yieldIns.push([(p as any).plant ?? 'P1', p.id, p.name, ts, +val.toFixed(2), p.tgt, warn ? 1 : 0]);
        ts += YIELD_INTERVAL_MS;
      }
    }

    await yieldIns.flush();
    logger.info(`[DB]   done yield_history: ${yieldIns.count} rows`);
    logger.info('[DB] seeding energy_readings...');
    // ── 4. Energy readings ────────────────────────────────────────────────────
    for (const a of energyAssets) {
      let ts = startMs;
      while (ts < now) {
        const hour = new Date(ts).getHours();
        const kw = +(a._baseKw * DEMAND_CURVE[hour] + noise(a._baseKw * 0.06)).toFixed(0);
        const anomaly = kw > a._baseKw * 1.12 ? 1 : 0;
        await energyIns.push([(a as any).plant ?? 'P1', a.id, a.name, ts, kw, anomaly]);
        ts += ENERGY_INTERVAL_MS;
      }
    }

    await energyIns.flush();
    logger.info(`[DB]   done energy_readings: ${energyIns.count} rows`);
    logger.info('[DB] seeding safety_events...');
    // ── 5. Safety events ──────────────────────────────────────────────────────
    const zones = ['Zone A', 'Zone B', 'Zone C', 'Zone D'];
    let safetyCounter = 1;

    for (let day = 0; day < DAYS; day++) {
      // ~2 events per day randomly
      const numEvents = Math.random() < 0.3 ? 0 : Math.random() < 0.6 ? 1 : 2;
      for (let e = 0; e < numEvents; e++) {
        const zone = zones[Math.floor(Math.random() * zones.length)];
        const ts = startMs + day * 86400000 + Math.floor(Math.random() * 86400000);
        const sev = Math.random() < 0.2 ? 'critical' : Math.random() < 0.5 ? 'high' : 'medium';
        // Always resolve seeded historical events — they represent past incidents,
        // not live ones. Leaving resolvedAt=null caused them to appear as open
        // in the dashboard on every fresh start, inflating the open count.
        const resolvedAt = ts + Math.floor((0.5 + Math.random() * 2) * 3600000);
        const h2s  = sev === 'critical' ? 2 + Math.random() * 8 : Math.random() * 2;
        const co   = sev === 'critical' ? 30 + Math.random() * 50 : Math.random() * 20;
        const ch4  = sev === 'critical' ? 8 + Math.random() * 15 : Math.random() * 5;

        await safetyIns.push([
          ({'Zone A':'P1','Zone B':'P1','Zone C':'P2','Zone D':'P2'} as Record<string,string>)[zone] ?? 'P1',
          `SEV-${String(safetyCounter++).padStart(4,'0')}`,
          zone, 'Gas precursor', sev,
          +h2s.toFixed(2), +co.toFixed(2), +ch4.toFixed(2),
          ts, resolvedAt  // always resolved — historical data, not live
        ]);
      }
    }

    await safetyIns.flush();
    logger.info(`[DB]   done safety_events: ${safetyIns.count} rows`);
  });


  const oeeCount = ((await db.prepare('SELECT COUNT(*) as c FROM oee_readings').get()) as { c: number }).c;
  const batchCount = ((await db.prepare('SELECT COUNT(*) as c FROM batches').get()) as { c: number }).c;
  const alertCount = ((await db.prepare('SELECT COUNT(*) as c FROM alerts').get()) as { c: number }).c;

  logger.info(`[DB] History seeded — ${oeeCount} OEE readings, ${batchCount} batches, ${alertCount} alerts`);
}
