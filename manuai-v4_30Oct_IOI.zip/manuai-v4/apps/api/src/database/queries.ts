/**
 * ManuAI — Database Queries
 * All historical data queries in one place.
 * Same queries work on Azure SQL in Phase 2 — just change DATABASE_URL.
 */

import { getDb } from './connection';

// Max rows returned per trend query. Charts render at most ~100–200 points;
// returning thousands of raw rows wastes bandwidth and slows rendering.
// 288 = one reading per 5 min over 24 hrs — enough for any chart granularity.
const TREND_LIMIT = 288;

// ── OEE ───────────────────────────────────────────────────────────────────────

export async function getOeeTrend(machineId: string, days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return await getDb().prepare(`
    SELECT datetime(ts/1000, 'unixepoch') as time, oee, avail, perf, qual, ts
    FROM oee_readings
    WHERE machine_id = ? AND ts >= ?
    ORDER BY ts ASC
    LIMIT ${TREND_LIMIT}
  `).all(machineId, since) as Array<{ time: string; oee: number; avail: number; perf: number; qual: number; ts: number }>;
}

export async function getPlantOeeTrend(days = 30, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const pidSql = plant && plant !== 'All Plants' ? ' AND o.plant_id = ?' : '';
  const pidArg = (plant && plant !== 'All Plants') ? plant : null;
  // Replaced correlated sub-queries (ran 2 full-table scans PER DAY row = 60+
  // sub-queries for a 30-day window) with a single-pass GROUP BY. Health and
  // yield are pre-aggregated per day in CTEs then LEFT JOINed — one pass each.
  const plantFilter = pidArg ? `AND plant_id = '${pidArg}'` : '';
  return await getDb().prepare(`
    WITH day_oee AS (
      SELECT strftime('%Y-%m-%d', datetime(ts/1000,'unixepoch')) as day,
        AVG(oee) as avg_oee, MIN(oee) as min_oee, MAX(oee) as max_oee,
        AVG(avail) as avg_avail, AVG(perf) as avg_perf, AVG(qual) as avg_qual
      FROM oee_readings o
      WHERE ts >= ? ${pidSql}
      GROUP BY day
    ),
    day_health AS (
      SELECT strftime('%Y-%m-%d', datetime(ts/1000,'unixepoch')) as day,
        AVG(health) as avg_health
      FROM machine_health
      WHERE ts >= ? ${plantFilter}
      GROUP BY day
    ),
    day_yield AS (
      SELECT strftime('%Y-%m-%d', datetime(started_at/1000,'unixepoch')) as day,
        AVG(actual_yield) as avg_yield
      FROM batches
      WHERE started_at >= ? AND actual_yield > 0 ${plantFilter}
      GROUP BY day
    )
    SELECT o.day, o.avg_oee, o.min_oee, o.max_oee,
           o.avg_avail, o.avg_perf, o.avg_qual,
           h.avg_health, y.avg_yield
    FROM day_oee o
    LEFT JOIN day_health h ON h.day = o.day
    LEFT JOIN day_yield  y ON y.day = o.day
    ORDER BY o.day ASC
  `).all(...[
    since, ...(pidArg ? [pidArg] : []),  // day_oee filter
    since,                                // day_health filter
    since,                                // day_yield filter
  ]) as Array<{ day: string; avg_oee: number; min_oee: number; max_oee: number; avg_avail: number; avg_perf: number; avg_qual: number; avg_health: number | null; avg_yield: number | null }>;
}

export async function getOeeSummary(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return await getDb().prepare(`
    SELECT
      machine_id,
      machine_name,
      line,
      AVG(oee)       as avg_oee,
      MIN(oee)       as min_oee,
      MAX(oee)       as max_oee,
      SUM(loss_min)  as total_loss_min
    FROM oee_readings
    WHERE ts >= ?
    GROUP BY machine_id
    ORDER BY avg_oee ASC
  `).all(since) as Array<{ machine_id: string; machine_name: string; line: string; avg_oee: number; min_oee: number; max_oee: number; total_loss_min: number }>;
}

// ── Machine Health ─────────────────────────────────────────────────────────────

export async function getHealthTrend(machineId: string, days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  // For short windows (sensor feed = 1-2 days) the raw 5-min rows are exactly
  // what the caller wants. Multi-day RUL trend charts use getHealthTrendDaily
  // instead, which averages to ~1 point/day. Keep LIMIT to bound the response.
  return await getDb().prepare(`
    SELECT datetime(ts/1000, 'unixepoch') as time,
           health, rul, vib, temp, pressure, status, ts
    FROM machine_health
    WHERE machine_id = ? AND ts >= ?
    ORDER BY ts ASC
    LIMIT ${TREND_LIMIT}
  `).all(machineId, since) as Array<{ time: string; health: number; rul: number; vib: number; temp: number; pressure: number; status: string; ts: number }>;
}

// Daily-granularity RUL trend for the multi-day "RUL Trend - At-Risk Assets"
// chart. Returns ~1 row per day across the full window (averaged per calendar
// day) so the LineChart draws a continuous line rather than one dot per series.
export async function getHealthTrendDaily(machineId: string, days = 14) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const rows = await getDb().prepare(`
    SELECT
      date(ts/1000, 'unixepoch')         as day,
      MIN(ts)                            as ts,
      AVG(rul)                           as rul,
      AVG(health)                        as health,
      AVG(vib)                           as vib,
      AVG(temp)                          as temp
    FROM machine_health
    WHERE machine_id = ? AND ts >= ?
    GROUP BY day
    ORDER BY day ASC
    LIMIT 60
  `).all(machineId, since) as Array<{ day: string; ts: number; rul: number; health: number; vib: number; temp: number }>;
  // Rounding happens here, not in SQL: PostgreSQL has no round(double precision, integer), SQLite does.
  return rows.map(r => ({ ...r, ts: Number(r.ts), rul: Math.round(Number(r.rul)), health: Math.round(Number(r.health)),
                          vib: Math.round(Number(r.vib) * 100) / 100, temp: Math.round(Number(r.temp)) }));
}

export async function getAllHealthSummary() {
  const since = Date.now() - 7 * 24 * 3600 * 1000; // last 7 days
  return await getDb().prepare(`
    SELECT
      machine_id,
      AVG(health) as avg_health,
      MIN(health) as min_health,
      AVG(vib)    as avg_vib,
      MAX(vib)    as max_vib,
      AVG(temp)   as avg_temp
    FROM machine_health
    WHERE ts >= ?
    GROUP BY machine_id
  `).all(since) as Array<{ machine_id: string; avg_health: number; min_health: number; avg_vib: number; max_vib: number; avg_temp: number }>;
}

// ── Twin actuals (live, from DB) ───────────────────────────────────────────────
// Returns the latest live "actual" reading for the twin KPIs whose value exists
// in the DB. The twin compares these against its (computed) predicted values.
// KPIs not sourced here (e.g. conveyor speed, coolant flow) fall back to CSV in
// the route. This is what makes divergence real: the actual side now moves with
// the simulation engine's writes instead of being a frozen CSV constant.
export async function getTwinActuals(): Promise<Record<string, number>> {
  const out: Record<string, number> = {};
  const db = getDb();
  // Latest machine_health row per machine (vib + temp) — powers vibration and
  // temperature twin KPIs.
  try {
    const healthRows = await db.prepare(`
      SELECT mh.machine_id, mh.vib, mh.temp
      FROM machine_health mh
      JOIN (SELECT machine_id, MAX(ts) AS mts FROM machine_health GROUP BY machine_id) last
        ON mh.machine_id = last.machine_id AND mh.ts = last.mts
    `).all() as Array<{ machine_id: string; vib: number; temp: number }>;
    const byMachine = new Map(healthRows.map(r => [r.machine_id, r]));
    if (byMachine.get('MCH-06')) out['MCH06_VIBRATION'] = +byMachine.get('MCH-06')!.vib.toFixed(2);
    if (byMachine.get('MCH-01')) out['REACTOR_TEMP']    = +byMachine.get('MCH-01')!.temp.toFixed(1);
    if (byMachine.get('MCH-03')) out['MCH03_TEMP']      = +byMachine.get('MCH-03')!.temp.toFixed(1);
  } catch { /* table may be empty pre-seed; route falls back to CSV */ }
  // Plant OEE — average of latest-day OEE across machines.
  try {
    const since = Date.now() - 24 * 3600 * 1000;
    const oee = await db.prepare(`SELECT AVG(oee) AS avg_oee FROM oee_readings WHERE ts >= ?`).get(since) as { avg_oee: number } | undefined;
    if (oee && oee.avg_oee != null) out['PLANT_OEE'] = +Number(oee.avg_oee).toFixed(1);
  } catch { /* fall back to CSV */ }
  // Plant energy intensity (kWh/unit) — derive from energy + OEE if available.
  // Kept conservative: only emit if energy_readings has data.
  try {
    const since = Date.now() - 24 * 3600 * 1000;
    const en = await db.prepare(`SELECT AVG(kw) AS avg_kw FROM energy_readings WHERE ts >= ?`).get(since) as { avg_kw: number } | undefined;
    if (en && en.avg_kw != null) {
      // Approximate intensity index off the live average draw (demo-scale).
      out['PLANT_ENERGY'] = +(Number(en.avg_kw) / 240).toFixed(2);
    }
  } catch { /* fall back to CSV */ }
  return out;
}

// Live per-asset snapshot (OEE / health / RUL / vib / temp) for pre-filling the
// what-if scenario parameters. Joins the latest oee_readings + machine_health row
// per machine. CSV machine list is the fallback if the DB is empty.
export async function getAssetLiveSnapshot(plant?: string): Promise<Array<{ machine_id: string; name: string; line: string; plant: string; oee: number; health: number; rul: number; vib: number; temp: number }>> {
  const db = getDb();
  const hasPlant = plant && plant !== 'All Plants';
  try {
    // Latest health row per machine — plant filter applied to BOTH subquery and outer query.
    const health = hasPlant
      ? (await db.prepare(`
          SELECT mh.machine_id, mh.plant_id, mh.health, mh.rul, mh.vib, mh.temp
          FROM machine_health mh
          JOIN (SELECT machine_id, MAX(ts) AS mts FROM machine_health WHERE plant_id = ? GROUP BY machine_id) last
            ON mh.machine_id = last.machine_id AND mh.ts = last.mts
          WHERE mh.plant_id = ?
        `).all(plant, plant) as Array<{ machine_id: string; plant_id: string; health: number; rul: number; vib: number; temp: number }>)
      : (await db.prepare(`
          SELECT mh.machine_id, mh.plant_id, mh.health, mh.rul, mh.vib, mh.temp
          FROM machine_health mh
          JOIN (SELECT machine_id, MAX(ts) AS mts FROM machine_health GROUP BY machine_id) last
            ON mh.machine_id = last.machine_id AND mh.ts = last.mts
        `).all() as Array<{ machine_id: string; plant_id: string; health: number; rul: number; vib: number; temp: number }>);
    // Latest-day avg OEE per machine — plant filter applied here too.
    const since = Date.now() - 24 * 3600 * 1000;
    const oeeRows = hasPlant
      ? (await db.prepare(`
          SELECT machine_id, machine_name, line, AVG(oee) AS oee
          FROM oee_readings WHERE ts >= ? AND plant_id = ? GROUP BY machine_id
        `).all(since, plant) as Array<{ machine_id: string; machine_name: string; line: string; oee: number }>)
      : (await db.prepare(`
          SELECT machine_id, machine_name, line, AVG(oee) AS oee
          FROM oee_readings WHERE ts >= ? GROUP BY machine_id
        `).all(since) as Array<{ machine_id: string; machine_name: string; line: string; oee: number }>);
    const oeeIdx = new Map(oeeRows.map(r => [r.machine_id, r]));
    const out = health.map(h => {
      const o = oeeIdx.get(h.machine_id);
      return {
        machine_id: h.machine_id,
        name: o?.machine_name ?? h.machine_id,
        line: o?.line ?? '',
        plant: h.plant_id,
        oee: o ? +Number(o.oee).toFixed(1) : 0,
        health: +Number(h.health).toFixed(0),
        rul: +Number(h.rul).toFixed(0),
        vib: +Number(h.vib).toFixed(1),
        temp: +Number(h.temp).toFixed(1),
      };
    });
    if (out.length) return out;
  } catch { /* fall through to CSV */ }
  return [];
}

// ── Alerts ─────────────────────────────────────────────────────────────────────

export async function getAlertHistory(days = 30, severity?: string) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const query = severity
    ? `SELECT * FROM alerts WHERE ts >= ? AND severity = ? ORDER BY ts DESC LIMIT 200`
    : `SELECT * FROM alerts WHERE ts >= ? ORDER BY ts DESC LIMIT 200`;
  const params = severity ? [since, severity] : [since];
  return await getDb().prepare(query).all(...params) as Array<{
    id: string; machine_id: string; machine_name: string; line: string;
    type: string; severity: string; message: string; ts: number;
    acked: number; acked_by: string; acked_at: number;
  }>;
}

export async function getAlertStats(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return await getDb().prepare(`
    SELECT
      severity,
      COUNT(*) as total,
      SUM(acked) as acked,
      COUNT(*) - SUM(acked) as open
    FROM alerts
    WHERE ts >= ?
    GROUP BY severity
  `).all(since) as Array<{ severity: string; total: number; acked: number; open: number }>;
}

// ── Batches ────────────────────────────────────────────────────────────────────

export async function getBatchHistory(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return await getDb().prepare(`
    SELECT *,
      datetime(started_at/1000, 'unixepoch') as start_time,
      datetime(completed_at/1000, 'unixepoch') as end_time
    FROM batches
    WHERE started_at >= ?
    ORDER BY started_at DESC
    LIMIT 100
  `).all(since) as Array<{
    id: string; product: string; qty_kg: number; plan_yield: number;
    actual_yield: number; status: string; started_at: number; completed_at: number;
    start_time: string; end_time: string;
  }>;
}

export async function getBatchStats(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return await getDb().prepare(`
    SELECT
      product,
      COUNT(*) as total_batches,
      AVG(plan_yield)   as avg_plan,
      AVG(actual_yield) as avg_actual,
      MIN(actual_yield) as min_yield,
      MAX(actual_yield) as max_yield
    FROM batches
    WHERE started_at >= ? AND status = 'completed'
    GROUP BY product
  `).all(since) as Array<{ product: string; total_batches: number; avg_plan: number; avg_actual: number; min_yield: number; max_yield: number }>;
}

// ── Yield Params ──────────────────────────────────────────────────────────────

export async function getYieldParamTrend(paramId: string, days = 7) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return await getDb().prepare(`
    SELECT
      datetime(ts/1000, 'unixepoch') as time,
      value, target, warn, ts
    FROM yield_history
    WHERE param_id = ? AND ts >= ?
    ORDER BY ts ASC
  `).all(paramId, since) as Array<{ time: string; value: number; target: number; warn: number; ts: number }>;
}

// ── Energy ────────────────────────────────────────────────────────────────────

export async function getEnergyTrend(days = 30, plant?: string) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const plantSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const plantArg = plant && plant !== 'All Plants' ? plant : null;
  return await getDb().prepare(`
    SELECT
      strftime('%Y-%m-%d', datetime(ts/1000, 'unixepoch')) as day,
      SUM(kw)  as total_kw,
      AVG(kw)  as avg_kw,
      SUM(anomaly) as anomalies
    FROM energy_readings
    WHERE ts >= ?` + plantSql + `
    GROUP BY day
    ORDER BY day ASC
  `).all(...[since, ...(plantArg ? [plantArg] : [])]) as Array<{ day: string; total_kw: number; avg_kw: number; anomalies: number }>;
}

// Instantaneous plant load over the last 24h, bucketed by hour.
// "Plant load" = sum of all assets' kw AT A GIVEN TIMESTAMP (instantaneous draw),
// then averaged across the timestamps within each hour. The older getEnergyTrend
// summed kw across an entire DAY (every asset x every 5-min reading), which
// inflated the figure ~100x (e.g. 170,000 kW vs the real ~1,100 kW plant draw).
export async function getEnergyLoad24h(plant?: string) {
  const since = Date.now() - 24 * 3600 * 1000;
  const plantSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const plantArg = plant && plant !== 'All Plants' ? plant : null;
  // Step 1: per-timestamp plant total (sum across assets at that instant).
  // Step 2: average those instantaneous totals within each clock hour.
  return await getDb().prepare(`
    SELECT hour, AVG(plant_kw) AS kw, SUM(ts_anom) AS anomalies
    FROM (
      SELECT
        strftime('%H:00', datetime(ts/1000, 'unixepoch')) AS hour,
        ts,
        SUM(kw)      AS plant_kw,
        MAX(anomaly) AS ts_anom
      FROM energy_readings
      WHERE ts >= ?` + plantSql + `
      GROUP BY ts
    )
    GROUP BY hour
    ORDER BY hour ASC
  `).all(...[since, ...(plantArg ? [plantArg] : [])]) as Array<{ hour: string; kw: number; anomalies: number }>;
}

export async function getEnergyByAsset(days = 7, plant?: string) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const plantSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const plantArg = plant && plant !== 'All Plants' ? plant : null;
  return await getDb().prepare(`
    SELECT
      asset_id,
      asset_name,
      AVG(kw)  as avg_kw,
      MAX(kw)  as peak_kw,
      SUM(anomaly) as anomaly_count
    FROM energy_readings
    WHERE ts >= ?` + plantSql + `
    GROUP BY asset_id
    ORDER BY avg_kw DESC
  `).all(...[since, ...(plantArg ? [plantArg] : [])]) as Array<{ asset_id: string; asset_name: string; avg_kw: number; peak_kw: number; anomaly_count: number }>;
}

// ── Safety ────────────────────────────────────────────────────────────────────

export async function getSafetyEventHistory(days = 30, plant?: string) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const plantSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const plantArg = plant && plant !== 'All Plants' ? plant : null;
  return await getDb().prepare(`
    SELECT *,
      datetime(ts/1000, 'unixepoch') as event_time,
      CASE WHEN resolved_at IS NOT NULL
        THEN ROUND((resolved_at - ts) / 60000.0, 0)
        ELSE NULL
      END as resolution_min
    FROM safety_events
    WHERE ts >= ?` + plantSql + `
    ORDER BY ts DESC
    LIMIT 100
  `).all(...[since, ...(plantArg ? [plantArg] : [])]) as Array<{
    id: string; zone: string; event_type: string; severity: string;
    h2s: number; co: number; ch4: number; ts: number; resolved_at: number;
    event_time: string; resolution_min: number;
  }>;
}

export async function getSafetyStats(days = 30) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  return await getDb().prepare(`
    SELECT
      severity,
      COUNT(*) as total,
      SUM(CASE WHEN resolved_at IS NOT NULL THEN 1 ELSE 0 END) as resolved,
      AVG(CASE WHEN resolved_at IS NOT NULL
        THEN (resolved_at - ts) / 60000.0
        ELSE NULL END) as avg_resolution_min
    FROM safety_events
    WHERE ts >= ?
    GROUP BY severity
  `).all(since) as Array<{ severity: string; total: number; resolved: number; avg_resolution_min: number }>;
}

// Monthly OEE grouped by line-cluster (Issue 14: real data split, not fabricated offset)
export async function getMonthlyOeeByLineGroup(days = 180, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const plantSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const args: any[] = [since, ...(plant && plant !== 'All Plants' ? [plant] : [])];
  return await getDb().prepare(`
    SELECT
      strftime('%Y-%m', ts/1000, 'unixepoch') as month,
      CASE WHEN plant_id = 'P1' THEN 'g1' ELSE 'g2' END as grp,
      AVG(oee) as avg_oee
    FROM oee_readings
    WHERE ts >= ?${plantSql}
    GROUP BY month, grp
    ORDER BY month ASC
  `).all(...args) as Array<{ month: string; grp: string; avg_oee: number }>;
}

// Issue fix: real per-category loss aggregation (Six Big Losses were fabricated
// from fixed config weights; oee_readings has actual loss_type + loss_min)
// V37: signature now takes a sinceMs Unix timestamp directly (was `days = 30`)
// so the caller controls the time window. The six-losses tile banner says
// "Today" — that means since today's 00:00, not "last 30 days". When the
// banner and the loss-trend chart's rightmost bar should equal each other,
// they must use the same time window.
export async function getLossByType(sinceMs: number, plant = 'All Plants') {
  const lossSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const lossArg = plant && plant !== 'All Plants' ? plant : null;
  return await getDb().prepare(`
    SELECT loss_type,
           SUM(loss_min) as total_min,
           COUNT(DISTINCT machine_id) as machine_cnt,
           GROUP_CONCAT(DISTINCT machine_id) as machines
    FROM oee_readings
    WHERE ts >= ? AND loss_type IS NOT NULL AND loss_min > 0` + lossSql + `
    GROUP BY loss_type
    ORDER BY total_min DESC
  `).all(...[sinceMs, ...(lossArg ? [lossArg] : [])]) as Array<{ loss_type: string; total_min: number; machine_cnt: number; machines: string }>;
}

export async function getWeeklyLossByType(days = 42, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const weekLossSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const weekLossArg = plant && plant !== 'All Plants' ? plant : null;
  return await getDb().prepare(`
    SELECT strftime('%Y-%W', datetime(ts/1000, 'unixepoch')) as wk,
           loss_type,
           SUM(loss_min) as total_min
    FROM oee_readings
    WHERE ts >= ? AND loss_type IS NOT NULL AND loss_min > 0` + weekLossSql + `
    GROUP BY wk, loss_type
    ORDER BY wk ASC
  `).all(...[since, ...(weekLossArg ? [weekLossArg] : [])]) as Array<{ wk: string; loss_type: string; total_min: number }>;
}

// V32: daily loss aggregation for the 7-day Loss Trend chart on the OEE
// agent's Six Big Losses tab. The chart's title says "7 Days" but the
// previous implementation used weekly buckets — this returns one row per
// (day, loss_type) pair so the bar chart actually shows 7 daily bars.
export async function getDailyLossByType(days = 7, plant = 'All Plants') {
  const since = Date.now() - days * 24 * 3600 * 1000;
  const dayLossSql = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const dayLossArg = plant && plant !== 'All Plants' ? plant : null;
  return await getDb().prepare(`
    SELECT strftime('%Y-%m-%d', datetime(ts/1000, 'unixepoch')) as day,
           loss_type,
           SUM(loss_min) as total_min
    FROM oee_readings
    WHERE ts >= ? AND loss_type IS NOT NULL AND loss_min > 0` + dayLossSql + `
    GROUP BY day, loss_type
    ORDER BY day ASC
  `).all(...[since, ...(dayLossArg ? [dayLossArg] : [])]) as Array<{ day: string; loss_type: string; total_min: number }>;
}

// Issue fix: real per-shift OEE by hour-of-day bucket (was plantAvg x invented factor)
export async function getOeeByHourRange(startHour: number, endHour: number, days = 7) {
  const since = Date.now() - days * 24 * 3600 * 1000;
  // Handles overnight shifts (e.g. 22 -> 06) via OR
  const cond = startHour < endHour
    ? "CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) >= ? AND CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) < ?"
    : "(CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) >= ? OR CAST(strftime('%H', datetime(ts/1000,'unixepoch')) AS INTEGER) < ?)";
  const row = await getDb().prepare(
    `SELECT AVG(oee) as avg_oee FROM oee_readings WHERE ts >= ? AND ${cond}`
  ).get(since, startHour, endHour) as { avg_oee: number | null };
  return row?.avg_oee != null ? +Number(row.avg_oee).toFixed(1) : null;
}

// Per-machine loss aggregation since UTC midnight.
// Returns one row per machine with total loss_min and dominant loss_type.
// Used by the OEE dashboard's machine cards so each card shows real cumulative
// loss minutes for today rather than the engine's drift counter.
// Sums across this query exactly equal the Loss Today tile (which sums the
// six-losses categories) because both pull from the same `oee_readings` table
// with the same UTC-midnight time origin.
export async function getMachineLossesToday(plant = 'All Plants') {
  const d = new Date(); d.setUTCHours(0, 0, 0, 0);
  const sinceMs = d.getTime();
  const pidFilter = plant && plant !== 'All Plants' ? ' AND plant_id = ?' : '';
  const params: any[] = [sinceMs];
  if (plant && plant !== 'All Plants') params.push(plant);
  // First pass: total loss minutes per machine
  const totals = await getDb().prepare(`
    SELECT machine_id, SUM(loss_min) as loss_min_today
    FROM oee_readings
    WHERE ts >= ?${pidFilter}
    GROUP BY machine_id
  `).all(...params) as Array<{ machine_id: string; loss_min_today: number }>;
  // Second pass: dominant loss category per machine (the loss_type with the
  // highest cumulative loss_min today). Computed in SQL with a window-style
  // ranking trick: sum per (machine, type), then pick the type with max sum.
  const dominantRows = await getDb().prepare(`
    SELECT machine_id, loss_type, SUM(loss_min) as type_min
    FROM oee_readings
    WHERE ts >= ?${pidFilter}
    GROUP BY machine_id, loss_type
    ORDER BY machine_id, type_min DESC
  `).all(...params) as Array<{ machine_id: string; loss_type: string; type_min: number }>;
  const dominant: Record<string, string> = {};
  for (const r of dominantRows) {
    if (!dominant[r.machine_id]) dominant[r.machine_id] = r.loss_type; // first per machine = highest because of ORDER BY
  }
  return totals.map(t => ({
    machine_id: t.machine_id,
    loss_min_today: Math.round(Number(t.loss_min_today ?? 0)),
    dominant_loss_type: dominant[t.machine_id] ?? '—',
  }));
}
