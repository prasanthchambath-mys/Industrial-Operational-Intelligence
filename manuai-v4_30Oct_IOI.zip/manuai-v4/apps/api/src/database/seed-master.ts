/**
 * ManuAI — Master Data Seeder  V43
 *
 * Seeds ALL Tier 2 (reference) and Tier 3 (transactional) tables from CSV
 * on first startup. Subsequent startups are skipped (idempotent check).
 *
 * Tier 1 (time-series) is written by the simulation engine / connectors.
 * Tier 4 (Semantic Core dims) is seeded by seed-dimensions.ts (unchanged).
 *
 * Settings CSVs (platform_config, baselines, ml_thresholds, etc.) stay
 * as CSV — they are config files, not records.
 */

import { getDb } from './connection';
import { logger } from '../middleware/logger';
import {
  loadMachines, loadUtilities, loadYieldParams, loadTagMappings,
  loadSupplyRisks, loadQualityDefects, loadQualityLines,
  loadSafetyZones, loadSafetyPermits, loadTechnicians,
  loadEnergyAssets, loadWorkOrders, loadProductionOrders,
  loadLimsResults, loadParts, loadPartsSpendHistory,
  loadTwinScenarios, loadTwinComponents, loadTwinKPIs,
  loadEnergyDispatch, loadEnergyWaste, loadDemandForecast,
  loadSuppliers, loadSupplierPlantMap, loadSkus, loadInventoryPositions,
  loadExternalRiskAlerts, loadReorderRules, loadReorderRequests, loadAutoApprovedOrders,
  loadSupplierRiskFactors, loadSupplierLeadTimeHistory, loadSupplierPerformanceMetrics,
} from '../data/csv-loader';

async function alreadySeeded(): Promise<boolean> {
  try {
    const db = getDb();
    const r = await db.prepare('SELECT COUNT(*) as cnt FROM ref_machines').get() as { cnt: number };
    return r.cnt > 0;
  } catch { return false; }
}

export async function seedMasterData(): Promise<void> {
  if (await alreadySeeded()) {
    logger.info('[Seed] Master data already seeded — skipping');
    return;
  }

  const db = getDb();
  const now = Date.now();
  logger.info('[Seed] Seeding Tier 2 + Tier 3 tables from CSV...');

  // ─── TIER 2: Reference / master data ─────────────────────────────────────

  // ref_machines
  try {
    const machines = loadMachines() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_machines
      (id, name, line, plant_id, asset_type, degrade_rate, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = machines;
    await db.transaction(async (tx) => {
      for (const m of rows) {
        await tx.run(insSql, [m.id, m.name, m.line, m.plant ?? 'P1', 'production_machine',
                m.degrade_rate ?? 0.05, 'CSV', now]);
      }
    });
    
    logger.info(`[Seed] ref_machines: ${machines.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_machines failed', { error: String(e) }); }

  // ref_utilities
  try {
    const utils = loadUtilities() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_utilities
      (id, name, plant_id, asset_type, oee_link, degrade_rate, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = utils;
    await db.transaction(async (tx) => {
      for (const u of rows) {
        await tx.run(insSql, [u.id, u.name, u.plant ?? 'P1', 'utility_asset',
                u.oee_link ?? null, u.degrade_rate ?? 0.05, 'CSV', now]);
      }
    });
    
    logger.info(`[Seed] ref_utilities: ${utils.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_utilities failed', { error: String(e) }); }

  // ref_yield_params
  try {
    const params = loadYieldParams() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_yield_params
      (id, plant_id, name, unit, value, target, min_val, max_val, drift_rate, drift_direction, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = params;
    await db.transaction(async (tx) => {
      for (const p of rows) {
        await tx.run(insSql, [p.id, p.plant ?? 'P1', p.name, p.unit ?? '',
                p.value ?? p.val ?? 0, p.target ?? p.tgt ?? 0,
                p.min ?? null, p.max ?? null,
                p.drift_rate ?? 0, p.drift_direction ?? 0, 'CSV', now]);
      }
    });
    
    logger.info(`[Seed] ref_yield_params: ${params.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_yield_params failed', { error: String(e) }); }

  // ref_tag_mappings
  try {
    const tagMap = loadTagMappings();
    const insSql = `INSERT OR REPLACE INTO ref_tag_mappings
      (param_id, plant_id, pi_tag, opc_node_id, description, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)`;
    const entries = [...tagMap.entries()];
    await db.transaction(async (tx) => {
      for (const [paramId, v] of entries) {
        await tx.run(insSql, [paramId, v.plant ?? 'P1', v.piTag ?? null, v.opcNodeId ?? null, v.description ?? null, now]);
      }
    });
    
    logger.info(`[Seed] ref_tag_mappings: ${tagMap.size} rows`);
  } catch (e) { logger.warn('[Seed] ref_tag_mappings failed', { error: String(e) }); }

  // ref_energy_assets
  try {
    const assets = loadEnergyAssets() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_energy_assets
      (id, plant_id, name, rated_kw, current_kw, anomaly_threshold_pct, shiftable, critical, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = assets;
    await db.transaction(async (tx) => {
      for (const a of rows) {
        await tx.run(insSql, [a.id, a.plant ?? 'P1', a.name, a.rated_kw ?? 0, a.current_kw ?? null,
                a.anomaly_threshold_pct ?? 12,
                a.shiftable === 'true' || a.shiftable === true ? 1 : 0,
                a.critical  === 'true' || a.critical  === true ? 1 : 0,
                'CSV', now]);
      }
    });
    
    logger.info(`[Seed] ref_energy_assets: ${assets.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_energy_assets failed', { error: String(e) }); }

  // ref_safety_zones
  try {
    const zones = loadSafetyZones() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_safety_zones
      (zone_id, plant_id, h2s_alarm1, h2s_alarm2, h2s_evac,
       co_alarm1, co_alarm2, co_evac, ch4_alarm1, ch4_alarm2, ch4_evac,
       personnel_normal, amr_enabled, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = zones;
    await db.transaction(async (tx) => {
      for (const z of rows) {
        // loadSafetyZones() returns { zone, thresholds:{h2s:{alarm1,alarm2,evac},co,ch4},
        // personnelNormal, amrEnabled, plant } — bind that shape (not flat z.h2s_alarm1).
        const th = z.thresholds ?? {};
        await tx.run(insSql, [z.zone, z.plant ?? 'P1',
                th.h2s?.alarm1 ?? 1, th.h2s?.alarm2 ?? 5, th.h2s?.evac ?? 10,
                th.co?.alarm1 ?? 25, th.co?.alarm2 ?? 50, th.co?.evac ?? 100,
                th.ch4?.alarm1 ?? 10, th.ch4?.alarm2 ?? 20, th.ch4?.evac ?? 25,
                z.personnelNormal ?? 0,
                z.amrEnabled === true ? 1 : 0,
                now]);
      }
    });
    
    logger.info(`[Seed] ref_safety_zones: ${zones.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_safety_zones failed', { error: String(e) }); }

  // ref_technicians
  try {
    const techs = loadTechnicians() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_technicians
      (id, name, role, shift, specialisation, plant_id, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)`;
    const rows = techs;
    await db.transaction(async (tx) => {
      for (const t of rows) {
        await tx.run(insSql, [t.id, t.name, t.role, t.shift ?? null, t.specialisation ?? null, t.plant ?? 'P1', now]);
      }
    });
    
    logger.info(`[Seed] ref_technicians: ${techs.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_technicians failed', { error: String(e) }); }

  // ref_quality_lines
  try {
    const lines = loadQualityLines() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_quality_lines
      (line_id, plant_id, quality_rate_pct, model_version, updated_at)
      VALUES (?, ?, ?, ?, ?)`;
    const rows = lines;
    await db.transaction(async (tx) => {
      for (const l of rows) {
        const plant = ['Line A','Line B'].includes(l.line) ? 'P1' : 'P2';
        await tx.run(insSql, [l.line, plant, l.quality_rate_pct ?? null, l.model_version ?? null, now]);
      }
    });
    
    logger.info(`[Seed] ref_quality_lines: ${lines.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_quality_lines failed', { error: String(e) }); }

  // ref_supply_risks is seeded once, in the supply-chain governance section below
  // (uses String(single_source) so the boolean binds safely). The earlier duplicate
  // here bound a raw boolean and crashed ("can only bind numbers, strings, ..."),
  // so it has been removed — see the DB-authoritative block later in this function.

  // ─── TIER 3: Transactional records ───────────────────────────────────────

  // trx_work_orders
  try {
    const wos = loadWorkOrders() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_work_orders
      (id, plant_id, asset_id, asset_name, wo_type, priority, description, status,
       assigned_to, oee_link, sap_order_type, planner_group, work_centre,
       functional_location, source_system, created_at, closed_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = wos;
    await db.transaction(async (tx) => {
      for (const w of rows) {
        const ts = w.created_at ? new Date(w.created_at).getTime() : now;
        await tx.run(insSql, [w.id, w.plant ?? 'P1', w.asset, w.name ?? null,
                w.type ?? 'Corrective', w.pri ?? 'P2',
                w.desc ?? null, w.status ?? 'open',
                w.assigned ?? null,
                w.oeeLink === true || w.oeeLink === 'true' ? 1 : 0,
                w.sapOrderType ?? null, w.plannerGroup ?? null,
                w.workCentre ?? null, w.functionalLocation ?? null,
                'CSV', ts,
                w.closed_at ? new Date(w.closed_at).getTime() : null,
                now]);
      }
    });
    
    logger.info(`[Seed] trx_work_orders: ${wos.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_work_orders failed', { error: String(e) }); }

  // trx_production_orders
  try {
    const pos = loadProductionOrders() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_production_orders
      (id, plant_id, product, qty_kg, plan_yield, actual_yield, status, start_date, end_date, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = pos;
    await db.transaction(async (tx) => {
      for (const p of rows) {
        // loadProductionOrders() emits start/end/qty/plan/actual (not the raw
        // *_date/qty_kg/*_yield column names) — map them so the DB rows carry
        // the real scheduled window instead of NULL.
        await tx.run(insSql, [p.id, p.plant ?? 'P1', p.product,
                parseFloat(String(p.qty)) || 0,
                p.plan ?? null, p.actual ?? null,
                p.status ?? 'planned', p.start ?? null, p.end ?? null,
                'CSV', now]);
      }
    });
    
    logger.info(`[Seed] trx_production_orders: ${pos.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_production_orders failed', { error: String(e) }); }

  // trx_quality_defects
  try {
    const defects = loadQualityDefects() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_quality_defects
      (id, plant_id, line, time_of_day, component, defect_type, severity, action, confidence, source_system, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = defects;
    await db.transaction(async (tx) => {
      for (const d of rows) {
        const plant = ['Line A','Line B'].includes(d.line) ? 'P1' : 'P2';
        await tx.run(insSql, [d.id, plant, d.line, d.time ?? null, d.component ?? null,
                d.defect_type ?? d.type, d.severity, d.action ?? null,
                d.confidence ?? null, 'VISION_AI', now]);
      }
    });
    
    logger.info(`[Seed] trx_quality_defects: ${defects.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_quality_defects failed', { error: String(e) }); }

  // trx_lims_results
  try {
    const lims = loadLimsResults() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_lims_results
      (id, plant_id, batch_id, test_name, result, limit_range, status, analyst, time_of_day, source_system, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = lims;
    await db.transaction(async (tx) => {
      for (const l of rows) {
        await tx.run(insSql, [l.id, l.plant ?? 'P1', l.batch, l.test, l.result ?? null,
                l.limit ?? null, l.status ?? 'pending', l.analyst ?? null,
                l.time ?? null, 'LIMS', now]);
      }
    });
    
    logger.info(`[Seed] trx_lims_results: ${lims.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_lims_results failed', { error: String(e) }); }

  // trx_safety_permits
  try {
    const permits = loadSafetyPermits() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_safety_permits
      (ptw_id, plant_id, asset_id, work_type, technician, status,
       jha_complete, isolation_verified, competency_valid, source_system, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = permits;
    await db.transaction(async (tx) => {
      for (const p of rows) {
        await tx.run(insSql, [p.id, p.plant ?? 'P1', p.asset ?? null,
                p.type, p.tech ?? null, p.status ?? 'pending',
                p.jha === true || p.jha === 'true' ? 1 : 0,
                p.isolation === true || p.isolation === 'true' ? 1 : 0,
                p.competency === true || p.competency === 'true' ? 1 : 0,
                'CSV', now, now]);
      }
    });
    
    logger.info(`[Seed] trx_safety_permits: ${permits.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_safety_permits failed', { error: String(e) }); }

  // trx_parts_orders
  try {
    const parts = loadParts() as any;
    const orders = parts?.orders ?? [];
    const insSql = `INSERT OR IGNORE INTO trx_parts_orders
      (order_id, plant_id, sku, part_name, asset_id, qty, unit_cost_inr, status,
       rules_triggered, rul_days, lead_days, stock_qty, reorder_qty, auto_order,
       source_system, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = orders;
    const invBySku: Record<string, any> = {};
    for (const inv of (parts?.inventory ?? [])) invBySku[inv.sku] = inv;
    await db.transaction(async (tx) => {
      for (const o of rows) {
        const inv = invBySku[o.sku] ?? {};
        const plant = o.plant ?? ((o.asset ?? '') <= 'MCH-04' ? 'P1' : 'P2');
        const unitCost = o.qty ? (o.cost ?? 0) / o.qty : (o.cost ?? null);
        await tx.run(insSql, [o.id, plant, o.sku, o.part ?? null, o.asset ?? null,
                o.qty ?? 1, unitCost, o.status ?? 'planned',
                o.rules ?? null, o.rul ?? null, o.lead ?? null,
                inv.stock ?? 0, inv.reorder ?? 1,
                inv.autoOrder === true || inv.autoOrder === 'true' ? 1 : 0,
                'CSV', now, now]);
      }
    });
    
    logger.info(`[Seed] trx_parts_orders: ${orders.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_parts_orders failed', { error: String(e) }); }

  // trx_parts_spend
  try {
    const spend = loadPartsSpendHistory() as any[];
    const insSql = `INSERT OR REPLACE INTO trx_parts_spend
      (plant_id, month_label, planned_inr, unplanned_inr, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)`;
    const rows = spend;
    await db.transaction(async (tx) => {
      for (const s of rows) {
        // loadPartsSpendHistory() returns { m, planned, unplanned, plant }
        await tx.run(insSql, [s.plant ?? 'P1', s.m, s.planned ?? 0, s.unplanned ?? 0, 'CSV', now]);
      }
    });
    
    logger.info(`[Seed] trx_parts_spend: ${spend.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_parts_spend failed', { error: String(e) }); }

  // trx_twin_scenarios
  try {
    const scenarios = loadTwinScenarios() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_twin_scenarios
      (id, plant_id, name, status, impact, confidence, horizon, scenario_type, description, source_system, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = scenarios;
    await db.transaction(async (tx) => {
      for (const s of rows) {
        await tx.run(insSql, [s.id, s.plant ?? 'Both', s.name, s.status ?? 'pending',
                s.impact ?? null, s.confidence ?? null, s.horizon ?? null,
                s.type ?? null, s.description ?? null, 'CSV', now, now]);
      }
    });
    
    logger.info(`[Seed] trx_twin_scenarios: ${scenarios.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_twin_scenarios failed', { error: String(e) }); }

  // trx_twin_components
  try {
    const comps = loadTwinComponents() as Record<string, any[]>;
    const insSql = `INSERT OR IGNORE INTO trx_twin_components
      (asset_id, component_name, health, temp, vib, alert, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
    let total = 0;
    const entries = Object.entries(comps);
    await db.transaction(async (tx) => {
      for (const [assetId, components] of entries) {
        for (const c of components) {
          await tx.run(insSql, [assetId, c.c ?? c.component ?? c.component_name,
                  c.h ?? c.health ?? null, c.t ?? c.temp ?? null, c.v ?? c.vib ?? null,
                  c.a === true || c.alert === true || c.alert === 'true' ? 1 : 0,
                  'CSV', now]);
          total++;
        }
      }
    });
    
    logger.info(`[Seed] trx_twin_components: ${total} rows`);
  } catch (e) { logger.warn('[Seed] trx_twin_components failed', { error: String(e) }); }

  // trx_twin_kpis
  try {
    const kpis = loadTwinKPIs() as any[];
    const insSql = `INSERT OR REPLACE INTO trx_twin_kpis
      (kpi_id, plant_id, kpi_name, unit, actual, twin_predicted, divergence_threshold_pct, asset_id, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = kpis;
    await db.transaction(async (tx) => {
      for (const k of rows) {
        await tx.run(insSql, [k.kpi_id, k.plant ?? 'Both', k.kpi_name, k.unit ?? null,
                k.actual ?? null, k.twin_predicted ?? null,
                k.divergence_threshold_pct ?? 3.0, k.asset_id ?? null, 'CSV', now]);
      }
    });
    
    logger.info(`[Seed] trx_twin_kpis: ${kpis.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_twin_kpis failed', { error: String(e) }); }

  // trx_energy_dispatch
  try {
    const dispatch = loadEnergyDispatch() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_energy_dispatch
      (id, plant_id, asset_id, action, saving_kwh, saving_inr, status, dispatch_type, source_system, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = dispatch;
    await db.transaction(async (tx) => {
      for (const d of rows) {
        await tx.run(insSql, [d.id, d.plant ?? 'P1', d.asset ?? d.asset_id ?? '',
                d.action, d.saving_kwh ?? null, d.saving_inr ?? null,
                d.status ?? 'pending', d.type ?? null, 'CSV', now, now]);
      }
    });
    
    logger.info(`[Seed] trx_energy_dispatch: ${dispatch.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_energy_dispatch failed', { error: String(e) }); }

  // trx_energy_waste
  try {
    const waste = loadEnergyWaste() as any[];
    const insSql = `INSERT OR IGNORE INTO trx_energy_waste
      (id, plant_id, waste_type, kwh, cost_inr, asset_id, description, period, source_system, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rows = waste;
    await db.transaction(async (tx) => {
      for (const w of rows) {
        await tx.run(insSql, [w.id, w.plant ?? 'P1', w.type ?? w.waste_type,
                w.kwh ?? 0, w.cost_inr ?? null,
                w.asset ?? w.asset_id ?? null,
                w.description ?? null, w.period ?? 'today', 'CSV', now]);
      }
    });
    
    logger.info(`[Seed] trx_energy_waste: ${waste.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_energy_waste failed', { error: String(e) }); }

  // trx_demand_forecast
  try {
    const forecast = loadDemandForecast() as any[];
    const insSql = `INSERT OR REPLACE INTO trx_demand_forecast
      (plant_id, product, week_label, actual_kg, forecast_kg, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)`;
    const rows = forecast;
    await db.transaction(async (tx) => {
      for (const f of rows) {
        await tx.run(insSql, [f.plant ?? 'P1', f.product, f.week ?? f.w,
                f.actual ?? f.actual_kg ?? null,
                f.forecast ?? f.forecast_kg ?? 0, 'CSV', now]);
      }
    });
    
    logger.info(`[Seed] trx_demand_forecast: ${forecast.length} rows`);
  } catch (e) { logger.warn('[Seed] trx_demand_forecast failed', { error: String(e) }); }

  // ─── Supply-chain governance entities (DB-authoritative) ─────────────────
  // ref_supply_risks (risk-card master) — seeded here so getSupplyRisks() is
  // DB-served (the REF_SOURCES snapshot seeder has a column mismatch and is
  // superseded for supply by this block).
  try {
    const rows = loadSupplyRisks() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_supply_risks
      (supplier_id, plant_id, supplier_name, sku, description, current_stock_days, reorder_point_days,
       lead_time_contracted_days, lead_time_actual_days, monthly_consumption, unit_cost_inr,
       single_source, country_of_origin, financial_risk_score, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.supplier_id, r.plant ?? 'P1', r.supplier_name, r.sku,
        r.description, r.current_stock_days, r.reorder_point_days, r.lead_time_contracted_days,
        r.lead_time_actual_days, r.monthly_consumption, r.unit_cost_inr,
        String(r.single_source), r.country_of_origin, r.financial_risk_score, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_supply_risks: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_supply_risks failed', { error: String(e) }); }

  // ref_suppliers
  try {
    const rows = loadSuppliers() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_suppliers
      (supplier_id, supplier_name, supplier_region, supplier_country, credit_rating,
       payment_terms, risk_score, risk_level, financial_status, primary_contact,
       is_active, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.supplier_id, r.supplier_name, r.supplier_region,
        r.supplier_country, r.credit_rating, r.payment_terms, r.risk_score, r.risk_level,
        r.financial_status, r.primary_contact, String(r.is_active), 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_suppliers: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_suppliers failed', { error: String(e) }); }

  // ref_supplier_plant_map
  try {
    const rows = loadSupplierPlantMap() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_supplier_plant_map
      (supplier_id, plant_id, relationship_type, monthly_exposure, ytd_order_value,
       mtd_order_value, supplier_status, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.supplier_id, r.plant_id, r.relationship_type,
        r.monthly_exposure, r.ytd_order_value, r.mtd_order_value, r.supplier_status, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_supplier_plant_map: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_supplier_plant_map failed', { error: String(e) }); }

  // ref_skus
  try {
    const rows = loadSkus() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_skus
      (sku_id, sku_code, sku_name, category, unit_of_measure, criticality, plant_id,
       preferred_supplier_id, alternate_supplier_id, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.sku_id, r.sku_code, r.sku_name, r.category,
        r.unit_of_measure, r.criticality, r.plant_id, r.preferred_supplier_id,
        r.alternate_supplier_id, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_skus: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_skus failed', { error: String(e) }); }

  // ref_inventory_positions
  try {
    const rows = loadInventoryPositions() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_inventory_positions
      (inventory_id, plant_id, sku_id, supplier_id, current_stock_days, reorder_point_days,
       safety_stock_days, monthly_consumption, current_inventory_cost, baseline_inventory_cost,
       last_updated_date, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.inventory_id, r.plant_id, r.sku_id, r.supplier_id,
        r.current_stock_days, r.reorder_point_days, r.safety_stock_days, r.monthly_consumption,
        r.current_inventory_cost, r.baseline_inventory_cost, r.last_updated_date, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_inventory_positions: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_inventory_positions failed', { error: String(e) }); }

  // ref_external_risk_alerts
  try {
    const rows = loadExternalRiskAlerts() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_external_risk_alerts
      (alert_id, plant_id, supplier_id, sku_id, alert_type, severity, region, source,
       description, recommended_action, alert_date, status, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.alert_id, r.plant_id, r.supplier_id, r.sku_id,
        r.alert_type, r.severity, r.region, r.source, r.description, r.recommended_action,
        r.alert_date, r.status, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_external_risk_alerts: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_external_risk_alerts failed', { error: String(e) }); }

  // ref_supplier_risk_factors
  try {
    const rows = loadSupplierRiskFactors() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_supplier_risk_factors
      (factor_id, supplier_id, sku_id, plant_id, factor_type, factor_description,
       severity, created_date, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.factor_id, r.supplier_id, r.sku_id, r.plant_id,
        r.factor_type, r.factor_description, r.severity, r.created_date, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_supplier_risk_factors: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_supplier_risk_factors failed', { error: String(e) }); }

  // ref_supplier_lead_time_history
  try {
    const rows = loadSupplierLeadTimeHistory() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_supplier_lead_time_history
      (record_id, supplier_id, sku_id, plant_id, week, lead_time_days, sla_lead_time_days,
       source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.record_id, r.supplier_id, r.sku_id, r.plant_id,
        r.week, r.lead_time_days, r.sla_lead_time_days, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_supplier_lead_time_history: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_supplier_lead_time_history failed', { error: String(e) }); }

  // ref_supplier_performance_metrics
  try {
    const rows = loadSupplierPerformanceMetrics() as any[];
    const insSql = `INSERT OR REPLACE INTO ref_supplier_performance_metrics
      (metric_id, supplier_id, sku_id, plant_id, metric_name, metric_value, metric_unit,
       period, trend_direction, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.metric_id, r.supplier_id, r.sku_id, r.plant_id,
        r.metric_name, r.metric_value, r.metric_unit, r.period, r.trend_direction, 'CSV', now]);
    });
    
    logger.info(`[Seed] ref_supplier_performance_metrics: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] ref_supplier_performance_metrics failed', { error: String(e) }); }

  // gov_reorder_rules (enabled stored as 0/1)
  try {
    const rows = loadReorderRules() as any[];
    const insSql = `INSERT OR REPLACE INTO gov_reorder_rules
      (rule_id, rule_name, category, description, conditions, approval_mode, enabled,
       plant_scope, created_date, last_triggered_date, trigger_count, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.rule_id, r.rule_name, r.category, r.description,
        r.conditions, r.approval_mode, r.enabled ? 1 : 0, r.plant_scope, r.created_date,
        r.last_triggered_date ?? null, r.trigger_count ?? 0, 'CSV', now]);
    });
    
    logger.info(`[Seed] gov_reorder_rules: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] gov_reorder_rules failed', { error: String(e) }); }

  // gov_reorder_requests
  try {
    const rows = loadReorderRequests() as any[];
    const insSql = `INSERT OR REPLACE INTO gov_reorder_requests
      (request_id, plant_id, sku_id, supplier_id, requested_qty, requested_value, requested_date,
       trigger_reason, approval_reason, approval_mode, triggered_by_rule_id, status, created_by,
       source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.request_id, r.plant_id, r.sku_id, r.supplier_id,
        r.requested_qty, r.requested_value, r.requested_date, r.trigger_reason, r.approval_reason,
        r.approval_mode, r.triggered_by_rule_id, r.status, r.created_by, 'CSV', now]);
    });
    
    logger.info(`[Seed] gov_reorder_requests: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] gov_reorder_requests failed', { error: String(e) }); }

  // gov_auto_approved_orders
  try {
    const rows = loadAutoApprovedOrders() as any[];
    const insSql = `INSERT OR REPLACE INTO gov_auto_approved_orders
      (order_id, plant_id, sku_id, supplier_id, approved_qty, approved_value, approved_date,
       rule_id, rule_name, sap_status, status, reason, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    const rs = rows;
    await db.transaction(async (tx) => {
      for (const r of rs) await tx.run(insSql, [r.order_id, r.plant_id, r.sku_id, r.supplier_id,
        r.approved_qty, r.approved_value, r.approved_date, r.rule_id, r.rule_name,
        r.sap_status, r.status, r.reason, 'CSV', now]);
    });
    
    logger.info(`[Seed] gov_auto_approved_orders: ${rows.length} rows`);
  } catch (e) { logger.warn('[Seed] gov_auto_approved_orders failed', { error: String(e) }); }

  logger.info('[Seed] Master data seeding complete');
}

/**
 * Refresh master data from CSV — call when CSVs change at runtime.
 * Uses INSERT OR REPLACE so existing rows are overwritten.
 */
export async function refreshMasterData(): Promise<void> {
  try {
    const db = getDb();
    await db.prepare('DELETE FROM ref_machines').run();
    await db.prepare('DELETE FROM ref_utilities').run();
    await db.prepare('DELETE FROM ref_yield_params').run();
    await db.prepare('DELETE FROM ref_energy_assets').run();
    await db.prepare('DELETE FROM ref_safety_zones').run();
    await db.prepare('DELETE FROM ref_technicians').run();
    await db.prepare('DELETE FROM ref_quality_lines').run();
    await db.prepare('DELETE FROM ref_tag_mappings').run();
    await db.prepare('DELETE FROM ref_supply_risks').run();
    logger.info('[Seed] Cleared Tier 2 tables for refresh');
  } catch (e) { logger.warn('[Seed] Refresh clear failed', { error: String(e) }); }
  await seedMasterData();
}
