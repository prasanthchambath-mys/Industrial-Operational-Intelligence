/**
 * ManuAI — Database Schema  V43
 *
 * Tables are grouped into four tiers:
 *
 *  TIER 1 — Time-series fact tables (engine writes every tick)
 *  TIER 2 — Reference / master data (seeded from CSV, routes query DB)
 *  TIER 3 — Transactional records  (seeded from CSV, writable by agents)
 *  TIER 4 — Semantic Core          (KPI engine, conflict log)
 *
 * Settings CSVs (platform_config, baselines, ml_thresholds, pdm_rules,
 * conflict_rules, personas, shifts, tech_stack, scenario_steps,
 * demand_curve, carbon_trend) stay as CSV — they are config files,
 * not records, and must be editable in Excel without a DB migration.
 */

import { getDb, dropRelationIfExists } from './connection';
import { logger } from '../middleware/logger';

export async function runMigrations(): Promise<void> {
  const db = getDb();

  // dim_supplier changed kind across versions (table → view). Drop it safely
  // (view OR legacy table) before the schema exec recreates it as a view, so a
  // restart over an existing DB never hits "use DROP VIEW to delete view".
  await dropRelationIfExists('dim_supplier');

  await db.exec(`
  -- ═══════════════════════════════════════════════════════════════════
  -- TIER 1 — Time-series fact tables (sim engine writes; routes read)
  -- ═══════════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS oee_readings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    plant_id     TEXT    NOT NULL DEFAULT 'P1',
    machine_id   TEXT    NOT NULL,
    machine_name TEXT    NOT NULL,
    line         TEXT    NOT NULL,
    ts           INTEGER NOT NULL,
    oee          REAL    NOT NULL,
    avail        REAL    NOT NULL,
    perf         REAL    NOT NULL,
    qual         REAL    NOT NULL,
    loss_type    TEXT,
    loss_min     INTEGER DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_oee_machine_ts  ON oee_readings(machine_id, ts);
  CREATE INDEX IF NOT EXISTS idx_oee_plant_ts    ON oee_readings(plant_id, ts);
  CREATE INDEX IF NOT EXISTS idx_oee_ts          ON oee_readings(ts);

  CREATE TABLE IF NOT EXISTS machine_health (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    plant_id     TEXT    NOT NULL DEFAULT 'P1',
    machine_id   TEXT    NOT NULL,
    ts           INTEGER NOT NULL,
    health       REAL    NOT NULL,
    rul          REAL    NOT NULL,
    vib          REAL    NOT NULL,
    temp         REAL    NOT NULL,
    pressure     REAL    NOT NULL DEFAULT 0,
    status       TEXT    NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_health_machine_ts ON machine_health(machine_id, ts);
  CREATE INDEX IF NOT EXISTS idx_health_plant_ts   ON machine_health(plant_id, ts);

  CREATE TABLE IF NOT EXISTS alerts (
    id           TEXT    PRIMARY KEY,
    plant_id     TEXT    NOT NULL DEFAULT 'P1',
    machine_id   TEXT    NOT NULL,
    machine_name TEXT,
    line         TEXT,
    type         TEXT    NOT NULL,
    severity     TEXT    NOT NULL,
    message      TEXT    NOT NULL,
    ts           INTEGER NOT NULL,
    acked        INTEGER DEFAULT 0,
    acked_by     TEXT,
    acked_at     INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_alerts_plant_ts  ON alerts(plant_id, ts);
  CREATE INDEX IF NOT EXISTS idx_alerts_severity  ON alerts(severity);

  CREATE TABLE IF NOT EXISTS batches (
    id           TEXT    PRIMARY KEY,
    plant_id     TEXT    NOT NULL DEFAULT 'P1',
    product      TEXT    NOT NULL,
    qty_kg       INTEGER NOT NULL,
    plan_yield   REAL    NOT NULL,
    actual_yield REAL,
    status       TEXT    NOT NULL,
    started_at   INTEGER NOT NULL,
    completed_at INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_batches_plant_ts ON batches(plant_id, started_at);

  CREATE TABLE IF NOT EXISTS yield_history (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    plant_id     TEXT    NOT NULL DEFAULT 'P1',
    param_id     TEXT    NOT NULL,
    param_name   TEXT    NOT NULL,
    ts           INTEGER NOT NULL,
    value        REAL    NOT NULL,
    target       REAL    NOT NULL,
    warn         INTEGER DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_yield_param_ts ON yield_history(param_id, ts);

  CREATE TABLE IF NOT EXISTS energy_readings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    plant_id     TEXT    NOT NULL DEFAULT 'P1',
    asset_id     TEXT    NOT NULL,
    asset_name   TEXT    NOT NULL,
    ts           INTEGER NOT NULL,
    kw           REAL    NOT NULL,
    anomaly      INTEGER DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_energy_asset_ts  ON energy_readings(asset_id, ts);
  CREATE INDEX IF NOT EXISTS idx_energy_plant_ts  ON energy_readings(plant_id, ts);

  CREATE TABLE IF NOT EXISTS safety_events (
    id           TEXT    PRIMARY KEY,
    plant_id     TEXT    NOT NULL DEFAULT 'P1',
    zone         TEXT    NOT NULL,
    event_type   TEXT    NOT NULL,
    severity     TEXT    NOT NULL,
    h2s          REAL    DEFAULT 0,
    co           REAL    DEFAULT 0,
    ch4          REAL    DEFAULT 0,
    ts           INTEGER NOT NULL,
    resolved_at  INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_safety_plant_ts ON safety_events(plant_id, ts);

  -- ═══════════════════════════════════════════════════════════════════
  -- TIER 2 — Reference / master data
  -- Seeded once from CSV on startup. Routes query these tables.
  -- In Phase A, real connectors upsert into these tables directly.
  -- ═══════════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS ref_machines (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    line            TEXT NOT NULL,
    plant_id        TEXT NOT NULL,
    asset_type      TEXT NOT NULL DEFAULT 'production_machine',
    rated_kw        REAL,
    degrade_rate    REAL DEFAULT 0.05,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS ref_utilities (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    plant_id        TEXT NOT NULL,
    asset_type      TEXT NOT NULL DEFAULT 'utility_asset',
    rated_kw        REAL,
    oee_link        TEXT,
    degrade_rate    REAL DEFAULT 0.05,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS ref_yield_params (
    id              TEXT NOT NULL,
    plant_id        TEXT NOT NULL,
    name            TEXT NOT NULL,
    unit            TEXT,
    value           REAL NOT NULL,
    target          REAL NOT NULL,
    min_val         REAL,
    max_val         REAL,
    drift_rate      REAL DEFAULT 0,
    drift_direction INTEGER DEFAULT 0,
    pi_tag          TEXT,
    opc_node_id     TEXT,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL,
    PRIMARY KEY (id, plant_id)
  );

  CREATE TABLE IF NOT EXISTS ref_energy_assets (
    id                    TEXT NOT NULL,
    plant_id              TEXT NOT NULL,
    name                  TEXT NOT NULL,
    rated_kw              REAL NOT NULL,
    current_kw            REAL,
    anomaly_threshold_pct REAL DEFAULT 12,
    shiftable             INTEGER DEFAULT 0,
    critical              INTEGER DEFAULT 0,
    source_system         TEXT DEFAULT 'CSV',
    updated_at            INTEGER NOT NULL,
    PRIMARY KEY (id, plant_id)
  );

  CREATE TABLE IF NOT EXISTS ref_safety_zones (
    zone_id         TEXT NOT NULL,
    plant_id        TEXT NOT NULL,
    h2s_alarm1      REAL DEFAULT 1.0,
    h2s_alarm2      REAL DEFAULT 5.0,
    h2s_evac        REAL DEFAULT 10.0,
    co_alarm1       REAL DEFAULT 25.0,
    co_alarm2       REAL DEFAULT 50.0,
    co_evac         REAL DEFAULT 100.0,
    ch4_alarm1      REAL DEFAULT 10.0,
    ch4_alarm2      REAL DEFAULT 20.0,
    ch4_evac        REAL DEFAULT 25.0,
    personnel_normal INTEGER DEFAULT 0,
    amr_enabled     INTEGER DEFAULT 0,
    updated_at      INTEGER NOT NULL,
    PRIMARY KEY (zone_id, plant_id)
  );

  CREATE TABLE IF NOT EXISTS ref_technicians (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    role            TEXT NOT NULL,
    shift           TEXT,
    specialisation  TEXT,
    plant_id        TEXT NOT NULL,
    active          INTEGER DEFAULT 1,
    updated_at      INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS ref_quality_lines (
    line_id         TEXT NOT NULL,
    plant_id        TEXT NOT NULL,
    quality_rate_pct REAL,
    model_version   TEXT,
    updated_at      INTEGER NOT NULL,
    PRIMARY KEY (line_id, plant_id)
  );

  CREATE TABLE IF NOT EXISTS ref_tag_mappings (
    param_id        TEXT NOT NULL,
    plant_id        TEXT NOT NULL,
    pi_tag          TEXT,
    opc_node_id     TEXT,
    description     TEXT,
    updated_at      INTEGER NOT NULL,
    PRIMARY KEY (param_id, plant_id)
  );

  CREATE TABLE IF NOT EXISTS ref_supply_risks (
    supplier_id                 TEXT NOT NULL,
    plant_id                    TEXT NOT NULL,
    supplier_name               TEXT NOT NULL,
    sku                         TEXT NOT NULL,
    description                 TEXT,
    current_stock_days          REAL,
    reorder_point_days          REAL,
    lead_time_contracted_days   INTEGER,
    lead_time_actual_days       INTEGER,
    monthly_consumption         REAL,
    unit_cost_inr               REAL,
    single_source               TEXT DEFAULT 'false',
    country_of_origin           TEXT,
    financial_risk_score        REAL DEFAULT 0,
    source_system               TEXT DEFAULT 'CSV',
    updated_at                  INTEGER NOT NULL,
    PRIMARY KEY (supplier_id, plant_id)
  );

  -- ── Supply-chain governance entities (DB-authoritative) ──────────────
  -- Reference data (read-only at runtime): suppliers, sku master, inventory,
  -- external alerts, plant map, and supplier-detail intelligence. Seeded from
  -- CSV on first boot. Phase A: SAP MM / D&B / LIMS connectors upsert here.
  CREATE TABLE IF NOT EXISTS ref_suppliers (
    supplier_id      TEXT PRIMARY KEY,
    supplier_name    TEXT NOT NULL,
    supplier_region  TEXT,
    supplier_country TEXT,
    credit_rating    TEXT,
    payment_terms    TEXT,
    risk_score       REAL DEFAULT 0,
    risk_level       TEXT,
    financial_status TEXT,
    primary_contact  TEXT,
    is_active        TEXT DEFAULT 'true',
    source_system    TEXT DEFAULT 'CSV',
    updated_at       INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ref_supplier_plant_map (
    supplier_id       TEXT NOT NULL,
    plant_id          TEXT NOT NULL,
    relationship_type TEXT,
    monthly_exposure  REAL DEFAULT 0,
    ytd_order_value   REAL DEFAULT 0,
    mtd_order_value   REAL DEFAULT 0,
    supplier_status   TEXT,
    source_system     TEXT DEFAULT 'CSV',
    updated_at        INTEGER NOT NULL,
    PRIMARY KEY (supplier_id, plant_id)
  );
  CREATE TABLE IF NOT EXISTS ref_skus (
    sku_id                TEXT PRIMARY KEY,
    sku_code              TEXT NOT NULL,
    sku_name              TEXT,
    category              TEXT,
    unit_of_measure       TEXT,
    criticality           TEXT,
    plant_id              TEXT,
    preferred_supplier_id TEXT,
    alternate_supplier_id TEXT,
    source_system         TEXT DEFAULT 'CSV',
    updated_at            INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ref_inventory_positions (
    inventory_id            TEXT PRIMARY KEY,
    plant_id                TEXT NOT NULL,
    sku_id                  TEXT NOT NULL,
    supplier_id             TEXT,
    current_stock_days      REAL,
    reorder_point_days      REAL,
    safety_stock_days       REAL,
    monthly_consumption     REAL,
    current_inventory_cost  REAL,
    baseline_inventory_cost REAL,
    last_updated_date       TEXT,
    source_system           TEXT DEFAULT 'CSV',
    updated_at              INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ref_external_risk_alerts (
    alert_id           TEXT PRIMARY KEY,
    plant_id           TEXT,
    supplier_id        TEXT,
    sku_id             TEXT,
    alert_type         TEXT,
    severity           TEXT,
    region             TEXT,
    source             TEXT,
    description        TEXT,
    recommended_action TEXT,
    alert_date         TEXT,
    status             TEXT,
    source_system      TEXT DEFAULT 'CSV',
    updated_at         INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ref_supplier_risk_factors (
    factor_id          TEXT PRIMARY KEY,
    supplier_id        TEXT NOT NULL,
    sku_id             TEXT,
    plant_id           TEXT,
    factor_type        TEXT,
    factor_description TEXT,
    severity           TEXT,
    created_date       TEXT,
    source_system      TEXT DEFAULT 'CSV',
    updated_at         INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ref_supplier_lead_time_history (
    record_id         TEXT PRIMARY KEY,
    supplier_id       TEXT NOT NULL,
    sku_id            TEXT,
    plant_id          TEXT,
    week              TEXT,
    lead_time_days    INTEGER,
    sla_lead_time_days INTEGER,
    source_system     TEXT DEFAULT 'CSV',
    updated_at        INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS ref_supplier_performance_metrics (
    metric_id        TEXT PRIMARY KEY,
    supplier_id      TEXT NOT NULL,
    sku_id           TEXT,
    plant_id         TEXT,
    metric_name      TEXT,
    metric_value     TEXT,
    metric_unit      TEXT,
    period           TEXT,
    trend_direction  TEXT,
    source_system    TEXT DEFAULT 'CSV',
    updated_at       INTEGER NOT NULL
  );
  -- Governance state (mutable at runtime): rules' enabled flag is toggled,
  -- requests are appended + status-updated, auto-orders are appended. Seeded
  -- from CSV on first boot; resets on down -v. Phase A: Postgres tables.
  CREATE TABLE IF NOT EXISTS gov_reorder_rules (
    rule_id             TEXT PRIMARY KEY,
    rule_name           TEXT,
    category            TEXT,
    description         TEXT,
    conditions          TEXT,
    approval_mode       TEXT,
    enabled             INTEGER DEFAULT 1,
    plant_scope         TEXT,
    created_date        TEXT,
    last_triggered_date TEXT,
    trigger_count       INTEGER DEFAULT 0,
    source_system       TEXT DEFAULT 'CSV',
    updated_at          INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS gov_reorder_requests (
    request_id          TEXT PRIMARY KEY,
    plant_id            TEXT,
    sku_id              TEXT,
    supplier_id         TEXT,
    requested_qty       REAL,
    requested_value     REAL,
    requested_date      TEXT,
    trigger_reason      TEXT,
    approval_reason     TEXT,
    approval_mode       TEXT,
    triggered_by_rule_id TEXT,
    status              TEXT,
    created_by          TEXT,
    source_system       TEXT DEFAULT 'CSV',
    updated_at          INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS gov_auto_approved_orders (
    order_id      TEXT PRIMARY KEY,
    plant_id      TEXT,
    sku_id        TEXT,
    supplier_id   TEXT,
    approved_qty  REAL,
    approved_value REAL,
    approved_date TEXT,
    rule_id       TEXT,
    rule_name     TEXT,
    sap_status    TEXT,
    status        TEXT,
    reason        TEXT,
    source_system TEXT DEFAULT 'CSV',
    updated_at    INTEGER NOT NULL
  );

  -- ═══════════════════════════════════════════════════════════════════
  -- TIER 3 — Transactional records
  -- Seeded from CSV on startup. Agents write new rows.
  -- In Phase A, SAP/LIMS connectors upsert into these tables.
  -- ═══════════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS trx_work_orders (
    id                  TEXT PRIMARY KEY,
    plant_id            TEXT NOT NULL,
    asset_id            TEXT NOT NULL,
    asset_name          TEXT,
    wo_type             TEXT NOT NULL,
    priority            TEXT NOT NULL,
    description         TEXT,
    status              TEXT NOT NULL DEFAULT 'open',
    assigned_to         TEXT,
    oee_link            INTEGER DEFAULT 0,
    sap_order_type      TEXT,
    planner_group       TEXT,
    work_centre         TEXT,
    functional_location TEXT,
    triggered_by        TEXT,
    source_system       TEXT DEFAULT 'MANUAI',
    created_at          INTEGER NOT NULL,
    closed_at           INTEGER,
    updated_at          INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_wo_plant    ON trx_work_orders(plant_id, status);
  CREATE INDEX IF NOT EXISTS idx_wo_asset    ON trx_work_orders(asset_id);

  CREATE TABLE IF NOT EXISTS trx_production_orders (
    id              TEXT PRIMARY KEY,
    plant_id        TEXT NOT NULL,
    product         TEXT NOT NULL,
    qty_kg          REAL NOT NULL,
    plan_yield      REAL,
    actual_yield    REAL,
    status          TEXT NOT NULL DEFAULT 'planned',
    start_date      TEXT,
    end_date        TEXT,
    sap_order_no    TEXT,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_po_plant ON trx_production_orders(plant_id, status);

  CREATE TABLE IF NOT EXISTS trx_quality_defects (
    id              TEXT PRIMARY KEY,
    plant_id        TEXT NOT NULL,
    line            TEXT NOT NULL,
    time_of_day     TEXT,
    component       TEXT,
    defect_type     TEXT NOT NULL,
    severity        TEXT NOT NULL,
    action          TEXT,
    confidence      REAL,
    ncr_id          TEXT,
    source_system   TEXT DEFAULT 'VISION_AI',
    created_at      INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_qd_plant_line ON trx_quality_defects(plant_id, line);
  CREATE INDEX IF NOT EXISTS idx_qd_created    ON trx_quality_defects(created_at);

  CREATE TABLE IF NOT EXISTS trx_lims_results (
    id              TEXT PRIMARY KEY,
    plant_id        TEXT NOT NULL,
    batch_id        TEXT NOT NULL,
    test_name       TEXT NOT NULL,
    result          TEXT,
    limit_range     TEXT,
    status          TEXT NOT NULL DEFAULT 'pending',
    analyst         TEXT,
    time_of_day     TEXT,
    source_system   TEXT DEFAULT 'LIMS',
    created_at      INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_lims_batch ON trx_lims_results(batch_id);

  CREATE TABLE IF NOT EXISTS trx_safety_permits (
    ptw_id              TEXT PRIMARY KEY,
    plant_id            TEXT NOT NULL,
    asset_id            TEXT,
    work_type           TEXT NOT NULL,
    technician          TEXT,
    status              TEXT NOT NULL DEFAULT 'pending',
    jha_complete        INTEGER DEFAULT 0,
    isolation_verified  INTEGER DEFAULT 0,
    competency_valid    INTEGER DEFAULT 0,
    blocked_by_rule     TEXT,
    source_system       TEXT DEFAULT 'CSV',
    created_at          INTEGER NOT NULL,
    updated_at          INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ptw_plant ON trx_safety_permits(plant_id, status);

  CREATE TABLE IF NOT EXISTS trx_parts_orders (
    order_id        TEXT PRIMARY KEY,
    plant_id        TEXT NOT NULL,
    sku             TEXT NOT NULL,
    part_name       TEXT,
    asset_id        TEXT,
    qty             INTEGER NOT NULL DEFAULT 1,
    unit_cost_inr   REAL,
    status          TEXT NOT NULL DEFAULT 'planned',
    rules_triggered TEXT,
    rul_days        INTEGER,
    lead_days       INTEGER,
    stock_qty       INTEGER DEFAULT 0,
    reorder_qty     INTEGER DEFAULT 1,
    auto_order      INTEGER DEFAULT 0,
    sap_pr_no       TEXT,
    source_system   TEXT DEFAULT 'CSV',
    created_at      INTEGER NOT NULL,
    updated_at      INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_parts_plant  ON trx_parts_orders(plant_id, status);
  CREATE INDEX IF NOT EXISTS idx_parts_asset  ON trx_parts_orders(asset_id);

  CREATE TABLE IF NOT EXISTS trx_parts_spend (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    plant_id        TEXT NOT NULL,
    month_label     TEXT NOT NULL,
    planned_inr     REAL NOT NULL,
    unplanned_inr   REAL NOT NULL,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_spend_plant_month ON trx_parts_spend(plant_id, month_label);

  CREATE TABLE IF NOT EXISTS trx_twin_scenarios (
    id              TEXT PRIMARY KEY,
    plant_id        TEXT NOT NULL,
    name            TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending',
    impact          TEXT,
    confidence      REAL,
    horizon         TEXT,
    scenario_type   TEXT,
    description     TEXT,
    source_system   TEXT DEFAULT 'CSV',
    created_at      INTEGER NOT NULL,
    updated_at      INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS trx_twin_components (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    asset_id        TEXT NOT NULL,
    component_name  TEXT NOT NULL,
    health          REAL,
    temp            REAL,
    vib             REAL,
    alert           INTEGER DEFAULT 0,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_twin_comp_asset ON trx_twin_components(asset_id);

  CREATE TABLE IF NOT EXISTS trx_twin_kpis (
    kpi_id          TEXT NOT NULL,
    plant_id        TEXT NOT NULL,
    kpi_name        TEXT NOT NULL,
    unit            TEXT,
    actual          REAL,
    twin_predicted  REAL,
    divergence_threshold_pct REAL DEFAULT 3.0,
    asset_id        TEXT,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL,
    PRIMARY KEY (kpi_id, plant_id)
  );

  CREATE TABLE IF NOT EXISTS trx_energy_dispatch (
    id              TEXT PRIMARY KEY,
    plant_id        TEXT NOT NULL,
    asset_id        TEXT NOT NULL,
    action          TEXT NOT NULL,
    saving_kwh      REAL,
    saving_inr      REAL,
    status          TEXT NOT NULL DEFAULT 'pending',
    dispatch_type   TEXT,
    source_system   TEXT DEFAULT 'CSV',
    created_at      INTEGER NOT NULL,
    updated_at      INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_dispatch_plant ON trx_energy_dispatch(plant_id, status);

  CREATE TABLE IF NOT EXISTS trx_energy_waste (
    id              TEXT PRIMARY KEY,
    plant_id        TEXT NOT NULL,
    waste_type      TEXT NOT NULL,
    kwh             REAL NOT NULL,
    cost_inr        REAL,
    asset_id        TEXT,
    description     TEXT,
    period          TEXT DEFAULT 'today',
    source_system   TEXT DEFAULT 'CSV',
    created_at      INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS trx_demand_forecast (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    plant_id        TEXT NOT NULL,
    product         TEXT NOT NULL,
    week_label      TEXT NOT NULL,
    actual_kg       REAL,
    forecast_kg     REAL NOT NULL,
    source_system   TEXT DEFAULT 'CSV',
    updated_at      INTEGER NOT NULL
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_demand_plant_week_prod
    ON trx_demand_forecast(plant_id, product, week_label);

  -- ═══════════════════════════════════════════════════════════════════
  -- TIER 4 — Semantic Core (KPI engine, conflict log, dim tables)
  -- ═══════════════════════════════════════════════════════════════════

  CREATE TABLE IF NOT EXISTS dim_plant (
    plant_id     TEXT PRIMARY KEY,
    plant_name   TEXT NOT NULL,
    location     TEXT,
    timezone     TEXT DEFAULT 'Asia/Kolkata',
    currency     TEXT DEFAULT 'INR',
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_line (
    line_id      TEXT PRIMARY KEY,
    line_name    TEXT NOT NULL,
    plant_id     TEXT NOT NULL REFERENCES dim_plant(plant_id),
    line_type    TEXT,
    capacity_pct REAL DEFAULT 100,
    created_at   INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS dim_asset (
    asset_id     TEXT PRIMARY KEY,
    asset_name   TEXT NOT NULL,
    asset_type   TEXT NOT NULL,
    line_id      TEXT REFERENCES dim_line(line_id),
    plant_id     TEXT NOT NULL,
    rated_kw     REAL,
    source_system TEXT DEFAULT 'PI_HISTORIAN',
    created_at   INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_dim_asset_plant ON dim_asset(plant_id);

  -- dim_supplier is a conformed-dimension VIEW over ref_suppliers (the single
  -- supplier entity of record). Previously a separate table seeded from
  -- supply_risks.csv that was keyed by SKU (a bug) and could drift from
  -- ref_suppliers. The view maps the operational columns to the star-schema
  -- shape and derives single_source from the per-SKU risk rows.
  -- dim_supplier is dropped programmatically before this migration via
  -- dropRelationIfExists('dim_supplier') (see runMigrations), so a plain
  -- CREATE VIEW is safe and idempotent on every boot. We deliberately avoid
  -- CREATE VIEW IF NOT EXISTS here: SQLite accepts it but PostgreSQL does not
  -- (there is no IF NOT EXISTS for CREATE VIEW), which broke azure-sim bootstrap.
  -- Plain CREATE VIEW is valid in BOTH engines.
  CREATE VIEW dim_supplier AS
    SELECT
      s.supplier_id                       AS supplier_id,
      s.supplier_name                     AS supplier_name,
      s.supplier_country                  AS country,
      LOWER(COALESCE(s.risk_level, 'medium')) AS risk_category,
      CASE WHEN EXISTS (
        SELECT 1 FROM ref_supply_risks r
        WHERE r.supplier_id = s.supplier_id AND r.single_source = 'true'
      ) THEN 1 ELSE 0 END                 AS single_source,
      s.updated_at                        AS created_at
    FROM ref_suppliers s;

  CREATE TABLE IF NOT EXISTS dim_material (
    material_id   TEXT PRIMARY KEY,
    material_name TEXT NOT NULL,
    unit          TEXT NOT NULL,
    category      TEXT,
    lead_days     INTEGER DEFAULT 14,
    created_at    INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS semantic_kpi_definition (
    kpi_id       TEXT PRIMARY KEY,
    kpi_name     TEXT NOT NULL,
    formula      TEXT NOT NULL,
    unit         TEXT NOT NULL,
    agents       TEXT NOT NULL,
    source_system TEXT NOT NULL,
    governance   TEXT DEFAULT 'Semantic Layer',
    is_derived   INTEGER DEFAULT 0,
    version       INTEGER NOT NULL DEFAULT 1,
    valid_from    INTEGER,
    updated_by    TEXT DEFAULT 'system',
    change_reason TEXT DEFAULT 'Initial definition',
    created_at   INTEGER NOT NULL
  );

  -- Append-only audit log: one row per superseded version of a KPI definition.
  -- Enables "what was the OEE formula on 12 Jun, who changed it, and why".
  -- Phase E: this is the lineage feed Azure Purview ingests for KPI governance.
  CREATE TABLE IF NOT EXISTS semantic_kpi_definition_history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    kpi_id        TEXT NOT NULL REFERENCES semantic_kpi_definition(kpi_id),
    version       INTEGER NOT NULL,
    kpi_name      TEXT NOT NULL,
    formula       TEXT NOT NULL,
    unit          TEXT NOT NULL,
    agents        TEXT NOT NULL,
    source_system TEXT NOT NULL,
    governance    TEXT,
    is_derived    INTEGER DEFAULT 0,
    valid_from    INTEGER,
    valid_to      INTEGER NOT NULL,
    changed_by    TEXT,
    change_reason TEXT,
    change_ts     INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_kpi_def_hist ON semantic_kpi_definition_history(kpi_id, version);

  CREATE TABLE IF NOT EXISTS semantic_kpi_value (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kpi_id       TEXT NOT NULL REFERENCES semantic_kpi_definition(kpi_id),
    plant_id     TEXT,
    asset_id     TEXT,
    scope        TEXT DEFAULT 'plant',
    ts           INTEGER NOT NULL,
    value        REAL NOT NULL,
    target       REAL,
    status       TEXT DEFAULT 'ok'
  );
  CREATE INDEX IF NOT EXISTS idx_kpi_value_kpi_ts    ON semantic_kpi_value(kpi_id, ts);
  CREATE INDEX IF NOT EXISTS idx_kpi_value_plant_ts  ON semantic_kpi_value(plant_id, kpi_id, ts);

  CREATE TABLE IF NOT EXISTS semantic_event (
    event_id     TEXT PRIMARY KEY,
    event_type   TEXT NOT NULL,
    from_agent   TEXT NOT NULL,
    asset_id     TEXT,
    severity     TEXT NOT NULL,
    message      TEXT NOT NULL,
    payload      TEXT,
    ts           INTEGER NOT NULL,
    resolved_at  INTEGER,
    scenario_id  TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_sem_event_ts    ON semantic_event(ts);
  CREATE INDEX IF NOT EXISTS idx_sem_event_asset ON semantic_event(asset_id);

  CREATE TABLE IF NOT EXISTS semantic_event_impact (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id     TEXT NOT NULL REFERENCES semantic_event(event_id),
    target_agent TEXT NOT NULL,
    impact_type  TEXT NOT NULL,
    impact_value REAL,
    impact_unit  TEXT,
    description  TEXT NOT NULL,
    action_taken TEXT,
    action_ref   TEXT,
    ts           INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_sem_impact_event ON semantic_event_impact(event_id);

  CREATE TABLE IF NOT EXISTS orchestration_scenario (
    scenario_id  TEXT PRIMARY KEY,
    scenario_name TEXT NOT NULL,
    trigger_event TEXT NOT NULL,
    asset_id     TEXT,
    status       TEXT DEFAULT 'running',
    started_at   INTEGER NOT NULL,
    completed_at INTEGER,
    steps_total  INTEGER DEFAULT 0,
    steps_done   INTEGER DEFAULT 0,
    summary      TEXT
  );

  CREATE TABLE IF NOT EXISTS plant_config (
    plant_id    TEXT NOT NULL,
    config_key  TEXT NOT NULL,
    value       TEXT NOT NULL,
    label       TEXT,
    unit        TEXT,
    updated_at  INTEGER,
    PRIMARY KEY (plant_id, config_key)
  );

  CREATE TABLE IF NOT EXISTS schema_version (
    version    INTEGER PRIMARY KEY,
    applied_at INTEGER NOT NULL,
    note       TEXT
  );
  `);

  // Mark V43 schema
  const existing = await db.prepare('SELECT version FROM schema_version WHERE version = 3').get();
  if (!existing) {
    await db.prepare('INSERT OR IGNORE INTO schema_version (version, applied_at, note) VALUES (3, ?, ?)').run(Date.now(), 'V43 — full data model, Tier2/3 tables');
  }

  logger.info('[DB] Schema V43 migrations complete');
}

export async function isHistorySeeded(): Promise<boolean> {
  const db = getDb();
  const row = await db.prepare('SELECT COUNT(*) as cnt FROM oee_readings').get() as { cnt: number };
  return row.cnt > 1000;
}

export async function runPlantMigration(): Promise<void> {
  const db = getDb();
  const addCol = async (table: string, col: string, def: string): Promise<void> => {
    try {
      const cols = db.pragma?.(`table_info(${table})`) as any[] ?? [];
      if (!cols.find((c: any) => c.name === col)) {
        await db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`);
        logger.info(`[DB] Added ${col} to ${table}`);
      }
    } catch (e) { logger.warn(`[DB] Migration skip: ${table}.${col}`, { error: String(e) }); }
  };

  // Backcompat: ensure old tables have plant_id if they existed before V43
  for (const t of ['oee_readings','machine_health','safety_events','alerts','batches','yield_history','energy_readings']) {
    await addCol(t, 'plant_id', "TEXT NOT NULL DEFAULT 'P1'");
  }
  await addCol('machine_health', 'pressure', 'REAL NOT NULL DEFAULT 0');
  await addCol('semantic_kpi_value', 'plant_id', 'TEXT DEFAULT NULL');
  await addCol('semantic_kpi_definition', 'is_derived', 'INTEGER DEFAULT 0');
  await addCol('semantic_kpi_definition', 'version', 'INTEGER NOT NULL DEFAULT 1');
  await addCol('semantic_kpi_definition', 'valid_from', 'INTEGER');
  await addCol('semantic_kpi_definition', 'updated_by', "TEXT DEFAULT 'system'");
  await addCol('semantic_kpi_definition', 'change_reason', "TEXT DEFAULT 'Initial definition'");

  // Indexes for backcompat
  try {
    await db.exec(`
      CREATE INDEX IF NOT EXISTS idx_oee_plant_ts    ON oee_readings(plant_id, ts);
      CREATE INDEX IF NOT EXISTS idx_health_plant_ts ON machine_health(plant_id, ts);
      CREATE INDEX IF NOT EXISTS idx_safety_plant_ts ON safety_events(plant_id, ts);
      CREATE INDEX IF NOT EXISTS idx_energy_plant_ts ON energy_readings(plant_id, ts);
      CREATE INDEX IF NOT EXISTS idx_kpi_value_plant_ts ON semantic_kpi_value(plant_id, kpi_id, ts);
    `);
  } catch { /* already exist */ }

  // Seed plant_config defaults
  const cfgCount = ((await db.prepare('SELECT COUNT(*) as cnt FROM plant_config').get()) as { cnt: number }).cnt;
  if (cfgCount === 0) {
    const insSql = 'INSERT OR IGNORE INTO plant_config (plant_id, config_key, value, label, unit) VALUES (?, ?, ?, ?, ?)';
    const configs = [
      ['P1','oee_target','85','OEE Target','%'],
      ['P1','energy_tariff_rs','6.50','Energy Tariff','Rs/kWh'],
      ['P1','peak_tariff_rs','9.20','Peak Tariff','Rs/kWh'],
      ['P1','rul_critical_days','14','RUL Critical','days'],
      ['P1','rul_warning_days','30','RUL Warning','days'],
      ['P1','carbon_intensity','0.82','Grid Carbon','kgCO2/kWh'],
      ['P1','sap_plant_code','1000','SAP Plant Code',''],
      ['P1','pi_server_name','PIServer-MUM','PI Server',''],
      ['P1','yield_target','89','Yield Target','%'],
      ['P2','oee_target','88','OEE Target','%'],
      ['P2','energy_tariff_rs','6.80','Energy Tariff','Rs/kWh'],
      ['P2','peak_tariff_rs','9.50','Peak Tariff','Rs/kWh'],
      ['P2','rul_critical_days','14','RUL Critical','days'],
      ['P2','rul_warning_days','30','RUL Warning','days'],
      ['P2','carbon_intensity','0.86','Grid Carbon','kgCO2/kWh'],
      ['P2','sap_plant_code','2000','SAP Plant Code',''],
      ['P2','pi_server_name','PIServer-PUN','PI Server',''],
      ['P2','yield_target','86','Yield Target','%'],
    ];
    await db.transaction(async (tx) => { for (const r of configs) await tx.run(insSql, [...r]); });
    logger.info('[DB] plant_config seeded');
  }

  // ── Auto-close orphaned safety events ─────────────────────────────────────
  // Events can get stuck open when the container restarts and loses the
  // in-memory _activeSafetyEventId that would have called resolveSafetyEventInDB.
  // On every startup: resolve any unresolved event older than 4 hours so the
  // dashboard doesn't accumulate phantom critical alarms across restarts.
  // 4h = 240 min — long enough that a real event would have been acted on.
  // This is a maintenance sweep, not a suppression: events still appear in the
  // 30-day history query; they just stop counting as "open critical".
  try {
    const cutoff = Date.now() - 4 * 60 * 60 * 1000;   // 4 hours ago
    const result = await db.prepare(
      `UPDATE safety_events SET resolved_at = ? WHERE resolved_at IS NULL AND ts < ?`
    ).run(Date.now(), cutoff);
    if ((result as any).changes > 0) {
      logger.info(`[DB] Auto-closed ${(result as any).changes} orphaned safety events (>4h old)`);
    }
  } catch (e) {
    logger.warn('[DB] Safety event auto-close failed', { error: String(e) });
  }

  logger.info('[DB] Plant migration complete');
}
