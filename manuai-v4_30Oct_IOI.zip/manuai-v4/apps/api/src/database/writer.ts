/**
 * ManuAI — Live Data Writer
 *
 * Called by the simulation engine on every tick. Writes current state to the
 * database so history accumulates over time.
 *
 * Phase A: all writes are async. Transaction blocks use the tx-scoped handle
 * (tx.run) instead of cached prepared statements, because a statement prepared
 * on the Postgres pool would execute on a different connection than the one
 * holding BEGIN. The SQL strings are defined once as consts and reused per row.
 * Writes are non-blocking — failures are logged but never crash the engine.
 */

import { getDb } from './connection';
import { PlantState } from '../simulation/engine';
import { logger } from '../middleware/logger';

const OEE_WRITE_INTERVAL_MS    = 5 * 60 * 1000;   // 5 min — matches history query granularity
const YIELD_WRITE_INTERVAL_MS  = 5 * 60 * 1000;   // 5 min
const ENERGY_WRITE_INTERVAL_MS = 30 * 60 * 1000;  // 30 min — energy trend is hourly

let lastOeeWrite   = 0;
let lastYieldWrite = 0;
let lastEnergyWrite = 0;

const writtenAlerts  = new Set<string>();
const writtenBatches = new Set<string>();
const writtenSafety  = new Set<string>();

const INSERT_OEE = `
  INSERT INTO oee_readings (plant_id, machine_id, machine_name, line, ts, oee, avail, perf, qual, loss_type, loss_min)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
const INSERT_HEALTH = `
  INSERT INTO machine_health (plant_id, machine_id, ts, health, rul, vib, temp, pressure, status)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
const INSERT_YIELD = `
  INSERT INTO yield_history (plant_id, param_id, param_name, ts, value, target, warn)
  VALUES (?, ?, ?, ?, ?, ?, ?)`;
const INSERT_ENERGY = `
  INSERT INTO energy_readings (plant_id, asset_id, asset_name, ts, kw, anomaly)
  VALUES (?, ?, ?, ?, ?, ?)`;

export async function writeStateToDB(state: PlantState): Promise<void> {
  try {
    const db = getDb();
    const now = Date.now();

    // ── OEE + Health (every 5 min) ─────────────────────────────────────────
    if (now - lastOeeWrite >= OEE_WRITE_INTERVAL_MS) {
      await db.transaction(async (tx) => {
        for (const m of state.machines) {
          const pid = (m as any).plant ?? 'P1';
          await tx.run(INSERT_OEE, [pid, m.id, m.name, m.line, now, m.oee, m.avail, m.perf, m.qual, m.loss, m.lossMin]);
          await tx.run(INSERT_HEALTH, [pid, m.id, now, m.health, m.rul, m.vib, m.temp, (m as any).pressure ?? 0, m.status]);
        }
        // Utilities are monitored PdM assets too (compressors/chillers) — persist
        // their health so a critical utility's RUL trend line has data to plot.
        for (const u of (state.utilities ?? [])) {
          await tx.run(INSERT_HEALTH, [(u as any).plant ?? 'P1', u.id, now, u.health, u.rul, u.vib, u.temp, (u as any).press ?? 0, u.status]);
        }
      });
      lastOeeWrite = now;
    }

    // ── Yield params (every 5 min) ─────────────────────────────────────────
    if (now - lastYieldWrite >= YIELD_WRITE_INTERVAL_MS) {
      await db.transaction(async (tx) => {
        for (const p of state.yieldParams) {
          const ypid = (p as any).plant ?? 'P1';
          await tx.run(INSERT_YIELD, [ypid, p.id, p.name, now, p.val, p.tgt, p.warn ? 1 : 0]);
        }
      });
      lastYieldWrite = now;
    }

    // ── Energy (every 30 min) ─────────────────────────────────────────────
    if (now - lastEnergyWrite >= ENERGY_WRITE_INTERVAL_MS) {
      await db.transaction(async (tx) => {
        for (const a of state.energyAssets) {
          const epid = (a as any).plant ?? 'P1';
          await tx.run(INSERT_ENERGY, [epid, a.id, a.name, now, a.kw, a.anomaly ? 1 : 0]);
        }
      });
      lastEnergyWrite = now;
    }

    // ── Batch updates (whenever status changes) ────────────────────────────
    const b = state.batch;
    if (!writtenBatches.has(b.id + b.status)) {
      const bpid = (b as any).plantId ?? (String(b.product).includes('Z-04')||String(b.product).includes('PB-7') ? 'P2' : 'P1');
      await db.prepare(`
        INSERT OR REPLACE INTO batches (plant_id, id, product, qty_kg, plan_yield, actual_yield, status, started_at, completed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        bpid, b.id, b.product, b.qty, b.plan,
        b.actual ?? null, b.status,
        b.startedAt,
        b.status === 'completed' ? now : null
      );
      writtenBatches.add(b.id + b.status);
    }

  } catch (err) {
    logger.warn('[DB] Write error (non-fatal)', { error: String(err) });
  }
}

export async function writeAlertToDB(alert: {
  id: string; machineId: string; machineName: string; line: string;
  type: string; severity: string; message: string; ts: number; plantId?: string;
}): Promise<void> {
  if (writtenAlerts.has(alert.id)) return;
  try {
    await getDb().prepare(`
      INSERT OR IGNORE INTO alerts (plant_id, id, machine_id, machine_name, line, type, severity, message, ts, acked)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    `).run(alert.plantId ?? 'P1', alert.id, alert.machineId, alert.machineName, alert.line, alert.type, alert.severity, alert.message, alert.ts);
    writtenAlerts.add(alert.id);
  } catch (err) {
    logger.warn('[DB] Alert write error', { error: String(err) });
  }
}

export async function writeSafetyEventToDB(event: {
  id: string; zone: string; type: string; severity: string;
  h2s: number; co: number; ch4: number; ts: number; plantId?: string;
}): Promise<void> {
  if (writtenSafety.has(event.id)) return;
  try {
    const ZONE_PLANT: Record<string,string> = {'Zone A':'P1','Zone B':'P1','Zone C':'P2','Zone D':'P2'};
    const spid = ZONE_PLANT[event.zone] ?? event.plantId ?? 'P1';
    await getDb().prepare(`
      INSERT OR IGNORE INTO safety_events (plant_id, id, zone, event_type, severity, h2s, co, ch4, ts)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(spid, event.id, event.zone, event.type, event.severity, event.h2s, event.co, event.ch4, event.ts);
    writtenSafety.add(event.id);
  } catch (err) {
    logger.warn('[DB] Safety event write error', { error: String(err) });
  }
}

// Resolve a previously-persisted safety event when its gas spike clears. Sets
// resolved_at = now so the open/active count doesn't grow unbounded.
export async function resolveSafetyEventInDB(id: string): Promise<void> {
  if (!id) return;
  try {
    await getDb().prepare(`UPDATE safety_events SET resolved_at = ? WHERE id = ? AND resolved_at IS NULL`)
      .run(Date.now(), id);
  } catch (err) {
    logger.warn('[DB] Safety event resolve error', { error: String(err) });
  }
}

export async function ackAlertInDB(alertId: string, ackedBy: string): Promise<boolean> {
  try {
    const result = await getDb().prepare(`
      UPDATE alerts SET acked = 1, acked_by = ?, acked_at = ? WHERE id = ?
    `).run(ackedBy, Date.now(), alertId);
    return result.changes > 0;
  } catch (err) {
    logger.warn('[DB] Ack error', { error: String(err) });
    return false;
  }
}
