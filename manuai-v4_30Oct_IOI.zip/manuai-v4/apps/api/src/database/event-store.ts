/**
 * ManuAI — Semantic Event Store
 *
 * Persists every cross-agent event to SQLite.
 * Replaces the in-memory recentEvents[] array in semantic/service.ts.
 *
 * Every event now has:
 *   semantic_event          — the root event with full payload
 *   semantic_event_impact   — one row per impacted agent
 *
 * This gives a full audit trail: who fired it, what it impacted,
 * what actions were taken. Enterprise-grade traceability.
 */

import { getDb } from './connection';
import { logger } from '../middleware/logger';
import { CrossAgentEvent } from '../semantic/service';

export async function persistSemanticEvent(event: CrossAgentEvent): Promise<void> {
  try {
    const db = getDb();
    await db.prepare(`
      INSERT OR IGNORE INTO semantic_event
        (event_id, event_type, from_agent, asset_id, severity, message, payload, ts)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      event.id,
      event.type,
      event.from,
      event.asset || null,
      event.sev,
      event.msg,
      JSON.stringify(event),
      Date.now()
    );
  } catch(err) {
    logger.warn('[EventStore] Event persist error', { error: String(err) });
  }
}

export async function persistEventImpact(
  eventId: string,
  targetAgent: string,
  impactType: string,
  impactValue: number | null,
  impactUnit: string,
  description: string,
  actionTaken?: string,
  actionRef?: string
): Promise<void> {
  try {
    await getDb().prepare(`
      INSERT INTO semantic_event_impact
        (event_id, target_agent, impact_type, impact_value, impact_unit, description, action_taken, action_ref, ts)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(eventId, targetAgent, impactType, impactValue, impactUnit, description, actionTaken ?? null, actionRef ?? null, Date.now());
  } catch(err) {
    logger.warn('[EventStore] Impact persist error', { error: String(err) });
  }
}

export async function getRecentEvents(limit = 50): Promise<any[]> {
  try {
    return await getDb().prepare(`
      SELECT e.*, COUNT(i.id) as impact_count
      FROM semantic_event e
      LEFT JOIN semantic_event_impact i ON i.event_id = e.event_id
      GROUP BY e.event_id
      ORDER BY e.ts DESC
      LIMIT ?
    `).all(limit);
  } catch { return []; }
}

// Filter by plant_id stored inside the JSON `payload` column (semantic_event has
// no plant_id column — it's a JSON field). SQLite JSON1 (built into better-sqlite3)
// allows us to filter at the DB layer instead of post-filtering in JS.
// Events with no plant_id in payload are treated as plant-agnostic (returned for
// any plant filter) so cross-plant events (e.g. supply chain) still show.
export async function getRecentEventsByPlant(plantCode: string, limit = 50): Promise<any[]> {
  try {
    return await getDb().prepare(`
      SELECT e.*, COUNT(i.id) as impact_count
      FROM semantic_event e
      LEFT JOIN semantic_event_impact i ON i.event_id = e.event_id
      WHERE json_extract(e.payload, '$.plant_id') IS NULL
         OR json_extract(e.payload, '$.plant_id') = ''
         OR json_extract(e.payload, '$.plant_id') = ?
      GROUP BY e.event_id
      ORDER BY e.ts DESC
      LIMIT ?
    `).all(plantCode, limit);
  } catch (err) {
    // Fall back to in-JS filter if JSON1 isn't available
    try {
      const rows = await getDb().prepare(`
        SELECT e.*, COUNT(i.id) as impact_count
        FROM semantic_event e
        LEFT JOIN semantic_event_impact i ON i.event_id = e.event_id
        GROUP BY e.event_id
        ORDER BY e.ts DESC
        LIMIT ?
      `).all(limit * 2);
      return (rows as any[]).filter((r: any) => {
        try {
          const p = JSON.parse(r.payload ?? '{}');
          return !p.plant_id || p.plant_id === plantCode;
        } catch { return true; }
      }).slice(0, limit);
    } catch { return []; }
  }
}

export async function getEventWithImpacts(eventId: string): Promise<any> {
  try {
    const db = getDb();
    const event   = await db.prepare('SELECT * FROM semantic_event WHERE event_id=?').get(eventId);
    const impacts = await db.prepare('SELECT * FROM semantic_event_impact WHERE event_id=? ORDER BY ts ASC').all(eventId);
    return { event, impacts };
  } catch { return null; }
}

export async function getEventsByAsset(assetId: string, days = 7): Promise<any[]> {
  try {
    const since = Date.now() - days * 86400000;
    return await getDb().prepare(`
      SELECT * FROM semantic_event
      WHERE asset_id=? AND ts>=?
      ORDER BY ts DESC
    `).all(assetId, since);
  } catch { return []; }
}

export async function resolveEvent(eventId: string): Promise<void> {
  try {
    await getDb().prepare('UPDATE semantic_event SET resolved_at=? WHERE event_id=?').run(Date.now(), eventId);
  } catch { /* non-fatal */ }
}
