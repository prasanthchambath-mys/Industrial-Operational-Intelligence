/**
 * ManuAI — Database Connection  (Phase A: async dual-backend adapter)
 *
 * Phase 1 (current default): SQLite via better-sqlite3   — DATABASE_URL absent
 * Phase A (Azure):           PostgreSQL Flexible Server   — DATABASE_URL=postgresql://...
 *
 * ── Why this file changed for Phase A ────────────────────────────────────────
 * Postgres is asynchronous. better-sqlite3 is synchronous. To run the SAME
 * application code on both, the adapter exposes a single ASYNC surface that both
 * backends implement:
 *
 *     const rows = await getDb().prepare(sql).all(p1, p2);   // Promise<DbRow[]>
 *     const row  = await getDb().prepare(sql).get(p1);       // Promise<DbRow|undefined>
 *     const res  = await getDb().prepare(sql).run(p1, p2);   // Promise<DbResult>
 *     await getDb().exec(ddl);                               // Promise<void>
 *     await getDb().transaction(async (tx) => {              // tx-scoped handle
 *       await tx.run(sql, [a, b]);
 *     });
 *
 * The SQLite path wraps better-sqlite3's synchronous calls in resolved Promises
 * (zero behaviour change, microtask cost only). The Postgres path uses a pg.Pool
 * and converts SQLite SQL idioms → Postgres via adaptSql().
 *
 * TRANSACTIONS: better-sqlite3's db.transaction(fn) cannot be reused for Postgres
 * because a statement prepared on the pool runs on a *different* pooled connection
 * than the one holding BEGIN. So transaction(fn) now passes a transaction-scoped
 * handle `tx` whose run/get/all execute on the SAME connection that owns the
 * BEGIN/COMMIT. All call sites use `await db.transaction(async (tx) => …)`.
 *
 * SWITCH TO POSTGRES: set DATABASE_URL — nothing else changes.
 */

import path from 'path';
import fs   from 'fs';
import { logger } from '../middleware/logger';

// ─────────────────────────────────────────────────────────────────────────────
// Shared types
// ─────────────────────────────────────────────────────────────────────────────
export interface DbRow  { [key: string]: unknown }
export interface DbResult { changes: number; lastInsertRowid?: number | bigint }

/** A prepared statement whose execution methods are async on both backends. */
export interface PreparedStatement {
  all(...params: unknown[]): Promise<DbRow[]>;
  get(...params: unknown[]): Promise<DbRow | undefined>;
  run(...params: unknown[]): Promise<DbResult>;
}

/** Transaction-scoped handle — all calls run on the connection holding BEGIN. */
export interface TxHandle {
  run(sql: string, params?: unknown[]): Promise<DbResult>;
  get(sql: string, params?: unknown[]): Promise<DbRow | undefined>;
  all(sql: string, params?: unknown[]): Promise<DbRow[]>;
}

export interface DbAdapter {
  prepare(sql: string): PreparedStatement;
  // Direct async convenience methods (used by converted call sites that don't
  // want a prepared-statement object).
  all(sql: string, params?: unknown[]): Promise<DbRow[]>;
  get(sql: string, params?: unknown[]): Promise<DbRow | undefined>;
  run(sql: string, params?: unknown[]): Promise<DbResult>;
  exec(sql: string): Promise<void>;
  transaction<T>(fn: (tx: TxHandle) => Promise<T>): Promise<T>;
  pragma?(sql: string): unknown;     // SQLite only — no-op on Postgres
  close?(): Promise<void>;
  readonly backend: 'sqlite' | 'postgres';
}

// ─────────────────────────────────────────────────────────────────────────────
// SQLite adapter  (Phase 1 — default; sync engine wrapped as async)
// ─────────────────────────────────────────────────────────────────────────────
function makeSqliteAdapter(): DbAdapter {
  const dbPath = process.env.DATABASE_PATH
    ?? path.resolve(__dirname, '../../../../data/manuai.db');
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const Database = require('better-sqlite3');
  const db = new Database(dbPath) as import('better-sqlite3').Database;
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  logger.info(`[DB] SQLite connected: ${dbPath}`);

  const prepare = (sql: string): PreparedStatement => {
    const stmt = db.prepare(sql);
    return {
      all: async (...p) => stmt.all(...p) as DbRow[],
      get: async (...p) => stmt.get(...p) as DbRow | undefined,
      run: async (...p) => {
        const r = stmt.run(...p);
        return { changes: r.changes, lastInsertRowid: r.lastInsertRowid };
      },
    };
  };

  return {
    backend: 'sqlite',
    prepare,
    all: async (sql, params = []) => db.prepare(sql).all(...params) as DbRow[],
    get: async (sql, params = []) => db.prepare(sql).get(...params) as DbRow | undefined,
    run: async (sql, params = []) => {
      const r = db.prepare(sql).run(...params);
      return { changes: r.changes, lastInsertRowid: r.lastInsertRowid };
    },
    exec: async (sql) => { db.exec(sql); },
    pragma: (sql) => db.pragma(sql),
    // better-sqlite3 is fully synchronous on a single connection, so we drive the
    // transaction manually with BEGIN/COMMIT/ROLLBACK. The tx body may `await`
    // (its statements are sync-wrapped-as-async), and because there is exactly
    // one SQLite connection, the transaction stays open across those microtask
    // yields. This codebase only opens transactions at startup seeding (no
    // server traffic yet) and from the single sim-tick writer, so no concurrent
    // statement can interleave into the open transaction.
    transaction: async <T>(fn: (tx: TxHandle) => Promise<T>): Promise<T> => {
      const txHandle: TxHandle = {
        run: async (sql, params = []) => {
          const r = db.prepare(sql).run(...params);
          return { changes: r.changes, lastInsertRowid: r.lastInsertRowid };
        },
        get: async (sql, params = []) => db.prepare(sql).get(...params) as DbRow | undefined,
        all: async (sql, params = []) => db.prepare(sql).all(...params) as DbRow[],
      };
      db.exec('BEGIN');
      try {
        const result = await fn(txHandle);
        db.exec('COMMIT');
        return result;
      } catch (e) {
        try { db.exec('ROLLBACK'); } catch { /* ignore */ }
        throw e;
      }
    },
    close: async () => { db.close(); },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Safe relation drop — handles "is it a VIEW or a TABLE?" on both engines.
// SQLite refuses DROP TABLE on a view (and vice-versa), so a migration that
// recreates a relation whose kind changed between versions (e.g. dim_supplier
// went table → view) must inspect the catalog first. Idempotent: a no-op when
// the relation is absent.
// ─────────────────────────────────────────────────────────────────────────────
export async function dropRelationIfExists(name: string): Promise<void> {
  const db = getDb();
  if (db.backend === 'postgres') {
    const row = await db.get(
      `SELECT table_type FROM information_schema.tables WHERE table_name = $1
       UNION ALL SELECT 'VIEW' FROM information_schema.views WHERE table_name = $1 LIMIT 1`,
      [name],
    );
    const kind = (row?.table_type as string | undefined)?.toUpperCase();
    if (kind === 'VIEW') await db.exec(`DROP VIEW IF EXISTS ${name} CASCADE`);
    else await db.exec(`DROP TABLE IF EXISTS ${name} CASCADE`); // table or absent
    return;
  }
  // SQLite: sqlite_master.type is 'table' | 'view'
  const row = await db.get(`SELECT type FROM sqlite_master WHERE name = ?`, [name]);
  if (!row) return; // absent → nothing to drop
  if (row.type === 'view') await db.exec(`DROP VIEW IF EXISTS ${name}`);
  else if (row.type === 'table') await db.exec(`DROP TABLE IF EXISTS ${name}`);
}


// statements in schema.ts. Single source of truth for translating SQLite
// INSERT OR REPLACE / REPLACE INTO into Postgres ON CONFLICT (...) DO UPDATE.
// Do NOT guess these — if a table's PK changes in schema.ts, update it here too.
// ─────────────────────────────────────────────────────────────────────────────
export const CONFLICT_KEYS: Record<string, string[]> = {
  oee_readings: ['id'], machine_health: ['id'], alerts: ['id'], batches: ['id'],
  yield_history: ['id'], energy_readings: ['id'], safety_events: ['id'],
  ref_machines: ['id'], ref_utilities: ['id'],
  ref_yield_params: ['id', 'plant_id'], ref_energy_assets: ['id', 'plant_id'],
  ref_safety_zones: ['zone_id', 'plant_id'], ref_technicians: ['id'],
  ref_quality_lines: ['line_id', 'plant_id'], ref_tag_mappings: ['param_id', 'plant_id'],
  ref_supply_risks: ['supplier_id', 'plant_id'], ref_suppliers: ['supplier_id'],
  ref_supplier_plant_map: ['supplier_id', 'plant_id'], ref_skus: ['sku_id'],
  ref_inventory_positions: ['inventory_id'], ref_external_risk_alerts: ['alert_id'],
  ref_supplier_risk_factors: ['factor_id'], ref_supplier_lead_time_history: ['record_id'],
  ref_supplier_performance_metrics: ['metric_id'],
  gov_reorder_rules: ['rule_id'], gov_reorder_requests: ['request_id'],
  gov_auto_approved_orders: ['order_id'],
  trx_work_orders: ['id'], trx_production_orders: ['id'], trx_quality_defects: ['id'],
  trx_lims_results: ['id'], trx_safety_permits: ['ptw_id'], trx_parts_orders: ['order_id'],
  trx_parts_spend: ['id'], trx_twin_scenarios: ['id'], trx_twin_components: ['id'],
  trx_twin_kpis: ['kpi_id', 'plant_id'], trx_energy_dispatch: ['id'],
  trx_energy_waste: ['id'], trx_demand_forecast: ['id'],
  dim_plant: ['plant_id'], dim_line: ['line_id'], dim_asset: ['asset_id'],
  dim_material: ['material_id'], semantic_kpi_definition: ['kpi_id'],
  semantic_kpi_definition_history: ['id'], semantic_kpi_value: ['id'],
  semantic_event: ['event_id'], semantic_event_impact: ['id'],
  orchestration_scenario: ['scenario_id'], plant_config: ['plant_id', 'config_key'],
  schema_version: ['version'], fact_safety_event: ['id'],
};

// Insert an ON CONFLICT clause in the correct position — before a trailing
// RETURNING if one exists (Postgres requires ON CONFLICT to precede RETURNING).
function appendConflictClause(sql: string, clause: string): string {
  const ret = /\bRETURNING\b/i.exec(sql);
  if (ret) return `${sql.slice(0, ret.index).trimEnd()}${clause} ${sql.slice(ret.index)}`;
  return `${sql}${clause}`;
}

// Translate a single SQLite upsert statement → Postgres. Called only on the
// Postgres path (SQLite executes the original idiom natively and is untouched).
//   INSERT OR IGNORE  → INSERT ... ON CONFLICT DO NOTHING   (generic, no key needed)
//   INSERT OR REPLACE → INSERT ... ON CONFLICT (pk) DO UPDATE SET <non-pk> = EXCLUDED.<non-pk>
//   REPLACE INTO      → same as INSERT OR REPLACE
export function rewriteUpsertForPg(sql: string): string {
  if (/^\s*INSERT\s+OR\s+IGNORE\s+INTO\b/i.test(sql)) {
    return appendConflictClause(sql.replace(/^(\s*)INSERT\s+OR\s+IGNORE\b/i, '$1INSERT'),
                                ' ON CONFLICT DO NOTHING');
  }
  const repl = /^\s*(?:INSERT\s+OR\s+REPLACE|REPLACE)\s+INTO\s+([a-z_][a-z0-9_]*)\s*\(([^)]*)\)/i.exec(sql);
  if (repl) {
    const table = repl[1].toLowerCase();
    const cols = repl[2].split(',').map(s => s.trim()).filter(Boolean);
    const keys = CONFLICT_KEYS[table];
    if (!keys || keys.length === 0) {
      throw new Error(`adaptSql: cannot translate upsert into "${table}" — no conflict key registered in CONFLICT_KEYS`);
    }
    const keySet = new Set(keys.map(k => k.toLowerCase()));
    const updateCols = cols.filter(c => !keySet.has(c.toLowerCase()));
    const head = sql.replace(/^(\s*)(?:INSERT\s+OR\s+REPLACE|REPLACE)\b/i, '$1INSERT');
    // If every inserted column is part of the key there is nothing to update.
    const clause = updateCols.length === 0
      ? ` ON CONFLICT (${keys.join(', ')}) DO NOTHING`
      : ` ON CONFLICT (${keys.join(', ')}) DO UPDATE SET ${updateCols.map(c => `${c} = EXCLUDED.${c}`).join(', ')}`;
    return appendConflictClause(head, clause);
  }
  return sql;
}

// ─────────────────────────────────────────────────────────────────────────────
// Postgres SQL compatibility shim — SQLite idioms → Postgres equivalents
// ─────────────────────────────────────────────────────────────────────────────
export function adaptSql(sql: string): string {
  let i = 0;
  let out = rewriteUpsertForPg(sql)
    // ── Nested strftime(fmt, datetime(x/1000,'unixepoch')) ────────────────────
    // The OEE-trend / scorecard / loss-trend queries wrap the epoch column in
    // datetime() *inside* strftime(). These MUST be translated before the
    // standalone datetime() rule below — otherwise the inner datetime() is
    // rewritten first and the strftime() wrapper is left stranded (Postgres has
    // no strftime, which crashed getPlantOeeTrend). The [^,()]+? capture matches
    // the bare epoch column (ts, started_at, …), which contains no parentheses.
    .replace(/strftime\(\s*'%Y-%m-%d'\s*,\s*datetime\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)\s*\)/gi,
             "to_char(to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC','YYYY-MM-DD')")
    .replace(/strftime\(\s*'%Y-%m'\s*,\s*datetime\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)\s*\)/gi,
             "to_char(to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC','YYYY-MM')")
    .replace(/strftime\(\s*'%Y-%W'\s*,\s*datetime\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)\s*\)/gi,
             "to_char(to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC','IYYY-IW')")
    .replace(/strftime\(\s*'%H:00'\s*,\s*datetime\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)\s*\)/gi,
             "to_char(to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC','HH24:00')")
    .replace(/CAST\(\s*strftime\(\s*'%H'\s*,\s*datetime\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)\s*\)\s+AS\s+INTEGER\s*\)/gi,
             "EXTRACT(HOUR FROM to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC')::int")
    // date(x/1000,'unixepoch') → to_char(to_timestamp(x/1000.0), 'YYYY-MM-DD')   (SQLite day bucket)
    .replace(/(?<![\w.])date\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)/gi,
      (_m, x) => `to_char(to_timestamp(${x}/1000.0), 'YYYY-MM-DD')`)
    // datetime(x/1000,'unixepoch') → to_char(to_timestamp(x/1000.0) ... )
    .replace(/datetime\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)/gi,
             "to_char(to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC','YYYY-MM-DD HH24:MI:SS')")
    // date(x/1000,'unixepoch') → date form
    .replace(/\bdate\(\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)/gi,
             "to_char(to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC','YYYY-MM-DD')")
    // strftime('%Y-%m-%d', <expr>) → to_char(<expr-as-ts>,'YYYY-MM-DD')
    .replace(/strftime\(\s*'%Y-%m-%d'\s*,\s*([^()]+?)\s*\)/gi,
             "to_char(($1)::timestamp,'YYYY-MM-DD')")
    .replace(/strftime\(\s*'%Y-%m'\s*,\s*([^,()]+?)\s*\/\s*1000\s*,\s*'unixepoch'\s*\)/gi,
             "to_char(to_timestamp(($1)::float8/1000) AT TIME ZONE 'UTC','YYYY-MM')")
    .replace(/strftime\(\s*'%Y-%W'\s*,\s*([^()]+?)\s*\)/gi,
             "to_char(($1)::timestamp,'IYYY-IW')")
    .replace(/strftime\(\s*'%H:00'\s*,\s*([^()]+?)\s*\)/gi,
             "to_char(($1)::timestamp,'HH24:00')")
    // CAST(strftime('%H', <expr>) AS INTEGER) → EXTRACT(HOUR ...)
    .replace(/CAST\(\s*strftime\(\s*'%H'\s*,\s*([^()]+?)\s*\)\s+AS\s+INTEGER\s*\)/gi,
             "EXTRACT(HOUR FROM ($1)::timestamp)::int")
    // GROUP_CONCAT → string_agg
    .replace(/GROUP_CONCAT\(\s*DISTINCT\s+([^()]+?)\s*\)/gi, "string_agg(DISTINCT ($1)::text, ',')")
    .replace(/GROUP_CONCAT\(\s*([^()]+?)\s*\)/gi, "string_agg(($1)::text, ',')")
    // json_extract(col,'$.key') → col::jsonb ->> 'key'
    .replace(/json_extract\(\s*([A-Za-z_][\w.]*)\s*,\s*'\$\.([\w]+)'\s*\)/gi, "($1)::jsonb ->> '$2'")
    // INTEGER PRIMARY KEY AUTOINCREMENT → SERIAL PRIMARY KEY
    .replace(/INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT/gi, 'SERIAL PRIMARY KEY')
    // strftime('%s','now')*1000 → epoch ms
    .replace(/strftime\(\s*'%s'\s*,\s*'now'\s*\)\s*\*\s*1000/gi, "(EXTRACT(EPOCH FROM now())::bigint * 1000)");

  // Widen epoch-millisecond timestamp columns from INTEGER → BIGINT. They store
  // Date.now() (~1.7e12), which overflows Postgres' 32-bit INTEGER (SQLite INTEGER
  // is 64-bit, so this is a Postgres-only concern and SQLite DDL is untouched).
  // Gated to DDL (CREATE/ALTER TABLE) and restricted to a whitelist of known
  // timestamp columns, so count/flag INTEGER columns (enabled, active, acked,
  // trigger_count, steps_total/done, qty, lead_time_days, …) are left as INTEGER.
  if (/\b(?:CREATE|ALTER)\s+TABLE\b/i.test(out)) {
    out = out.replace(
      /\b(ts|created_at|updated_at|started_at|completed_at|closed_at|acked_at|resolved_at|valid_from|valid_to|change_ts|applied_at)(\s+)INTEGER\b/gi,
      '$1$2BIGINT');
  }

  // ? positional params → $1 $2 $3   (done last so shimmed fragments above,
  // which never contain ?, don't shift the count)
  out = out.replace(/\?/g, () => `$${++i}`);
  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// Epoch-ms parameter normalization (Postgres BIGINT safety net)
// ─────────────────────────────────────────────────────────────────────────────
// Epoch-ms timestamp columns are BIGINT in Postgres, which rejects fractional
// values (e.g. "1780353729756.9844"). Various historical/seed/sim writers can
// produce a decimal ms from expressions like `now + Math.random() * window` or
// `start + duration`. Rather than chase every call site, this truncates any bound
// parameter that maps to a known epoch-ms column to an integer, immediately before
// the statement reaches Postgres. It is column-name whitelisted, so non-timestamp
// numerics (yields, kW, gas ppm, counts, flags) are never touched, and it is a
// Postgres-only path — SQLite (64-bit INTEGER, tolerant of the fractional form) is
// left entirely untouched. Nulls pass through unchanged (in-process batches, etc.).
const EPOCH_MS_COLUMNS = new Set<string>([
  'ts', 'created_at', 'updated_at', 'started_at', 'completed_at', 'closed_at',
  'acked_at', 'resolved_at', 'valid_from', 'valid_to', 'change_ts', 'applied_at',
]);

function truncEpoch(v: unknown): unknown {
  return typeof v === 'number' && Number.isFinite(v) ? Math.trunc(v) : v;
}

export function normalizeEpochParams(sql: string, params: unknown[]): unknown[] {
  if (!Array.isArray(params) || params.length === 0) return params;

  // Multi-row inserts come only from the bulk history seeder, which truncates
  // epoch-ms columns at the source. This single-row column→param mapper would
  // only see the first tuple, so skip them entirely rather than partially map.
  if (/\)\s*,\s*\(/.test(sql)) return params;

  // INSERT [OR IGNORE|REPLACE] INTO <table> (c1, c2, ...) VALUES (?, ?, ...)
  // Only simple, fully-positional single-row inserts are rewritten; anything with
  // function calls / expressions in VALUES is left alone.
  const ins = /insert\s+(?:or\s+\w+\s+)?into\s+["'`]?\w+["'`]?\s*\(([^)]+)\)\s*values\s*\(([^)]*)\)/i.exec(sql);
  if (ins) {
    const cols = ins[1].split(',').map((c) => c.trim().replace(/["'`]/g, '').toLowerCase());
    const vals = ins[2].split(',').map((v) => v.trim());
    if (vals.length === cols.length && vals.every((v) => v === '?' || /^\$\d+$/.test(v))) {
      let out: unknown[] | null = null;
      cols.forEach((c, i) => {
        if (EPOCH_MS_COLUMNS.has(c)) {
          const t = truncEpoch(params[i]);
          if (t !== params[i]) { (out ??= params.slice())[i] = t; }
        }
      });
      return out ?? params;
    }
    return params;
  }

  // UPDATE <table> SET c1 = ?, c2 = ? [WHERE ...]
  // Skipped when the SET clause contains parentheses (function calls / expressions)
  // to avoid mis-splitting on commas and mis-mapping positional params.
  const upd = /update\s+["'`]?\w+["'`]?\s+set\s+([\s\S]+?)(?:\swhere\s|\sreturning\s|;?\s*$)/i.exec(sql);
  if (upd && !/[()]/.test(upd[1])) {
    const assigns = upd[1].split(',');
    let out: unknown[] | null = null;
    let pIdx = 0;
    for (const a of assigns) {
      const m = /^\s*["'`]?(\w+)["'`]?\s*=\s*(\?|\$\d+)\s*$/.exec(a);
      if (m) {
        if (EPOCH_MS_COLUMNS.has(m[1].toLowerCase())) {
          const t = truncEpoch(params[pIdx]);
          if (t !== params[pIdx]) { (out ??= params.slice())[pIdx] = t; }
        }
        pIdx++;
      } else {
        pIdx += (a.match(/\?|\$\d+/g) || []).length;
      }
    }
    return out ?? params;
  }

  return params;
}

// ─────────────────────────────────────────────────────────────────────────────
// Postgres adapter  (Phase A — set DATABASE_URL to enable)
// ─────────────────────────────────────────────────────────────────────────────
function makePgAdapter(url: string): DbAdapter {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { Pool, types } = require('pg');
  // Return BIGINT / int8 (type OID 20) — and therefore COUNT(*) results — as JS
  // numbers instead of node-postgres' default strings. Every bigint we store is an
  // epoch-ms timestamp or a row count, all well within Number.MAX_SAFE_INTEGER, so
  // this is lossless and makes Postgres reads behave like SQLite (numbers, not
  // strings) — avoiding string/number drift in comparisons, arithmetic, and JSON.
  types.setTypeParser(20, (v: string | null) => (v === null ? null : parseInt(v, 10)));
  const pool = new Pool({
    connectionString: url,
    ssl: url.includes('sslmode=require') ? { rejectUnauthorized: false } : false,
    max: Number(process.env.PG_POOL_MAX ?? 10),
    idleTimeoutMillis: 30000,
  });
  logger.info('[DB] PostgreSQL Flexible Server connected');

  const query = async (sql: string, params: unknown[]) =>
    pool.query(adaptSql(sql), normalizeEpochParams(sql, params));

  const prepare = (sql: string): PreparedStatement => ({
    all: async (...p) => (await query(sql, p)).rows as DbRow[],
    get: async (...p) => ((await query(sql, p)).rows[0]) as DbRow | undefined,
    run: async (...p) => { const r = await query(sql, p); return { changes: r.rowCount ?? 0 }; },
  });

  return {
    backend: 'postgres',
    prepare,
    all: async (sql, params = []) => (await query(sql, params)).rows as DbRow[],
    get: async (sql, params = []) => ((await query(sql, params)).rows[0]) as DbRow | undefined,
    run: async (sql, params = []) => { const r = await query(sql, params); return { changes: r.rowCount ?? 0 }; },
    exec: async (sql) => { await pool.query(adaptSql(sql)); },
    pragma: () => undefined,
    transaction: async <T>(fn: (tx: TxHandle) => Promise<T>): Promise<T> => {
      const client = await pool.connect();
      const tx: TxHandle = {
        run: async (sql, params = []) => { const r = await client.query(adaptSql(sql), normalizeEpochParams(sql, params)); return { changes: r.rowCount ?? 0 }; },
        get: async (sql, params = []) => (await client.query(adaptSql(sql), normalizeEpochParams(sql, params))).rows[0] as DbRow | undefined,
        all: async (sql, params = []) => (await client.query(adaptSql(sql), normalizeEpochParams(sql, params))).rows as DbRow[],
      };
      try {
        await client.query('BEGIN');
        const result = await fn(tx);
        await client.query('COMMIT');
        return result;
      } catch (e) {
        try { await client.query('ROLLBACK'); } catch { /* ignore */ }
        throw e;
      } finally {
        client.release();
      }
    },
    close: async () => { await pool.end(); },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Factory — single instance, chosen by DATABASE_URL
// ─────────────────────────────────────────────────────────────────────────────
let _adapter: DbAdapter | null = null;

export function getDb(): DbAdapter {
  if (!_adapter) {
    const provider = (process.env.DB_PROVIDER ?? '').trim().toLowerCase();
    const url = (process.env.DATABASE_URL ?? '').trim();
    let usePg: boolean;
    if (provider === 'postgres') {
      if (!url) throw new Error('[DB] DB_PROVIDER=postgres requires DATABASE_URL to be set');
      usePg = true;
    } else if (provider === 'sqlite') {
      usePg = false;   // explicit SQLite even if a DATABASE_URL happens to be present
    } else {
      // No explicit provider → infer from DATABASE_URL (backward compatible).
      usePg = url.startsWith('postgres://') || url.startsWith('postgresql://');
    }
    _adapter = usePg ? makePgAdapter(url) : makeSqliteAdapter();
  }
  return _adapter;
}

export async function closeDb(): Promise<void> {
  await _adapter?.close?.();
  _adapter = null;
}
