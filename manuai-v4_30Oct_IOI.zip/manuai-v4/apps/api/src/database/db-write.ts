// ─────────────────────────────────────────────────────────────────────────────
// Dialect-correct write helpers.
//
// These are the SANCTIONED API for new insert/upsert code. They emit native
// SQLite idioms on the SQLite backend and ON CONFLICT clauses on Postgres, using
// the schema-derived CONFLICT_KEYS map — never guessing conflict columns.
//
// NOTE: the large existing corpus of seed/writer statements still uses inline
// `INSERT OR IGNORE/REPLACE` SQL. Those are translated correctly and centrally by
// adaptSql() on the Postgres path (and run natively on SQLite), so they are
// dialect-safe without a risky 58-site rewrite. Prefer these helpers going forward.
// ─────────────────────────────────────────────────────────────────────────────
import { getDb, CONFLICT_KEYS } from './connection';

function placeholders(n: number, backend: string): string {
  // SQLite uses ?, Postgres uses $1..$n. adaptSql also converts ? → $n on the
  // Postgres path, so emitting ? here is safe for both; we emit the native form
  // directly to keep these helpers independent of the shim.
  return backend === 'postgres'
    ? Array.from({ length: n }, (_, i) => `$${i + 1}`).join(', ')
    : Array.from({ length: n }, () => '?').join(', ');
}

function resolveKeys(table: string, explicit?: string[]): string[] {
  const keys = explicit ?? CONFLICT_KEYS[table];
  if (!keys || keys.length === 0) {
    throw new Error(`db-write: no conflict key for "${table}" — pass conflictColumns or add it to CONFLICT_KEYS`);
  }
  return keys;
}

/** Insert a row, doing nothing on any key conflict (idempotent). */
export async function insertIgnore(table: string, columns: string[], values: unknown[]): Promise<void> {
  const db = getDb();
  const cols = columns.join(', ');
  const ph = placeholders(columns.length, db.backend);
  const sql = db.backend === 'postgres'
    ? `INSERT INTO ${table} (${cols}) VALUES (${ph}) ON CONFLICT DO NOTHING`
    : `INSERT OR IGNORE INTO ${table} (${cols}) VALUES (${ph})`;
  await db.run(sql, values);
}

/**
 * Upsert a row. On conflict over the table's key, updates the non-key columns.
 * conflictColumns defaults to the schema PK from CONFLICT_KEYS.
 */
export async function upsert(
  table: string,
  columns: string[],
  values: unknown[],
  conflictColumns?: string[],
  updateColumns?: string[],
): Promise<void> {
  const db = getDb();
  const cols = columns.join(', ');
  const ph = placeholders(columns.length, db.backend);
  if (db.backend !== 'postgres') {
    await db.run(`INSERT OR REPLACE INTO ${table} (${cols}) VALUES (${ph})`, values);
    return;
  }
  const keys = resolveKeys(table, conflictColumns);
  const keySet = new Set(keys.map(k => k.toLowerCase()));
  const updates = (updateColumns ?? columns.filter(c => !keySet.has(c.toLowerCase())));
  const clause = updates.length === 0
    ? `ON CONFLICT (${keys.join(', ')}) DO NOTHING`
    : `ON CONFLICT (${keys.join(', ')}) DO UPDATE SET ${updates.map(c => `${c} = EXCLUDED.${c}`).join(', ')}`;
  await db.run(`INSERT INTO ${table} (${cols}) VALUES (${ph}) ${clause}`, values);
}
