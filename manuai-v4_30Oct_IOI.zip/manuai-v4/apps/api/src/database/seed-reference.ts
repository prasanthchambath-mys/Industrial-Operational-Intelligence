/**
 * Issue 8 fix: persist reference CSV data to SQLite on startup.
 * Provides audit trail + DB queryability. Routes still serve from CSV in Phase 1;
 * Phase 2 will flip routes to query these tables.
 */
import { getDb } from './connection';
import { loadCsvRaw } from '../data/csv-loader';
import { logger } from '../middleware/logger';

// These reference datasets are seeded authoritatively by seed-master.ts into
// their real tables (trx_quality_defects, trx_twin_kpis, trx_safety_permits,
// ref_yield_params). The earlier REF_SOURCES snapshot here targeted ref_* tables
// that don't exist and column names that don't match the schema, producing boot
// warnings without adding any data. It is intentionally empty: do not re-add
// entries here — add the seed to seed-master.ts where the table is defined.
const REF_SOURCES: Array<{ csv: string; table: string; cols: string[] }> = [];

export async function seedReferenceData(): Promise<void> {
  const db = getDb();
  const now = Date.now();
  let total = 0;
  for (const src of REF_SOURCES) {
    try {
      const rows = loadCsvRaw(src.csv);
      if (!rows.length) continue;
      await db.prepare(`DELETE FROM ${src.table}`).run(); // refresh snapshot each boot
      const placeholders = src.cols.map(() => '?').join(',');
      const insSql = `INSERT INTO ${src.table} (${src.cols.join(',')}, loaded_at) VALUES (${placeholders}, ?)`;
      const rs = rows;
      await db.transaction(async (tx) => {
        for (const r of rs) await tx.run(insSql, [...src.cols.map(c => r[c] ?? null), now]);
      });
      total += rows.length;
    } catch (e) {
      logger.warn(`[RefSeed] ${src.csv} failed: ${e}`);
    }
  }
  logger.info(`[RefSeed] ${total} reference rows persisted to SQLite (Issue 8)`);
}
