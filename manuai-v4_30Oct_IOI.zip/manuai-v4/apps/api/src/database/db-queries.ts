/**
 * ManuAI — DB Query Helpers  V43
 *
 * Central access point for Tier 2 (reference) and Tier 3 (transactional)
 * tables. Routes call these instead of loadXxx() from csv-loader.
 *
 * Fallback contract: if the DB table is empty (first boot race or test env),
 * every function falls back to the CSV loader so nothing breaks.
 *
 * Phase A: when real connectors write into these tables (SAP upserts work
 * orders, LIMS upserts lab results, cameras write quality defects), these
 * queries automatically return live data — zero route changes needed.
 */

import { getDb } from './connection';
import {
  loadMachines, loadUtilities, loadYieldParams, loadWorkOrders,
  loadProductionOrders, loadQualityDefects, loadQualityLines,
  loadSafetyPermits, loadLimsResults, loadParts, loadPartsSpendHistory,
  loadTwinScenarios, loadTwinComponents, loadTwinKPIs,
  loadEnergyAssets, loadEnergyDispatch, loadEnergyWaste,
  loadSupplyRisks, loadDemandForecast, loadTechnicians, loadSafetyZones,
  loadSuppliers, loadSupplierPlantMap, loadSkus, loadInventoryPositions,
  loadExternalRiskAlerts, loadReorderRules, loadReorderRequests, loadAutoApprovedOrders,
  loadSupplierRiskFactors, loadSupplierLeadTimeHistory, loadSupplierPerformanceMetrics,
} from '../data/csv-loader';
import { logger } from '../middleware/logger';

async function dbCount(table: string): Promise<number> {
  try {
    const r = await getDb().prepare(`SELECT COUNT(*) as c FROM ${table}`).get() as { c: number };
    return r?.c ?? 0;
  } catch { return 0; }
}

// ── TIER 2: Reference / master data ──────────────────────────────────────────

export async function getMachines(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_machines') === 0) return loadMachines() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM ref_machines WHERE plant_id = ? ORDER BY id'
      : 'SELECT * FROM ref_machines ORDER BY id';
    const rows = plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all();
    return rows as any[];
  } catch (e) {
    logger.warn('[DB] getMachines fallback to CSV', { error: String(e) });
    return loadMachines() as any[];
  }
}

export async function getUtilities(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_utilities') === 0) return loadUtilities() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM ref_utilities WHERE plant_id = ? ORDER BY id'
      : 'SELECT * FROM ref_utilities ORDER BY id';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadUtilities() as any[]; }
}

export async function getYieldParams(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_yield_params') === 0) return loadYieldParams() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM ref_yield_params WHERE plant_id = ? ORDER BY id'
      : 'SELECT * FROM ref_yield_params ORDER BY id';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadYieldParams() as any[]; }
}

export async function getEnergyAssets(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_energy_assets') === 0) return loadEnergyAssets() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM ref_energy_assets WHERE plant_id = ? ORDER BY id'
      : 'SELECT * FROM ref_energy_assets ORDER BY id';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadEnergyAssets() as any[]; }
}

export async function getSafetyZones(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_safety_zones') === 0) return loadSafetyZones() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM ref_safety_zones WHERE plant_id = ? ORDER BY zone_id'
      : 'SELECT * FROM ref_safety_zones ORDER BY zone_id';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadSafetyZones() as any[]; }
}

export async function getSupplyRisks(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_supply_risks') === 0) return loadSupplyRisks() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM ref_supply_risks WHERE plant_id = ? ORDER BY supplier_id'
      : 'SELECT * FROM ref_supply_risks ORDER BY supplier_id';
    const rows = (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
    // Normalize to the CSV-loader shape downstream consumers expect:
    // expose `plant` (alias of plant_id), coerce numerics, single_source→bool.
    return rows.map(r => ({
      supplier_id: r.supplier_id, supplier_name: r.supplier_name, sku: r.sku,
      description: r.description,
      current_stock_days: Number(r.current_stock_days),
      reorder_point_days: Number(r.reorder_point_days),
      lead_time_contracted_days: Number(r.lead_time_contracted_days),
      lead_time_actual_days: Number(r.lead_time_actual_days),
      monthly_consumption: Number(r.monthly_consumption),
      unit_cost_inr: Number(r.unit_cost_inr),
      single_source: r.single_source === 'true' || r.single_source === true,
      country_of_origin: r.country_of_origin,
      financial_risk_score: Number(r.financial_risk_score),
      plant: r.plant_id, plant_id: r.plant_id,
    }));
  } catch { return loadSupplyRisks() as any[]; }
}

// ── Semantic KPI definition governance: versioned update + history ──────────
// A governed change snapshots the current row into the append-only history
// table (closing its validity window), then bumps the live row's version.
// All-or-nothing in one transaction so the audit trail can never diverge.
export async function dbUpdateKpiDefinition(
  kpiId: string,
  patch: Partial<{ kpi_name: string; formula: string; unit: string; agents: string; source_system: string; governance: string; is_derived: number }>,
  changedBy: string,
  reason: string,
): Promise<{ ok: boolean; version?: number; error?: string }> {
  try {
    const db = getDb();
    const cur = await db.prepare('SELECT * FROM semantic_kpi_definition WHERE kpi_id = ?').get(kpiId) as any;
    if (!cur) return { ok: false, error: 'KPI definition not found' };
    const now = Date.now();
    const next = {
      kpi_name:      patch.kpi_name      ?? cur.kpi_name,
      formula:       patch.formula       ?? cur.formula,
      unit:          patch.unit          ?? cur.unit,
      agents:        patch.agents        ?? cur.agents,
      source_system: patch.source_system ?? cur.source_system,
      governance:    patch.governance    ?? cur.governance,
      is_derived:    patch.is_derived != null ? (patch.is_derived ? 1 : 0) : cur.is_derived,
    };
    // No-op guard: if nothing actually changed, don't create a spurious version.
    const unchanged = next.kpi_name === cur.kpi_name && next.formula === cur.formula &&
      next.unit === cur.unit && next.agents === cur.agents &&
      next.source_system === cur.source_system && next.governance === cur.governance &&
      next.is_derived === cur.is_derived;
    if (unchanged) return { ok: true, version: cur.version };
    await db.transaction(async (tx) => {
      // 1) Snapshot the current (about-to-be-superseded) version into history.
      await tx.run(`INSERT INTO semantic_kpi_definition_history
        (kpi_id, version, kpi_name, formula, unit, agents, source_system, governance,
         is_derived, valid_from, valid_to, changed_by, change_reason, change_ts)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
        cur.kpi_id, cur.version, cur.kpi_name, cur.formula, cur.unit, cur.agents,
        cur.source_system, cur.governance, cur.is_derived, cur.valid_from ?? cur.created_at,
        now, changedBy, reason, now]);
      // 2) Update the live row to the new version.
      await tx.run(`UPDATE semantic_kpi_definition SET
        kpi_name = ?, formula = ?, unit = ?, agents = ?, source_system = ?, governance = ?,
        is_derived = ?, version = version + 1, valid_from = ?, updated_by = ?, change_reason = ?
        WHERE kpi_id = ?`, [
        next.kpi_name, next.formula, next.unit, next.agents, next.source_system, next.governance,
        next.is_derived, now, changedBy, reason, kpiId]);
    });
    const v = ((await db.prepare('SELECT version FROM semantic_kpi_definition WHERE kpi_id = ?').get(kpiId)) as any).version;
    return { ok: true, version: v };
  } catch (e) { return { ok: false, error: String(e) }; }
}

export async function getKpiDefinitionHistory(kpiId: string): Promise<any[]> {
  try {
    // Current version first, then prior versions newest-to-oldest from history.
    const cur = await getDb().prepare(`SELECT kpi_id, version, kpi_name, formula, unit, agents,
        source_system, governance, is_derived, valid_from, NULL as valid_to,
        updated_by as changed_by, change_reason, 'current' as state
      FROM semantic_kpi_definition WHERE kpi_id = ?`).get(kpiId) as any;
    const hist = await getDb().prepare(`SELECT kpi_id, version, kpi_name, formula, unit, agents,
        source_system, governance, is_derived, valid_from, valid_to,
        changed_by, change_reason, 'superseded' as state
      FROM semantic_kpi_definition_history WHERE kpi_id = ? ORDER BY version DESC`).all(kpiId) as any[];
    return cur ? [cur, ...hist] : hist;
  } catch { return []; }
}
// Each reader is DB-first with a CSV last-resort fallback (table empty or
// query error). Mutations write to SQLite so governance state survives within
// a session and resets on `docker compose down -v` (re-seed from CSV).
const boolToStr = (v: any) => (v === 1 || v === '1' || v === true || v === 'true');

export async function getSuppliers(): Promise<any[]> {
  try {
    if (await dbCount('ref_suppliers') === 0) return loadSuppliers() as any[];
    return (await getDb().prepare('SELECT * FROM ref_suppliers ORDER BY supplier_id').all() as any[])
      .map(r => ({ ...r, risk_score: Number(r.risk_score), is_active: boolToStr(r.is_active) }));
  } catch { return loadSuppliers() as any[]; }
}
export async function getSupplierPlantMap(): Promise<any[]> {
  try {
    if (await dbCount('ref_supplier_plant_map') === 0) return loadSupplierPlantMap() as any[];
    return (await getDb().prepare('SELECT * FROM ref_supplier_plant_map ORDER BY supplier_id, plant_id').all() as any[])
      .map(r => ({ ...r, monthly_exposure: Number(r.monthly_exposure), ytd_order_value: Number(r.ytd_order_value), mtd_order_value: Number(r.mtd_order_value) }));
  } catch { return loadSupplierPlantMap() as any[]; }
}
export async function getSkus(): Promise<any[]> {
  try {
    if (await dbCount('ref_skus') === 0) return loadSkus() as any[];
    return (await getDb().prepare('SELECT * FROM ref_skus ORDER BY sku_id').all() as any[])
      .map(r => ({ ...r, alternate_supplier_id: r.alternate_supplier_id || null }));
  } catch { return loadSkus() as any[]; }
}
export async function getInventoryPositions(): Promise<any[]> {
  try {
    if (await dbCount('ref_inventory_positions') === 0) return loadInventoryPositions() as any[];
    return (await getDb().prepare('SELECT * FROM ref_inventory_positions ORDER BY inventory_id').all() as any[])
      .map(r => ({ ...r, current_stock_days: Number(r.current_stock_days), reorder_point_days: Number(r.reorder_point_days), safety_stock_days: Number(r.safety_stock_days), monthly_consumption: Number(r.monthly_consumption), current_inventory_cost: Number(r.current_inventory_cost), baseline_inventory_cost: Number(r.baseline_inventory_cost) }));
  } catch { return loadInventoryPositions() as any[]; }
}
export async function getExternalRiskAlerts(): Promise<any[]> {
  try {
    if (await dbCount('ref_external_risk_alerts') === 0) return loadExternalRiskAlerts() as any[];
    return await getDb().prepare('SELECT * FROM ref_external_risk_alerts ORDER BY alert_id').all() as any[];
  } catch { return loadExternalRiskAlerts() as any[]; }
}
export async function getSupplierRiskFactors(): Promise<any[]> {
  try {
    if (await dbCount('ref_supplier_risk_factors') === 0) return loadSupplierRiskFactors() as any[];
    return await getDb().prepare('SELECT * FROM ref_supplier_risk_factors ORDER BY factor_id').all() as any[];
  } catch { return loadSupplierRiskFactors() as any[]; }
}
export async function getSupplierLeadTimeHistory(): Promise<any[]> {
  try {
    if (await dbCount('ref_supplier_lead_time_history') === 0) return loadSupplierLeadTimeHistory() as any[];
    return (await getDb().prepare('SELECT * FROM ref_supplier_lead_time_history ORDER BY record_id').all() as any[])
      .map(r => { const lead = Number(r.lead_time_days), sla = Number(r.sla_lead_time_days); return { ...r, lead_time_days: lead, sla_lead_time_days: sla, drift_days: lead - sla }; });
  } catch { return loadSupplierLeadTimeHistory() as any[]; }
}
export async function getSupplierPerformanceMetrics(): Promise<any[]> {
  try {
    if (await dbCount('ref_supplier_performance_metrics') === 0) return loadSupplierPerformanceMetrics() as any[];
    return await getDb().prepare('SELECT * FROM ref_supplier_performance_metrics ORDER BY metric_id').all() as any[];
  } catch { return loadSupplierPerformanceMetrics() as any[]; }
}
export async function getReorderRulesDb(): Promise<any[]> {
  try {
    if (await dbCount('gov_reorder_rules') === 0) return loadReorderRules() as any[];
    return (await getDb().prepare('SELECT * FROM gov_reorder_rules ORDER BY rule_id').all() as any[])
      .map(r => ({ ...r, enabled: boolToStr(r.enabled), trigger_count: Number(r.trigger_count), last_triggered_date: r.last_triggered_date || null }));
  } catch { return loadReorderRules() as any[]; }
}
export async function getReorderRequestsDb(): Promise<any[]> {
  try {
    if (await dbCount('gov_reorder_requests') === 0) return loadReorderRequests() as any[];
    return (await getDb().prepare('SELECT * FROM gov_reorder_requests ORDER BY updated_at DESC').all() as any[])
      .map(r => ({ ...r, requested_qty: Number(r.requested_qty), requested_value: Number(r.requested_value) }));
  } catch { return loadReorderRequests() as any[]; }
}
export async function getAutoApprovedOrdersDb(): Promise<any[]> {
  try {
    if (await dbCount('gov_auto_approved_orders') === 0) return loadAutoApprovedOrders() as any[];
    return (await getDb().prepare('SELECT * FROM gov_auto_approved_orders ORDER BY updated_at DESC').all() as any[])
      .map(r => ({ ...r, approved_qty: Number(r.approved_qty), approved_value: Number(r.approved_value) }));
  } catch { return loadAutoApprovedOrders() as any[]; }
}

// ── Governance mutations (write-through to SQLite) ──────────────────────────
export async function dbBumpRule(ruleId: string, lastTriggeredDate: string): Promise<void> {
  try {
    await getDb().prepare(`UPDATE gov_reorder_rules
      SET trigger_count = trigger_count + 1, last_triggered_date = ?, updated_at = ?
      WHERE rule_id = ?`).run(lastTriggeredDate, Date.now(), ruleId);
  } catch (e) { logger.warn(`[Supply] dbBumpRule failed: ${e}`); }
}
export async function dbToggleRule(ruleId: string, enabled?: boolean): Promise<{ ok: boolean; enabled?: boolean; error?: string }> {
  try {
    const row = await getDb().prepare('SELECT enabled FROM gov_reorder_rules WHERE rule_id = ?').get(ruleId) as any;
    if (!row) return { ok: false, error: 'rule not found' };
    const next = typeof enabled === 'boolean' ? enabled : !boolToStr(row.enabled);
    await getDb().prepare('UPDATE gov_reorder_rules SET enabled = ?, updated_at = ? WHERE rule_id = ?')
      .run(next ? 1 : 0, Date.now(), ruleId);
    return { ok: true, enabled: next };
  } catch (e) { return { ok: false, error: String(e) }; }
}
export async function dbInsertReorderRequest(req: any): Promise<void> {
  try {
    await getDb().prepare(`INSERT OR REPLACE INTO gov_reorder_requests
      (request_id, plant_id, sku_id, supplier_id, requested_qty, requested_value, requested_date,
       trigger_reason, approval_reason, approval_mode, triggered_by_rule_id, status, created_by,
       source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      req.request_id, req.plant_id, req.sku_id, req.supplier_id, req.requested_qty, req.requested_value,
      req.requested_date, req.trigger_reason, req.approval_reason, req.approval_mode,
      req.triggered_by_rule_id, req.status, req.created_by, 'AI Agent', Date.now());
  } catch (e) { logger.warn(`[Supply] dbInsertReorderRequest failed: ${e}`); }
}
export async function dbInsertAutoOrder(order: any): Promise<void> {
  try {
    await getDb().prepare(`INSERT OR REPLACE INTO gov_auto_approved_orders
      (order_id, plant_id, sku_id, supplier_id, approved_qty, approved_value, approved_date,
       rule_id, rule_name, sap_status, status, reason, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      order.order_id, order.plant_id, order.sku_id, order.supplier_id, order.approved_qty,
      order.approved_value, order.approved_date, order.rule_id, order.rule_name,
      order.sap_status, order.status, order.reason, order.source_system ?? 'SAP_MM', Date.now());
  } catch (e) { logger.warn(`[Supply] dbInsertAutoOrder failed: ${e}`); }
}
export async function dbInsertReorderRule(rule: any): Promise<{ ok: boolean; error?: string }> {
  try {
    const exists = await getDb().prepare('SELECT 1 FROM gov_reorder_rules WHERE rule_id = ?').get(rule.rule_id);
    if (exists) return { ok: false, error: 'rule_id already exists' };
    await getDb().prepare(`INSERT INTO gov_reorder_rules
      (rule_id, rule_name, category, description, conditions, approval_mode, enabled, plant_scope,
       created_date, last_triggered_date, trigger_count, source_system, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      rule.rule_id, rule.rule_name, rule.category, rule.description, rule.conditions,
      rule.approval_mode, rule.enabled ? 1 : 0, rule.plant_scope,
      rule.created_date, null, 0, 'UI', Date.now());
    return { ok: true };
  } catch (e) { return { ok: false, error: String(e) }; }
}
export async function dbUpdateRequestStatus(requestId: string, status: string): Promise<{ ok: boolean; row?: any; error?: string }> {
  try {
    const row = await getDb().prepare('SELECT * FROM gov_reorder_requests WHERE request_id = ?').get(requestId) as any;
    if (!row) return { ok: false, error: 'request not found' };
    await getDb().prepare('UPDATE gov_reorder_requests SET status = ?, updated_at = ? WHERE request_id = ?')
      .run(status, Date.now(), requestId);
    return { ok: true, row: { ...row, requested_qty: Number(row.requested_qty), requested_value: Number(row.requested_value) } };
  } catch (e) { return { ok: false, error: String(e) }; }
}

export async function getTechnicians(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_technicians') === 0) return loadTechnicians() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM ref_technicians WHERE plant_id = ? AND active = 1 ORDER BY id'
      : 'SELECT * FROM ref_technicians WHERE active = 1 ORDER BY id';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadTechnicians() as any[]; }
}

export async function getQualityLines(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('ref_quality_lines') === 0) return loadQualityLines() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT line_id as line, quality_rate_pct, model_version FROM ref_quality_lines WHERE plant_id = ?'
      : 'SELECT line_id as line, quality_rate_pct, model_version FROM ref_quality_lines';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadQualityLines() as any[]; }
}

// ── TIER 3: Transactional records ────────────────────────────────────────────

export async function getWorkOrders(plant?: string, status?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_work_orders') === 0) return loadWorkOrders() as any[];
    let sql = 'SELECT * FROM trx_work_orders WHERE 1=1';
    const params: any[] = [];
    if (plant && plant !== 'All Plants') { sql += ' AND plant_id = ?'; params.push(plant); }
    if (status) { sql += ' AND status = ?'; params.push(status); }
    sql += ' ORDER BY created_at DESC LIMIT 200';
    return await getDb().prepare(sql).all(...params) as any[];
  } catch { return loadWorkOrders() as any[]; }
}

// Normalize a production-order row to the single shape the UI consumes
// (start/end/plan/actual/qty/plant), accepting either raw DB column names
// (start_date/qty_kg/plan_yield/...) or the CSV-loader keys.
function mapProductionOrder(r: any): any {
  if (r.start !== undefined || r.qty !== undefined) return r; // already loader shape
  return {
    id:      r.id,
    product: r.product,
    qty:     r.qty_kg != null ? `${r.qty_kg} kg` : (r.qty ?? ''),
    plan:    r.plan_yield ?? null,
    actual:  r.actual_yield ?? null,
    status:  r.status,
    start:   r.start_date ?? null,
    end:     r.end_date ?? null,
    plant:   r.plant_id ?? r.plant ?? 'P1',
  };
}

export async function getProductionOrders(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_production_orders') === 0) return (loadProductionOrders() as any[]).map(mapProductionOrder);
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM trx_production_orders WHERE plant_id = ? ORDER BY updated_at DESC LIMIT 100'
      : 'SELECT * FROM trx_production_orders ORDER BY updated_at DESC LIMIT 100';
    const rows = (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
    return rows.map(mapProductionOrder);
  } catch { return (loadProductionOrders() as any[]).map(mapProductionOrder); }
}

export async function getQualityDefects(plant?: string, line?: string, limit = 100): Promise<any[]> {
  try {
    if (await dbCount('trx_quality_defects') === 0) return loadQualityDefects() as any[];
    let sql = 'SELECT * FROM trx_quality_defects WHERE 1=1';
    const params: any[] = [];
    if (plant && plant !== 'All Plants') { sql += ' AND plant_id = ?'; params.push(plant); }
    if (line) { sql += ' AND line = ?'; params.push(line); }
    sql += ` ORDER BY created_at DESC LIMIT ${limit}`;
    return await getDb().prepare(sql).all(...params) as any[];
  } catch { return loadQualityDefects() as any[]; }
}

export async function getLimsResults(plant?: string, batchId?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_lims_results') === 0) return loadLimsResults() as any[];
    let sql = 'SELECT * FROM trx_lims_results WHERE 1=1';
    const params: any[] = [];
    if (plant && plant !== 'All Plants') { sql += ' AND plant_id = ?'; params.push(plant); }
    if (batchId) { sql += ' AND batch_id = ?'; params.push(batchId); }
    sql += ' ORDER BY created_at DESC LIMIT 50';
    return await getDb().prepare(sql).all(...params) as any[];
  } catch { return loadLimsResults() as any[]; }
}

export async function getSafetyPermits(plant?: string, status?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_safety_permits') === 0) return loadSafetyPermits() as any[];
    let sql = 'SELECT * FROM trx_safety_permits WHERE 1=1';
    const params: any[] = [];
    if (plant && plant !== 'All Plants') { sql += ' AND plant_id = ?'; params.push(plant); }
    if (status) { sql += ' AND status = ?'; params.push(status); }
    sql += ' ORDER BY created_at DESC LIMIT 50';
    return await getDb().prepare(sql).all(...params) as any[];
  } catch { return loadSafetyPermits() as any[]; }
}

export async function getPartsOrders(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_parts_orders') === 0) {
      const p = loadParts() as any;
      return p?.orders ?? [];
    }
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT * FROM trx_parts_orders WHERE plant_id = ? ORDER BY created_at DESC LIMIT 100'
      : 'SELECT * FROM trx_parts_orders ORDER BY created_at DESC LIMIT 100';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { const p = loadParts() as any; return p?.orders ?? []; }
}

export async function getPartsSpend(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_parts_spend') === 0) return loadPartsSpendHistory() as any[];
    const sql = plant && plant !== 'All Plants'
      ? 'SELECT month_label as month, planned_inr, unplanned_inr, plant_id as plant FROM trx_parts_spend WHERE plant_id = ? ORDER BY month_label'
      : 'SELECT month_label as month, planned_inr, unplanned_inr, plant_id as plant FROM trx_parts_spend ORDER BY plant_id, month_label';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadPartsSpendHistory() as any[]; }
}

export async function getTwinScenarios(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_twin_scenarios') === 0) return loadTwinScenarios() as any[];
    const sql = plant && plant !== 'All Plants'
      ? "SELECT * FROM trx_twin_scenarios WHERE plant_id = ? OR plant_id = 'Both' ORDER BY updated_at DESC"
      : 'SELECT * FROM trx_twin_scenarios ORDER BY updated_at DESC';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadTwinScenarios() as any[]; }
}

export async function getTwinComponents(assetId?: string): Promise<Record<string, any[]>> {
  try {
    if (await dbCount('trx_twin_components') === 0) return loadTwinComponents() as Record<string, any[]>;
    const sql = assetId
      ? 'SELECT * FROM trx_twin_components WHERE asset_id = ? ORDER BY component_name'
      : 'SELECT * FROM trx_twin_components ORDER BY asset_id, component_name';
    const rows = (assetId
      ? await getDb().prepare(sql).all(assetId)
      : await getDb().prepare(sql).all()) as any[];
    const grouped: Record<string, any[]> = {};
    for (const r of rows) {
      if (!grouped[r.asset_id]) grouped[r.asset_id] = [];
      grouped[r.asset_id].push(r);
    }
    return grouped;
  } catch { return loadTwinComponents() as Record<string, any[]>; }
}

export async function getTwinKPIs(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_twin_kpis') === 0) return loadTwinKPIs() as any[];
    const sql = plant && plant !== 'All Plants'
      ? "SELECT * FROM trx_twin_kpis WHERE plant_id = ? OR plant_id = 'Both'"
      : 'SELECT * FROM trx_twin_kpis';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadTwinKPIs() as any[]; }
}

export async function getEnergyDispatch(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_energy_dispatch') === 0) return loadEnergyDispatch() as any[];
    const sql = plant && plant !== 'All Plants'
      ? "SELECT * FROM trx_energy_dispatch WHERE plant_id = ? ORDER BY created_at DESC"
      : 'SELECT * FROM trx_energy_dispatch ORDER BY plant_id, created_at DESC';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadEnergyDispatch() as any[]; }
}

export async function getEnergyWaste(plant?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_energy_waste') === 0) return loadEnergyWaste() as any[];
    const sql = plant && plant !== 'All Plants'
      ? "SELECT * FROM trx_energy_waste WHERE plant_id = ? ORDER BY created_at DESC"
      : 'SELECT * FROM trx_energy_waste ORDER BY plant_id, created_at DESC';
    return (plant && plant !== 'All Plants'
      ? await getDb().prepare(sql).all(plant)
      : await getDb().prepare(sql).all()) as any[];
  } catch { return loadEnergyWaste() as any[]; }
}

export async function getDemandForecast(plant?: string, product?: string): Promise<any[]> {
  try {
    if (await dbCount('trx_demand_forecast') === 0) return loadDemandForecast() as any[];
    let sql = 'SELECT plant_id as plant, product, week_label as week, actual_kg as actual, forecast_kg as forecast FROM trx_demand_forecast WHERE 1=1';
    const params: any[] = [];
    if (plant && plant !== 'All Plants') { sql += ' AND plant_id = ?'; params.push(plant); }
    if (product) { sql += ' AND product = ?'; params.push(product); }
    sql += ' ORDER BY plant_id, product, week_label';
    return await getDb().prepare(sql).all(...params) as any[];
  } catch { return loadDemandForecast() as any[]; }
}

// ── Write helpers (Phase A: SAP/LIMS upserts land here) ──────────────────────

export async function upsertWorkOrder(wo: {
  id: string; plant_id: string; asset_id: string; asset_name?: string;
  wo_type: string; priority: string; description?: string; status: string;
  assigned_to?: string; sap_order_type?: string; triggered_by?: string;
}): Promise<void> {
  const now = Date.now();
  await getDb().prepare(`INSERT OR REPLACE INTO trx_work_orders
    (id, plant_id, asset_id, asset_name, wo_type, priority, description, status,
     assigned_to, sap_order_type, triggered_by, source_system, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(wo.id, wo.plant_id, wo.asset_id, wo.asset_name ?? null,
         wo.wo_type, wo.priority, wo.description ?? null, wo.status,
         wo.assigned_to ?? null, wo.sap_order_type ?? null, wo.triggered_by ?? null,
         'SAP_PM', now, now);
}

export async function upsertQualityDefect(d: {
  id: string; plant_id: string; line: string; defect_type: string;
  severity: string; confidence?: number; action?: string; ncr_id?: string;
}): Promise<void> {
  const now = Date.now();
  await getDb().prepare(`INSERT OR IGNORE INTO trx_quality_defects
    (id, plant_id, line, defect_type, severity, confidence, action, ncr_id, source_system, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(d.id, d.plant_id, d.line, d.defect_type, d.severity,
         d.confidence ?? null, d.action ?? null, d.ncr_id ?? null, 'VISION_AI', now);
}

export async function upsertLimsResult(r: {
  id: string; plant_id: string; batch_id: string; test_name: string;
  result: string; limit_range?: string; status: string; analyst?: string;
}): Promise<void> {
  const now = Date.now();
  await getDb().prepare(`INSERT OR REPLACE INTO trx_lims_results
    (id, plant_id, batch_id, test_name, result, limit_range, status, analyst, source_system, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(r.id, r.plant_id, r.batch_id, r.test_name, r.result,
         r.limit_range ?? null, r.status, r.analyst ?? null, 'LIMS', now);
}

export async function upsertSupplyRisk(s: {
  supplier_id: string; plant_id: string; supplier_name: string; sku: string;
  current_stock_days?: number; lead_time_actual_days?: number;
  financial_risk_score?: number; single_source?: string;
}): Promise<void> {
  const now = Date.now();
  await getDb().prepare(`INSERT OR REPLACE INTO ref_supply_risks
    (supplier_id, plant_id, supplier_name, sku,
     current_stock_days, lead_time_actual_days, financial_risk_score,
     single_source, source_system, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(s.supplier_id, s.plant_id, s.supplier_name, s.sku,
         s.current_stock_days ?? null, s.lead_time_actual_days ?? null,
         s.financial_risk_score ?? 0, s.single_source ?? 'false', 'SAP_MM', now);
}
