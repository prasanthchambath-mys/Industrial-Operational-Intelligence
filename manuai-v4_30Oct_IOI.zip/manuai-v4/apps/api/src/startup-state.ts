// ── Startup state ────────────────────────────────────────────────────────────
// Single source of truth for boot progress, shared between the bootstrap sequence
// (index.ts) and the readiness probe (routes/health.ts) without a circular import.
//
// Phase A safety contract: the API must NOT report ready — and must NOT serve
// business traffic — until every required boot step has completed. If any step
// fails, bootError is set, readiness returns not_ready (503), and the not-ready
// gate blocks all /api routes except /api/health/*. This is the "fail readiness
// clearly" path; the container stays up so an operator can curl /api/health/ready
// and see the exact bootError rather than facing a crash-loop that hides it.

export interface StartupState {
  bootComplete: boolean;
  bootError: string | null;
  dbReady: boolean;
  migrationsComplete: boolean;
  seedComplete: boolean;
  dataLoadMode: string;
  dbProvider: string;
  startedAt: string;
}

export const APP_VERSION = process.env.APP_VERSION ?? '4.0.0';

export const startupState: StartupState = {
  bootComplete: false,
  bootError: null,
  dbReady: false,
  migrationsComplete: false,
  seedComplete: false,
  dataLoadMode: (process.env.DATA_LOAD_MODE ?? 'csv').toLowerCase(),
  dbProvider: (process.env.DB_PROVIDER ?? '').toLowerCase() || 'auto',
  startedAt: new Date().toISOString(),
};
