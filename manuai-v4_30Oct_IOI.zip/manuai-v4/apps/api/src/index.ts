import 'dotenv/config';
import { runMigrations, runPlantMigration } from './database/schema';
import { isHistorySeeded } from './database/schema';
import { seedHistory } from './database/seed-history';
import { seedDimensions } from './database/seed-dimensions';
import { seedReferenceData } from './database/seed-reference';
import { seedMasterData } from './database/seed-master';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import { createServer } from 'http';
import { initWebSocket } from './websocket/broadcaster';
import { authMiddleware } from './middleware/auth';
import { requestLogger, logger, errorHandler } from './middleware/logger';
import { startIngestion } from './connectors/iot-hub';
import { simulationEngine } from './simulation/engine';
import { warmKpiDefinitions } from './semantic/service';
import { startupState, APP_VERSION } from './startup-state';
import { getDb } from './database/connection';
import healthRoutes from './routes/health';
import oeeRoutes from './routes/oee';
import yieldRoutes from './routes/yield';
import pdmRoutes from './routes/pdm';
import qualityRoutes from './routes/quality';
import energyRoutes from './routes/energy';
import supplyRoutes from './routes/supply';
import twinRoutes from './routes/twin';
import safetyRoutes from './routes/safety';
import semanticRoutes from './routes/semantic';
import aiRoutes from './routes/ai';
import historyRoutes from './routes/history';
import configRoutes      from './routes/config';
import { sourceRouter }      from './routes/source';
import { semanticCoreRouter } from './routes/semantic-core';
import { registerLiveSources } from './semantic/live-sources';
import { resolverMode } from './semantic/resolver';
import { startSemanticScheduler, checkSeedDrift } from './semantic/governance-runtime';

const app = express();
app.set('trust proxy', 1); // Trust nginx proxy - fixes rate limiter X-Forwarded-For error
const httpServer = createServer(app);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.CORS_ORIGINS?.split(',') ?? ['http://localhost:5173'],
  credentials: true,
}));
app.use(rateLimit({ windowMs: 60_000, max: 2000, standardHeaders: true, skip: (req) => req.path.startsWith('/api/oee/live') || req.path.startsWith('/api/health') }));
app.use(compression());
app.use(express.json({ limit: '1mb' }));
app.use(requestLogger);

app.use('/api/health',   healthRoutes);
app.get('/api/version', (_req, res) => {
  res.json({ version: APP_VERSION, node: process.version, ts: Date.now() });
});
// ── Not-ready gate ──────────────────────────────────────────────────────────
// Until bootstrap completes, every /api route except /api/health/* returns 503.
// This enforces "must not accept traffic before boot is complete" at the app
// layer, independent of the orchestrator's readiness probe.
app.use('/api', (req, res, next) => {
  if (startupState.bootComplete) return next();
  if (req.path.startsWith('/health')) return next();
  return res.status(503).json({
    status: 'not_ready',
    bootComplete: false,
    bootError: startupState.bootError,
    timestamp: new Date().toISOString(),
  });
});
app.use('/api',          authMiddleware);
app.use('/api/oee',      oeeRoutes);
app.use('/api/yield',    yieldRoutes);
app.use('/api/pdm',      pdmRoutes);
app.use('/api/quality',  qualityRoutes);
app.use('/api/energy',   energyRoutes);
app.use('/api/supply',   supplyRoutes);
app.use('/api/twin',     twinRoutes);
app.use('/api/safety',   safetyRoutes);
app.use('/api/semantic', semanticRoutes);
app.use('/api/ai',       aiRoutes);
app.use('/api/history',  historyRoutes);
app.use('/api/config',      configRoutes);
app.use('/api/source',      sourceRouter);
app.use('/api/semantic/core', semanticCoreRouter);
app.use(errorHandler);

// ── Database init ──────────────────────────────────────────────────────────
// Lifecycle is config-driven so the SAME image serves local-demo, local-azure-sim,
// and Azure Phase A without code changes:
//   RUN_MIGRATIONS=true|false   — apply schema migrations on boot (default true)
//   SEED_ON_BOOT=true|false     — seed reference+history data on boot (default true)
//   DATA_LOAD_MODE=csv|db|none  — csv: seed from CSV; db: data pre-loaded into the
//                                 DB out-of-band (Phase A), never overwrite it; none: skip
// Everything is awaited in dependency order BEFORE the server accepts traffic, so
// the first request can never race an unseeded DB.
const RUN_MIGRATIONS = (process.env.RUN_MIGRATIONS ?? 'true').toLowerCase() !== 'false';
const SEED_ON_BOOT   = (process.env.SEED_ON_BOOT ?? 'true').toLowerCase() !== 'false';
const DATA_LOAD_MODE = (process.env.DATA_LOAD_MODE ?? 'csv').toLowerCase();

async function bootstrap(): Promise<void> {
  if (RUN_MIGRATIONS) {
    await runMigrations();
    await runPlantMigration();
  } else {
    logger.info('[DB] RUN_MIGRATIONS=false — skipping schema migrations');
  }
  startupState.migrationsComplete = true;

  // Phase A loads governed captured extracts into Postgres out-of-band
  // (DATA_LOAD_MODE=db, SEED_ON_BOOT=false), so the container must never seed
  // over real data. CSV seeding only runs in demo / azure-sim modes.
  const shouldSeed = SEED_ON_BOOT && DATA_LOAD_MODE === 'csv';
  if (shouldSeed) {
    await seedDimensions();
    await seedReferenceData();
    if (!(await isHistorySeeded())) {
      logger.info('Database empty — seeding 30 days of historical data...');
      await seedHistory();
      await seedMasterData();
    } else {
      logger.info('[DB] Historical data already present — skipping seed');
    }
  } else {
    logger.info(`[DB] Seeding skipped (SEED_ON_BOOT=${SEED_ON_BOOT}, DATA_LOAD_MODE=${DATA_LOAD_MODE})`);
  }
  startupState.seedComplete = true;

  // Verify DB is actually reachable before declaring readiness. In DATA_LOAD_MODE=db
  // (Phase A) this is the check that fails the boot if Postgres connectivity is down.
  await getDb().prepare('SELECT 1 as ok').get();
  startupState.dbReady = true;

  // DB-authoritative KPI definitions override the CSV bootstrap cache.
  try { await warmKpiDefinitions(); } catch (e) { logger.warn('[DB] KPI warm failed', { error: String(e) }); }
}

// HTTP server starts listening immediately so liveness/readiness probes respond
// during and after boot. The not-ready gate (above) blocks business traffic until
// bootstrap succeeds; readiness reports not_ready with the exact error on failure.
const PORT = Number(process.env.PORT ?? 4000);
httpServer.listen(PORT, () => {
  logger.info(`ManuAI API listening on port ${PORT} [${process.env.NODE_ENV ?? 'development'}] — boot in progress`);
});
initWebSocket(httpServer);

bootstrap()
  .then(() => {
    startupState.bootComplete = true;
    startupState.bootError = null;
    logger.info('[DB] Bootstrap complete — API ready');

    // Start IoT Hub ingestion (falls back to simulation if no connection string)
    void startIngestion();

    // Start synthetic data engine only after a clean boot (never write to a
    // broken/unseeded DB). Disabled when real connectors are active.
    if (process.env.MOCK_DATA_ENGINE !== 'false') {
      // Uniform KPI cadence: the engine ticks once and broadcasts EVERY KPI channel
      // (oee, quality, supply, twin, safety, yield, energy) together on the same
      // interval, so no KPI updates on a different schedule from another. This is
      // aligned to the frontend's unified 15s refresh (REST poll + KPI snapshot) so
      // the whole pipeline shares a single 15s heartbeat. Override with SIM_TICK_MS.
      const simTickMs = Number(process.env.SIM_TICK_MS ?? 15000);
      simulationEngine.start(Number.isFinite(simTickMs) && simTickMs > 0 ? simTickMs : 15000);
      logger.info('Synthetic data engine active');
    } else {
      logger.info('Synthetic data engine disabled (real connectors mode)');
    }
    registerLiveSources();
    logger.info(`[Semantic] resolver mode: ${resolverMode()}`);
    if (resolverMode() !== 'off') {
      checkSeedDrift().then(d => logger.info('[Semantic] seed drift check', d)).catch(e => logger.warn('[Semantic] drift check failed', { error: String(e) }));
      startSemanticScheduler();
    }
    logger.info(`ManuAI API running on port ${PORT} [${process.env.NODE_ENV ?? 'development'}]`);
  })
  .catch(err => {
    startupState.bootComplete = false;
    startupState.bootError = err instanceof Error ? err.message : String(err);
    logger.error('[DB] Bootstrap FAILED — API will report not_ready and refuse traffic', { error: startupState.bootError });
    // The synthetic engine is NOT started. Readiness stays not_ready (503) and the
    // not-ready gate blocks all /api business routes. Operators see bootError via
    // /api/health/ready. We deliberately do not crash-loop, which would hide the cause.
  });

export default app;
