import { Router } from 'express';
import { loadYieldParams, loadTagMappings, loadPlatformConfig } from '../data/csv-loader';
import { getTagsBatch } from '../connectors/pi-historian';
import { getTodayResults } from '../connectors/lims';
import { getProductionOrders } from '../connectors/sap-odata';
import { getProductionOrders as getDbProductionOrders } from '../database/db-queries';
import { writeSetPoint } from '../connectors/opc-ua';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { broadcast } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { getPlantState } from '../simulation/engine';
import { z } from 'zod';
import { normalizePlant } from '../data/plant';

const router = Router();

// ── Non-blocking ML cache (yield-optimizer) ──────────────────────────────────
// Keeps /api/yield/params fast: the route reads the last cached prediction and,
// when stale, fires a background refresh it does NOT await. TTL matches the 15s
// dashboard poll, so the Python service is hit at most once per plant per cycle.
const _yieldMlCache = new Map<string, { data: any; ts: number }>();
const _ML_TTL_MS = 15000;
function getYieldMlCached(key: string, payload: any): any {
  const hit = _yieldMlCache.get(key);
  const fresh = hit && (Date.now() - hit.ts) < _ML_TTL_MS;
  const url = process.env.YIELD_SERVICE_URL;
  if (!fresh && url) {
    fetch(`${url}/predict`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload), signal: AbortSignal.timeout(2500),
    })
      .then(r => (r.ok ? r.json() : null))
      .then(d => { if (d) _yieldMlCache.set(key, { data: d, ts: Date.now() }); })
      .catch(() => { /* leave previous cached value */ });
  }
  return hit?.data ?? null;
}

// DCS parameter metadata. Tag mappings (PI tag path + OPC-UA node ID) sourced
// from tag_mappings.csv — replaces the hardcoded synthesized pattern used in
// Phase 1 demo. Falls back to a clearly-marked legacy pattern only if a row is
// missing from the mapping CSV (defensive).
function getParamsMeta() {
  const tagMap = loadTagMappings();
  return (loadYieldParams() as any[]).map(p => {
    const mapping = tagMap.get(p.id);
    if (!mapping) {
      logger.warn(`[Yield] No tag mapping for ${p.id} — using fallback synthesized pattern. Add a row to tag_mappings.csv.`);
    }
    return {
      id:     p.id,
      name:   p.name,
      // Real PI tag from the CSV registry. Fallback synthesis only fires if CSV row missing.
      piTag:  mapping?.piTag ?? `Plant.Reactor.${p.id.replace('-','')}.PV`,
      nodeId: mapping?.opcNodeId ?? `ns=2;s=${p.id.replace('-','')}_SP`,
      unit:   p.unit,
      min:    Number(p.min ?? 0),
      max:    Number(p.max ?? 100),
      target: Number(p.tgt ?? 0),
      plant:  p.plant || mapping?.plant || 'P1',
      // Per-param warn threshold (fraction of target) — falls back to platform default
      warnThresholdPct: p.warnThresholdPct,
    };
  });
}

router.get('/params', async (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  // Load yield agent knobs from platform_config.csv. Defaults match the
  // previous hardcoded behaviour so removing CSV rows is non-breaking.
  const cfg = loadPlatformConfig();
  const defaultWarnPct = cfg.yieldThreshold?.warn_threshold_pct_default ?? 0.05;
  const impactSensitivity = cfg.yieldThreshold?.impact_sensitivity ?? 5;
  const impactMaxPct = cfg.yieldThreshold?.impact_max_pct ?? 5;

  const piValues = await getTagsBatch(getParamsMeta().map(p => p.piTag)).catch(() => ({}));
  const simParams = getPlantState().yieldParams;

  const params = getParamsMeta().map(p => {
    const simVal = simParams.find(sp => sp.id === p.id);
    const val = piValues[p.piTag] ?? simVal?.val ?? p.target;
    const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId: p.id });
    // Yield impact heuristic (Phase 1): magnitude proportional to how far the parameter
    // sits from target relative to its safe range. Bounded by impact_max_pct. Sign indicates
    // direction (positive = recommended adjustment will improve yield). Replace with XGBoost
    // feature attribution in Phase 2.
    const range = Math.max(0.001, p.max - p.min);
    const offsetRatio = (p.target - val) / range;
    const impactPct = Math.max(-impactMaxPct, Math.min(impactMaxPct, offsetRatio * impactSensitivity));
    const impact = `${impactPct >= 0 ? '+' : ''}${impactPct.toFixed(2)}% yield`;
    // Warn threshold: per-param value if set, else platform default
    const warnPct = p.warnThresholdPct ?? defaultWarnPct;
    return {
      ...p, val: +val.toFixed(1),
      warn: p.target !== 0 && Math.abs(val - p.target) / p.target > warnPct,
      blocked: conflict.blocked, blockedReason: conflict.reason,
      impact,
    };
  });
  const filteredParams = pfCode && pfCode !== 'All Plants'
    ? params.filter((p:any) => !p.plant || p.plant === pfCode || p.plant === 'Both')
    : params;

  // ML enrichment (non-blocking): the yield-optimizer prediction is served from a
  // 15s in-memory cache. On a stale/cold cache we kick off a background refresh and
  // return the last value (or null) immediately — the request NEVER waits on the
  // Python service, so /params stays fast even when the service is cold. The banner
  // fills in within one poll cycle. Rule heuristic (`impact`) always present.
  let ml: any = null;
  if (process.env.YIELD_SERVICE_URL) {
    const payload: any = { batch_id: 'live', run_minutes: 0 };
    for (const p of params) payload[String(p.id).toLowerCase().replace(/-/g, '_')] = p.val;
    ml = getYieldMlCached(pfCode ?? 'all', payload);
  }
  res.json({
    params: filteredParams,
    ml,                                   // XGBoost prediction (cached; null until first refresh lands)
    source_mode: ml ? 'ML+SIM' : 'SIM',
    timestamp: new Date().toISOString(),
  });
});

const WriteSchema = z.object({ tagId: z.string(), value: z.number(), reason: z.string().min(5) });

router.post('/dcs-write', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  const parsed = WriteSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.issues }); return; }
  const { tagId, value, reason } = parsed.data;

  const conflict = semanticLayer.checkConflict({ agent: 'yield', type: 'dcs_write', tagId });
  if (conflict.blocked) { res.status(409).json({ error: 'Semantic Layer block', reason: conflict.reason }); return; }

  const param = getParamsMeta().find(p => p.id === tagId);
  if (!param) { res.status(404).json({ error: `Unknown tag: ${tagId}` }); return; }
  if (value < param.min || value > param.max) { res.status(400).json({ error: `${value} out of safe range [${param.min}, ${param.max}]` }); return; }

  const ok = await writeSetPoint(param.nodeId, value);
  if (!ok) { res.status(502).json({ error: 'OPC-UA write failed' }); return; }

  logger.info('DCS write', { tagId, value, user: req.user?.name, reason });
  await semanticLayer.publishEvent({ id:`DCS-${Date.now()}`, from:'yield', to:'oee', type:'dcs_write', sev:'info',
    msg:`${param.name} → ${value} ${param.unit}: ${reason}`, impact:'Yield impact expected within 15 min', asset:tagId,
    plant_id: ((param as any).plant === 'P2' ? 'P2' : 'P1'),
    ts:new Date().toISOString() } as any);
  broadcast('yield', { type:'dcs_confirmed', tagId, value });
  res.json({ success: true, tagId, value, unit: param.unit });
});

// POST /api/yield/dismiss — operator dismisses a yield recommendation without
// writing to DCS. Records the rejection as a semantic event so the audit trail
// is complete (previously the Insights panel "Dismiss" button only mutated
// local state and the action evaporated on refresh).
router.post('/dismiss', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { tagId, reason } = (req.body ?? {}) as { tagId?: string; reason?: string };
  if (!tagId) return res.status(400).json({ error: 'tagId required' });
  const param = getParamsMeta().find(p => p.id === tagId);
  const paramName = param?.name ?? tagId;
  const now = new Date().toISOString();
  try {
    await semanticLayer.publishEvent({
      id: `DISMISS-${Date.now()}`, from: 'yield', to: 'audit',
      type: 'yield_rec_dismissed', sev: 'info',
      msg: `Yield rec for ${paramName} dismissed${reason ? ` — ${reason}` : ''}`,
      impact: 'Recommendation not pushed to DCS',
      asset: tagId,
      plant_id: ((param as any)?.plant === 'P2' ? 'P2' : 'P1'),
      ts: now,
    } as any);
  } catch { /* event publish must not block dismiss */ }
  res.json({ success: true, tagId, dismissedBy: req.user?.name, at: now });
});

router.get('/lims', async (req, res) => {
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  const all = await getTodayResults();
  const results = pfCode && pfCode !== 'All Plants'
    ? (all as any[]).filter((r:any) => !r.plant || r.plant === pfCode)
    : all;
  res.json({ results });
});

// Canonical timestamp format for production orders: YYYY-MM-DD HH:MM (local).
// Used only as a last resort when a live batch has no persisted row; all other
// rows carry their stored window from the DB unchanged.
function toYmdHm(ms: number): string {
  const d = new Date(ms);
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

router.get('/orders', async (req, res) => {
  const opf = req.query.plant as string | undefined;
  const opfCode = normalizePlant(opf);
  const state = getPlantState();
  // Single source of truth: production orders come from the DB table
  // (trx_production_orders), which itself falls back to CSV when unseeded.
  // In live SAP mode (SAP_ODATA_BASE_URL set) the OData connector takes precedence.
  let orders: any[] = [];
  if (process.env.SAP_ODATA_BASE_URL) {
    orders = (await getProductionOrders().catch(() => [])) as any[];
  }
  if (!orders.length) {
    try { orders = await getDbProductionOrders(opfCode ?? undefined); } catch { orders = []; }
  }
  // The live in-progress batch shares its id with a persisted order. Take its
  // scheduled window (start/end) from that DB row so the format and the dates
  // match every other row — the simulation engine only supplies the dynamic
  // fields it owns (plan/actual/status). Fall back to a YYYY-MM-DD HH:MM
  // rendering of the live epoch only if no persisted row exists.
  const liveSrc = orders.find((o: any) => o.id === state.batch.id);
  const liveOrder = {
    id: state.batch.id, product: state.batch.product,
    qty: `${state.batch.qty} kg`, plan: state.batch.plan,
    actual: state.batch.actual, status: state.batch.status,
    start: liveSrc?.start ?? toYmdHm(state.batch.startedAt),
    end:   liveSrc?.end   ?? toYmdHm(state.batch.startedAt + state.batch.durationMs),
    plant: liveSrc?.plant ?? 'P1',
  };
  const filteredOrders = opfCode && opfCode !== 'All Plants' ? orders.filter((o:any)=>!o.plant||o.plant===opfCode) : orders;
  // Only include the live batch when the selected plant matches it (or no filter).
  const includeLive = !opfCode || opfCode === 'All Plants' || opfCode === liveOrder.plant;
  // De-duplicate: if a row shares the live batch's id, drop it so the live
  // (in-progress) version wins. Prevents the "two rows with PP-88414" effect.
  const deduped = includeLive
    ? [liveOrder, ...filteredOrders.filter((o:any) => o.id !== liveOrder.id)]
    : filteredOrders;
  res.json({ orders: deduped });
});

export default router;
