/**
 * ManuAI — Platform Configuration Route
 *
 * Serves all customer-configurable values from platform_config.csv.
 * Edit platform_config.csv in Excel → restart → values update in UI.
 * No code change, no rebuild needed.
 */

import { Router } from 'express';
import { loadPlatformConfig, loadTechStack, loadSemanticKpiDefs, loadPersonas, loadBaselines, loadAgentTargets } from '../data/csv-loader';
import { refreshMasterData } from '../database/seed-master';
import { requireRole, ROLES } from '../middleware/auth';

const router = Router();

router.get('/', async (_req, res) => {
  try {
    res.json(loadPlatformConfig());
  } catch (err) {
    res.status(500).json({ error: 'Failed to load platform config' });
  }
});

router.get('/tech-stack', async (_req, res) => {
  try { res.json({ stacks: loadTechStack() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load tech stack' }); }
});

router.get('/semantic-kpis', async (_req, res) => {
  try { res.json({ definitions: loadSemanticKpiDefs() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load semantic KPI definitions' }); }
});

router.get('/personas', async (_req, res) => {
  try { res.json({ personas: loadPersonas() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load personas' }); }
});

router.get('/baselines', async (req, res) => {
  try {
    const plant = req.query.plant as string | undefined;
    res.json({ baselines: loadBaselines(plant) });
  }
  catch (err) { res.status(500).json({ error: 'Failed to load baselines' }); }
});

router.get('/agent-targets', async (_req, res) => {
  try { res.json({ targets: loadAgentTargets() }); }
  catch (err) { res.status(500).json({ error: 'Failed to load agent targets' }); }
});

// ── Per-plant configuration from plant_config DB table ──────────────────────
router.get('/plant/:plantId', async (_req, res) => {
  try {
    const { plantId } = _req.params;
    const db = require('../database/connection').getDb();
    const rows = await db.prepare('SELECT config_key, value, label, unit FROM plant_config WHERE plant_id = ?').all(plantId) as {config_key:string,value:string,label:string,unit:string}[];
    const config: Record<string, {value:string,label:string,unit:string}> = {};
    for (const r of rows) config[r.config_key] = { value: r.value, label: r.label, unit: r.unit };
    res.json({ plantId, config });
  } catch { res.json({ plantId: _req.params.plantId, config: {} }); }
});

// All registered plants (from dim_plant dimension table)
router.get('/plants', async (_req, res) => {
  try {
    const db = require('../database/connection').getDb();
    const plants = await db.prepare(`
      SELECT p.plant_id, p.plant_name, p.location, p.timezone, p.currency,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='oee_target') as oee_target,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='sap_plant_code') as sap_plant_code,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='energy_tariff_rs') as energy_tariff_rs,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='yield_target') as yield_target,
             (SELECT value FROM plant_config WHERE plant_id=p.plant_id AND config_key='pi_server_name') as pi_server_name
      FROM dim_plant p ORDER BY p.plant_id
    `).all();
    res.json({ plants });
  } catch { res.json({ plants: [] }); }
});

/**
 * Plant topology — the canonical mapping from plant codes → machines, utilities,
 * production lines, and safety zones. Sourced from machines.csv / energy_assets.csv
 * / safety_zones.csv via data/plant.ts. The frontend fetches this at startup so
 * it never has to hardcode the same lists.
 */
router.get('/plant-topology', async (_req, res) => {
  try {
    const { getTopology, getPlantCodes } = require('../data/plant');
    const t = getTopology();
    const plants = getPlantCodes().map((code: string) => ({
      code,
      // Human-friendly label: 'P1' → 'Plant 1', 'P2' → 'Plant 2'
      label:    `Plant ${code.replace(/^P/, '')}`,
      machines:  t.machinesByPlant.get(code)  ?? [],
      utilities: t.utilitiesByPlant.get(code) ?? [],
      assets:    [...(t.machinesByPlant.get(code)  ?? []),
                  ...(t.utilitiesByPlant.get(code) ?? [])],
      lines:     t.linesByPlant.get(code)    ?? [],
      zones:     t.zonesByPlant.get(code)    ?? [],
    }));
    res.json({ plants });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load plant topology', detail: String(err) });
  }
});

// POST /api/config/reload — refresh Tier2/3 DB tables from CSV without restart
// Useful after editing a CSV in Excel and wanting the change reflected immediately
router.post('/reload', requireRole(ROLES.ADMIN, ROLES.ENGINEER), async (_req, res) => {
  try {
    await refreshMasterData();
    res.json({ ok: true, message: 'Master data reloaded from CSV into DB' });
  } catch (err) {
    res.status(500).json({ error: 'Reload failed', detail: String(err) });
  }
});

export default router;
