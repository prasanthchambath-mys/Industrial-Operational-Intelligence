import { Router } from 'express';

// Loss split factors from platform_config.csv (section: loss_split) — Issue 9 fix
import { loadCsvRaw } from '../data/csv-loader';
const LOSS_SPLIT = (() => {
  const defaults = { changeover_setup: 0.15, startup_defects: 0.05, inprocess_defects: 0.04 };
  try {
    const rows = loadCsvRaw('platform_config.csv').filter((r: any) => r.section === 'loss_split');
    for (const r of rows) {
      if (r.key in defaults) (defaults as any)[r.key] = Number(r.value);
    }
  } catch { /* use defaults */ }
  return defaults;
})();
import { getPlantState } from '../simulation/engine';
import { normalizePlant, plantForAsset } from '../data/plant';
import { getTagsBatch } from '../connectors/pi-historian';
import { semanticLayer } from '../semantic/service';
import { logger } from '../middleware/logger';
import { loadMachines } from '../data/csv-loader';
import { createMaintenanceNotification } from '../connectors/sap-odata';
import { requireRole, ROLES } from '../middleware/auth';
import { broadcast } from '../websocket/broadcaster';
import {
  applyAlertOverrides, setAlertOverride, getAlertOverride,
} from '../state/runtime-overrides';

const router = Router();

// getMachineTags() built from machines.csv — pi_tag column
// REPLACE WITH: PI Web API tag registry in Phase 3
function getMachineTags(): Record<string, { avail: string; perf: string; qual: string }> {
  const machines = loadMachines();
  const result: Record<string, { avail: string; perf: string; qual: string }> = {};
  for (const m of machines) {
    const line = (m.line ?? 'LineA').replace(/\s/g, '');
    const id   = m.id.replace('-', '');
    result[m.id] = {
      avail: `Plant.${line}.${id}.Availability`,
      perf:  `Plant.${line}.${id}.Performance`,
      qual:  `Plant.${line}.${id}.Quality`,
    };
  }
  return result;
}

router.get('/live', async (_req, res) => {
  try {
    const allTags = Object.values(getMachineTags()).flatMap(t => [t.avail, t.perf, t.qual]);
    const piValues = await getTagsBatch(allTags).catch(() => ({}));
    const state = getPlantState();

    const roundM = (m: any) => ({
      ...m,
      health:  +Number(m.health).toFixed(1),
      rul:     Math.round(Number(m.rul)),
      lossMin: Math.round(Number(m.lossMin ?? 0)),
      vib:     +Number(m.vib  ?? 0).toFixed(1),
      temp:    Math.round(Number(m.temp ?? 0)),
    });
    const machines = state.machines.map(m => {
      const tags = getMachineTags()[m.id];
      if (tags && Object.keys(piValues).length > 0) {
        const avail = piValues[tags.avail] ?? m.avail;
        const perf  = piValues[tags.perf]  ?? m.perf;
        const qual  = piValues[tags.qual]  ?? m.qual;
        return roundM({ ...m, avail:+avail.toFixed(1), perf:+perf.toFixed(1), qual:+qual.toFixed(1),
                 oee:+(avail * perf * qual / 10000).toFixed(1) });
      }
      return roundM(m);
    });

    // Utilities ride alongside machines (NOT merged in) so the fleet-critical
    // count can include them while plantOEE keeps averaging machines only.
    const utilities = state.utilities.map((u: any) => ({
      id: u.id, name: u.name, health: Math.round(Number(u.health)),
      rul: Math.round(Number(u.rul)), status: u.status, plant: u.plant,
    }));
    res.json({ machines, utilities, plantOEE: state.plantOEE, timestamp: new Date().toISOString() });
  } catch (err) {
    logger.error('OEE live error', { error: String(err) });
    const state = getPlantState();
    const roundM2 = (m: any) => ({
      ...m,
      health:  +Number(m.health).toFixed(1),
      rul:     Math.round(Number(m.rul)),
      lossMin: Math.round(Number(m.lossMin ?? 0)),
      vib:     +Number(m.vib  ?? 0).toFixed(1),
      temp:    Math.round(Number(m.temp ?? 0)),
    });
    const utilities = state.utilities.map((u: any) => ({
      id: u.id, name: u.name, health: Math.round(Number(u.health)),
      rul: Math.round(Number(u.rul)), status: u.status, plant: u.plant,
    }));
    res.json({ machines: state.machines.map(roundM2), utilities, plantOEE: state.plantOEE, timestamp: new Date().toISOString() });
  }
});

router.get('/losses', (req, res) => {
  const code = normalizePlant(req.query.plant);
  const state = getPlantState();
  const machines = code
    ? state.machines.filter(m => plantForAsset(m.id) === code)
    : state.machines;
  const breakdowns = machines.filter(m => m.loss === 'Unplanned Breakdown');
  const speedLoss  = machines.filter(m => m.loss === 'Speed Loss');
  const minorStops = machines.filter(m => m.loss === 'Minor Stops');
  const totalMin   = machines.reduce((a,m)=>a+m.lossMin,0);

  const losses = [
    { name:'Unplanned Breakdown', min:breakdowns.reduce((a,m)=>a+m.lossMin,0), pct:0, cnt:breakdowns.length, machines:breakdowns.map(m=>m.id) },
    { name:'Speed Loss',          min:speedLoss.reduce((a,m)=>a+m.lossMin,0),  pct:0, cnt:speedLoss.length,  machines:speedLoss.map(m=>m.id)  },
    { name:'Minor Stops',         min:minorStops.reduce((a,m)=>a+m.lossMin,0), pct:0, cnt:minorStops.length, machines:minorStops.map(m=>m.id) },
    { name:'Changeover & Setup',  min:Math.floor(totalMin*LOSS_SPLIT.changeover_setup), pct:0, cnt:machines.filter(m=>m.status==='caution').length||8,  machines:machines.filter(m=>m.status==='caution').map(m=>m.id) },
    { name:'Startup Defects',     min:Math.floor(totalMin*LOSS_SPLIT.startup_defects), pct:0, cnt:machines.filter(m=>m.status==='good').length||3,  machines:machines.filter(m=>m.status==='good').slice(0,1).map(m=>m.id) },
    { name:'In-process Defects',  min:Math.floor(totalMin*LOSS_SPLIT.inprocess_defects), pct:0, cnt:machines.filter(m=>m.status==='critical').length||4,  machines:machines.filter(m=>m.status==='critical').slice(0,1).map(m=>m.id) },
  ].map(l => ({ ...l, pct:totalMin>0 ? +(l.min/totalMin*100).toFixed(1) : 0 }));

  res.json({ losses, totalMinutes: totalMin, date: new Date().toISOString().split('T')[0] });
});

router.get('/alerts', (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const code = normalizePlant(req.query.plant);
  const state = getPlantState();
  // Routing destination strings sourced from platform_config oee_alert_routing.
  // Was inline 'Maintenance team notified' / 'Supervisor notified' literals.
  const cfg = (() => { try { const { loadPlatformConfig } = require('../data/csv-loader'); return loadPlatformConfig(); } catch { return {}; }})();
  const routing = (cfg.oeeAlertRouting ?? []) as Array<{id:string;trigger:string;dest:string;colorTok?:string}>;
  // Pick destination based on alert severity / loss type. Order of resolution:
  // 1. exact loss-type match against routing.trigger
  // 2. severity bucket (critical → first 'critical' row; warning → first 'warning_*' row)
  // 3. fallback to legacy hardcoded strings
  const findRoute = (sev: string, loss: string): string => {
    const exact = routing.find(r => r.trigger.toLowerCase() === String(loss).toLowerCase());
    if (exact) return exact.dest;
    if (sev === 'critical') {
      const c = routing.find(r => r.id === 'critical' || r.id.startsWith('critical'));
      if (c) return c.dest;
    }
    if (sev === 'warning') {
      const w = routing.find(r => r.id.startsWith('warning'));
      if (w) return w.dest;
    }
    return sev === 'critical' ? 'Maintenance team notified' : 'Supervisor notified';
  };
  const raw = state.machines
    .filter(m => (m.status === 'critical' || m.status === 'warning') && (!code || plantForAsset(m.id) === code))
    .map(m => ({
      id: `ALT-${m.id}`, sev: m.status === 'critical' ? 'critical' : 'warning',
      type: m.loss, machine: m.id, line: m.line,
      ts: new Date().toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit' }),
      ack: false,
      // V32 fix: vib/temp/oee/health were rendering with full float precision in
      // the alert text (`4.366225510504413 mm/s`, `70.97710966455286°C`). The
      // Dashboard tile shows the same values to 1 decimal — alerts now match.
      // Also exposes raw numeric fields so the frontend can re-derive the
      // displayed message against current machine state and stay in lock-step
      // with the Dashboard refresh cycle.
      oee:    +Number(m.oee).toFixed(1),
      health: +Number(m.health).toFixed(1),
      vib:    +Number(m.vib).toFixed(1),
      temp:   +Number(m.temp).toFixed(1),
      rul:    Math.round(Number(m.rul)),
      msg: `${m.name}: ${m.loss}. OEE ${Number(m.oee).toFixed(1)}%, Health ${Number(m.health).toFixed(1)}%, Vib ${Number(m.vib).toFixed(1)} mm/s, Temp ${Number(m.temp).toFixed(1)}°C. RUL: ${Math.round(Number(m.rul))}d.`,
      routed: findRoute(m.status, m.loss),
    }));
  // Layer runtime overrides — ack flag, WO id, escalation note all live here
  res.json({ alerts: applyAlertOverrides(raw) });
});

// POST /api/oee/alerts/:id/ack
// Records operator acknowledgement. Was a no-op stub; now persists to runtime
// overrides + publishes a low-priority semantic event for audit traceability.
router.post('/alerts/:id/ack', requireRole(ROLES.OPERATOR, ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const existing = getAlertOverride(id);
  if (existing?.acked) {
    return res.json({ success: true, id, acked: true, alreadyAcked: true, ackedAt: existing.ackedAt, ackedBy: existing.ackedBy });
  }
  const now = new Date().toISOString();
  const ov = setAlertOverride(id, {
    acked: true,
    ackedAt: now,
    ackedBy: req.user?.name ?? 'unknown',
  });
  try {
    // Resolve machine id from the alert id pattern `ALT-{machineId}` to publish a meaningful event
    const machineId = id.startsWith('ALT-') ? id.slice(4) : id;
    await semanticLayer.publishEvent({
      id: `ALT-ACK-${Date.now()}`, from: 'oee', to: 'oee',
      type: 'alert_acked', sev: 'info',
      msg: `Alert ${id} acknowledged by ${ov.ackedBy}`,
      impact: 'Operator aware — clock starts on resolution',
      asset: machineId, plant_id: plantForAsset(machineId) ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish must not block ack */ }
  broadcast('oee', { type: 'alert_acked', id, ts: now });
  logger.info('Alert acked', { id, user: req.user?.name });
  res.json({ success: true, id, acked: true, ackedAt: now, ackedBy: ov.ackedBy });
});

// POST /api/oee/alerts/:id/wo  { description?, priority? }
// Creates a real SAP PM maintenance notification, attaches the WO id to the
// alert override, publishes a work_order_created semantic event so the PdM
// agent sees the corrective WO landing on its plate.
router.post('/alerts/:id/wo', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { description, priority } = req.body as { description?: string; priority?: string };
  const machineId = id.startsWith('ALT-') ? id.slice(4) : id;
  // Semantic conflict check — maintenance WO affects OEE; same rule used elsewhere.
  // plantId is passed so the CR-003 plant-fallback can match (gas precursor in
  // Plant 1 zone → blocks WOs on Plant 1 assets).
  const conflict = semanticLayer.checkConflict({
    agent: 'pdm', type: 'work_order', assetId: machineId,
    plantId: plantForAsset(machineId) ?? undefined,
  });
  if (conflict.blocked) return res.status(409).json({ blocked: true, reason: conflict.reason, ruleId: conflict.ruleId });
  const fallbackDesc = `Auto-created from OEE alert ${id}`;
  try {
    const wo = await createMaintenanceNotification({
      equipment: machineId,
      text: description ?? fallbackDesc,
      priority,
    });
    const now = new Date().toISOString();
    const woId = wo?.MaintenanceNotification ?? `WO-${Date.now()}`;
    const ov = setAlertOverride(id, {
      acked: true,
      ackedAt: now,
      ackedBy: req.user?.name ?? 'unknown',
      woId,
      woCreatedAt: now,
      woCreatedBy: req.user?.name ?? 'unknown',
      woNote: `SAP PM work order ${woId} created`,
    });
    try {
      await semanticLayer.publishEvent({
        id: `WO-FA-${Date.now()}`, from: 'oee', to: 'pdm',
        type: 'work_order_created', sev: 'info',
        msg: `WO ${woId} created from alert ${id}: ${description ?? fallbackDesc}`,
        impact: 'Maintenance scheduled — alert resolution pending WO completion',
        asset: machineId, plant_id: plantForAsset(machineId) ?? 'P1', ts: now,
      } as any);
    } catch { /* event publish must not block WO creation */ }
    broadcast('oee', { type: 'alert_wo_created', id, woId, ts: now });
    res.json({ success: true, id, woId, override: ov });
  } catch (e) {
    logger.warn('SAP PM WO from alert failed', { id, error: String(e) });
    res.status(502).json({ error: 'SAP PM unavailable — WO not created' });
  }
});

// POST /api/oee/alerts/:id/escalate  { to?, reason? }
// Records operator escalation. Publishes a higher-severity semantic event so
// supervisors are notified via downstream channels in Phase A.
router.post('/alerts/:id/escalate', requireRole(ROLES.OPERATOR, ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { to, reason } = req.body as { to?: string; reason?: string };
  const escalatedTo = to ?? 'shift supervisor';
  const now = new Date().toISOString();
  const ov = setAlertOverride(id, {
    escalated: true,
    escalatedAt: now,
    escalatedBy: req.user?.name ?? 'unknown',
    escalatedTo,
    escalateNote: `Escalated to ${escalatedTo}${reason ? ` — ${reason}` : ''}`,
  });
  try {
    const machineId = id.startsWith('ALT-') ? id.slice(4) : id;
    await semanticLayer.publishEvent({
      id: `ALT-ESC-${Date.now()}`, from: 'oee', to: 'oee',
      type: 'alert_escalated', sev: 'warning',
      msg: `Alert ${id} escalated to ${escalatedTo} by ${ov.escalatedBy}${reason ? ` — ${reason}` : ''}`,
      impact: 'Supervisor engaged — response SLA tightens',
      asset: machineId, plant_id: plantForAsset(machineId) ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish must not block escalation */ }
  broadcast('oee', { type: 'alert_escalated', id, escalatedTo, ts: now });
  res.json({ success: true, id, escalatedTo, override: ov });
});

export default router;
