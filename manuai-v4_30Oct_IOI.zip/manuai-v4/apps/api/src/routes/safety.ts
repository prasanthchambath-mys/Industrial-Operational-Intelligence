import { safetyRouter } from './all-routes';
import { loadSafetyPermits } from '../data/csv-loader';
import { getSafetyZones } from '../database/db-queries';
import { normalizePlant } from '../data/plant';
import { applyPtwOverrides } from '../state/runtime-overrides';

safetyRouter.get('/permits', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  const all = loadSafetyPermits() as any[];
  const filtered = pf && pfCode && pfCode !== 'All Plants' ? all.filter((r:any)=>!r.plant||r.plant===pfCode||r.plant==='Both') : all;
  // Layer runtime PTW decisions on top — same overrides also flow through /ptw
  res.json({ permits: applyPtwOverrides(filtered) });
});

safetyRouter.get('/zones', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  // DB-backed: ref_safety_zones seeded from safety_zones.csv, CSV fallback if DB empty
  const all = await getSafetyZones(pfCode ?? undefined);
  res.json({ zones: all });
});

export default safetyRouter;
