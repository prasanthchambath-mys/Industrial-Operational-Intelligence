import { energyRouter } from './all-routes';
import {
  loadEnergyWaste, loadCarbonTrend,
  loadDemandForecast, loadEnergyDispatch, loadPlatformConfig,
} from '../data/csv-loader';
import { normalizePlant, plantForAsset } from '../data/plant';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { broadcast } from '../websocket/broadcaster';
import {
  applyDispatchOverrides, setDispatchOverride, isValidDispatchTransition,
} from '../state/runtime-overrides';
import { getDb } from '../database/connection';

// Helper — returns rows belonging to the selected plant or all rows for "All Plants"
function filterByPlantCol<T extends { plant?: string }>(rows: T[], raw: unknown): T[] {
  const code = normalizePlant(raw);
  if (!code) return rows;
  return rows.filter((r) => !r.plant || r.plant === code || r.plant === 'Both');
}

energyRouter.get('/waste', async (req, res) => {
  res.json({ waste: filterByPlantCol(loadEnergyWaste() as any[], req.query.plant) });
});
energyRouter.get('/carbon', async (req, res) => {
  const all = loadCarbonTrend() as any[];
  const pf = req.query.plant as string | undefined;
  const pfCode = normalizePlant(pf);
  if (pfCode) {
    // Specific plant: 12 monthly rows for that plant.
    res.json({ data: all.filter(r => r.plant === pfCode) });
    return;
  }
  // All Plants: the CSV holds one row per plant per month (24 rows = 12 months x 2
  // plants). Returning them raw made the chart show each month twice (Jan, Jan,
  // Feb, Feb...). Aggregate to one value per month — the mean carbon intensity
  // across plants — preserving the CSV's calendar order (first-seen month wins).
  const order: string[] = [];
  const acc: Record<string, { sum: number; n: number; unit: string }> = {};
  for (const r of all) {
    if (!acc[r.m]) { acc[r.m] = { sum: 0, n: 0, unit: r.unit }; order.push(r.m); }
    acc[r.m].sum += Number(r.v); acc[r.m].n += 1;
  }
  const data = order.map(m => ({
    m, v: +(acc[m].sum / acc[m].n).toFixed(3), unit: acc[m].unit, plant: 'All Plants',
  }));
  res.json({ data });
});
energyRouter.get('/demand-forecast', async (req, res) => {
  res.json({ data: filterByPlantCol(loadDemandForecast() as any[], req.query.plant) });
});
energyRouter.get('/dispatch', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const rows = filterByPlantCol(loadEnergyDispatch() as any[], req.query.plant);
  res.json({ actions: applyDispatchOverrides(rows) });
});

// POST /api/energy/dispatch/:id/execute
// Operator dispatches the load action immediately. Backend validates the
// transition, runs the semantic conflict check (energy → yield rule blocks
// dispatch on yield-critical assets), publishes 'energy_dispatch' event so
// the Yield agent records the impact on its set-points.
energyRouter.post('/dispatch/:id/execute', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const all = applyDispatchOverrides(loadEnergyDispatch() as any[]);
  const action = all.find((a:any) => a.id === id);
  if (!action) return res.status(404).json({ error: `Dispatch ${id} not found` });
  if (!isValidDispatchTransition(action.status, 'dispatched')) {
    return res.status(409).json({ error: `Cannot dispatch action in status '${action.status}'.` });
  }
  // Semantic conflict — same rule the legacy POST /api/energy/dispatch used
  const conflict = semanticLayer.checkConflict({ agent: 'energy', type: 'dispatch', assetId: action.asset });
  if (conflict.blocked) {
    return res.status(409).json({ blocked: true, reason: conflict.reason, ruleId: conflict.ruleId });
  }
  const now = new Date().toISOString();
  const ov = {
    status: 'dispatched' as const,
    dispatchedAt: now,
    updatedBy: req.user?.name ?? 'unknown',
  };
  setDispatchOverride(id, ov);
  try {
    await semanticLayer.publishEvent({
      id: `ED-${Date.now()}`, from: 'energy', to: 'yield',
      type: 'energy_dispatch', sev: 'info',
      msg: `${action.action} (${action.asset}) — dispatched by ${ov.updatedBy}`,
      impact: `Saving: ${action.saving}`,
      asset: action.asset, plant_id: action.plant ?? plantForAsset(String(action.asset ?? '')) ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish failure must not block the dispatch */ }
  broadcast('energy', { type: 'dispatch_executed', id, ts: now });
  res.json({ success: true, id, status: 'dispatched', override: ov });
});

// POST /api/energy/dispatch/:id/schedule { deferHours? }
// Operator defers the dispatch to off-peak window. Default deferral hours
// comes from platform_config.energy_config.dispatch_deferral_hours (4h).
energyRouter.post('/dispatch/:id/schedule', requireRole(ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { deferHours } = req.body as { deferHours?: number };
  const all = applyDispatchOverrides(loadEnergyDispatch() as any[]);
  const action = all.find((a:any) => a.id === id);
  if (!action) return res.status(404).json({ error: `Dispatch ${id} not found` });
  if (!isValidDispatchTransition(action.status, 'scheduled')) {
    return res.status(409).json({ error: `Cannot schedule action in status '${action.status}'.` });
  }
  const cfg = loadPlatformConfig();
  const defaultDeferHours = Number((cfg.energyConfig as any)?.dispatch_deferral_hours?.value ?? 4);
  const hours = Number.isFinite(deferHours) && (deferHours as number) > 0 ? (deferHours as number) : defaultDeferHours;
  const scheduledAt = new Date(Date.now() + hours * 3600 * 1000);
  const scheduledForLabel = scheduledAt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const now = new Date().toISOString();
  const ov = {
    status: 'scheduled' as const,
    scheduledFor: scheduledForLabel,
    updatedBy: req.user?.name ?? 'unknown',
  };
  setDispatchOverride(id, ov);
  try {
    await semanticLayer.publishEvent({
      id: `ED-S-${Date.now()}`, from: 'energy', to: 'supply',
      type: 'energy_dispatch_scheduled', sev: 'info',
      msg: `${action.action} (${action.asset}) — deferred ${hours}h to ${scheduledForLabel} by ${ov.updatedBy}`,
      impact: `Saving deferred to off-peak window: ${action.saving}`,
      asset: action.asset, plant_id: action.plant ?? plantForAsset(String(action.asset ?? '')) ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish failure must not block scheduling */ }
  broadcast('energy', { type: 'dispatch_scheduled', id, scheduledFor: scheduledForLabel, ts: now });
  res.json({ success: true, id, status: 'scheduled', scheduledFor: scheduledForLabel, deferHours: hours, override: ov });
});

// GET /api/energy/iso/compliance
// Returns real Energy Review + Report Status payload — drives the ISO 50001
// dashboard. Last KPI snapshot timestamp + governed KPI count come from the
// semantic_kpi_value table. Was previously hardcoded as 'Automated' / 'Auto-compiled'.
energyRouter.get('/iso/compliance', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const code = normalizePlant(req.query.plant);
  try {
    const db = getDb();
    const params: any[] = [];
    let where = '';
    if (code) { where = 'WHERE plant_id = ?'; params.push(code); }
    // Latest write across any energy-related governed KPI
    const lastRow = await db.prepare(
      `SELECT MAX(ts) AS last_ts FROM semantic_kpi_value
       ${where ? where + ' AND' : 'WHERE'} kpi_id IN ('kwh_per_unit','carbon_intensity','peak_demand','energy_cost')`
    ).get(...params) as any;
    const distinctKpiRow = await db.prepare(
      `SELECT COUNT(DISTINCT kpi_id) AS n FROM semantic_kpi_value ${where}`
    ).get(...params) as any;
    const lastTs = lastRow?.last_ts ? Number(lastRow.last_ts) : null;
    const ageMinutes = lastTs ? Math.round((Date.now() - lastTs) / 60000) : null;
    res.json({
      lastSnapshotTs: lastTs,
      lastSnapshotAgeMinutes: ageMinutes,
      governedKpiCount: distinctKpiRow?.n ?? 0,
      plant_id: code ?? 'All Plants',
      ts: new Date().toISOString(),
    });
  } catch (e) {
    res.json({ lastSnapshotTs: null, lastSnapshotAgeMinutes: null, governedKpiCount: 0, error: String(e) });
  }
});

energyRouter.get('/live', async (req, res) => {
  // REPLACE WITH: Azure IoT Hub / SCADA real-time energy feed in Phase 3
  const code = normalizePlant(req.query.plant);
  const byPlant = (a: any) => !code || a.plant === code;
  try {
    const { getPlantState } = require('../simulation/engine');
    const simAssets = getPlantState().energyAssets;
    if (Array.isArray(simAssets) && simAssets.length) {
      return res.json({ assets: simAssets.filter(byPlant).map((a: any) => ({
        id: a.id, name: a.name, kw: a.kw, anomaly: !!a.anomaly, plant: a.plant,
      })) });
    }
  } catch { /* fall through to CSV */ }
  try {
    const { loadEnergyAssets } = require('../data/csv-loader');
    res.json({ assets: (loadEnergyAssets() as any[]).filter(byPlant) });
  } catch {
    res.json({ assets: [] });
  }
});

export default energyRouter;
