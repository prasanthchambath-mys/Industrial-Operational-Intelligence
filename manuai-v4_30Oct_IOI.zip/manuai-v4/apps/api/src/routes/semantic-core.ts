/**
 * ManuAI — Semantic Core API Routes
 *
 * Exposes the enterprise semantic data model via REST API.
 * These routes are the enterprise-grade layer between source systems
 * and agent dashboards.
 *
 * /api/semantic/dimensions/*  — Dimension tables (assets, lines, suppliers)
 * /api/semantic/kpis/*        — KPI engine values and trends
 * /api/semantic/events/*      — Persistent cross-agent event log
 * /api/semantic/scenarios/*   — Orchestration scenario status
 */

import { Router } from 'express';
import { getDb } from '../database/connection';
import { getLatestKPIs, getKPITrend, computeKPIs } from '../kpi/engine';
import { getRecentEvents, getRecentEventsByPlant, getEventWithImpacts, getEventsByAsset } from '../database/event-store';
import { getActiveScenarios, getScenarioSteps } from '../orchestration/scenario-engine';
import { normalizePlant, linesFor } from '../data/plant';
import { logger } from '../middleware/logger';
import { getPlantState } from '../simulation/engine';
import { dbUpdateKpiDefinition, getKpiDefinitionHistory,
  getMachines, getWorkOrders, getTwinKPIs, getTwinScenarios, getEnergyWaste } from '../database/db-queries';
import { getSupplyChainDashboardMetrics } from '../supply/governance';
import { warmKpiDefinitions } from '../semantic/service';
import {
  loadQualityLines, loadTwinKPIs, loadSupplyRisks, loadSafetyPermits, loadSafetyZones, loadProductionOrders,
} from '../data/csv-loader';

export const semanticCoreRouter = Router();

// ── Dimension tables ──────────────────────────────────────────────────────────
semanticCoreRouter.get('/dimensions/plants', async (_req, res) => {
  try {
    res.json({ plants: await getDb().prepare('SELECT * FROM dim_plant').all() });
  } catch { res.json({ plants: [] }); }
});

semanticCoreRouter.get('/dimensions/lines', async (_req, res) => {
  try {
    res.json({ lines: await getDb().prepare('SELECT l.*, p.plant_name FROM dim_line l JOIN dim_plant p ON p.plant_id=l.plant_id').all() });
  } catch { res.json({ lines: [] }); }
});

semanticCoreRouter.get('/dimensions/assets', async (_req, res) => {
  try {
    res.json({ assets: await getDb().prepare('SELECT * FROM dim_asset ORDER BY asset_type, asset_name').all() });
  } catch { res.json({ assets: [] }); }
});

semanticCoreRouter.get('/dimensions/assets/:assetId', async (req, res) => {
  try {
    const asset = await getDb().prepare('SELECT * FROM dim_asset WHERE asset_id=?').get(req.params.assetId);
    if (!asset) { res.status(404).json({ error: 'Asset not found' }); return; }
    res.json({ asset });
  } catch { res.status(500).json({ error: 'Query failed' }); }
});

semanticCoreRouter.get('/dimensions/suppliers', async (_req, res) => {
  try {
    res.json({ suppliers: await getDb().prepare('SELECT * FROM dim_supplier ORDER BY risk_category, supplier_name').all() });
  } catch { res.json({ suppliers: [] }); }
});

semanticCoreRouter.get('/dimensions/materials', async (_req, res) => {
  try {
    res.json({ materials: await getDb().prepare('SELECT * FROM dim_material').all() });
  } catch { res.json({ materials: [] }); }
});

// ── KPI Engine ────────────────────────────────────────────────────────────────
semanticCoreRouter.get('/kpis/latest', async (req, res) => {
  const assetId = req.query.asset_id as string | undefined;
  const scope   = assetId ? 'asset' : 'plant';
  const pfCode  = normalizePlant(req.query.plant) ?? null;
  res.json({ kpis: await getLatestKPIs(scope, assetId, pfCode), scope, asset_id: assetId ?? null, plant_id: pfCode });
});

semanticCoreRouter.get('/kpis/trend/:kpiId', async (req, res) => {
  const days    = Number(req.query.days ?? 30);
  const assetId = req.query.asset_id as string | undefined;
  const pfCode  = normalizePlant(req.query.plant) ?? null;
  res.json({ kpi_id: req.params.kpiId, days, plant_id: pfCode, data: await getKPITrend(req.params.kpiId, days, assetId, pfCode) });
});

semanticCoreRouter.get('/kpis/definitions', async (_req, res) => {
  try {
    res.json({ definitions: await getDb().prepare('SELECT * FROM semantic_kpi_definition').all() });
  } catch { res.json({ definitions: [] }); }
});

// Governance: full version history (change log) for one KPI definition.
semanticCoreRouter.get('/kpis/definitions/:kpiId/history', async (req, res) => {
  const history = await getKpiDefinitionHistory(req.params.kpiId);
  if (!history.length) { res.status(404).json({ error: 'KPI definition not found' }); return; }
  res.json({ kpi_id: req.params.kpiId, current_version: history[0]?.version ?? null, history });
});

// Governance: apply a governed change to a KPI definition. Snapshots the prior
// version to the audit log, bumps the version, and refreshes the engine cache.
semanticCoreRouter.patch('/kpis/definitions/:kpiId', async (req, res) => {
  const { changed_by, change_reason, ...patch } = req.body ?? {};
  if (!change_reason || !String(change_reason).trim()) {
    res.status(400).json({ error: 'change_reason is required for a governed KPI change' });
    return;
  }
  const allowed = ['kpi_name', 'formula', 'unit', 'agents', 'source_system', 'governance', 'is_derived'];
  const clean: any = {};
  for (const k of allowed) if (patch[k] !== undefined) clean[k] = patch[k];
  if (!Object.keys(clean).length) {
    res.status(400).json({ error: 'no editable fields supplied' });
    return;
  }
  const result = await dbUpdateKpiDefinition(req.params.kpiId, clean, changed_by || 'unknown', String(change_reason).trim());
  if (!result.ok) { res.status(result.error === 'KPI definition not found' ? 404 : 500).json(result); return; }
  await warmKpiDefinitions(); // KPI engine reads the new definition on next call
  logger.info(`[Semantic] KPI ${req.params.kpiId} → v${result.version} by ${changed_by || 'unknown'}: ${change_reason}`);
  res.json({ ok: true, kpi_id: req.params.kpiId, version: result.version });
});

// Centrally compute the agent count-type KPIs from the SAME DB selectors each
// agent dashboard uses, so the Semantic Layer is the single computation point
// (not just the single definition point). `scope` is a plant code (P1/P2) or
// undefined for All Plants. Returns a map keyed by kpi_id.
async function computeCountKpis(scope?: string): Promise<Record<string, number | null>> {
  const plantArg = scope ?? 'All Plants';
  const out: Record<string, number | null> = {};
  // ── PdM (machines under monitoring + maintenance WOs) ──
  try { out.assets_monitored = (await getMachines(scope) as any[]).length; } catch { out.assets_monitored = null; }
  try {
    const wos = await getWorkOrders(scope) as any[];
    const isOeeLinked = (w: any) => w.oee_link === 1 || w.oee_link === '1' || w.oee_link === true || w.oeeLink === true;
    const isOpen = (w: any) => String(w.status ?? '').toLowerCase() === 'open';
    out.oee_linked_wos = wos.filter(isOeeLinked).length;
    out.open_wos_today = wos.filter(isOpen).length;
  } catch { out.oee_linked_wos = null; out.open_wos_today = null; }
  // ── Energy (detected waste patterns) ──
  try { out.waste_patterns = (await getEnergyWaste(scope) as any[]).length; } catch { out.waste_patterns = null; }
  // ── Twin (diverging KPIs + running scenarios) ──
  try {
    const tk = await getTwinKPIs(scope) as any[];
    out.diverging_kpis = tk.filter((k: any) => {
      const tp = Number(k.twin_predicted ?? 0);
      if (!tp) return false;
      const divPct = Math.abs(Number(k.actual ?? 0) - tp) / Math.abs(tp) * 100;
      return divPct > Number(k.divergence_threshold_pct ?? 0);
    }).length;
  } catch { out.diverging_kpis = null; }
  try {
    out.active_scenarios = (await getTwinScenarios(scope) as any[])
      .filter((s: any) => String(s.status ?? '').toLowerCase() === 'running').length;
  } catch { out.active_scenarios = null; }
  // ── Supply (read the exact governance selector the Supply dashboard uses) ──
  try {
    const m: any = await getSupplyChainDashboardMetrics(plantArg);
    out.skus_monitored          = m.skusMonitored ?? null;
    out.high_risk_suppliers     = m.highRiskSuppliers ?? null;
    out.active_risks            = m.activeRisks?.total ?? null;
    out.safety_stock_alerts     = m.safetyStockAlerts ?? null;
    out.manual_approval_required = m.manualApprovalPending ?? null;
    out.auto_approved_orders    = m.autoApprovedOrders ?? null;
    out.suppliers_drifting      = m.suppliersDrifting ?? null;
    out.active_rules            = m.activeRulesCount ?? m.activeRules ?? null;
  } catch {
    for (const k of ['skus_monitored','high_risk_suppliers','active_risks','safety_stock_alerts','manual_approval_required','auto_approved_orders','suppliers_drifting','active_rules']) out[k] = null;
  }
  return out;
}

semanticCoreRouter.get('/kpis/summary', async (req, res) => {
  const pfCode = (req.query.plant as string | undefined)?.trim();
  const plantSpecified = pfCode && pfCode !== 'All Plants' && pfCode !== '';
  try {
    const db = getDb();
    // Get KPI definitions (these are global - the semantic dictionary)
    const defs = await db.prepare(`SELECT kpi_id, kpi_name, unit FROM semantic_kpi_definition ORDER BY kpi_id`).all() as any[];
    // Status + target thresholds from platform_config semantic_kpi_threshold —
    // previously hardcoded inline (e.g. `oee < 80 ? 'warn'`, `target: 85`).
    // Now an operator can edit the CSV to change governance thresholds without
    // a code change. Direction (higher_is_better / lower_is_better) drives
    // comparison sense.
    const { loadPlatformConfig } = require('../data/csv-loader');
    const cfg = (loadPlatformConfig() as any) ?? {};
    const thresholds: Record<string, { target: number | null; direction: 'higher_is_better' | 'lower_is_better'; warn: number | null; critical: number | null }> = cfg.semanticKpiThreshold ?? {};
    const tierFor = (kpiId: string, value: number | null | undefined): string | null => {
      const t = thresholds[kpiId];
      if (!t || value == null || !Number.isFinite(value)) return null;
      const v = Number(value);
      if (t.direction === 'higher_is_better') {
        if (t.critical != null && v < t.critical) return 'critical';
        if (t.warn     != null && v < t.warn)     return 'warn';
        return 'ok';
      }
      // lower_is_better
      if (t.critical != null && v > t.critical) return 'critical';
      if (t.warn     != null && v > t.warn)     return 'warn';
      return 'ok';
    };
    if (plantSpecified) {
      // Plant-specific: compute live values using the SAME sources as each agent dashboard.
      // Previously all values came from computeKPIs() (the OEE simulation engine) which
      // diverges from agent dashboard values for quality, defect_rate, twin_divergence, and
      // permit_compliance. Fix: override only those KPIs with their agent-authoritative source.

      // Engine covers: oee, availability, performance, asset_health_pct, rul_days, yield_pct,
      //                kwh_per_unit, carbon_intensity, near_miss_rate, supply_risk_score.
      const k: any = computeKPIs(pfCode);

      // ── Quality Rate: Quality Vision dashboard reads quality_lines.csv, not m.qual ──
      const plantLineIds = linesFor(pfCode as any);
      const allQLines = loadQualityLines() as any[];
      const qLines = plantLineIds.length
        ? allQLines.filter((l: any) => plantLineIds.some(ln => String(l.line ?? '').includes(ln)))
        : allQLines;
      const qualityRate = qLines.length
        ? +(qLines.reduce((s: number, l: any) => s + Number(l.rate ?? 0), 0) / qLines.length).toFixed(2)
        : k.plant_quality;
      // Defect Rate = 100 - Quality Rate (consistent with OEE definition used across dashboards)
      const defectRateFinal = +(100 - qualityRate).toFixed(2);

      // ── Twin Divergence: Twin dashboard reads twin_kpis.csv mean %, not engine's formula ──
      const allTwinKpis = loadTwinKPIs() as any[];
      const twinKpis = allTwinKpis.filter((tk: any) => !tk.plant || tk.plant === pfCode || tk.plant === 'Both');
      let twinDivergence = k.twin_divergence;
      if (twinKpis.length) {
        const pctSum = twinKpis.reduce((s: number, tk: any) => {
          const tp = Number(tk.twin_predicted ?? 0);
          return s + (tp !== 0 ? Math.abs(Number(tk.actual ?? 0) - tp) / Math.abs(tp) * 100 : 0);
        }, 0);
        twinDivergence = +(pctSum / twinKpis.length).toFixed(2);
      }

      // ── Permit Compliance: Safety dashboard reads safety_permits.csv with plant filter ──
      const allPermits = loadSafetyPermits() as any[];
      const plantPermits = allPermits.filter((p: any) => !p.plant_id || p.plant_id === pfCode);
      const validPermits = plantPermits.filter((p: any) => ['approved','active','valid'].includes(p.status));
      const permitCompliance = plantPermits.length
        ? +(validPermits.length / plantPermits.length * 100).toFixed(1)
        : k.permit_compliance;

      // ── Yield %: align EXACTLY to what /yield/orders returns to the Yield
      // dashboard and the YIELD mini tile. That endpoint prepends a live
      // in-progress batch (state.batch, tagged P1, actual perturbed every tick)
      // and dedupes by id. Replicating it here keeps the KPI Live Value in
      // lockstep with the dashboard tiles. Previously this used loadProductionOrders()
      // alone, which excluded the live batch and made the values drift apart.
      const allOrders = loadProductionOrders() as any[];
      const stateBatch = getPlantState().batch;
      const liveOrder = {
        id: stateBatch.id, plan: stateBatch.plan, actual: stateBatch.actual,
        status: stateBatch.status, plant: 'P1',
      };
      const filteredOrders = allOrders.filter((o: any) => !o.plant || o.plant === pfCode);
      const includeLive = pfCode === liveOrder.plant; // P1 only
      const combinedOrders = includeLive
        ? [liveOrder, ...filteredOrders.filter((o: any) => o.id !== liveOrder.id)]
        : filteredOrders;
      const completedOrders = combinedOrders.filter((o: any) => o.actual != null && Number(o.actual) > 0);
      const yieldPctLive = completedOrders.length
        ? +(completedOrders.reduce((s: number, o: any) => s + Number(o.actual ?? 0), 0) / completedOrders.length).toFixed(2)
        : k.yield_pct;

      const valueByKpi: Record<string, number | null> = {
        oee:                k.plant_oee,
        availability:       k.plant_availability,
        performance:        k.plant_performance,
        quality:            qualityRate,          // ← quality_lines.csv avg, matches Quality dashboard
        asset_health_pct:   k.avg_health,
        rul_days:           k.min_rul,
        yield_pct:          yieldPctLive,         // ← avg of completed sap orders, matches Yield dashboard + mini tile
        kwh_per_unit:       k.energy_kwh_per_unit,
        carbon_intensity:   k.carbon_intensity,
        defect_rate:        defectRateFinal,      // ← 100 - quality_rate, consistent
        near_miss_rate:     k.near_miss_rate,
        supply_risk_score:  k.supply_risk_score,
        twin_divergence:    twinDivergence,       // ← twin_kpis.csv mean %, matches Twin dashboard
        permit_compliance:  permitCompliance,     // ← safety_permits.csv plant slice
        ...(await computeCountKpis(pfCode)),               // ← agent count KPIs computed centrally (single computation point)
      };
      const summary = defs.map((d: any) => {
        const v = valueByKpi[d.kpi_id];
        const t = thresholds[d.kpi_id];
        return {
          kpi_id: d.kpi_id, kpi_name: d.kpi_name, unit: d.unit,
          value:     v ?? null,
          target:    t?.target  ?? null,
          status:    tierFor(d.kpi_id, v),
          direction: t?.direction ?? null,
          ts: Date.now(),
        };
      });
      return res.json({ summary, computed_at: new Date().toISOString(), plant_id: pfCode, source: 'live' });
    }
    // All Plants: compute the SAME way as plant-specific, but across all plants.
    // Previously this returned DB rolled-up values that the KPI engine writes every
    // ~5 minutes — guaranteed to drift from the agent dashboards' 10s polling.
    // Now: compute live from the same CSV/state sources the dashboards read, so the
    // KPI dictionary "Live Value" always matches the dashboard tiles in real time.
    const k: any = computeKPIs(undefined); // undefined = all plants
    // Quality Rate from quality_lines.csv — average all lines
    const allQLinesAll = loadQualityLines() as any[];
    const qualityRateAll = allQLinesAll.length
      ? +(allQLinesAll.reduce((s: number, l: any) => s + Number(l.rate ?? 0), 0) / allQLinesAll.length).toFixed(2)
      : k.plant_quality;
    const defectRateAll = +(100 - qualityRateAll).toFixed(2);
    // Twin Divergence from twin_kpis.csv — mean across all KPIs
    const allTwinKpisAll = loadTwinKPIs() as any[];
    let twinDivergenceAll = k.twin_divergence;
    if (allTwinKpisAll.length) {
      const pctSum = allTwinKpisAll.reduce((s: number, tk: any) => {
        const tp = Number(tk.twin_predicted ?? 0);
        return s + (tp !== 0 ? Math.abs(Number(tk.actual ?? 0) - tp) / Math.abs(tp) * 100 : 0);
      }, 0);
      twinDivergenceAll = +(pctSum / allTwinKpisAll.length).toFixed(2);
    }
    // Permit Compliance from safety_permits.csv — across all plants
    const allPermitsAll = loadSafetyPermits() as any[];
    const validPermitsAll = allPermitsAll.filter((p: any) => ['approved','active','valid'].includes(p.status));
    const permitComplianceAll = allPermitsAll.length
      ? +(validPermitsAll.length / allPermitsAll.length * 100).toFixed(1)
      : k.permit_compliance;

    // Yield % across all plants — include live batch (matches /yield/orders + mini tile)
    const allOrdersAll = loadProductionOrders() as any[];
    const stateBatchAll = getPlantState().batch;
    const liveOrderAll = {
      id: stateBatchAll.id, plan: stateBatchAll.plan, actual: stateBatchAll.actual,
      status: stateBatchAll.status, plant: 'P1',
    };
    // All Plants: include live batch unconditionally, then dedupe by id
    const combinedAll = [liveOrderAll, ...allOrdersAll.filter((o: any) => o.id !== liveOrderAll.id)];
    const completedOrdersAll = combinedAll.filter((o: any) => o.actual != null && Number(o.actual) > 0);
    const yieldPctAll = completedOrdersAll.length
      ? +(completedOrdersAll.reduce((s: number, o: any) => s + Number(o.actual ?? 0), 0) / completedOrdersAll.length).toFixed(2)
      : k.yield_pct;

    const valueByKpiAll: Record<string, number | null> = {
      oee:                k.plant_oee,
      availability:       k.plant_availability,
      performance:        k.plant_performance,
      quality:            qualityRateAll,
      asset_health_pct:   k.avg_health,
      rul_days:           k.min_rul,
      yield_pct:          yieldPctAll,
      kwh_per_unit:       k.energy_kwh_per_unit,
      carbon_intensity:   k.carbon_intensity,
      defect_rate:        defectRateAll,
      near_miss_rate:     k.near_miss_rate,
      supply_risk_score:  k.supply_risk_score,
      twin_divergence:    twinDivergenceAll,
      permit_compliance:  permitComplianceAll,
      ...(await computeCountKpis(undefined)),            // ← agent count KPIs computed centrally (All Plants)
    };

    // Reuse `defs` already loaded from DB at top of route — same fields
    // (kpi_id/kpi_name/unit) the plant-specific branch uses. The DB is seeded
    // from semantic_kpi_definitions.csv on startup, so editing the CSV + a
    // restart (or Reload CSV button) propagates here too.
    const summary = defs.map((d: any) => {
      const v = valueByKpiAll[d.kpi_id];
      const t = thresholds[d.kpi_id];
      return {
        kpi_id: d.kpi_id, kpi_name: d.kpi_name, unit: d.unit,
        value:     v ?? null,
        target:    t?.target  ?? null,
        status:    tierFor(d.kpi_id, v),
        direction: t?.direction ?? null,
        ts: Date.now(),
      };
    });
    res.json({ summary, computed_at: new Date().toISOString(), plant_id: 'All Plants', source: 'live' });
  } catch (err) {
    logger.warn('[KPI Summary] error', { error: String(err) });
    res.json({ summary: [] });
  }
});

// ── Event Store ───────────────────────────────────────────────────────────────

/** Reconstruct an event row from the DB into the shape the frontend/WS expects.
 *  Raw DB row: { event_id, event_type, from_agent, asset_id, severity, message, payload, ts, ... }
 *  Frontend shape: { id, type, from, to, asset, sev, msg, plant_id, line_id, ts, ... }
 *  Without this, the frontend has no plant_id to filter on (it's stuck inside payload). */
function rehydrateEvent(r: any): any {
  let payload: any = {};
  try { payload = JSON.parse(r.payload ?? '{}'); } catch { /* ignore */ }
  return {
    ...payload,
    id:    r.event_id,
    type:  r.event_type,
    from:  r.from_agent,
    asset: r.asset_id ?? payload.asset,
    sev:   r.severity,
    msg:   r.message,
    ts:    typeof r.ts === 'number' ? new Date(r.ts).toISOString() : r.ts,
  };
}

semanticCoreRouter.get('/events', async (req, res) => {
  const limit = Number(req.query.limit ?? 50);
  const pfCode = (req.query.plant as string | undefined)?.trim();
  // Use DB-level filter when a specific plant is selected (faster than post-filter)
  const rows = pfCode && pfCode !== 'All Plants' && pfCode !== ''
    ? await getRecentEventsByPlant(pfCode, limit)
    : await getRecentEvents(limit);
  // Rehydrate so frontend gets { id, plant_id, line_id, ... } at top level — not buried in payload JSON
  const events = (rows as any[]).map(rehydrateEvent);
  res.json({ events });
});

semanticCoreRouter.get('/events/:eventId', async (req, res) => {
  const result = await getEventWithImpacts(req.params.eventId);
  if (!result) { res.status(404).json({ error: 'Event not found' }); return; }
  res.json(result);
});

semanticCoreRouter.get('/events/asset/:assetId', async (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ asset_id: req.params.assetId, events: await getEventsByAsset(req.params.assetId, days) });
});

semanticCoreRouter.get('/events/impacts', async (_req, res) => {
  try {
    const impacts = await getDb().prepare(`
      SELECT i.*, e.event_type, e.from_agent, e.asset_id, e.severity, e.ts as event_ts
      FROM semantic_event_impact i
      JOIN semantic_event e ON e.event_id = i.event_id
      ORDER BY i.ts DESC LIMIT 100
    `).all();
    res.json({ impacts });
  } catch { res.json({ impacts: [] }); }
});

// ── Orchestration Scenarios ───────────────────────────────────────────────────
semanticCoreRouter.get('/scenarios', async (_req, res) => {
  res.json({ scenarios: await getActiveScenarios() });
});

semanticCoreRouter.get('/scenarios/:scenarioId', async (req, res) => {
  const steps = await getScenarioSteps(req.params.scenarioId);
  if (!steps.length) { res.status(404).json({ error: 'Scenario not found' }); return; }
  res.json(steps[0]);
});

// ── Data model overview ───────────────────────────────────────────────────────
semanticCoreRouter.get('/model', async (_req, res) => {
  try {
    const db = getDb();
    const counts = {
      dim_plant:    ((await db.prepare('SELECT COUNT(*) as n FROM dim_plant').get()) as any).n,
      dim_line:     ((await db.prepare('SELECT COUNT(*) as n FROM dim_line').get()) as any).n,
      dim_asset:    ((await db.prepare('SELECT COUNT(*) as n FROM dim_asset').get()) as any).n,
      dim_supplier: ((await db.prepare('SELECT COUNT(*) as n FROM dim_supplier').get()) as any).n,
      dim_material: ((await db.prepare('SELECT COUNT(*) as n FROM dim_material').get()) as any).n,
      semantic_kpi_definition: ((await db.prepare('SELECT COUNT(*) as n FROM semantic_kpi_definition').get()) as any).n,
      semantic_kpi_value:      ((await db.prepare('SELECT COUNT(*) as n FROM semantic_kpi_value').get()) as any).n,
      semantic_event:          ((await db.prepare('SELECT COUNT(*) as n FROM semantic_event').get()) as any).n,
      semantic_event_impact:   ((await db.prepare('SELECT COUNT(*) as n FROM semantic_event_impact').get()) as any).n,
      orchestration_scenario:  ((await db.prepare('SELECT COUNT(*) as n FROM orchestration_scenario').get()) as any).n,
    };
    res.json({
      model_version: 2,
      architecture: 'Semantic Core Data Model',
      tables: counts,
      description: 'Enterprise semantic data model with dimensions, facts, KPI engine and event orchestration.',
    });
  } catch(err) { res.status(500).json({ error: String(err) }); }
});
