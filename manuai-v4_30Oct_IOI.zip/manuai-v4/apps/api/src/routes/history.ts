/**
 * ManuAI — History Routes
 * Serves all historical data from SQLite database.
 * These endpoints power the trend charts across all 8 agents.
 */

import { Router } from 'express';
import {
  getOeeTrend, getPlantOeeTrend, getOeeSummary, getLossByType, getWeeklyLossByType, getDailyLossByType, getOeeByHourRange,
  getMachineLossesToday,
  getHealthTrend, getHealthTrendDaily, getAllHealthSummary,
  getAlertHistory, getAlertStats,
  getBatchHistory, getBatchStats,
  getYieldParamTrend,
  getEnergyTrend, getEnergyByAsset, getEnergyLoad24h,
  getSafetyEventHistory, getSafetyStats,
  getMonthlyOeeByLineGroup } from '../database/queries';
import { getWorkOrders } from '../database/db-queries';
import { loadShifts, loadTechnicians, loadPlatformConfig } from '../data/csv-loader';
import { ackAlertInDB } from '../database/writer';
import { applySafetyEventOverrides } from '../state/runtime-overrides';
import { logger } from '../middleware/logger';
import { normalizePlant } from '../data/plant';

// ── Response cache for heavy history routes ────────────────────────────────────
// The two most expensive routes (plant-trend and scorecard) run CTE queries over
// 300K+ rows. Frontend polls every 15s — caching for 14s means DB is hit once per
// poll cycle per plant, not on every concurrent browser tab / re-render.
const _cache = new Map<string, { ts: number; data: any }>();
const CACHE_TTL = 14_000; // 14s — just under the 15s poll so data is always fresh
function cached<T>(key: string, fn: () => T): T {
  const hit = _cache.get(key);
  if (hit && Date.now() - hit.ts < CACHE_TTL) return hit.data as T;
  const data = fn();
  _cache.set(key, { ts: Date.now(), data });
  return data;
}

const router = Router();

// ── Async-safe handler wrapper ─────────────────────────────────────────────────
// Every history handler runs DB queries. Wrap the router's verb methods so a
// rejected/failed query returns a controlled 500 JSON instead of bubbling up as an
// unhandledRejection that can take the API process down (as the Postgres strftime
// error did). One place, covers all current and future history routes.
for (const verb of ['get', 'post', 'put', 'delete', 'patch'] as const) {
  const raw = (router as any)[verb].bind(router);
  (router as any)[verb] = (path: string, ...handlers: Array<(req: any, res: any, next: any) => any>) =>
    raw(path, ...handlers.map((h) => (req: any, res: any, next: any) =>
      Promise.resolve(h(req, res, next)).catch((err: unknown) => {
        logger.error('[history] route query failed', { path: req.originalUrl, error: String(err) });
        if (!res.headersSent) res.status(500).json({ error: 'history_query_failed', detail: String(err) });
      })));
}

// ── OEE History ────────────────────────────────────────────────────────────────
router.get('/oee/trend/:machineId', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  const data = await getOeeTrend(req.params.machineId, days);
  res.json({ machineId: req.params.machineId, days, data });
});

router.get('/oee/plant-trend', async (req, res) => {
  const pfCode2 = normalizePlant(req.query.plant);
  const days = Number(req.query.days ?? 30);
  const key = `plant-trend:${pfCode2}:${days}`;
  const data = await cached(key, () => getPlantOeeTrend(days, pfCode2 ?? 'All Plants'));
  res.json({ days, data });
});

router.get('/oee/summary', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: await getOeeSummary(days) });
});

// ── PdM Health History ─────────────────────────────────────────────────────────
router.get('/pdm/health/:machineId', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ machineId: req.params.machineId, days, data: await getHealthTrend(req.params.machineId, days) });
});

// Daily-granularity RUL trend for the multi-day "RUL Trend - At-Risk Assets"
// chart. Returns ~1 averaged point per calendar day so the line is continuous.
router.get('/pdm/health-daily/:machineId', async (req, res) => {
  const days = Number(req.query.days ?? 14);
  const data = await getHealthTrendDaily(req.params.machineId, days);
  // build marker — if this field is present in the response, the V74 build is live.
  res.json({ machineId: req.params.machineId, days, build: 'V88-twin-asset-scenarios', points: data.length, data });
});

router.get('/pdm/health-summary', async (_req, res) => {
  res.json({ data: await getAllHealthSummary() });
});

// ── Alerts History ─────────────────────────────────────────────────────────────
router.get('/alerts/history', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  const severity = req.query.severity as string | undefined;
  const data = await getAlertHistory(days, severity);
  res.json({ days, total: data.length, data });
});

router.get('/alerts/stats', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: await getAlertStats(days) });
});

router.post('/alerts/:id/ack', async (req, res) => {
  const ackedBy = req.user?.name ?? 'Unknown';
  const ok = await ackAlertInDB(req.params.id, ackedBy);
  if (!ok) { res.status(404).json({ error: 'Alert not found' }); return; }
  logger.info('Alert acknowledged', { id: req.params.id, by: ackedBy });
  res.json({ success: true, alertId: req.params.id, ackedBy });
});

// ── Batch / Yield History ──────────────────────────────────────────────────────
router.get('/yield/batches', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: await getBatchHistory(days) });
});

router.get('/yield/batch-stats', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: await getBatchStats(days) });
});

router.get('/yield/param-trend/:paramId', async (req, res) => {
  const days = Number(req.query.days ?? 7);
  res.json({ paramId: req.params.paramId, days, data: await getYieldParamTrend(req.params.paramId, days) });
});

// ── Energy History ─────────────────────────────────────────────────────────────
router.get('/energy/trend', async (req, res) => {
  const pfCode = normalizePlant(req.query.plant) ?? undefined;
  // Return the 24h instantaneous-load curve as { h, kw } so the chart's X-axis
  // (hour) and Y-axis (plant kW) are correct. Previously this returned a daily
  // SUM(kw) which both broke the hour label and inflated load ~100x.
  const rows = await getEnergyLoad24h(pfCode) as any[];
  const data = rows.map(r => ({ h: r.hour, kw: Math.round(Number(r.kw)), anomalies: r.anomalies }));
  res.json({ days: 1, data });
});

router.get('/energy/by-asset', async (req, res) => {
  const days = Number(req.query.days ?? 7);
  const pfCode = normalizePlant(req.query.plant) ?? undefined;
  res.json({ days, data: await getEnergyByAsset(days, pfCode) });
});

// ── Safety History ─────────────────────────────────────────────────────────────
router.get('/safety/events', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const days = Number(req.query.days ?? 30);
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  // Now using plant_id column directly — stamped at ingestion, no zone inference needed
  const rawEv = await getSafetyEventHistory(days, pfCode) as any[];
  // Add status field for runtime override layering (open / acked / resolved).
  // Was missing — frontend computed status from resolved_at only, ignoring acks.
  const seeded = rawEv.map((e: any) => ({
    ...e,
    status: e.resolved_at ? 'resolved' : 'open',
    action: e.resolved_at ? `Resolved — ${e.zone} readings normalised.`
          : e.severity === 'critical' ? `Evacuation alert issued for ${e.zone}. Hot-work permits blocked.`
          : `Precursor detected in ${e.zone}. Monitor and investigate.`,
  }));
  const data = applySafetyEventOverrides(seeded);
  res.json({ days, data });
});

router.get('/safety/stats', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  res.json({ days, data: await getSafetyStats(days) });
});


// ── Pre-computed Six Losses + Loss Trend (Issue 13: weights from config) ──────
router.get('/oee/six-losses', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pfCode3 = normalizePlant(req.query.plant);
  // V37: window defaults to "today" so the tile totals match the loss-trend
  // chart's rightmost (today) bar. Previously this returned a rolling N-day
  // cumulative (defaulting to 7 days from the frontend caller), so the tiles
  // showed ~7x the chart's today bar and a reviewer asked why the two views
  // disagreed about "today's" losses.
  // Range options: 'today' (since 00:00 UTC, matches chart day bucket),
  // 'days' (rolling N day window for backward compatibility).
  const range = String(req.query.range ?? 'today');
  let sinceMs: number;
  let windowLabel: string;
  if (range === 'today') {
    // UTC midnight — aligns with strftime('%Y-%m-%d', ..., 'unixepoch') day
    // buckets used by getDailyLossByType. Both views now share a time origin.
    const d = new Date(); d.setUTCHours(0, 0, 0, 0);
    sinceMs = d.getTime();
    windowLabel = 'today';
  } else {
    const days = Math.max(1, Math.min(90, Number(req.query.days ?? 7)));
    sinceMs = Date.now() - days * 24 * 3600 * 1000;
    windowLabel = `${days}d`;
  }
  // Categories sourced from platform_config.csv section oee_loss_category.
  // Was a hardcoded inline CAT array. Single source of truth for both this
  // route and the OeeLosses chart colors. Falls back to legacy 6-category set
  // only if the CSV section is missing.
  const cfg = loadPlatformConfig();
  const cats = (cfg.oeeLossCategories as any[])?.length ? cfg.oeeLossCategories : [
    { name: 'Unplanned Breakdown', color: '#ef4444', barKey: 'brk' },
    { name: 'Speed Loss',          color: '#f97316', barKey: 'spd' },
    { name: 'Minor Stops',         color: '#fbbf24', barKey: 'mst' },
    { name: 'Changeover & Setup',  color: '#f59e0b', barKey: 'chg' },
    { name: 'Startup Defects',     color: '#84cc16', barKey: 'sdef' },
    { name: 'In-process Defects',  color: '#a3e635', barKey: 'def' },
  ];
  const rows = await getLossByType(sinceMs, pfCode3 ?? 'All Plants') as any[];
  const totalMin = rows.reduce((s, r) => s + Number(r.total_min), 0);
  const byType: Record<string, any> = {};
  for (const r of rows) byType[r.loss_type] = r;
  const losses = cats.map((c: any) => {
    const r = byType[c.name];
    return {
      name: c.name, col: c.color, barKey: c.barKey,
      min:  r ? Math.round(Number(r.total_min)) : 0,
      pct:  r && totalMin > 0 ? +(Number(r.total_min) / totalMin * 100).toFixed(1) : 0,
      cnt:  r ? Number(r.machine_cnt) : 0,
      machines: r?.machines ? String(r.machines).split(',') : [],
    };
  });
  res.json({ range: windowLabel, sinceMs, losses, totalMin: Math.round(totalMin) });
});

router.get('/oee/loss-trend', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const days = Number(req.query.days ?? 7);
  const pfCode5 = normalizePlant(req.query.plant);
  // V32: was weekly buckets labelled W01..W06 even though the chart title says
  // "Loss Trend — 7 Days" — title and data disagreed. Now uses daily aggregation
  // so the 7-day window in the title and the X-axis bars match.
  // Categories sourced from platform_config oee_loss_category — same registry the
  // six-losses route uses, so the loss-trend chart bars match the cards perfectly.
  const cfg = loadPlatformConfig();
  const cats = (cfg.oeeLossCategories as any[])?.length ? cfg.oeeLossCategories : [
    { name: 'Unplanned Breakdown', barKey: 'brk' },
    { name: 'Changeover & Setup',  barKey: 'chg' },
    { name: 'Minor Stops',         barKey: 'mst' },
    { name: 'Speed Loss',          barKey: 'spd' },
    { name: 'Startup Defects',     barKey: 'sdef' },
    { name: 'In-process Defects',  barKey: 'def' },
  ];
  const rows = await getDailyLossByType(Math.max(days, 7), pfCode5 ?? 'All Plants') as any[];
  const byDay: Record<string, Record<string, number>> = {};
  for (const r of rows) {
    byDay[r.day] = byDay[r.day] ?? {};
    byDay[r.day][r.loss_type] = Math.round(Number(r.total_min));
  }
  // Build N most-recent days (chronologically). Each X-axis label is the
  // short date in MM-DD format (e.g. "06-16", "06-17") so the chart reads as a
  // 7-day calendar strip. We anchor to "today" and walk N days backward so days
  // with zero losses still appear as empty bars in the chart. Previously the
  // route returned only days that had at least one logged loss, which made a
  // quiet weekend disappear from the X-axis and broke the "last 7 days" framing.
  const daily: any[] = [];
  const dayMs = 24 * 3600 * 1000;
  const now = new Date();
  const pad2 = (n: number) => String(n).padStart(2, '0');
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * dayMs);
    const dayKey = d.toISOString().slice(0, 10); // YYYY-MM-DD in UTC, matches SQLite strftime
    const label = `${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())}`; // MM-DD
    const out: any = { w: label, day: dayKey };
    for (const c of cats as any[]) out[c.barKey] = byDay[dayKey]?.[c.name] ?? 0;
    daily.push(out);
  }
  res.json({ days, weeks: daily, categories: cats });
});


router.get('/oee/scorecard', async (req, res) => {
  const pfCode4 = normalizePlant(req.query.plant);
  const days = Number(req.query.days ?? 180);
  const key = `scorecard:${pfCode4}:${days}`;
  const rows = await cached(key, () => getMonthlyOeeByLineGroup(days, pfCode4 ?? 'All Plants'));
  const months: Record<string, { p1?: number; p2?: number }> = {};
  for (const r of rows) {
    if (!months[r.month]) months[r.month] = {};
    if (r.grp === 'g1') months[r.month].p1 = +Number(r.avg_oee).toFixed(1);
    else months[r.month].p2 = +Number(r.avg_oee).toFixed(1);
  }
  // OEE target: plant-specific from plant_config DB, fallback to platform_config.csv
  let oeeTarget = 85;
  try {
    const db = require('../database/connection').getDb();
    if (pfCode4 && pfCode4 !== 'All Plants') {
      const row = await db.prepare("SELECT value FROM plant_config WHERE plant_id=? AND config_key='oee_target'").get(pfCode4) as {value:string}|undefined;
      if (row) oeeTarget = Number(row.value);
    }
  } catch { /* use default */ }
  const out = Object.entries(months).slice(-6).map(([m, v]) => ({
    m: new Date(m + '-01').toLocaleString('default', { month: 'short' }),
    p1: v.p1 ?? 0, p2: v.p2 ?? 0, target: oeeTarget,
  }));
  res.json({ days, scorecard: out });
});

export default router;

// ── Shifts (computed from OEE history by hour of day) ─────────────────────────
router.get('/oee/shifts', async (req, res) => {
  const days = Number(req.query.days ?? 30);
  const pf = req.query.plant as string | undefined;  // Normalize plant selector value to CSV plant codes
  const pfCode = normalizePlant(pf);
  const data = await getPlantOeeTrend(days);
  // Group into shift buckets from daily data
  // Morning 06-14, Afternoon 14-22, Night 22-06
  const allShifts = loadShifts() as any[];
  const shiftDefs = pf && pfCode && pfCode !== 'All Plants' ? allShifts.filter((sh:any)=>!sh.plant||sh.plant===pfCode||sh.plant==='Both') : allShifts;
  const techList  = loadTechnicians();
  // Live work orders (plant-scoped like the shift defs) so each shift's WO / asset
  // counts are derived from the actual work-orders table rather than the static
  // open_wos / assets_managed fields in shifts.csv. Join key is the technician: a
  // shift's WOs = its technician's open/in-progress work orders; a shift's Assets =
  // the distinct assets that technician currently has work orders on.
  const liveWos = (await getWorkOrders(pf && pfCode && pfCode !== 'All Plants' ? pfCode : undefined))
    .filter((w:any) => w.status === 'open' || w.status === 'in_progress');
  const now = new Date();
  const nowHour = now.getHours();
  const shifts = await Promise.all(shiftDefs.map(async (s, i) => {
    const startH = parseInt(s.start);
    const endH   = parseInt(s.end);
    const active = nowHour >= startH && (endH === 6 ? nowHour >= 22 || nowHour < 6 : nowHour < endH);
    const tech   = techList.find(t => t.shift === s.name);
    // Live WO/asset counts for this shift's technician (fall back to the shift's
    // static roster values only when the technician is unknown, so a shift never
    // renders blank if the roster and WO data are out of sync).
    const techName = tech?.name;
    const techWos  = techName ? liveWos.filter((w:any) => w.assigned_to === techName) : [];
    const liveWoCount    = techWos.length;
    const liveAssetCount = new Set(techWos.map((w:any) => w.asset_id).filter(Boolean)).size;
    // Issue fix: real OEE for this shift's hour window (was plantAvg x invented 0.97+i*0.01)
    let avgOee: number;
    try {
      const sh = parseInt(String(s.start).split(':')[0]);
      const eh = parseInt(String(s.end).split(':')[0]);
      const v = await getOeeByHourRange(isNaN(sh)?0:sh, isNaN(eh)?24:eh, 7);
      avgOee = v ?? (data.length ? +(data.reduce((s2,d)=>s2+d.avg_oee,0)/data.length).toFixed(1) : 0);
    } catch { avgOee = data.length ? +(data.reduce((s2,d)=>s2+d.avg_oee,0)/data.length).toFixed(1) : 0; }
    return {
      shift:  s.name,
      tech:   tech?.name ?? 'Unassigned',
      role:   s.role,
      assets: techName ? liveAssetCount : s.assets,
      wos:    techName ? liveWoCount    : s.wos,
      status: active ? 'active' : i === ((shiftDefs.findIndex((_,j)=>{const sH=parseInt(shiftDefs[j].start);return nowHour>=sH;})+1)%shiftDefs.length) ? 'upcoming' : 'scheduled',
      start:  s.start,
      end:    s.end,
      avgOee,
    };
  }));
  res.json({ data: shifts });
});

// Per-machine loss totals since UTC midnight (today).
// Same time origin as /oee/six-losses?range=today so sums reconcile end-to-end.
// Used by the OEE dashboard's machine-level cards.
router.get('/oee/machine-losses', async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const pf = normalizePlant(req.query.plant) ?? 'All Plants';
  const data = await getMachineLossesToday(pf);
  res.json({ data, plant_id: pf, window: 'today_utc' });
});
