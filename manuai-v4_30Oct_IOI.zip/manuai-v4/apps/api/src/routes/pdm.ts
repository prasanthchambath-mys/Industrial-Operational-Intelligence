import { pdmRouter } from './all-routes';
import { loadParts, loadPdmRules } from '../data/csv-loader';
import { normalizePlant, plantForAsset } from '../data/plant';
import { semanticLayer } from '../semantic/service';
import { requireRole, ROLES } from '../middleware/auth';
import { broadcast } from '../websocket/broadcaster';
import {
  applyPartsOverrides, setPartsOverride, isValidPartsTransition,
} from '../state/runtime-overrides';

// PdM ML service proxy — calls the Python pdm-inference container.
// Process engineers can edit data/csv/ml_thresholds.csv (service=pdm) and
// see this endpoint's response change without restarting the service.
const PDM_SERVICE_URL = process.env.PDM_SERVICE_URL;

pdmRouter.post('/ml-predict', async (req, res) => {
  if (!PDM_SERVICE_URL) {
    res.status(503).json({
      error: 'PDM_SERVICE_URL not configured',
      hint: 'docker-compose should set PDM_SERVICE_URL=http://pdm-inference:8000',
    });
    return;
  }
  try {
    const r = await fetch(`${PDM_SERVICE_URL}/predict`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req.body),
      signal: AbortSignal.timeout(2000),
    });
    if (!r.ok) {
      res.status(r.status).json({ error: `ML service returned ${r.status}` });
      return;
    }
    const data = await r.json();
    res.json({ ...data, source: 'pdm-inference (CSV-driven thresholds)' });
  } catch (err) {
    res.status(502).json({ error: 'ML service unreachable', detail: String(err) });
  }
});

// Returns the live threshold set from the ML service so validators can audit
// what values are actually being applied (CSV value vs env override).
pdmRouter.get('/ml-thresholds', async (_req, res) => {
  if (!PDM_SERVICE_URL) { res.json({ source: 'csv-fallback', thresholds: {} }); return; }
  try {
    const r = await fetch(`${PDM_SERVICE_URL}/thresholds`, { signal: AbortSignal.timeout(2000) });
    res.json(await r.json());
  } catch { res.json({ source: 'unavailable', thresholds: {} }); }
});

// Add extra PdM endpoints not in all-routes.ts
pdmRouter.get('/parts', (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const code = normalizePlant(req.query.plant);
  const { orders, inventory } = loadParts();
  // Resolve plant by looking up each row's asset_id in the CSV-driven topology.
  // Replaces a previously hardcoded ['MCH-01'..'MCH-04'] / ['MCH-05'..'MCH-08'] check.
  const matchPlant = (row:any) => {
    if (!code) return true;
    const assetId = String(row.asset_id || row.asset || '');
    return plantForAsset(assetId) === code;
  };
  const filteredOrders = (orders as any[]).filter(matchPlant);
  res.json({
    // Apply runtime overrides — approve/reject transitions live here
    orders:    applyPartsOverrides(filteredOrders),
    inventory: (inventory as any[]).filter(matchPlant),
  });
});

// POST /api/pdm/parts/:id/approve
// Operator approves a pending/escalated PR. Backend validates the transition,
// stamps a PO number, publishes a semantic event so SupplyChain/OEE agents
// know parts are ordered, broadcasts WS update.
pdmRouter.post('/parts/:id/approve', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { orders } = loadParts();
  const merged = applyPartsOverrides(orders as any[]);
  const order = merged.find((o:any) => o.id === id);
  if (!order) return res.status(404).json({ error: `Order ${id} not found` });
  if (!isValidPartsTransition(order.status, 'ordered')) {
    return res.status(409).json({ error: `Cannot approve order in status '${order.status}'.` });
  }
  // Phase 1: deterministic PO number from order id. Phase A: real SAP MM call.
  const poNumber = `PO-${id.replace('ORD-', '')}`;
  const now = new Date().toISOString();
  const ov = {
    status: 'ordered' as const,
    poNumber,
    approvedAt: now,
    approvedBy: req.user?.name ?? 'unknown',
  };
  setPartsOverride(id, ov);
  try {
    await semanticLayer.publishEvent({
      id: `PO-${Date.now()}`, from: 'pdm', to: 'supply',
      type: 'parts_ordered', sev: 'info',
      msg: `${order.part} approved by ${ov.approvedBy} → ${poNumber}`,
      impact: `Lead time ${order.lead}d — restock for ${order.asset}`,
      asset: order.asset, plant_id: plantForAsset(String(order.asset ?? '')) ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish failure must not block approval */ }
  broadcast('pdm', { type: 'parts_approved', id, poNumber, ts: now });
  res.json({ success: true, id, poNumber, status: 'ordered', override: ov });
});

// POST /api/pdm/parts/:id/reject { reason }
pdmRouter.post('/parts/:id/reject', requireRole(ROLES.MAINTENANCE, ROLES.ENGINEER, ROLES.ADMIN), async (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  const { id } = req.params;
  const { reason } = req.body as { reason?: string };
  const { orders } = loadParts();
  const merged = applyPartsOverrides(orders as any[]);
  const order = merged.find((o:any) => o.id === id);
  if (!order) return res.status(404).json({ error: `Order ${id} not found` });
  if (!isValidPartsTransition(order.status, 'rejected')) {
    return res.status(409).json({ error: `Cannot reject order in status '${order.status}'.` });
  }
  const now = new Date().toISOString();
  const ov = {
    status: 'rejected' as const,
    rejectedReason: reason ?? 'Operator rejection',
    approvedAt: now,
    approvedBy: req.user?.name ?? 'unknown',
  };
  setPartsOverride(id, ov);
  try {
    await semanticLayer.publishEvent({
      id: `PO-RJ-${Date.now()}`, from: 'pdm', to: 'supply',
      type: 'parts_order_rejected', sev: 'warning',
      msg: `${order.part} rejected by ${ov.approvedBy}${reason ? ` — ${reason}` : ''}`,
      impact: 'Asset RUL risk remains — operator dissent recorded',
      asset: order.asset, plant_id: plantForAsset(String(order.asset ?? '')) ?? 'P1', ts: now,
    } as any);
  } catch { /* event publish failure must not block rejection */ }
  broadcast('pdm', { type: 'parts_rejected', id, ts: now });
  res.json({ success: true, id, status: 'rejected', override: ov });
});

pdmRouter.get('/rules', (_req, res) => {
  res.json({ rules: loadPdmRules() });
});

export default pdmRouter;
