import { Router } from 'express';
import { checkPIHealth } from '../connectors/pi-historian';
import { checkSAPHealth } from '../connectors/sap-odata';
import { checkLIMSHealth } from '../connectors/lims';
import { checkOPCUAHealth } from '../connectors/opc-ua';
import { startupState, APP_VERSION } from '../startup-state';
import axios from 'axios';

const router = Router();

// ── Liveness probe — INSTANT, no dependency checks ──────────────────────────
// Kubernetes/Container Apps liveness probe hits this. Must return in <50ms or
// the orchestrator kills a healthy container. Checks only that the event loop
// is responsive — NOT downstream dependencies or boot state.
router.get('/live', (_req, res) => {
  res.json({ status: 'alive', ts: Date.now() });
});

// ── Readiness probe — gated on boot state ───────────────────────────────────
// Returns ready ONLY after the full bootstrap (migrations + seed/data + DB
// connectivity check) has completed. If boot failed, reports not_ready (503)
// with the exact bootError. Also revalidates live DB connectivity each call so a
// DB that drops after boot flips the pod out of rotation.
router.get('/ready', async (_req, res) => {
  if (!startupState.bootComplete) {
    return res.status(503).json({
      status: 'not_ready',
      bootComplete: false,
      bootError: startupState.bootError,
      dbReady: startupState.dbReady,
      migrationsComplete: startupState.migrationsComplete,
      seedComplete: startupState.seedComplete,
      timestamp: new Date().toISOString(),
    });
  }
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { getDb } = require('../database/connection');
    await getDb().prepare('SELECT 1 as ok').get();
    res.json({
      status: 'ready',
      bootComplete: true,
      dbReady: true,
      migrationsComplete: startupState.migrationsComplete,
      seedComplete: startupState.seedComplete,
      dataLoadMode: startupState.dataLoadMode,
      dbProvider: startupState.dbProvider,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(503).json({
      status: 'not_ready',
      bootComplete: true,
      dbReady: false,
      bootError: String(err),
      timestamp: new Date().toISOString(),
    });
  }
});

// ── Version — mounted at /api/health/version (also exposed at /api/version) ──
router.get('/version', (_req, res) => {
  res.json({ version: APP_VERSION, node: process.version, ts: Date.now() });
});

async function pingService(url: string): Promise<boolean> {
  try { await axios.get(`${url}/health`, { timeout: 3000 }); return true; }
  catch { return false; }
}

router.get('/', async (_req, res) => {
  const [pi, sap, lims, opc] = await Promise.allSettled([
    checkPIHealth(), checkSAPHealth(), checkLIMSHealth(), checkOPCUAHealth(),
  ]);

  const serviceUrls = {
    pdm:    process.env.PDM_SERVICE_URL,
    yield:  process.env.YIELD_SERVICE_URL,
    energy: process.env.ENERGY_SERVICE_URL,
    quality:process.env.QUALITY_SERVICE_URL,
    supply: process.env.SUPPLY_SERVICE_URL,
    twin:   process.env.TWIN_SERVICE_URL,
    safety: process.env.SAFETY_SERVICE_URL,
  };

  const serviceChecks = await Promise.allSettled(
    Object.entries(serviceUrls).map(([, url]) => url ? pingService(url) : Promise.resolve(false))
  );
  const serviceNames = Object.keys(serviceUrls);
  const services: Record<string, boolean> = {};
  serviceNames.forEach((name, i) => {
    services[name] = serviceChecks[i].status === 'fulfilled' ? (serviceChecks[i] as any).value : false;
  });

  res.json({
    status: 'ok',
    version: '4.0.0',
    timestamp: new Date().toISOString(),
    agents: { oee: 'ok', yield: 'ok', pdm: 'ok', quality: 'ok', energy: 'ok', supply: 'ok', twin: 'ok', safety: 'ok' },
    connectors: {
      pi_historian: pi.status === 'fulfilled' ? pi.value : false,
      sap_odata:    sap.status === 'fulfilled' ? sap.value : false,
      lims:         lims.status === 'fulfilled' ? lims.value : false,
      opc_ua:       opc.status === 'fulfilled' ? opc.value : false,
      iot_hub:      !!process.env.IOT_HUB_CONNECTION_STRING,
      anthropic:    !!process.env.ANTHROPIC_API_KEY,
      redis:        !!process.env.REDIS_URL,
    },
    python_services: services,
    mock_mode: {
      pi:     !process.env.PI_WEB_API_URL,
      sap:    !process.env.SAP_ODATA_BASE_URL,
      lims:   !process.env.LIMS_BASE_URL,
      opc_ua: !process.env.OPC_UA_ENDPOINT,
      iot_hub:!process.env.IOT_HUB_CONNECTION_STRING,
    },
  });
});

export default router;
