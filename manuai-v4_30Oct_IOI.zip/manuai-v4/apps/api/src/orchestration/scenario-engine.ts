/**
 * ManuAI — Orchestration Scenario Engine
 *
 * Demonstrates the full enterprise cross-agent cascade.
 * When MCH-06 / any asset degrades below critical threshold,
 * the scenario engine fires in sequence:
 *
 * 1. PdM predicts RUL — publishes semantic_event MAINTENANCE_REQUIRED
 * 2. Digital Twin simulates failure impact on OEE
 * 3. OEE Agent shows current + projected loss
 * 4. Parts/Supply: PO raised for required spares, lead time checked
 * 5. Safety: PTW pre-created for maintenance window
 * 6. Yield: Parameters adjusted to compensate for reduced capacity
 * 7. Quality: Defect rate monitoring heightened
 * 8. Energy: Load redistributed away from degrading asset
 *
 * All steps persist to semantic_event_impact.
 * The frontend receives each step via WebSocket cross_agent_event — no frontend change.
 */

import { getDb } from '../database/connection';
import { semanticLayer } from '../semantic/service';
import { persistSemanticEvent, persistEventImpact, resolveEvent } from '../database/event-store';
import { broadcastEvent } from '../websocket/broadcaster';
import { logger } from '../middleware/logger';
import { getPlantState } from '../simulation/engine';
import { loadParts, loadSupplyRisks, loadScenarioSteps } from '../data/csv-loader';
import { plantForAsset } from '../data/plant';

// Track active scenarios to avoid duplicate runs
const activeScenarios = new Map<string, number>(); // assetId → startedAt

export interface ScenarioStep {
  step:   number;
  agent:  string;
  action: string;
  result: string;
  ref?:   string;
}

/**
 * Main orchestration trigger.
 * Called by simulation engine when an asset degrades to critical.
 * Fires the full cross-agent cascade in sequence with realistic delays.
 */
export async function triggerDegradationScenario(
  assetId: string,
  assetName: string,
  rul: number,
  health: number
): Promise<void> {
  // Cooldown for the same asset's scenario — read from platform_config.csv
  // (sim_thresholds.scenario_cooldown_minutes), default 20 min if not set.
  const lastRun = activeScenarios.get(assetId) ?? 0;
  let cooldownMs = 20 * 60 * 1000;
  try {
    const cfg = (require('../data/csv-loader').loadPlatformConfig() as any)?.simThresholds ?? {};
    if (Number.isFinite(cfg.scenario_cooldown_minutes)) {
      cooldownMs = cfg.scenario_cooldown_minutes * 60 * 1000;
    }
  } catch { /* CSV not ready — use default */ }
  if (Date.now() - lastRun < cooldownMs) return;
  activeScenarios.set(assetId, Date.now());

  const scenarioId = `SCN-${assetId}-${Date.now()}`;
  const eventId    = `EVT-${assetId}-${Date.now()}`;
  const now        = Date.now();

  logger.info(`[Orchestration] Scenario triggered — ${assetId} RUL=${rul}d`, { scenarioId });

  // Resolve plant_id from CSV-derived topology (single source of truth)
  const rootPlantId = plantForAsset(assetId) ?? 'P1';

  // Publish root scenario event — persists to SQLite AND broadcasts via WebSocket.
  // Previously only persisted (via persistSemanticEvent), so the root event
  // never reached the frontend Insights panel — only the 7 child step events did.
  await semanticLayer.publishEvent({
    id: eventId, type: 'ASSET_DEGRADATION_SCENARIO',
    from: 'pdm', to: 'all',
    sev: rul < 10 ? 'critical' : 'warning',
    msg: `${assetName}: RUL ${rul} days. Full cross-agent orchestration initiated.`,
    impact: `OEE risk, yield risk, supply lead time check, PTW pre-creation`,
    asset: assetId, ts: new Date().toISOString(),
    plant_id: rootPlantId,
    asset_id: assetId,
  } as any);

  // Register scenario in DB
  try {
    await getDb().prepare(`
      INSERT OR IGNORE INTO orchestration_scenario
        (scenario_id, scenario_name, trigger_event, asset_id, status, started_at, steps_total)
      VALUES (?, ?, ?, ?, 'running', ?, 8)
    `).run(scenarioId, `${assetName} Degradation Response`, eventId, assetId, now);
  } catch { /* non-fatal */ }

  const steps: ScenarioStep[] = [];
  const stepConfigs = loadScenarioSteps();
  const state = getPlantState();
  const asset = state.machines.find(m => m.id === assetId);
  const parts = loadParts();
  const relatedPart = (parts.orders as any[]).find((p:any) =>
    p.asset === assetId || assetId.toLowerCase().includes(p.sku?.toLowerCase()?.slice(0,3) ?? 'XXX'));
  const partAvailable  = relatedPart ? (relatedPart.stock ?? 0) > 0 : false;
  const partLeadDays   = relatedPart?.lead ?? 5;
  const oeeProjectedLoss = +(health < 30 ? 18.4 : health < 50 ? 12.1 : 7.2).toFixed(1);
  const currentOee     = asset?.oee ?? 72;
  const ptwId          = `PTW-${assetId}-${Date.now().toString().slice(-6)}`;
  const deadline       = new Date(Date.now() + rul * 86400000).toDateString();

  // Template variable resolver
  const resolve = (tpl: string) => tpl
    .replace('{rul}',          String(rul))
    .replace('{deadline}',     deadline)
    .replace('{asset_name}',   assetName)
    .replace('{oee_loss}',     String(oeeProjectedLoss))
    .replace('{current_oee}',  String(currentOee))
    .replace('{projected_oee}',String((currentOee - oeeProjectedLoss).toFixed(1)))
    .replace('{yield_risk}',   '3.2')
    .replace('{line}',         asset?.line ?? 'linked line')
    .replace('{ptw_id}',       ptwId)
    .replace('{parts_status}', partAvailable
      ? `Required spares available in stock for ${assetName} maintenance.`
      : `Critical spare (${relatedPart?.sku ?? 'SRV-SERVO'}) lead time ${partLeadDays} days. PO required immediately.`);

  for (const step of stepConfigs) {
    await delay(step.delayMs);

    const desc      = resolve(step.descriptionTpl);
    const actionOk  = step.actionLabelOk;
    const actionNot = step.actionLabelNotOk;

    // Compute step-specific values
    let impactValue: number | null = null;
    let actionTaken  = actionOk;
    let actionRef: string | null   = null;

    switch (step.agent) {
      case 'pdm':     impactValue = rul;               actionRef = `WO-${assetId}-AUTO`;   break;
      case 'twin':    impactValue = oeeProjectedLoss;  actionRef = `SCN-${assetId}`;       break;
      case 'oee':     impactValue = oeeProjectedLoss;                                       break;
      case 'supply':
        impactValue = partAvailable ? 0 : partLeadDays;
        actionTaken = partAvailable ? actionOk : actionNot;
        actionRef   = partAvailable ? null : `PO-${assetId}-EMRG`;
        break;
      case 'safety':  actionRef = ptwId;                                                    break;
      case 'yield':   impactValue = 3.2;                                                    break;
      case 'quality': impactValue = 1.8;                                                    break;
      case 'energy':  actionRef = `LD-${assetId}`;                                         break;
    }

    await persistEventImpact(eventId, step.agent, step.impactType,
      impactValue, step.impactUnit, desc, actionTaken, actionRef);

    steps.push({ step: step.stepNum, agent: step.agent, action: step.actionType,
                 result: desc, ref: actionRef ?? undefined });

    await broadcastStep(assetId, step.agent, 'all', step.eventType,
      desc, step.severity, scenarioId);
  }

  const summary = `${stepConfigs.length}-agent orchestration complete for ${assetName}. RUL=${rul}d. PTW created. Parts checked. Yield adjusted.`;
  try {
    await getDb().prepare(`
      UPDATE orchestration_scenario
      SET status='complete', completed_at=?, steps_done=?, summary=?
      WHERE scenario_id=?
    `).run(Date.now(), stepConfigs.length, summary, scenarioId);
  } catch { /* non-fatal */ }

  logger.info(`[Orchestration] Scenario complete — ${scenarioId}`, { steps: steps.length });
}

async function broadcastStep(
  assetId: string, from: string, to: string,
  type: string, msg: string, sev: 'critical'|'warning'|'info',
  scenarioId?: string
): Promise<void> {
  // Resolve plant_id from CSV-derived topology — works automatically for any
  // new plant/asset added in machines.csv or energy_assets.csv.
  const plantId = plantForAsset(assetId) ?? 'P1';
  const event = {
    id:          `${type}-${assetId}-${Date.now()}`,
    from, to, type, sev, msg,
    impact:      msg,
    asset_id:    assetId,
    asset:       assetId,       // legacy compat
    plant_id:    plantId,
    line_id:     null,          // resolved per asset at query time
    scenario_id: scenarioId ?? null,
    source_mode: 'Synthetic',
    ts:          new Date().toISOString(),
  };
  // publishEvent persists to SQLite AND broadcasts via WebSocket
  // No separate broadcastEvent() needed — avoids duplicate delivery
  await semanticLayer.publishEvent(event as any);
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export async function getActiveScenarios(): Promise<any[]> {
  try {
    return await getDb().prepare(
      'SELECT * FROM orchestration_scenario ORDER BY started_at DESC LIMIT 10'
    ).all();
  } catch { return []; }
}

export async function getScenarioSteps(scenarioId: string): Promise<any[]> {
  try {
    const db = getDb();
    const scenario = await db.prepare('SELECT * FROM orchestration_scenario WHERE scenario_id=?').get(scenarioId);
    if (!scenario) return [];
    const event = await db.prepare('SELECT * FROM semantic_event WHERE event_id=?').get((scenario as any).trigger_event);
    const impacts = await db.prepare('SELECT * FROM semantic_event_impact WHERE event_id=? ORDER BY ts ASC').all((scenario as any).trigger_event);
    return [{ scenario, event, impacts }];
  } catch { return []; }
}
