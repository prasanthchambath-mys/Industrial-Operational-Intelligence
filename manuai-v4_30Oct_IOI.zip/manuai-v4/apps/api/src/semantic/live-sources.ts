/**
 * Live source adapters for the semantic resolver.
 *
 * Each adapter returns the SAME rows the legacy buildX() function computes over, produced by the
 * SAME helpers and the SAME inline derivations (scoring, open-event overrides, divergence). Where a
 * builder derives fields inline (supply severity, twin diverging), the derivation is mirrored here
 * line for line; shadow mode proves the mirror numerically before 'on' is ever set.
 *
 * Every row carries plant_id so the resolver can apply the declared plant dimension.
 */
import { registerLiveSource } from './resolver';
import { liveMachines, liveEnergyAssets, liveYieldParams } from '../ai/ai-context-builder';
import { getQualityDefects, getEnergyWaste, getSupplyRisks, getSafetyPermits, getTwinKPIs } from '../database/db-queries';
import { loadPlatformConfig } from '../data/csv-loader';
import { getSafetyEventHistory } from '../database/queries';
import { applySafetyEventOverrides } from '../state/runtime-overrides';

const num = (v: unknown, d = 0): number => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const withPlant = (r: any) => ({ ...r, plant_id: r.plant_id ?? r.plant });

export function registerLiveSources(): void {
  registerLiveSource('live.machines', async () => (await liveMachines()).map(withPlant));
  registerLiveSource('live.energy_assets', async () => (await liveEnergyAssets()).map(withPlant));
  registerLiveSource('live.yield_params', async () => (await liveYieldParams()).map(p => ({ ...withPlant(p), param_id: p.id, warn: !!p.warn })));
  registerLiveSource('quality.defects_today', async f => (await getQualityDefects(f.plant ?? undefined, f.line ?? undefined, 200)).map(withPlant));
  registerLiveSource('energy.waste', async f => (await getEnergyWaste(f.plant ?? undefined)).map(withPlant));
  registerLiveSource('safety.permits', async f => (await getSafetyPermits(f.plant ?? undefined)).map(withPlant));

  // Mirrors buildSupply's scoring exactly (thresholds from platform_config, severity by stock cover).
  registerLiveSource('supply.risks_scored', async f => {
    const risks = await getSupplyRisks(f.plant ?? undefined);
    const supTh = (loadPlatformConfig() as any).supplyThreshold ?? {};
    const stockCriticalDays = Number(supTh.stock_critical_days ?? 14);
    const stockHighDays = Number(supTh.stock_high_days ?? 30);
    return risks.map((r: any) => {
      const contracted = num(r.lead_time_contracted_days, 1);
      const actual = num(r.lead_time_actual_days, contracted);
      const leadDrift = contracted ? actual / contracted : 1;
      const financial = num(r.financial_risk_score, 0) / 100 + 0.5;
      const geo = (r.single_source === 'true' || r.single_source === true) ? 1.3 : 1.0;
      const stockDays = num(r.current_stock_days, 999);
      const reorderDays = num(r.reorder_point_days, 0);
      return {
        supplier_id: r.supplier_id, plant_id: r.plant_id ?? r.plant, sku: r.sku,
        risk_score: +(leadDrift * financial * geo * 100).toFixed(1),
        below_reorder: stockDays < reorderDays,
        severity: stockDays < stockCriticalDays ? 'critical' : stockDays < stockHighDays ? 'high' : 'medium',
      };
    });
  });

  // Mirrors buildSafety's open-event derivation (30-day history, runtime overrides, unresolved only).
  registerLiveSource('safety.open_events', async f => {
    const raw = await getSafetyEventHistory(30, f.plant ?? undefined);
    const events = applySafetyEventOverrides(raw.map((e: any) => ({ ...e, status: e.resolved_at ? 'resolved' : 'open' })));
    return events.filter((e: any) => (e.status ?? 'open') !== 'resolved')
                 .map((e: any) => ({ id: e.id, plant_id: e.plant_id ?? e.plant, zone: e.zone, severity: e.severity, status: e.status ?? 'open' }));
  });

  // Mirrors buildTwin's divergence derivation.
  registerLiveSource('twin.kpis_scored', async f => {
    const kpis = await getTwinKPIs(f.plant ?? undefined);
    return kpis.map((k: any) => {
      const actual = num(k.actual); const pred = num(k.twin_predicted, actual);
      const divPct = pred ? +(Math.abs(actual - pred) / pred * 100).toFixed(2) : 0;
      return { kpi_id: k.kpi_name, plant_id: k.plant_id ?? k.plant, divergence_pct: divPct, diverging: divPct > num(k.divergence_threshold_pct, 3),
               stale: Date.now() - num(k.updated_at, Date.now()) > 3_600_000 };
    });
  });
}
