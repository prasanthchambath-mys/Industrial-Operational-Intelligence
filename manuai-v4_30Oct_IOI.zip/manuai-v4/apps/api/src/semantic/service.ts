import { EventEmitter } from 'events';
import { loadConflictRules } from '../data/csv-loader';
import { persistSemanticEvent, persistEventImpact, getRecentEvents as getStoredEvents } from '../database/event-store';
import { logger } from '../middleware/logger';
import { broadcastEvent } from '../websocket/broadcaster';

export type AgentId = 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety';

export interface CrossAgentEvent {
  id: string; from: AgentId | string; to: AgentId | string;
  type: string; sev: 'critical' | 'warning' | 'info';
  msg: string; impact: string; asset: string; ts: string;
}

export interface AgentAction {
  agent: AgentId; type: string; assetId?: string; tagId?: string;
  // Plant of the action's target. When the action's `assetId` doesn't directly
  // identify a zone (e.g. PTW gating where the permit is keyed by asset_id
  // rather than zone), zone-scoped rules can still match by comparing
  // plantForZone(fault.zoneId) === plantId. Set by the route from
  // plantForAsset(assetId).
  plantId?: string;
}

// KPI definitions loaded from semantic_kpi_definitions.csv (seeded to DB at startup)
// Source: data/csv/semantic_kpi_definitions.csv — edit there to change definitions
// REPLACE WITH: Azure App Configuration or admin UI in Phase 2
import { loadSemanticKpiDefs } from '../data/csv-loader';
import { getDb } from '../database/connection';
import { resolveKPI } from './resolver';

// Health threshold for "machine in critical state" — read from
// platform_config.csv (sim_thresholds.health_recovery_min) once and cached.
// Mirrors the sim engine's threshold so semantic conflict detection stays in
// lock-step with what the simulation considers critical. Edit the CSV value
// to change behaviour — no code change required.
let _healthMin: number | null = null;
function getHealthMin(): number {
  if (_healthMin !== null) return _healthMin;
  try {
    const cfg = (require('../data/csv-loader').loadPlatformConfig() as any)?.simThresholds ?? {};
    _healthMin = Number.isFinite(cfg.health_recovery_min) ? cfg.health_recovery_min : 60;
  } catch { _healthMin = 60; }
  return _healthMin!;
}

// Sync CSV bootstrap — used for the lazy synchronous cache so getKpiDefinitions()
// (which backs a Proxy with synchronous property access) stays synchronous.
function loadKpiDefinitionsFromCsv(): Record<string, any> {
  const defs = loadSemanticKpiDefs();
  const result: Record<string, any> = {};
  for (const d of defs as any[]) {
    result[d.id] = { name: d.name, formula: d.formula, unit: d.unit,
      agents: Array.isArray(d.agents) ? d.agents : d.agents.split(';'),
      src: d.src, governance: d.governance };
  }
  return result;
}

// Async DB-authoritative loader — read once at startup (and after governance
// edits) via warmKpiDefinitions() to override the CSV bootstrap.
async function loadKpiDefinitionsFromDb(): Promise<Record<string, any>> {
  try {
    const rows = await getDb().prepare('SELECT * FROM semantic_kpi_definition').all() as any[];
    if (rows.length === 0) throw new Error('empty');
    const result: Record<string, any> = {};
    for (const r of rows) {
      result[r.kpi_id] = {
        name:    r.kpi_name,
        formula: r.formula,
        unit:    r.unit,
        agents:  r.agents.split(','),
        src:     r.source_system,
        governance: r.governance,
      };
    }
    return result;
  } catch {
    return loadKpiDefinitionsFromCsv();   // DB not ready yet
  }
}

let _kpiDefsCache: Record<string, any> | null = null;
export function getKpiDefinitions(): Record<string, any> {
  if (!_kpiDefsCache) _kpiDefsCache = loadKpiDefinitionsFromCsv();
  return _kpiDefsCache;
}
// DB-authoritative refresh — call at startup after seeding and after any
// governed KPI-definition change so the semantic layer reflects the DB.
export async function warmKpiDefinitions(): Promise<void> {
  _kpiDefsCache = await loadKpiDefinitionsFromDb();
}
export function reloadKpiDefinitions(): void { _kpiDefsCache = null; }

// Legacy export for backward compat — lazy loaded from CSV/DB
export const KPI_DEFINITIONS = new Proxy({} as Record<string, any>, {
  get: (_t, key: string) => getKpiDefinitions()[key],
  ownKeys: () => Object.keys(getKpiDefinitions()),
  getOwnPropertyDescriptor: () => ({ configurable: true, enumerable: true }),
});

// Conflict rules loaded from conflict_rules.csv — no hardcoded rules
// REPLACE WITH: CMMS conflict rule API in Phase 3
let _conflictRulesCache: ReturnType<typeof loadConflictRules> | null = null;
function getConflictRules() {
  if (!_conflictRulesCache) _conflictRulesCache = loadConflictRules();
  return _conflictRulesCache;
}
// Public reload — called by /api/semantic/reload after CSV edits. Without this
// the conflict_rules.csv was effectively read-only at runtime.
export function reloadConflictRules(): void {
  _conflictRulesCache = null;
  _healthMin = null;  // also flush the health-min sim-threshold cache
}

// Active faults: Map<"ruleId::assetId", { since, assetId, zoneId? }>
// Key is scoped: "CR-001::MCH-06" — asset-specific blocking
const activeFaults = new Map<string, { since: Date; assetId: string; zoneId?: string }>();

class SemanticLayerService {
  private emitter = new EventEmitter();
  private recentEvents: CrossAgentEvent[] = [];
  private _cache = new Map<string, { val: unknown; exp: number }>();

  constructor() {
    this.emitter.setMaxListeners(50);
    logger.info('[Semantic] Using in-memory event bus (Redis inactive)');
  }

  getKPIDefinitions() { return getKpiDefinitions(); }
  /** The single governed read path for a KPI value: definition, binding, calculation, freshness and lineage from the database. */
  getKPI(kpiId: string, plantId?: string | null) { return resolveKPI(kpiId, { plant: plantId ?? null }); }

  registerFault(ruleId: string, assetId: string, zoneId?: string): void {
    activeFaults.set(`${ruleId}::${assetId}`, { since: new Date(), assetId, zoneId });
    logger.info('Semantic Layer: fault registered', { ruleId, assetId, zoneId });
  }

  resolveFault(ruleId: string, assetId: string): void {
    activeFaults.delete(`${ruleId}::${assetId}`);
    logger.info('Semantic Layer: fault resolved', { ruleId, assetId });
  }

  getActiveFaults(): Array<{ key: string; ruleId: string; assetId: string; zoneId?: string; since: Date }> {
    return Array.from(activeFaults.entries()).map(([key, v]) => ({
      key, ruleId: key.split('::')[0], assetId: v.assetId, zoneId: v.zoneId, since: v.since,
    }));
  }

  /**
   * Unified view of every conflict the Semantic Layer is currently enforcing,
   * across ALL rule types (yield DCS, PTW, work orders, energy dispatch, …).
   * Used by /api/semantic/active-blocks for the right-panel aggregate counter.
   *
   * Computed from two sources, to match checkConflict() exactly:
   *   1. activeFaults map — explicitly registered faults (CR-002 gas, CR-001 maintenance)
   *   2. Live plant state — machines in sustained critical state (the fallback path)
   * Without (2), the yield params get blocked=true but the counter showed 0 — a visible
   * contradiction in the UI.
   */
  getActiveBlocks(): Array<{
    ruleId: string; blockAgent: string; blockAction: string; triggerAgent: string;
    scope: 'asset' | 'zone'; assetId: string; zoneId?: string;
    plant_id: 'P1' | 'P2' | null; reason: string; since: Date;
  }> {
    const rules = getConflictRules();
    const ruleById = new Map(rules.map(r => [r.id, r]));
    // Topology lookups via data/plant.ts — was hardcoded P1A/P2A sets + zone-name
    // substring matching here. CSV-driven topology = no silent drift if machines.csv
    // adds a 9th machine or changes plant assignment.
    const { plantForAsset, plantForZone } = require('../data/plant') as typeof import('../data/plant');
    const assetPlant = (a: string) => (plantForAsset(a) ?? null) as 'P1'|'P2'|null;
    const zonePlant  = (z?: string) => (z ? plantForZone(z) : null) as 'P1'|'P2'|null;

    // Source 1: explicitly registered active faults.
    // For yield DCS-write rules, expand into one entry per affected yield param
    // (matching the right-panel display); for other rule types, one entry per
    // (rule, machine) tuple.
    let yieldParamsState: Array<{ id: string; name: string; plant?: string }> = [];
    try {
      const { getPlantState } = require('../simulation/engine');
      yieldParamsState = (getPlantState().yieldParams ?? []) as any[];
    } catch { /* sim not ready */ }

    const fromFaults = Array.from(activeFaults.entries()).flatMap(([key, v]) => {
      const ruleId = key.split('::')[0];
      const rule = ruleById.get(ruleId);
      if (!rule) return [];
      const plant_id = (rule.assetScope === 'zone' ? zonePlant(v.zoneId) : assetPlant(v.assetId)) as 'P1'|'P2'|null;
      // Yield DCS-write rules expand to one entry per affected param
      if (rule.blockAgent === 'yield' && rule.blockActionType === 'dcs_write') {
        const affectedParams = yieldParamsState.filter(
          (yp) => !yp.plant || yp.plant === plant_id || yp.plant === 'Both'
        );
        if (affectedParams.length === 0) {
          // Fallback: at least one entry so the counter is non-zero
          return [{
            ruleId, blockAgent: rule.blockAgent, blockAction: rule.blockActionType,
            triggerAgent: rule.triggerAgent, scope: rule.assetScope as 'asset' | 'zone',
            assetId: v.assetId, zoneId: v.zoneId, plant_id,
            reason: rule.reason, since: v.since,
          }];
        }
        return affectedParams.map((yp) => ({
          ruleId, blockAgent: rule.blockAgent, blockAction: rule.blockActionType,
          triggerAgent: rule.triggerAgent, scope: rule.assetScope as 'asset' | 'zone',
          assetId: v.assetId, zoneId: v.zoneId, plant_id,
          reason: `${yp.name}: ${rule.reason}`, since: v.since,
        }));
      }
      return [{
        ruleId,
        blockAgent:  rule.blockAgent,
        blockAction: rule.blockActionType,
        triggerAgent: rule.triggerAgent,
        scope:       rule.assetScope as 'asset' | 'zone',
        assetId:     v.assetId,
        zoneId:      v.zoneId,
        plant_id,
        reason:      rule.reason,
        since:       v.since,
      }];
    });

    // Source 2: live-state-derived blocks (mirrors checkConflict's fallback path).
    // For yield DCS-write rules, expand the block to one entry PER affected yield
    // param in the plant — matching how the right-panel Insights displays them.
    // Previously: 1 critical machine × 1 pdm rule = 1 block entry, but the UI
    // showed N yield params each with a BLOCKED badge → counter said "1 action
    // blocked" while user saw 3 visible blocks. Now they match.
    const seen = new Set(fromFaults.map(b => `${b.ruleId}::${b.assetId}`));
    const fromLive: typeof fromFaults = [];
    try {
      const { getPlantState } = require('../simulation/engine');
      const state = getPlantState();
      const criticalMachines = (state.machines as any[]).filter(
        (m: any) => m.status === 'critical' && m.health < getHealthMin()
      );
      const pdmAssetRules = rules.filter(r => r.triggerAgent === 'pdm' && r.assetScope === 'asset');
      const allYieldParams = state.yieldParams as Array<{ id: string; name: string; plant?: string }>;
      for (const m of criticalMachines) {
        for (const r of pdmAssetRules) {
          const key = `${r.id}::${m.id}`;
          if (seen.has(key)) continue;
          seen.add(key);
          const machinePlant = assetPlant(m.id);
          // For yield DCS writes, expand into per-param entries — every yield
          // param in this plant is blocked by this single critical machine,
          // so the counter must reflect every visible block.
          if (r.blockAgent === 'yield' && r.blockActionType === 'dcs_write') {
            const affectedParams = allYieldParams.filter(
              (yp) => !yp.plant || yp.plant === machinePlant || yp.plant === 'Both'
            );
            for (const yp of affectedParams) {
              fromLive.push({
                ruleId:       r.id,
                blockAgent:   r.blockAgent,
                blockAction:  r.blockActionType,
                triggerAgent: r.triggerAgent,
                scope:        r.assetScope as 'asset' | 'zone',
                assetId:      m.id,
                zoneId:       undefined,
                plant_id:     machinePlant as 'P1'|'P2'|null,
                reason:       `${yp.name}: ${r.reason.replace('PdM critical fault detected', `${m.name} is in critical state`)}`,
                since:        new Date(),
              });
            }
          } else {
            // Non-yield rules (PTW, WO, dispatch): keep one entry per (rule, machine)
            fromLive.push({
              ruleId:       r.id,
              blockAgent:   r.blockAgent,
              blockAction:  r.blockActionType,
              triggerAgent: r.triggerAgent,
              scope:        r.assetScope as 'asset' | 'zone',
              assetId:      m.id,
              zoneId:       undefined,
              plant_id:     machinePlant as 'P1'|'P2'|null,
              reason:       r.reason.replace('PdM critical fault detected', `${m.name} is in critical state`),
              since:        new Date(),
            });
          }
        }
      }
    } catch { /* simulation not ready yet */ }

    return [...fromFaults, ...fromLive];
  }

  checkConflict(action: AgentAction): { blocked: boolean; reason?: string; ruleId?: string } {
    const rules = getConflictRules();
    // For zone-scoped rules and zone-sourced asset-scoped rules, we may need to
    // derive the fault's plant. Loaded lazily to avoid an import cycle.
    let plantForZone: ((z?: string) => string | null) | null = null;
    try { ({ plantForZone } = require('../data/plant') as typeof import('../data/plant') as any); } catch { /* topology may not be loaded yet */ }
    // Check ephemeral fault map first
    for (const rule of rules) {
      if (rule.blockAgent !== action.agent) continue;
      if (rule.blockActionType !== action.type) continue;
      for (const [faultKey, fault] of activeFaults) {
        if (!faultKey.startsWith(rule.id)) continue;
        // Unified fault-match logic with plant fallback. Without this, CR-003
        // (asset-scoped, registered with zone as fault assetId by the sim
        // engine when a gas precursor fires) could never match a WO creation
        // on a concrete machine like MCH-01.
        let matches = false;
        if (rule.assetScope === 'asset') {
          if (action.assetId && fault.assetId === action.assetId) {
            matches = true;
          } else if (action.plantId && fault.zoneId && plantForZone && plantForZone(fault.zoneId) === action.plantId) {
            // Fault sourced from a zone (e.g. CR-003 from gas precursor),
            // action targets an asset in the same plant — block.
            matches = true;
          } else if (!action.assetId && !action.plantId) {
            // No context → broad match (preserves prior loose behaviour)
            matches = true;
          }
        } else if (rule.assetScope === 'zone') {
          if (action.assetId && fault.zoneId === action.assetId) {
            matches = true;
          } else if (action.plantId && fault.zoneId && plantForZone && plantForZone(fault.zoneId) === action.plantId) {
            // Action carries a plant id but no zone (e.g. PTW gated by asset)
            matches = true;
          } else if (!action.assetId && !action.plantId) {
            matches = true;
          }
        } else {
          matches = true; // global scope
        }
        if (matches) return { blocked: true, reason: rule.reason, ruleId: rule.id };
      }
    }
    // Fallback: check live plant state against ALL CSV-defined rules that target a machine asset scope.
    // Ensures blocked state persists even if activeFaults map was cleared (e.g. after restart).
    // Issue fix: was hardcoding 'yield', 'dcs_write', 'CR-001' — now fully CSV-rule-driven.
    try {
      const { getPlantState } = require('../simulation/engine');
      const state = getPlantState();
      // Hysteresis: only block on confirmed critical (not warning) to prevent rapid BLOCKED/NO CONFLICTS flipping
      // Machines must be status==='critical' (not just warning) to trigger semantic conflict
      const criticalMachines = (state.machines as any[]).filter(
        (m: any) => m.status === 'critical' && m.health < getHealthMin()
      );
      if (criticalMachines.length > 0) {
        // Find any CSV rule that blocks this agent/action due to a pdm-triggered machine fault
        const matchingRule = rules.find(r =>
          r.blockAgent === action.agent &&
          r.blockActionType === action.type &&
          r.triggerAgent === 'pdm' &&
          r.assetScope === 'asset'
        );
        if (matchingRule) {
          const affectedMachine = action.assetId
            ? criticalMachines.find((m: any) => m.id === action.assetId) ?? criticalMachines[0]
            : criticalMachines[0];
          return {
            blocked: true,
            reason: matchingRule.reason.replace('PdM critical fault detected', `${affectedMachine.name} is in critical state`),
            ruleId: matchingRule.id,
          };
        }
      }
    } catch { /* simulation not ready yet */ }
    return { blocked: false };
  }

  async publishEvent(event: CrossAgentEvent): Promise<void> {
    // Persist to SQLite first — full audit trail
    await persistSemanticEvent(event);
    // Keep in-memory for fast reads
    this.recentEvents.unshift(event);
    if (this.recentEvents.length > 500) this.recentEvents = this.recentEvents.slice(0, 500);
    this.emitter.emit('cross_agent_event', event);
    broadcastEvent(event as unknown as Record<string, unknown>);
    logger.info('Semantic event', { type: event.type, from: event.from, to: event.to });
  }

  async getRecentEvents(limit = 50): Promise<CrossAgentEvent[]> {
    try {
      // Read from SQLite for persistence across restarts
      const stored = await getStoredEvents(limit);
      if (stored.length > 0) {
        return stored.map((r: any) => ({
          ...JSON.parse(r.payload ?? '{}'),
          id: r.event_id, type: r.event_type,
          from: r.from_agent, asset: r.asset_id,
          sev: r.severity, msg: r.message, ts: new Date(r.ts).toISOString(),
        }));
      }
    } catch { /* fall through to in-memory */ }
    return this.recentEvents.slice(0, limit);
  }

  async cache<T>(key: string, ttl: number, fn: () => Promise<T>): Promise<T> {
    const cached = this._cache.get(key);
    if (cached && Date.now() < cached.exp) return cached.val as T;
    const val = await fn();
    this._cache.set(key, { val, exp: Date.now() + ttl * 1000 });
    return val;
  }
}

export const semanticLayer = new SemanticLayerService();
