/**
 * Semantic governance runtime — Steps 7 and 8 of the DB-authoritative spec, inside the existing API container.
 *
 * Step 7 — refresh: on a jittered timer (and from POST /admin/refresh) call semantic_refresh() in the database,
 *   which takes the replica lock and re-aggregates by watermark, then resolve every LIVE-bound KPI per plant and
 *   append governed values to semantic_kpi_value with freshness. Bounded timeout, one retry, never in the request path.
 * Step 8 — drift guard: at startup compare the seed CSV checksum with semantic_seed_manifest. DB ahead of CSV is
 *   normal (log). CSV ahead of DB means someone edited the file expecting it to take effect: fail LOUD (error log +
 *   manifest flagged so semantic_model_drift shows it). Export: writeGlossaryCsv() round-trips the DB model to CSV.
 * Step 5 — prompts: agent prompts come from semantic_prompt_template with {{critical_days}} / {{urgent_days}}
 *   substituted from the threshold source. PROMPT_THRESHOLD_SOURCE=legacy (default) reproduces today's text exactly;
 *   =ml_thresholds binds to ml_thresholds.csv.
 *
 * Alerting: no Teams/webhook path exists in this codebase, so failures are logged at ERROR (see report).
 */
import { createHash } from 'crypto';
import { promises as fs } from 'fs';
import path from 'path';
import { getDb } from '../database/connection';
import { logger } from '../middleware/logger';
import { resolveKPI, loadBindings, resolverMode } from './resolver';

const REPLICA = process.env.CONTAINER_APP_REPLICA_NAME ?? process.env.HOSTNAME ?? `pid-${process.pid}`;
const nowMs = () => Date.now();
const enabled = () => resolverMode() !== 'off' && (getDb() as any).backend === 'postgres';

// ------------------------------------------------------------------------------------------------
// Step 7 — refresh
// ------------------------------------------------------------------------------------------------
export interface RefreshResult { run_id: number | null; status: string; kpis_refreshed: number; live_kpis: number; message: string; replica: string }

async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return Promise.race([p, new Promise<T>((_, rej) => setTimeout(() => rej(new Error(`timeout after ${ms}ms`)), ms))]);
}

export async function runRefresh(trigger: 'scheduler' | 'admin', timeoutMs = 120_000): Promise<RefreshResult> {
  const db = getDb();
  const attempt = async (): Promise<RefreshResult> => {
    const rows = (await withTimeout(db.all('SELECT * FROM semantic_refresh(?, ?)', [REPLICA, trigger]), timeoutMs)) as any[];
    const r = rows[0] ?? { status: 'failed', message: 'no result' };
    if (r.status !== 'ok') return { run_id: r.run_id ?? null, status: r.status, kpis_refreshed: 0, live_kpis: 0, message: r.message ?? '', replica: REPLICA };
    // Live-bound KPIs are resolved here (adapters need the running engine) and appended as governed values.
    const bindings = await loadBindings(true); let live = 0;
    for (const b of bindings.values()) {
      if (b.source_kind !== 'live') continue;
      for (const plant of ['All Plants', 'P1', 'P2']) {
        try {
          const v = await resolveKPI(b.kpi_id, { plant });
          await db.run(`INSERT INTO semantic_kpi_value (kpi_id, plant_id, asset_id, scope, ts, value, target, status) VALUES (?, ?, NULL, 'governed', ?, ?, NULL, 'refreshed')`,
                       [b.kpi_id, plant, nowMs(), v.value]);
          await db.all('SELECT semantic_touch_freshness(?, ?, true, NULL, ?)', [b.kpi_id, plant, Math.max(60, v.freshness.cadence_seconds * 4)]);
          live++;
        } catch (error) {
          await db.all('SELECT semantic_touch_freshness(?, ?, false, ?, 300)', [b.kpi_id, plant, String(error).slice(0, 500)]).catch(() => undefined);
        }
      }
    }
    return { run_id: r.run_id, status: 'ok', kpis_refreshed: Number(r.kpis_refreshed ?? 0), live_kpis: live, message: r.message ?? '', replica: REPLICA };
  };
  try { return await attempt(); }
  catch (e1) {
    logger.warn('[Semantic] refresh attempt 1 failed; retrying once', { error: String(e1) });
    try { return await attempt(); }
    catch (e2) { logger.error('[Semantic] refresh failed after retry — ALERT', { error: String(e2), replica: REPLICA }); return { run_id: null, status: 'failed', kpis_refreshed: 0, live_kpis: 0, message: String(e2), replica: REPLICA }; }
  }
}

let timer: NodeJS.Timeout | null = null;
export function startSemanticScheduler(): void {
  if (!enabled()) { logger.info('[Semantic] refresh scheduler inactive (resolver off or non-Postgres)'); return; }
  if (timer) return;
  const everyMs = Math.max(5, Number(process.env.SEMANTIC_REFRESH_MINUTES ?? 60)) * 60_000;
  const jitter = Math.floor(Math.random() * 120_000) + 60_000;             // 1–3 min jittered start
  logger.info('[Semantic] refresh scheduler active', { everyMin: everyMs / 60_000, firstRunInSec: Math.round(jitter / 1000), replica: REPLICA });
  const tick = () => { void runRefresh('scheduler').then(r => logger.info('[Semantic] refresh', r as any)); };
  timer = setTimeout(() => { tick(); timer = setInterval(tick, everyMs); timer.unref?.(); }, jitter);
  timer.unref?.();
}
export function stopSemanticScheduler(): void { if (timer) { clearTimeout(timer); clearInterval(timer); timer = null; } }

// ------------------------------------------------------------------------------------------------
// Step 8 — drift guard and export
// ------------------------------------------------------------------------------------------------
const CSV_DIR = process.env.CSV_DATA_DIR ?? path.resolve(__dirname, '../../../../data/csv');
const SEED = 'semantic_kpi_definitions.csv';

export async function checkSeedDrift(): Promise<{ status: 'in_sync' | 'db_ahead' | 'csv_ahead' | 'no_manifest' | 'no_csv'; detail: string }> {
  const db = getDb();
  let csv: string; let mtimeMs: number;
  try { const p = path.join(CSV_DIR, SEED); csv = await fs.readFile(p, 'utf8'); mtimeMs = (await fs.stat(p)).mtimeMs; }
  catch { return { status: 'no_csv', detail: `${SEED} not found in ${CSV_DIR}` }; }
  const checksum = createHash('sha256').update(csv).digest('hex');
  const rowCount = csv.split('\n').filter(l => l.trim()).length - 1;
  const m = ((await db.all('SELECT checksum, loaded_at FROM semantic_seed_manifest WHERE csv_name = ?', [SEED])) as any[])[0];
  if (!m) {
    await db.run('INSERT INTO semantic_seed_manifest (csv_name, checksum, row_count, seed_version, loaded_at) VALUES (?, ?, ?, ?, ?)', [SEED, checksum, rowCount, 'bootstrap', nowMs()]);
    return { status: 'no_manifest', detail: 'manifest created from the current CSV; the DB is authoritative from here' };
  }
  if (m.checksum === checksum) return { status: 'in_sync', detail: 'CSV matches the manifest' };
  if (mtimeMs > Number(m.loaded_at)) {
    logger.error('[Semantic] DRIFT: seed CSV was edited after the DB model moved on. The DB is authoritative; CSV edits do NOT take effect. Export the DB model to CSV and commit that instead.', { csv: SEED });
    await db.run('UPDATE semantic_seed_manifest SET seed_version = ? WHERE csv_name = ?', ['DRIFT: csv edited ' + new Date(mtimeMs).toISOString(), SEED]);
    return { status: 'csv_ahead', detail: 'CSV edited after manifest load — fail loud' };
  }
  return { status: 'db_ahead', detail: 'DB model has changed since the CSV was loaded (normal)' };
}

/** Round-trip: dump the governed glossary (definitions + bindings) to CSV so a UI change can be committed to git. */
export async function writeGlossaryCsv(outPath: string): Promise<number> {
  const rows = (await getDb().all(`SELECT kpi_id, kpi_name, formula, unit, agents, source_system, governance, is_derived, version,
      source_kind, source_name, value_column, aggregation, filter_predicate, expression, dimensions, entity_key, order_column, value_precision, legacy_key, binding_version
    FROM semantic_kpi_definition ORDER BY kpi_id`)) as any[];
  const cols = Object.keys(rows[0] ?? {});
  const esc = (v: unknown) => { const s = v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  await fs.writeFile(outPath, [cols.join(','), ...rows.map(r => cols.map(c => esc(r[c])).join(','))].join('\n') + '\n', 'utf8');
  return rows.length;
}

// ------------------------------------------------------------------------------------------------
// Step 5 — prompt templates bound to thresholds
// ------------------------------------------------------------------------------------------------
let promptCache: { at: number; byAgent: Map<string, string> } | null = null;
export async function agentPrompt(agent: string, fallback: string): Promise<string> {
  if ((getDb() as any).backend !== 'postgres') return fallback;
  try {
    if (!promptCache || Date.now() - promptCache.at > 300_000) {
      const rows = (await getDb().all('SELECT agent, template FROM semantic_prompt_template')) as any[];
      promptCache = { at: Date.now(), byAgent: new Map(rows.map(r => [r.agent, r.template])) };
    }
    const t = promptCache.byAgent.get(agent); if (!t) return fallback;
    const vars = await thresholdVariables();
    return t.replace(/\{\{(\w+)\}\}/g, (_, k) => String(vars[k] ?? `{{${k}}}`));
  } catch { return fallback; }
}
async function thresholdVariables(): Promise<Record<string, number>> {
  // legacy (default) reproduces today's prompt text exactly; ml_thresholds binds to the engine's thresholds.
  if ((process.env.PROMPT_THRESHOLD_SOURCE ?? 'legacy') === 'legacy') return { critical_days: 14, urgent_days: 30 };
  try {
    const csv = await fs.readFile(path.join(CSV_DIR, 'ml_thresholds.csv'), 'utf8'); const out: Record<string, number> = {};
    for (const line of csv.split('\n')) { const c = line.split(','); if (c[2] === 'critical_days' || c[2] === 'urgent_days') out[c[2]] = Number(c[3]); }
    return out;
  } catch { return { critical_days: 14, urgent_days: 30 }; }
}
