/**
 * resolveKPI() — the single governed read path for KPI values.
 *
 * Definition, source binding, calculation, dimensionality, freshness and lineage all come from
 * PostgreSQL (semantic_kpi_definition binding columns + semantic_source). No calculation is
 * hardcoded here: this module only knows how to (1) fetch a named source, (2) apply a declared
 * filter, (3) apply a declared aggregation, (4) evaluate a declared arithmetic expression.
 *
 * Mode (SEMANTIC_RESOLVER env, default off):
 *   off    — never called from the request path. Zero behaviour change. Ships to Azure first.
 *   shadow — computed alongside the legacy buildX() path, compared, logged to
 *            semantic_resolution_log; the LEGACY value is what the caller receives.
 *   on     — the resolver's value replaces the legacy value where a binding exists;
 *            buildX() remains the fallback for unbound KPIs and for any resolver error.
 *
 * Live sources are served by adapters that call the SAME helper functions the legacy builders
 * use, so a shadow mismatch can only come from the declared calculation, never from the data.
 * No new dependency: uses the application's database adapter and helpers only.
 */
import { getDb } from '../database/connection';
import { logger } from '../middleware/logger';
import { normalizePlant } from '../data/plant';

export type ResolverMode = 'off' | 'shadow' | 'on';
export const RESOLVER_VERSION = 'resolver-1.0';

export function resolverMode(): ResolverMode {
  const m = (process.env.SEMANTIC_RESOLVER ?? 'off').toLowerCase();
  return m === 'shadow' || m === 'on' ? m : 'off';
}

export interface KpiBinding {
  kpi_id: string; kpi_name: string; unit: string | null; source_kind: 'live' | 'table' | 'derived' | null;
  source_name: string | null; value_column: string | null; aggregation: string | null;
  filter_predicate: Predicate[] | null; expression: string | null; dimensions: string | null;
  order_column: string | null; value_precision: number | null; legacy_key: string | null; binding_version: number;
}
export interface Predicate { field: string; op: 'eq' | 'neq' | 'eq_ci' | 'gt' | 'gte' | 'lt' | 'lte' | 'in' | 'truthy' | 'falsy'; value?: unknown }
export interface ResolvedKPI {
  kpi_id: string; value: number | null; grain: string; freshness: { source: string; computed_at: number; cadence_seconds: number };
  lineage: { source_kind: string; source_name: string | null; physical: string | null; value_column: string | null; aggregation: string | null;
             filter: Predicate[] | null; expression: string | null; depends_on: string[]; binding_version: number };
  record_count: number; mode: ResolverMode;
}
export interface ResolveFilters { plant?: string | null; line?: string | null; asset?: string | null }

// ---------------------------------------------------------------------------------------------
// Source adapters. Each returns the SAME rows the legacy builder reads. Registered by the API at
// startup (registerLiveSources) so this module stays free of simulation imports.
// ---------------------------------------------------------------------------------------------
type Rows = Record<string, unknown>[];
type Adapter = (f: ResolveFilters) => Promise<Rows>;
const adapters = new Map<string, Adapter>();
export function registerLiveSource(name: string, adapter: Adapter): void { adapters.set(name, adapter); }
export function registeredSources(): string[] { return [...adapters.keys()]; }

// ---------------------------------------------------------------------------------------------
// Bindings are read from the database and cached briefly; the DB is authoritative.
// ---------------------------------------------------------------------------------------------
let cache: { at: number; byId: Map<string, KpiBinding>; sources: Map<string, any> } | null = null;
const CACHE_MS = 60_000;
export async function loadBindings(force = false): Promise<Map<string, KpiBinding>> {
  if (!force && cache && Date.now() - cache.at < CACHE_MS) return cache.byId;
  const db = getDb();
  const rows = (await db.all(`SELECT kpi_id, kpi_name, unit, source_kind, source_name, value_column, aggregation, filter_predicate,
                                     expression, dimensions, order_column, value_precision, legacy_key, binding_version
                                FROM semantic_kpi_definition`)) as any[];
  const srcs = (await db.all('SELECT * FROM semantic_source')) as any[];
  const byId = new Map<string, KpiBinding>();
  for (const r of rows) byId.set(r.kpi_id, { ...r, filter_predicate: parseJson(r.filter_predicate), binding_version: Number(r.binding_version ?? 0) });
  cache = { at: Date.now(), byId, sources: new Map(srcs.map(s => [s.source_name, s])) };
  return byId;
}
function parseJson(v: unknown): Predicate[] | null {
  if (v == null) return null; if (Array.isArray(v)) return v as Predicate[];
  try { const p = JSON.parse(String(v)); return Array.isArray(p) ? p : null; } catch { return null; }
}

// ---------------------------------------------------------------------------------------------
// Pure calculation primitives. Exported for tests.
// ---------------------------------------------------------------------------------------------
const num = (v: unknown, d = 0): number => { const n = Number(v); return Number.isFinite(n) ? n : d; };

export function applyPredicates(rows: Rows, preds: Predicate[] | null): Rows {
  if (!preds?.length) return rows;
  return rows.filter(r => preds.every(p => {
    const v = r[p.field];
    switch (p.op) {
      case 'eq': return v === p.value;
      case 'neq': return v !== p.value;
      case 'eq_ci': return String(v ?? '').toLowerCase() === String(p.value ?? '').toLowerCase();
      case 'gt': return num(v) > num(p.value); case 'gte': return num(v) >= num(p.value);
      case 'lt': return num(v) < num(p.value); case 'lte': return num(v) <= num(p.value);
      case 'in': return Array.isArray(p.value) && p.value.includes(v);
      case 'truthy': return !!v; case 'falsy': return !v;
      default: return false;
    }
  }));
}

export function aggregate(rows: Rows, column: string, agg: string, orderColumn?: string | null): number | null {
  if (!rows.length) return agg === 'count' || agg === 'count_distinct' ? 0 : null;
  const vals = rows.map(r => r[column]);
  switch (agg) {
    case 'count': return rows.length;
    case 'count_distinct': return new Set(vals.map(v => String(v))).size;
    case 'sum': return vals.reduce<number>((s, v) => s + num(v), 0);
    case 'avg': return vals.reduce<number>((s, v) => s + num(v), 0) / rows.length;
    case 'min': return Math.min(...vals.map(v => num(v, Number.POSITIVE_INFINITY)));
    case 'max': return Math.max(...vals.map(v => num(v, Number.NEGATIVE_INFINITY)));
    case 'last': {   // latest non-null value in order: sparse daily measures (e.g. MTTR) are null on days with no events
      const sorted = orderColumn ? [...rows].sort((a, b) => String(a[orderColumn]).localeCompare(String(b[orderColumn]))) : rows;
      for (let k = sorted.length - 1; k >= 0; k--) { const v = sorted[k][column]; if (v != null && v !== '') return num(v); }
      return null;
    }
    default: throw new Error(`unknown aggregation ${agg}`);
  }
}

/** Safe arithmetic over kpi_ids: + - * / ( ) numbers and identifiers only. No eval. */
export function evaluateExpression(expr: string, values: Record<string, number | null>): number | null {
  const tokens = expr.match(/\s*([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|[-+*/()])\s*/g)?.map(t => t.trim()) ?? [];
  if (tokens.join('') !== expr.replace(/\s+/g, '')) throw new Error(`illegal characters in expression: ${expr}`);
  let i = 0; let nullSeen = false;
  const peek = () => tokens[i]; const next = () => tokens[i++];
  const factor = (): number => {
    const t = next();
    if (t === '(') { const v = expr_(); if (next() !== ')') throw new Error('unbalanced parentheses'); return v; }
    if (t === '-') return -factor();
    if (/^\d/.test(t)) return Number(t);
    if (!(t in values)) throw new Error(`unknown kpi ${t}`);
    const v = values[t]; if (v == null) { nullSeen = true; return 0; } return v;
  };
  const term = (): number => { let v = factor(); while (peek() === '*' || peek() === '/') { const op = next(); const r = factor(); v = op === '*' ? v * r : (r === 0 ? NaN : v / r); } return v; };
  const expr_ = (): number => { let v = term(); while (peek() === '+' || peek() === '-') { const op = next(); const r = term(); v = op === '+' ? v + r : v - r; } return v; };
  const out = expr_(); if (i !== tokens.length) throw new Error('trailing tokens');
  return nullSeen || !Number.isFinite(out) ? null : out;
}

export function roundTo(v: number | null, precision: number | null): number | null {
  if (v == null || precision == null) return v; const f = 10 ** precision; return Math.round(v * f) / f;
}

// ---------------------------------------------------------------------------------------------
// The resolver
// ---------------------------------------------------------------------------------------------
function applyPlant(rows: Rows, plant: string | null | undefined, plantColumn = 'plant_id'): Rows {
  const code = normalizePlant(plant ?? undefined);
  if (!code) return rows;
  return rows.filter(r => (r[plantColumn] ?? r.plant) === code);
}

async function fetchSource(b: KpiBinding, f: ResolveFilters): Promise<{ rows: Rows; physical: string | null; cadence: number }> {
  const src = cache?.sources.get(b.source_name ?? '');
  if (!src) throw new Error(`source ${b.source_name} not registered in semantic_source`);
  if (src.source_kind === 'live') {
    const ad = adapters.get(src.adapter); if (!ad) throw new Error(`no adapter registered for ${src.adapter}`);
    const rows = await ad(f);
    return { rows: applyPlant(rows, f.plant, src.plant_column), physical: src.adapter, cadence: Number(src.freshness_seconds ?? 15) };
  }
  // table source: constant SQL from the registry; relation and columns come from the model, never from the request
  if (!/^[a-z_][a-z0-9_]*\.[a-z_][a-z0-9_]*$/.test(String(src.relation))) throw new Error(`unsafe relation ${src.relation}`);
  const code = normalizePlant(f.plant ?? undefined);
  const plantName = code ? (await getDb().all(`SELECT plant_name FROM analytics_core.dim_plant WHERE plant_id = ?`, [code]))[0]?.plant_name : null;
  const where = plantName ? ` WHERE ${src.plant_column} = ?` : '';
  const rows = (await getDb().all(`SELECT * FROM ${src.relation}${where}`, plantName ? [plantName] : [])) as Rows;
  return { rows, physical: src.relation, cadence: Number(src.freshness_seconds ?? 3600) };
}

export async function resolveKPI(kpiId: string, f: ResolveFilters = {}, depth = 0): Promise<ResolvedKPI> {
  const mode = resolverMode();
  const bindings = await loadBindings();
  const b = bindings.get(kpiId);
  if (!b) throw new Error(`unknown kpi ${kpiId}`);
  if (!b.source_kind) throw new Error(`kpi ${kpiId} is not bound (legacy path serves it)`);
  if (depth > 5) throw new Error(`derived KPI nesting too deep at ${kpiId}`);
  const base = { kpi_id: kpiId, mode, lineage: { source_kind: b.source_kind, source_name: b.source_name, physical: null as string | null,
    value_column: b.value_column, aggregation: b.aggregation, filter: b.filter_predicate, expression: b.expression, depends_on: [] as string[], binding_version: b.binding_version } };

  if (b.source_kind === 'derived') {
    const ids = [...new Set((b.expression ?? '').match(/[A-Za-z_][A-Za-z0-9_]*/g) ?? [])].filter(id => bindings.has(id));
    const vals: Record<string, number | null> = {}; let minCount = Number.POSITIVE_INFINITY; let cadence = 15;
    for (const id of ids) { const r = await resolveKPI(id, f, depth + 1); vals[id] = r.value; minCount = Math.min(minCount, r.record_count); cadence = Math.max(cadence, r.freshness.cadence_seconds); }
    const value = roundTo(evaluateExpression(b.expression ?? '', vals), b.value_precision);
    return { ...base, value, grain: 'derived', record_count: Number.isFinite(minCount) ? minCount : 0,
             freshness: { source: 'derived', computed_at: Date.now(), cadence_seconds: cadence }, lineage: { ...base.lineage, depends_on: ids } };
  }
  const { rows, physical, cadence } = await fetchSource(b, f);
  const filtered = applyPredicates(rows, b.filter_predicate);
  const value = roundTo(aggregate(filtered, b.value_column ?? '', b.aggregation ?? 'count', b.order_column), b.value_precision);
  const src = cache?.sources.get(b.source_name ?? '');
  return { ...base, value, grain: String(src?.grain ?? 'row'), record_count: filtered.length,
           freshness: { source: b.source_name ?? '', computed_at: Date.now(), cadence_seconds: cadence }, lineage: { ...base.lineage, physical } };
}

// ---------------------------------------------------------------------------------------------
// Shadow / on integration used by the context builder. Never throws; never blocks the legacy path.
// ---------------------------------------------------------------------------------------------
const TOL = 1e-6;
export async function reconcileCalculated(
  agent: string, calculated: Record<string, unknown>, f: ResolveFilters,
): Promise<{ calculated: Record<string, unknown>; compared: number; mismatches: number }> {
  const mode = resolverMode();
  if (mode === 'off') return { calculated, compared: 0, mismatches: 0 };
  const bindings = await loadBindings();
  const plantId = normalizePlant(f.plant ?? undefined) ?? 'All Plants';
  const out = { ...calculated }; let compared = 0, mismatches = 0; const logs: any[] = [];
  for (const b of bindings.values()) {
    if (!b.legacy_key || !b.source_kind) continue;
    if (!(b.legacy_key in calculated) && !(agent && (b.legacy_key in calculated))) continue;
    if (!(b.legacy_key in calculated)) continue;
    const legacy = calculated[b.legacy_key];
    const legacyNum = typeof legacy === 'number' ? legacy : null;
    try {
      const r = await resolveKPI(b.kpi_id, f);
      const matched = legacyNum != null && r.value != null && Math.abs(legacyNum - r.value) <= TOL;
      compared++; if (!matched) mismatches++;
      logs.push([Date.now(), mode, b.kpi_id, plantId, r.value, legacyNum, b.legacy_key, matched, r.record_count, matched ? null : `legacy=${legacyNum} resolver=${r.value}`]);
      if (mode === 'on' && r.value != null) out[b.legacy_key] = r.value;   // fall back to legacy on null
    } catch (error) {
      compared++; mismatches++;
      logs.push([Date.now(), mode, b.kpi_id, plantId, null, legacyNum, b.legacy_key, false, 0, `error: ${String(error).slice(0, 200)}`]);
    }
  }
  if (logs.length) {
    try {
      const db = getDb();
      for (const l of logs) await db.run(`INSERT INTO semantic_resolution_log (ts, mode, kpi_id, plant_id, resolver_value, legacy_value, legacy_key, matched, record_count, note)
                                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, l);
    } catch (error) { logger.warn('[Semantic] resolution log write failed', { error: String(error) }); }
  }
  if (mismatches) logger.warn(`[Semantic] ${mode}: ${mismatches}/${compared} KPI mismatches for ${agent} (${plantId})`);
  return { calculated: out, compared, mismatches };
}
