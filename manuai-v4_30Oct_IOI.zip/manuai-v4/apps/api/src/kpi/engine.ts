/**
 * ManuAI — KPI Engine
 * Computes all governed KPIs from plant state → persists to semantic_kpi_value.
 * Agent APIs serve from this table, not from raw simulation state directly.
 * Phase 3: swap getPlantState() for real source system queries.
 */
import { getDb } from '../database/connection';
import { getPlantState } from '../simulation/engine';
import { logger } from '../middleware/logger';
import { loadCsvRaw } from '../data/csv-loader';
import { plantForAsset } from '../data/plant';

let lastKpiWrite = 0;
// India grid carbon factor (CEA standard) — overridable via env
const CARBON_GRID_FACTOR = parseFloat(process.env.CARBON_GRID_FACTOR ?? '0.82');

const KPI_WRITE_INTERVAL_MS = 5 * 60 * 1000;

export interface ComputedKPIs {
  plant_oee: number; plant_availability: number; plant_performance: number;
  plant_quality: number; avg_health: number; min_rul: number;
  yield_pct: number; energy_kwh_per_unit: number; carbon_intensity: number;
  defect_rate: number; near_miss_rate: number;
  supply_risk_score: number; twin_divergence: number; permit_compliance: number;
  computed_at: number;
  per_asset: Array<{ asset_id:string; oee:number; health:number; rul:number; vib:number; temp:number; status:string }>;
}

export function computeKPIs(plantCode?: string): ComputedKPIs {
  const state = getPlantState();
  // Filter machines, energy assets, safety zones by plant when a specific plant is requested.
  // Without this, the KPI summary returns plant-aggregate values regardless of the plant filter.
  const machines = plantCode
    ? state.machines.filter(m => (m as any).plant === plantCode || plantForAsset(m.id) === plantCode)
    : state.machines;
  const energyAssets = plantCode
    ? state.energyAssets.filter(a => (a as any).plant === plantCode || plantForAsset(a.id) === plantCode)
    : state.energyAssets;
  const safetyZones = plantCode
    ? state.safetyZones.filter((z: any) => !z.plant || z.plant === plantCode)
    : state.safetyZones;
  // Guard against empty plant — fall back to global state so KPIs show "--" instead of NaN
  if (!machines.length) {
    return computeKPIsInternal(state.machines, state.energyAssets, state.safetyZones, state.batch, state.tickCount);
  }
  return computeKPIsInternal(machines, energyAssets, safetyZones, state.batch, state.tickCount);
}

function computeKPIsInternal(
  machines: any[], energyAssets: any[], safetyZones: any[], batch: any, tickCount: number
): ComputedKPIs {
  const now = Date.now();
  // Formula constants from platform_config kpi_formula — was inline magic numbers
  // (14/30 day bands, 6/3/1 weights, *1000 near-miss normalisation, cap 10).
  // Falls back to prior defaults if section is missing.
  const cfgFormula: Record<string, number> = (() => {
    try { return (require('../data/csv-loader').loadPlatformConfig() as any)?.kpiFormula ?? {}; }
    catch { return {}; }
  })();
  const STOCK_CRITICAL = cfgFormula.supply_stock_critical_days        ?? 14;
  const STOCK_WARN     = cfgFormula.supply_stock_warn_days            ?? 30;
  const W_CRITICAL     = cfgFormula.supply_stock_critical_weight      ?? 6;
  const W_WARN         = cfgFormula.supply_stock_warn_weight          ?? 3;
  const W_OK           = cfgFormula.supply_stock_ok_weight            ?? 1;
  const FIN_SCALE_MAX  = cfgFormula.supply_fin_risk_scale_max          ?? 20;
  const FIN_WEIGHT_MAX = cfgFormula.supply_fin_risk_weight_max         ?? 4;
  const SCORE_CAP      = cfgFormula.supply_score_cap                  ?? 10;
  const NM_NORM        = cfgFormula.near_miss_per_n_ticks             ?? 1000;
  const plant_oee          = machines.reduce((s,m)=>s+m.oee,0)/machines.length;
  const plant_availability = machines.reduce((s,m)=>s+m.avail,0)/machines.length;
  const plant_performance  = machines.reduce((s,m)=>s+m.perf,0)/machines.length;
  const plant_quality      = machines.reduce((s,m)=>s+m.qual,0)/machines.length;
  const avg_health = machines.reduce((s,m)=>s+m.health,0)/machines.length;
  const min_rul    = Math.min(...machines.map(m=>m.rul));
  const yield_pct = batch.actual !== null ? (batch.actual/batch.plan)*100 : batch.plan;
  const total_kw = energyAssets.reduce((s,a)=>s+a.kw,0);
  const energy_kwh_per_unit = plant_oee>0 ? +(total_kw/(plant_oee/100*100)).toFixed(3) : 0;
  const carbon_intensity    = +(energy_kwh_per_unit*CARBON_GRID_FACTOR).toFixed(3);
  const defect_rate = +(100-plant_quality).toFixed(2);
  const spiking = safetyZones.filter(z=>(z as any)._spiking).length;
  const near_miss_rate = +(spiking/Math.max(tickCount,1)*NM_NORM).toFixed(3);
  // Issue 4: KPIs from Phase 1 CSV reference data
  const supplyRows = loadCsvRaw('supply_risks.csv');
  const supply_risk_score = supplyRows.length
    ? +(supplyRows.reduce((s: number, r: any) => {
        const stock = Number(r.current_stock_days ?? 30);
        const fin = Number(r.financial_risk_score ?? 0);
        // Stock-band weight ladder driven by config
        const stockRisk = stock < STOCK_CRITICAL ? W_CRITICAL : stock < STOCK_WARN ? W_WARN : W_OK;
        // Financial risk scaled to [0, FIN_WEIGHT_MAX]
        const finRisk = Math.min(fin / FIN_SCALE_MAX, 1) * FIN_WEIGHT_MAX;
        return s + Math.min(stockRisk + finRisk, SCORE_CAP);
      }, 0) / supplyRows.length).toFixed(2)
    : 0;
  const twinRows = loadCsvRaw('twin_kpis.csv');
  const twin_divergence = twinRows.length
    ? +(twinRows.reduce((s: number, k: any) => {
        const tp = Number(k.twin_predicted ?? 0);
        return s + (tp !== 0 ? Math.abs(Number(k.actual ?? 0) - tp) / Math.abs(tp) * 100 : 0);
      }, 0) / twinRows.length).toFixed(2)
    : 0;
  const ptwRows = loadCsvRaw('safety_permits.csv');
  const validPtw = ptwRows.filter((p: any) => p.status === 'approved' || p.status === 'active' || p.status === 'valid').length;
  const permit_compliance = ptwRows.length ? +(validPtw / ptwRows.length * 100).toFixed(1) : 100;
  return {
    plant_oee:+plant_oee.toFixed(2), plant_availability:+plant_availability.toFixed(2),
    plant_performance:+plant_performance.toFixed(2), plant_quality:+plant_quality.toFixed(2),
    avg_health:+avg_health.toFixed(2), min_rul:+min_rul.toFixed(1),
    yield_pct:+yield_pct.toFixed(2), energy_kwh_per_unit, carbon_intensity,
    defect_rate, near_miss_rate, supply_risk_score, twin_divergence, permit_compliance, computed_at:now,
    per_asset: machines.map(m=>({ asset_id:m.id, oee:+m.oee.toFixed(2), health:+m.health.toFixed(2),
      rul:+m.rul.toFixed(1), vib:+m.vib.toFixed(2), temp:+m.temp.toFixed(1), status:m.status })),
  };
}

export async function persistKPIs(kpis: ComputedKPIs, plantId: string | null = null): Promise<void> {
  const now = Date.now();
  if (now - lastKpiWrite < KPI_WRITE_INTERVAL_MS && plantId === null) return;
  try {
    const db = getDb();
    const insertSql = 'INSERT INTO semantic_kpi_value (kpi_id,asset_id,scope,ts,value,target,status,plant_id) VALUES (?,?,?,?,?,?,?,?)';
    const st = (v:number,t:number,w=0.95) => v<t*w?'critical':v<t?'warn':'ok';
    // Issue fix: OEE target from platform_config.csv benchmark.your_target (was hardcoded 85)
    let OEE_TGT = 85;
    try {
      const { loadPlatformConfig } = require('../data/csv-loader');
      OEE_TGT = Number(loadPlatformConfig()?.benchmarks?.your_target ?? 85);
    } catch { /* keep fallback */ }
    const p = plantId;  // null = portfolio aggregate, 'P1'/'P2' = per-plant
    // Quality Rate for the KPI dictionary must match the Quality Vision dashboard source
    // (quality_lines.csv avg quality_rate_pct), not the OEE engine's m.qual average.
    let qualityRateForDb = kpis.plant_quality;
    try {
      const { loadQualityLines } = require('../data/csv-loader');
      const qLines = loadQualityLines() as any[];
      let relevantLines = qLines;
      if (plantId) {
        const { linesFor } = require('../data/plant');
        const lineIds = linesFor(plantId as any) as string[];
        if (lineIds.length) {
          relevantLines = qLines.filter((l: any) => lineIds.some((ln: string) => String(l.line ?? '').includes(ln)));
        }
      }
      if (relevantLines.length) {
        qualityRateForDb = +(relevantLines.reduce((s: number, l: any) => s + Number(l.rate ?? 0), 0) / relevantLines.length).toFixed(2);
      }
    } catch { /* keep kpis.plant_quality as fallback */ }
    const defectRateForDb = +(100 - qualityRateForDb).toFixed(2);
    await db.transaction(async (tx)=>{
      await tx.run(insertSql, ['oee',null,'plant',now,kpis.plant_oee,OEE_TGT,st(kpis.plant_oee,OEE_TGT),p]);
      await tx.run(insertSql, ['availability',null,'plant',now,kpis.plant_availability,90,st(kpis.plant_availability,90),p]);
      await tx.run(insertSql, ['performance',null,'plant',now,kpis.plant_performance,90,st(kpis.plant_performance,90),p]);
      await tx.run(insertSql, ['quality',null,'plant',now,qualityRateForDb,98,st(qualityRateForDb,98),p]);
      await tx.run(insertSql, ['asset_health_pct',null,'plant',now,kpis.avg_health,70,st(kpis.avg_health,70),p]);
      await tx.run(insertSql, ['rul_days',null,'plant',now,kpis.min_rul,30,kpis.min_rul<10?'critical':kpis.min_rul<30?'warn':'ok',p]);
      await tx.run(insertSql, ['yield_pct',null,'plant',now,kpis.yield_pct,90,st(kpis.yield_pct,90),p]);
      await tx.run(insertSql, ['kwh_per_unit',null,'plant',now,kpis.energy_kwh_per_unit,0,'ok',p]);
      await tx.run(insertSql, ['carbon_intensity',null,'plant',now,kpis.carbon_intensity,0,'ok',p]);
      await tx.run(insertSql, ['defect_rate',null,'plant',now,defectRateForDb,2,defectRateForDb>5?'critical':defectRateForDb>2?'warn':'ok',p]);
      await tx.run(insertSql, ['near_miss_rate',null,'plant',now,kpis.near_miss_rate,5,kpis.near_miss_rate>10?'critical':kpis.near_miss_rate>5?'warn':'ok',p]);
      await tx.run(insertSql, ['supply_risk_score',null,'plant',now,kpis.supply_risk_score,5,kpis.supply_risk_score>7?'critical':kpis.supply_risk_score>5?'warn':'ok',p]);
      await tx.run(insertSql, ['twin_divergence',null,'plant',now,kpis.twin_divergence,3,kpis.twin_divergence>5?'critical':kpis.twin_divergence>3?'warn':'ok',p]);
      await tx.run(insertSql, ['permit_compliance',null,'plant',now,kpis.permit_compliance,95,kpis.permit_compliance<90?'critical':kpis.permit_compliance<95?'warn':'ok',p]);
      for(const a of kpis.per_asset){
        await tx.run(insertSql, ['oee',a.asset_id,'asset',now,a.oee,OEE_TGT,st(a.oee,OEE_TGT),p]);
        await tx.run(insertSql, ['asset_health_pct',a.asset_id,'asset',now,a.health,70,st(a.health,70),p]);
        await tx.run(insertSql, ['rul_days',a.asset_id,'asset',now,a.rul,30,a.rul<10?'critical':a.rul<30?'warn':'ok',p]);
      }
    });
    if (plantId === null) lastKpiWrite = now;
  } catch(err){ logger.warn('[KPI] Write error',{error:String(err)}); }
}

export async function getLatestKPIs(scope:'plant'|'asset'='plant', assetId?:string, plantId?:string|null) {
  const db = getDb();
  if(assetId){
    const plantSql = plantId ? ' AND (plant_id=? OR plant_id IS NULL)' : '';
    const args: any[] = [assetId, ...(plantId?[plantId]:[])];
    return await db.prepare(`SELECT kpi_id,value,target,status,ts,plant_id FROM semantic_kpi_value WHERE asset_id=?${plantSql} ORDER BY ts DESC LIMIT 10`).all(...args);
  }
  // Plant scope: prefer matching plant_id row; if none recorded for that plant yet,
  // gracefully fall back to portfolio aggregate (plant_id IS NULL) so dashboards never go blank.
  if (plantId) {
    const rows = await db.prepare(`SELECT kpi_id,value,target,status,ts,plant_id FROM semantic_kpi_value WHERE scope=? AND asset_id IS NULL AND plant_id=? ORDER BY ts DESC LIMIT 20`).all(scope, plantId);
    if (Array.isArray(rows) && rows.length) return rows;
  }
  return await db.prepare('SELECT kpi_id,value,target,status,ts,plant_id FROM semantic_kpi_value WHERE scope=? AND asset_id IS NULL AND plant_id IS NULL ORDER BY ts DESC LIMIT 20').all(scope);
}

export async function getKPITrend(kpiId:string, days=30, assetId?:string, plantId?:string|null) {
  const db = getDb();
  const since = Date.now()-days*86400000;
  const dayMs = 86400000;
  const plantSql = plantId ? ' AND plant_id=?' : ' AND plant_id IS NULL';
  const plantArg: any[] = plantId ? [plantId] : [];
  return await db.prepare(`
    SELECT (ts/${dayMs})*${dayMs} as day_ts, AVG(value) as avg_value, MIN(value) as min_value, MAX(value) as max_value
    FROM semantic_kpi_value
    WHERE kpi_id=? AND scope=? AND (asset_id=? OR (?  IS NULL AND asset_id IS NULL))${plantSql} AND ts>=?
    GROUP BY day_ts ORDER BY day_ts ASC
  `).all(kpiId, assetId?'asset':'plant', assetId??null, assetId??null, ...plantArg, since);
}
