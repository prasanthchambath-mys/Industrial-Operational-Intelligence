import axios from 'axios';
import { io, Socket } from 'socket.io-client';

// ── HTTP client ────────────────────────────────────────────────
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? '',
  timeout: 12_000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach Bearer token (set by auth hook after Azure AD login)
api.interceptors.request.use((config) => {
  const token = sessionStorage.getItem('manuai_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401) {
      sessionStorage.removeItem('manuai_token');
      // window.location.href = '/login'; // Uncomment in production
    }
    return Promise.reject(err instanceof Error ? err : new Error(String(err)));
  },
);

// ── Agent API methods ──────────────────────────────────────────
export const oeeApi = {
  getLive:   () => api.get('/api/oee/live').then(r => r.data),
  getLosses: () => api.get('/api/oee/losses').then(r => r.data),
  getAlerts: () => api.get('/api/oee/alerts').then(r => r.data),
  // POST /api/oee/alerts/:id/ack — record acknowledgement + publish semantic event.
  ackAlert: (id: string) =>
    api.post<{ success: boolean; id: string; ackedAt?: string; ackedBy?: string; error?: string }>(
      `/api/oee/alerts/${encodeURIComponent(id)}/ack`, {}
    ).then(r => r.data).catch(err => ({
      success: false, id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/oee/alerts/:id/wo — auto-create SAP PM notification from alert,
  // attach the WO id back to the alert. Backend runs semantic conflict check.
  createWoFromAlert: (id: string, description?: string, priority?: string) =>
    api.post<{ success: boolean; id: string; woId?: string; error?: string; blocked?: boolean; reason?: string }>(
      `/api/oee/alerts/${encodeURIComponent(id)}/wo`,
      { description, priority }
    ).then(r => r.data).catch(err => ({
      success: false, id,
      error: err?.response?.data?.error ?? err?.response?.data?.reason ?? 'Network error',
      blocked: err?.response?.data?.blocked,
      reason: err?.response?.data?.reason,
    })),
  // POST /api/oee/alerts/:id/escalate { to?, reason? } — record escalation,
  // publish warning-severity semantic event.
  escalateAlert: (id: string, to?: string, reason?: string) =>
    api.post<{ success: boolean; id: string; escalatedTo?: string; error?: string }>(
      `/api/oee/alerts/${encodeURIComponent(id)}/escalate`,
      { to, reason }
    ).then(r => r.data).catch(err => ({
      success: false, id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
};

export const yieldApi = {
  getParams: (plant = 'All Plants') => api.get(`/api/yield/params?plant=${encodeURIComponent(plant)}`).then(r => r.data),
  dcsWrite:  (tagId: string, value: number, reason: string) =>
    api.post('/api/yield/dcs-write', { tagId, value, reason }).then(r => r.data),
  // POST /api/yield/dismiss — records operator dismissal as a semantic event
  // so the rejection is auditable across refreshes.
  dismiss: (tagId: string, reason?: string) =>
    api.post<{ success: boolean; tagId: string; dismissedBy?: string; at?: string }>(
      '/api/yield/dismiss', { tagId, reason }
    ).then(r => r.data).catch(() => ({ success: false, tagId })),
  getLims:   () => api.get('/api/yield/lims').then(r => r.data),
  getOrders: () => api.get('/api/yield/orders').then(r => r.data),
};

export const pdmApi = {
  getAssets:    () => api.get('/api/pdm/assets').then(r => r.data),
  getSensors:   (id: string) => api.get(`/api/pdm/sensors/${id}`).then(r => r.data),
  getWorkOrders:() => api.get('/api/pdm/workorders').then(r => r.data),
  createWO:     (body: { equipment: string; description: string; priority?: string }) =>
    api.post('/api/pdm/workorders', body).then(r => r.data),
  partsOrder:   (body: { material: string; quantity: number; assetId: string; reason: string }) =>
    api.post('/api/pdm/parts-order', body).then(r => r.data),
  // PATCH /api/pdm/workorders/:id — transition WO status (open→in_progress→completed).
  // Backend validates the transition and publishes a semantic event.
  transitionWo: (id: string, status: 'in_progress' | 'completed', notes?: string) =>
    api.patch<{ success: boolean; id: string; status: string; error?: string }>(
      `/api/pdm/workorders/${encodeURIComponent(id)}`, { status, notes }
    ).then(r => r.data).catch(err => ({
      success: false, id, status,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/pdm/parts/:id/approve — raises a PO, publishes parts_ordered event
  approveParts: (id: string) =>
    api.post<{ success: boolean; id: string; poNumber?: string; status: string; error?: string }>(
      `/api/pdm/parts/${encodeURIComponent(id)}/approve`, {}
    ).then(r => r.data).catch(err => ({
      success: false, id, status: 'pending_approval',
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/pdm/parts/:id/reject { reason } — records operator dissent
  rejectParts: (id: string, reason?: string) =>
    api.post<{ success: boolean; id: string; status: string; error?: string }>(
      `/api/pdm/parts/${encodeURIComponent(id)}/reject`, { reason }
    ).then(r => r.data).catch(err => ({
      success: false, id, status: 'pending_approval',
      error: err?.response?.data?.error ?? 'Network error',
    })),
};

export const qualityApi = {
  getDefects: () => api.get('/api/quality/defects').then(r => r.data),
  getLines:   () => api.get('/api/quality/lines').then(r => r.data),
  // GET /api/quality/model/history — CSV seed + runtime retrain entries layered on top
  getHistory: () => api.get<{ history: any[] }>('/api/quality/model/history').then(r => r.data),
  // POST /api/quality/retrain — federated retraining trigger.
  // Returns the new training entry with realistic metrics (70% improvement,
  // 20% no-change, 10% regression). Backend records the override + publishes
  // model_retrained semantic event.
  retrain: () => api.post<{ success: boolean; entry?: any; outcome?: string; delta?: any; error?: string }>(
    '/api/quality/retrain', {}
  ).then(r => r.data).catch(err => ({
    success: false,
    error: err?.response?.data?.error ?? 'Network error',
  })),
};

export const energyApi = {
  getLoad:    () => api.get('/api/energy/load').then(r => r.data),
  dispatch:   (body: { assetId: string; action: string }) => api.post('/api/energy/dispatch', body).then(r => r.data),
  // POST /api/energy/dispatch/:id/execute — transition pending→dispatched.
  // Backend validates state machine, runs semantic conflict check, publishes
  // energy_dispatch event to Yield agent.
  executeDispatch: (id: string) =>
    api.post<{ success: boolean; id: string; status: string; error?: string; blocked?: boolean; reason?: string }>(
      `/api/energy/dispatch/${encodeURIComponent(id)}/execute`, {}
    ).then(r => r.data).catch(err => ({
      success: false, id, status: 'pending',
      error: err?.response?.data?.error ?? err?.response?.data?.reason ?? 'Network error',
      blocked: err?.response?.data?.blocked,
      reason: err?.response?.data?.reason,
    })),
  // POST /api/energy/dispatch/:id/schedule { deferHours? } — transition pending→scheduled.
  // Deferral hours default from platform_config.energy_config.dispatch_deferral_hours.
  scheduleDispatch: (id: string, deferHours?: number) =>
    api.post<{ success: boolean; id: string; status: string; scheduledFor?: string; deferHours?: number; error?: string }>(
      `/api/energy/dispatch/${encodeURIComponent(id)}/schedule`,
      deferHours !== undefined ? { deferHours } : {}
    ).then(r => r.data).catch(err => ({
      success: false, id, status: 'pending',
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // GET /api/energy/iso/compliance — drives ISO 50001 Energy Review + Report
  // Status cards from real semantic_kpi_value timestamps.
  getIsoCompliance: (plant: string) =>
    api.get<{ lastSnapshotTs: number | null; lastSnapshotAgeMinutes: number | null; governedKpiCount: number }>(
      `/api/energy/iso/compliance?plant=${encodeURIComponent(plant)}`
    ).then(r => r.data).catch(() => ({ lastSnapshotTs: null, lastSnapshotAgeMinutes: null, governedKpiCount: 0 })),
};

export const supplyApi = {
  getRisks:    () => api.get('/api/supply/risks').then(r => r.data),
  // V39: forecast and products endpoints accept a `product` filter. The
  // Demand Forecast tab dropdown is populated from `products()`, then each
  // selection re-fetches forecast with that product.
  getForecast: (plant?: string, product?: string) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    if (product) qs.set('product', product);
    return api.get(`/api/supply/forecast?${qs}`).then(r => r.data);
  },
  products: (plant?: string) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    return api.get<{ products: string[]; plant_id: string }>(`/api/supply/products?${qs}`)
      .then(r => r.data).catch(() => ({ products: [], plant_id: plant ?? 'All Plants' }));
  },
  // GET /api/supply/inventory?plant&windowDays — V34: dedicated endpoint for the
  // Inventory tab. Returns three top-line counts (Total SKUs, Safety Stock
  // Alerts, Auto-Reorders Raised) plus the detail rows behind each.
  getInventory: (plant?: string, windowDays = 7) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    qs.set('windowDays', String(windowDays));
    return api.get<{
      summary: { totalSkus: number; safetyStockAlerts: number; autoReordersRaised: number; windowDays: number; plant_id: string };
      safetyStockList: Array<any>;
      autoReordersList: Array<any>;
      source_system: string;
    }>(`/api/supply/inventory?${qs}`).then(r => r.data).catch(() => ({
      summary: { totalSkus: 0, safetyStockAlerts: 0, autoReordersRaised: 0, windowDays, plant_id: plant ?? 'All Plants' },
      safetyStockList: [],
      autoReordersList: [],
      source_system: 'unavailable',
    }));
  },
  reorder:     (body: { material: string; quantity: number }) => api.post('/api/supply/reorder', body).then(r => r.data),
  // POST /api/supply/risks/:riskId/reorder — per-row reorder. Backend records
  // the override + calls SAP MM + publishes reorder_created semantic event.
  reorderRisk: (riskId: string, quantity?: number, reason?: string) =>
    api.post<{ success: boolean; riskId: string; prNumber?: string; quantity?: number; error?: string }>(
      `/api/supply/risks/${encodeURIComponent(riskId)}/reorder`,
      { quantity, reason }
    ).then(r => r.data).catch(err => ({
      success: false, riskId,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // ── Increment 2/3: supply-chain governance (plant-aware, data-driven) ──
  dashboardMetrics: (plant?: string) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    return api.get<any>(`/api/supply/dashboard-metrics?${qs}`).then(r => r.data).catch(() => null);
  },
  externalAlerts: (plant?: string) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    return api.get<{ alerts: any[]; plant_id: string }>(`/api/supply/external-alerts?${qs}`)
      .then(r => r.data).catch(() => ({ alerts: [], plant_id: plant ?? 'All Plants' }));
  },
  manualApprovals: (plant?: string, all = false) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    if (all) qs.set('all', '1');
    return api.get<{ requests: any[]; plant_id: string }>(`/api/supply/governance/manual?${qs}`)
      .then(r => r.data).catch(() => ({ requests: [], plant_id: plant ?? 'All Plants' }));
  },
  autoApproved: (plant?: string) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    return api.get<{ orders: any[]; plant_id: string }>(`/api/supply/governance/auto?${qs}`)
      .then(r => r.data).catch(() => ({ orders: [], plant_id: plant ?? 'All Plants' }));
  },
  reorderRules: (plant?: string) => {
    const qs = new URLSearchParams();
    if (plant && plant !== 'All Plants') qs.set('plant', plant);
    return api.get<{ rules: any[]; activeCount: number; plant_id: string }>(`/api/supply/governance/rules?${qs}`)
      .then(r => r.data).catch(() => ({ rules: [], activeCount: 0, plant_id: plant ?? 'All Plants' }));
  },
  createReorder: (riskId: string, plant?: string) =>
    api.post<any>('/api/supply/governance/create-reorder', { riskId, plant }).then(r => r.data)
      .catch((err: any) => ({ ok: false, error: err?.response?.data?.error ?? 'Network error' })),
  approveRequest: (requestId: string) =>
    api.post<any>('/api/supply/governance/approve', { requestId }).then(r => r.data)
      .catch((err: any) => ({ ok: false, error: err?.response?.data?.error ?? 'Network error' })),
  declineRequest: (requestId: string) =>
    api.post<any>('/api/supply/governance/decline', { requestId }).then(r => r.data)
      .catch((err: any) => ({ ok: false, error: err?.response?.data?.error ?? 'Network error' })),
  toggleRule: (ruleId: string, enabled?: boolean) =>
    api.post<any>('/api/supply/governance/toggle-rule', { ruleId, enabled }).then(r => r.data)
      .catch((err: any) => ({ ok: false, error: err?.response?.data?.error ?? 'Network error' })),
  createRule: (payload: { rule_name: string; category?: string; description?: string; conditions?: string; approval_mode: string; plant_scope?: string }) =>
    api.post<any>('/api/supply/governance/create-rule', payload).then(r => r.data)
      .catch((err: any) => ({ ok: false, error: err?.response?.data?.error ?? 'Network error' })),
  // GET /api/supply/risk-detail — supplier risk intelligence for the Risk
  // Monitor popup. Pass the card's identifiers; backend returns the full bundle.
  riskDetail: (args: { supplierId?: string; skuCode?: string; skuId?: string; plantId?: string; riskEventId?: string }) => {
    const qs = new URLSearchParams();
    Object.entries(args).forEach(([k, v]) => { if (v) qs.set(k, String(v)); });
    return api.get<any>(`/api/supply/risk-detail?${qs}`).then(r => r.data)
      .catch((err: any) => ({ error: err?.response?.data?.error ?? 'Network error' }));
  },
};

export const twinApi = {
  getStatus:    () => api.get('/api/twin/status').then(r => r.data),
  getDivergence:() => api.get('/api/twin/divergence').then(r => r.data),
  getScenarios: () => api.get('/api/twin/scenarios').then(r => r.data),
  // GET per-asset failure scenarios with live-prefilled params (plant-scoped).
  getAssetScenarios: (plant: string) =>
    api.get<{ plant?: string; source?: string; requiresPlant?: boolean; note?: string; scenarios: any[] }>(
      `/api/twin/asset-scenarios?plant=${encodeURIComponent(plant)}`
    ).then(r => r.data).catch(() => ({ scenarios: [], requiresPlant: true })),
  // POST stateless what-if simulate — returns computed impact/detail immediately.
  simulate: (scenarioType: string, params: Record<string, number|string>) =>
    api.post<{ success: boolean; impact?: string; impact_value?: number; confidence?: number; detail?: any; recommendations?: string[]; engine?: string }>(
      `/api/twin/simulate`, { scenario_type: scenarioType, params }
    ).then(r => r.data).catch(err => ({ success: false, error: err?.response?.data?.error ?? 'Network error' } as any)),
  // POST /api/twin/scenarios/:id/run — forwards what-if params to the twin-sync
  // service which COMPUTES the outcome. Returns 409 if already running.
  runScenario:  (id: string, params?: Record<string, number|string>, scenarioType?: string) =>
    api.post<{ success: boolean; scenarioId?: string; status?: string; startedAt?: string; durationSec?: number; source_mode?: string; computed?: boolean; impact?: string; confidence?: number; detail?: any; recommendations?: string[]; engine?: string; paramsUsed?: any; error?: string }>(
      `/api/twin/scenarios/${encodeURIComponent(id)}/run`, { params: params ?? {}, scenario_type: scenarioType }
    ).then(r => r.data).catch(err => ({
      success: false, scenarioId: id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/twin/scenarios/:id/cancel — abort a running scenario.
  cancelScenario: (id: string) =>
    api.post<{ success: boolean; scenarioId?: string; status?: string; cancelledAt?: string; error?: string }>(
      `/api/twin/scenarios/${encodeURIComponent(id)}/cancel`, {}
    ).then(r => r.data).catch(err => ({
      success: false, scenarioId: id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/twin/calibrate — manual recalibration trigger. Phase 1 publishes
  // semantic event; Phase A forwards to twin-sync /recalibrate.
  calibrate: (plant?: string) =>
    api.post<{ success: boolean; triggeredAt?: string; triggeredBy?: string; source_mode?: string; error?: string }>(
      '/api/twin/calibrate' + (plant && plant !== 'All Plants' ? `?plant=${encodeURIComponent(plant)}` : ''), {}
    ).then(r => r.data).catch(err => ({
      success: false,
      error: err?.response?.data?.error ?? 'Network error',
    })),
};

export const safetyApi = {
  getEvents:  () => api.get('/api/safety/events').then(r => r.data),
  getPTW:     () => api.get('/api/safety/ptw').then(r => r.data),
  // POST /api/safety/ptw/:id/approve — real approval. Backend validates JHA/
  // isolation/competency, records override, publishes ptw_approved event.
  // Returns 409 if validation fields fail or permit is not pending.
  approvePTW: (id: string, reason?: string) =>
    api.post<{ success: boolean; ptwId?: string; status?: string; decidedBy?: string; at?: string; error?: string }>(
      `/api/safety/ptw/${encodeURIComponent(id)}/approve`,
      { reason }
    ).then(r => r.data).catch(err => ({
      success: false, ptwId: id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/safety/ptw/:id/reject — requires a reason.
  rejectPTW: (id: string, reason: string) =>
    api.post<{ success: boolean; ptwId?: string; status?: string; error?: string }>(
      `/api/safety/ptw/${encodeURIComponent(id)}/reject`,
      { reason }
    ).then(r => r.data).catch(err => ({
      success: false, ptwId: id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/safety/events/:id/ack — operator picks up an open event.
  ackEvent: (id: string) =>
    api.post<{ success: boolean; eventId?: string; status?: string; ackedBy?: string; at?: string; error?: string }>(
      `/api/safety/events/${encodeURIComponent(id)}/ack`,
      {}
    ).then(r => r.data).catch(err => ({
      success: false, eventId: id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // POST /api/safety/events/:id/resolve — confirms precursor cleared.
  resolveEvent: (id: string, notes?: string) =>
    api.post<{ success: boolean; eventId?: string; status?: string; resolvedBy?: string; at?: string; error?: string }>(
      `/api/safety/events/${encodeURIComponent(id)}/resolve`,
      { notes }
    ).then(r => r.data).catch(err => ({
      success: false, eventId: id,
      error: err?.response?.data?.error ?? 'Network error',
    })),
  // GET /api/safety/compliance/status — counts + first/last event timestamps.
  complianceStatus: (plant?: string, days = 30) =>
    api.get<{ days: number; total: number; open: number; last_ts: string|null; first_ts: string|null; plant_id: string }>(
      `/api/safety/compliance/status?days=${days}` + (plant && plant !== 'All Plants' ? `&plant=${encodeURIComponent(plant)}` : '')
    ).then(r => r.data),
  // GET /api/safety/compliance/report — downloads CSV. Returns the URL to open.
  complianceReportUrl: (plant?: string, days = 30, framework = 'osha_300') =>
    `/api/safety/compliance/report?framework=${framework}&days=${days}` + (plant && plant !== 'All Plants' ? `&plant=${encodeURIComponent(plant)}` : ''),
  // GET /api/safety/zone-risk — live per-zone risk map from the safety-monitor
  // Python service (LSTM/rule precursor scoring). Falls back to zones with
  // 'unknown' risk when the service is unreachable so the UI can show a grey
  // "no signal" badge rather than a false "low".
  zoneRisk: (plant?: string) =>
    api.get<{ zone_risk: Record<string, string>; model_source?: string; source_mode: string; plant_id: string }>(
      '/api/safety/zone-risk' + (plant && plant !== 'All Plants' ? `?plant=${encodeURIComponent(plant)}` : '')
    ).then(r => r.data).catch(() => ({ zone_risk: {}, source_mode: 'CSV', plant_id: plant ?? 'All Plants' })),
  // GET /api/safety/ptw/assessments — per-permit service verdict (blocked +
  // reason + missing-validation flags). Returns [] when service is down.
  ptwAssessments: () =>
    api.get<{ assessments: any[]; source_mode: string; error?: string }>('/api/safety/ptw/assessments')
       .then(r => r.data).catch(() => ({ assessments: [], source_mode: 'CSV' })),
};

export const semanticApi = {
  getKPIs:   () => api.get('/api/semantic/kpis').then(r => r.data),
  getEvents: (plant?: string) => api.get('/api/semantic/events' + (plant && plant !== 'All Plants' ? `?plant=${encodeURIComponent(plant)}` : '')).then(r => r.data),
};

export const aiApi = {
  chat: (
    messages: Array<{ role: 'user' | 'assistant'; content: string }>,
    liveContext?: string,
    filters?: { plant?: string; line?: string; asset?: string; period?: string },
  ) =>
    api.post<{ reply: string }>('/api/ai/chat', { messages, liveContext, filters }, { timeout: 30_000 }).then(r => r.data),
  recommend: (agent: string, context: string, question: string) =>
    api.post<{ reply: string }>(`/api/ai/recommend/${agent}`, { context, question }, { timeout: 30_000 }).then(r => r.data),
};

export const dcsApi = {
  write: (tagId: string, value: number, reason: string) =>
    api.post<{ success: boolean; tagId: string; value: number; unit: string; error?: string; reason?: string }>(
      '/api/yield/dcs-write', { tagId, value, reason }
    ).then(r => r.data).catch(err => ({
      success: false,
      tagId, value, unit: '',
      error: err?.response?.data?.error ?? 'Network error',
      reason: err?.response?.data?.reason,
    })),
};

// ── WebSocket ──────────────────────────────────────────────────
let socket: Socket | null = null;

export function getSocket(): Socket {
  if (!socket) {
    socket = io(import.meta.env.VITE_WS_URL ?? '', {
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
    });
  }
  return socket;
}

export function subscribeChannels(channels: string[]): void {
  getSocket().emit('subscribe', channels);
}

export default api;
