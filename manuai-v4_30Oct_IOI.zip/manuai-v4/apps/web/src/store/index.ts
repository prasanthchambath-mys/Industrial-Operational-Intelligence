import { create } from 'zustand';
import { getSocket, subscribeChannels, oeeApi, yieldApi, semanticApi } from '../api';
import { codeFor } from '../topology';

export type Page = 'overview' | 'semantic' | 'oee' | 'yield' | 'pdm' | 'quality' | 'energy' | 'supply' | 'twin' | 'safety';

interface Store {
  page: Page;
  rightPanel: 'insights' | 'chat';
  plant: string;
  setPage: (p: Page) => void;
  setRightPanel: (p: 'insights' | 'chat') => void;
  setPlant: (p: string) => void;

  machines: unknown[];
  machinesAll: unknown[];
  utilities: unknown[];
  utilitiesAll: unknown[];
  plantOEE: number;
  fetchMachines: () => Promise<void>;

  yieldParams: unknown[];
  fetchYieldParams: () => Promise<void>;

  crossEvents: unknown[];
  addEvent: (e: unknown) => void;
  // Initial REST fetch of persisted events on mount — without this the
  // Insights panel starts empty and waits for the next WebSocket heartbeat.
  fetchCrossEvents: () => Promise<void>;

  wsConnected: boolean;
  initWebSocket: () => void;
}

const filterByPlant = (arr: any[], plant: string) => {
  const code = codeFor(plant);
  if (!code) return arr;
  return arr.filter((m: any) => m.plant === code);
};

export const useStore = create<Store>((set, get) => ({
  page: 'overview',
  rightPanel: 'insights',
  plant: 'All Plants',
  setPage: (page) => set({ page }),
  setRightPanel: (rightPanel) => set({ rightPanel }),
  // Issue fix: plant selector now actually filters machine data and clears stale cross-events
  setPlant: (plant) => set(s => ({
    plant,
    machines: filterByPlant(s.machinesAll as any[], plant),
    utilities: filterByPlant(s.utilitiesAll as any[], plant),
    // Clear cross-events so fetchCrossEvents re-fetches with new plant filter
    crossEvents: [],
  })),

  machines: [],
  machinesAll: [],
  utilities: [],
  utilitiesAll: [],
  plantOEE: 0,
  fetchMachines: async () => {
    try {
      const data = await oeeApi.getLive();
      set(s => ({
        machinesAll: data.machines, machines: filterByPlant(data.machines, s.plant),
        utilitiesAll: data.utilities ?? [], utilities: filterByPlant(data.utilities ?? [], s.plant),
        plantOEE: data.plantOEE,
      }));
    } catch {}
  },

  yieldParams: [],
  fetchYieldParams: async () => {
    try {
      const plant = get().plant;
      const data = await yieldApi.getParams(plant);
      set({ yieldParams: data.params });
    } catch {}
  },

  crossEvents: [],
  addEvent: (e) => set(s => ({ crossEvents: [e, ...s.crossEvents].slice(0, 100) })),
  fetchCrossEvents: async () => {
    try {
      const plant = get().plant;
      const data = await semanticApi.getEvents(plant);
      const events = (data?.events ?? []) as any[];
      set(s => {
        // Merge with anything WS has already delivered, dedup by id
        const existingIds = new Set((s.crossEvents as any[]).map(e => e?.id).filter(Boolean));
        const fresh = events.filter(e => e?.id && !existingIds.has(e.id));
        return { crossEvents: [...s.crossEvents, ...fresh].slice(0, 100) };
      });
      // If DB returned nothing (fresh container — sim engine fires first events ~30s
      // after startup), retry in 5s so the panel populates without waiting the
      // full 15s context poll interval.
      if (events.length === 0 && get().crossEvents.length === 0) {
        setTimeout(() => { void get().fetchCrossEvents(); }, 5000);
      }
    } catch {
      // non-fatal — WebSocket will populate as events arrive
    }
  },

  wsConnected: false,
  initWebSocket: () => {
    const socket = getSocket();
    subscribeChannels(['oee','yield','pdm','quality','energy','supply','twin','safety','semantic','alerts']);
    socket.on('connect', () => set({ wsConnected: true }));
    socket.on('disconnect', () => set({ wsConnected: false }));
    socket.on('cross_agent_event', (e: unknown) => set(s => {
      const ev = e as any;
      // Deduplicate by event id — prevents duplicate renders on reconnect / double-tick
      if (ev?.id && s.crossEvents.some((x:any) => x.id === ev.id)) return s;
      return { crossEvents: [e, ...s.crossEvents].slice(0, 100) };
    }));
    // Backend emits 'update' with { channel, data } wrapper
    socket.on('update', (payload: any) => {
      const { channel, data } = payload ?? {};
      if (channel === 'oee' && data?.machines) {
        set(s => ({
          machinesAll: data.machines, machines: filterByPlant(data.machines, s.plant),
          utilitiesAll: data.utilities ?? s.utilitiesAll,
          utilities: filterByPlant((data.utilities ?? s.utilitiesAll) as any[], s.plant),
          plantOEE: data.plantOEE ?? 0,
        }));
      }
      if (channel === 'yield' && data?.params) {
        // Filter yield params by current plant so the Yield KPI card counts only
        // the correct plant's warning params (not all-plant aggregate)
        set(s => {
          const code = codeFor(s.plant);
          const filtered = code
            ? (data.params as any[]).filter((p: any) => !p.plant || p.plant === code || p.plant === 'Both')
            : data.params;
          return { yieldParams: filtered };
        });
      }
    });
  },
}));
