import React,{createContext,useContext,useState,useEffect,useMemo,useCallback} from 'react';
import{useStore}from'./store';
import{loadTopology, codeFor}from'./topology';
import{
  fetchMachines,fetchUtilities,fetchPlatformConfig,fetchTechStack,fetchSemanticKpiDefs,
  fetchPersonas,fetchBaselines,fetchPdmRules,fetchEnergyWaste,fetchCarbonTrend,
  fetchSupplyRisks,fetchDemandForecast,fetchQualityDefects,fetchSafetyEvents,
  fetchSafetyPermits,fetchTwinScenarios,fetchDivergenceLog,fetchQualityLines,
  fetchEnergyAssets,fetchEnergyTrend,fetchWorkOrders,fetchShifts,fetchOeeTrend,
  fetchSixLosses,fetchLossTrend,fetchMachineLossesToday,fetchOeeScorecard,fetchRulTrend,fetchLims,
  fetchDcsSetpoints,fetchProductionOrders
}from'./csvApi';

export interface AppState {
  // Agent data arrays
  energyWaste:any[]; carbonTrend:any[]; supplyRisksData:any[];
  demandForecast:any[]; defectTrend:any[]; defectLog:any[];
  safetyEvents:any[]; ptwList:any[]; twinScenarios:any[];
  divergenceLog:any[]; qualityLines:any[]; energyAssets:any[];
  energyTrend:any[]; pdmRules:any[];
  // OEE/PdM/Yield data
  mch:any[]; util:any[]; wos:any[]; shifts:any[];
  oeeTrend:any[]; sixLosses:any[]; lossTrend:any[]; machineLossesToday:any[];
  oeeScorecard:any[]; rulTrend:any[];
  lims:any[]; dcs:any[]; sapOrders:any[];
  // Config
  appCfg:any; baselines:any; personasCfg:any; techStacks:any; semanticDefs:any[];
  // Live computed from store
  agsMachines:any[]; agsOee:number; critical:number; agsYield:any[];
  agsUtilities:any[]; criticalMachines:number; criticalUtilities:number;
  crossEvents:any[];
  // shared config ref
  _sharedCfg:{cfg:any,appCfg:any,baselines:any,techStacks:any};
}

const SC:{cfg:any,appCfg:any,baselines:any,techStacks:any}=
  {cfg:{},appCfg:{},baselines:{},techStacks:{}};

const defaultState:AppState={
  energyWaste:[],carbonTrend:[],supplyRisksData:[],demandForecast:[],
  defectTrend:[],defectLog:[],safetyEvents:[],ptwList:[],
  twinScenarios:[],divergenceLog:[],qualityLines:[],energyAssets:[],
  energyTrend:[],pdmRules:[],
  mch:[],util:[],wos:[],shifts:[],
  oeeTrend:[],sixLosses:[],lossTrend:[],machineLossesToday:[],oeeScorecard:[],rulTrend:[],
  lims:[],dcs:[],sapOrders:[],
  appCfg:{},baselines:{},personasCfg:{},techStacks:{},semanticDefs:[],
  agsMachines:[],agsOee:0,critical:0,agsYield:[],crossEvents:[],
  agsUtilities:[],criticalMachines:0,criticalUtilities:0,
  _sharedCfg:SC,
};

export const AppCtx=createContext<AppState>(defaultState);
export function useApp(){return useContext(AppCtx);}

export function AppProvider({children}:{children:React.ReactNode}){
  const{machines:agsMachines,utilities:agsUtilities,yieldParams:agsYield,crossEvents}=useStore();
  const agsOee=agsMachines.length
    ?+((agsMachines as any[]).reduce((s:number,m:any)=>s+Number(m.oee??0),0)/(agsMachines as any[]).length).toFixed(1)
    :0;
  // Fleet-critical = production machines (health<40) UNION utilities (health<35).
  // Each class keeps its own status band; we just count both 'critical' sets.
  // agsMachines/agsUtilities are already plant-filtered by the store.
  const criticalMachines=(agsMachines as any[]).filter((m:any)=>m.status==='critical').length;
  const criticalUtilities=(agsUtilities as any[]).filter((u:any)=>u.status==='critical').length;
  const critical=criticalMachines+criticalUtilities;

  const[energyWaste,setEnergyWaste]=useState<any[]>([]);
  const[carbonTrend,setCarbonTrend]=useState<any[]>([]);
  const[supplyRisksData,setSupplyRisksData]=useState<any[]>([]);
  const[demandForecast,setDemandForecast]=useState<any[]>([]);
  const[defectTrend,setDefectTrend]=useState<any[]>([]);
  const[defectLog,setDefectLog]=useState<any[]>([]);
  const[safetyEvents,setSafetyEvents]=useState<any[]>([]);
  const[ptwList,setPtwList]=useState<any[]>([]);
  const[twinScenarios,setTwinScenarios]=useState<any[]>([]);
  const[divergenceLog,setDivergenceLog]=useState<any[]>([]);
  const[qualityLines,setQualityLines]=useState<any[]>([]);
  const[energyAssets,setEnergyAssets]=useState<any[]>([]);
  const[energyTrend,setEnergyTrend]=useState<any[]>([]);
  const[appCfg,setAppCfg]=useState<any>({});
  const[techStacks,setTechStacks]=useState<any>({});
  const[semanticDefs,setSemanticDefs]=useState<any[]>([]);
  const[personasCfg,setPersonasCfg]=useState<any>({});
  const[baselines,setBaselines]=useState<any>({});
  const[pdmRules,setPdmRules]=useState<any[]>([]);
  // OEE/PdM/Yield local data
  const[mch,setMch]=useState<any[]>([]);
  const[util,setUtil]=useState<any[]>([]);
  const[wos,setWos]=useState<any[]>([]);
  const[shifts,setShifts]=useState<any[]>([]);
  const[oeeTrend,setOeeTrend]=useState<any[]>([]);
  const[sixLosses,setSixLosses]=useState<any[]>([]);
  const[machineLossesToday,setMachineLossesToday]=useState<any[]>([]);
  const[lossTrend,setLossTrend]=useState<any[]>([]);
  const[oeeScorecard,setOeeScorecard]=useState<any[]>([]);
  const[rulTrend,setRulTrend]=useState<any[]>([]);
  const[lims,setLims]=useState<any[]>([]);
  const[dcs,setDcs]=useState<any[]>([]);
  const[sapOrders,setSapOrders]=useState<any[]>([]);

  // Issue fix: plant selector — must be declared before useEffect that depends on it
  const plantSel=useStore(s=>s.plant);

  // Keep SC in sync
  SC.appCfg=appCfg; SC.cfg=appCfg; SC.baselines=baselines; SC.techStacks=techStacks;

  useEffect(()=>{
    const delay=(ms:number,fn:()=>void)=>setTimeout(fn,ms);
    const cleanupFns: Array<()=>void> = [];
    // Perf: skip interval work while the tab is hidden — a backgrounded tab was
    // still firing ~20 fetches/15s. Wrap each polled callback so it no-ops when
    // document.hidden; a visibilitychange listener refreshes promptly on return.
    const isHidden=()=>typeof document!=='undefined'&&document.hidden;
    const whenVisible=(fn:()=>void)=>()=>{ if(!isHidden()) fn(); };
    const onVisible=()=>{ if(!isHidden()){ loadCE(); loadQuality(); livePoll(); } };
    if(typeof document!=='undefined'){
      document.addEventListener('visibilitychange',onVisible);
      cleanupFns.push(()=>document.removeEventListener('visibilitychange',onVisible));
    }
    // Batch 0 — load plant topology FIRST. Every filter helper in the UI
    // (plant selector, evMatchesPlant, filterByMachine, filterByLine) reads
    // from this. Without it, helpers return empty/null. Fire-and-forget; the
    // topology cache lives in module state, so all subsequent calls see it.
    void loadTopology();
    // Immediately refetch yield params for the new plant (agsYield used in top KPI card)
    void useStore.getState().fetchYieldParams();
    // Batch 1 — critical config first (t=0), then tiles data staggered by 50ms
    // so the API isn't hit with 7 parallel calls simultaneously on mount.
    fetchPlatformConfig().then(d=>{setAppCfg(d);SC.appCfg=d;SC.cfg=d;}).catch(()=>{});
    fetchBaselines(plantSel).then(d=>{setBaselines(d??{});SC.baselines=d??{};}).catch(()=>{});
    fetchMachines(plantSel).then(d=>{setMch(d??[]);}).catch(()=>{});
    delay(50,()=>{
      fetchQualityLines(plantSel).then(d=>{setQualityLines(d??[]);}).catch(()=>{});
      fetchProductionOrders(plantSel).then(d=>{setSapOrders(d??[]);}).catch(()=>{});
    });
    // Initial fetch of persisted cross-agent events from SQLite. Without this,
    // the Insights panel starts empty on every page load and waits for the next
    // WebSocket heartbeat (up to 30s) — particularly visible when switching to
    // Plant 2 because P2 events arrive less frequently than P1's seed-critical
    // cascade. Polling every 15s also recovers from WebSocket drops.
    const loadCE=()=>{ void useStore.getState().fetchCrossEvents(); };
    // Immediately fetch cross-events for the current plant (clears stale events from prior plant).
    // Retry at 1s and 3s to close the race window where the container just started
    // and the simulation engine's 200ms startup heartbeat hasn't written to DB yet.
    loadCE();
    const ce1=setTimeout(loadCE, 1000);
    const ce3=setTimeout(loadCE, 3000);
    const ceIv=setInterval(whenVisible(loadCE), 15000);
    cleanupFns.push(()=>{ clearTimeout(ce1); clearTimeout(ce3); clearInterval(ceIv); });
    // Quality defects loaded immediately — critical for dashboard.
    // Also polled every 30s so the Quality dashboard shows fresh defects
    // (was previously polled by QualityDash; consolidated here to remove duplicate fetches).
    const loadQuality=()=>fetch(`/api/quality/defects?plant=${encodeURIComponent(plantSel)}`).then(r=>r.json()).then((res:any)=>{
      setDefectLog(res.log??[]);
      setDefectTrend(res.trend??[]);
    }).catch(()=>{});
    loadQuality();
    const qualityIv=setInterval(whenVisible(loadQuality),15000);
    cleanupFns.push(()=>clearInterval(qualityIv));
    // ── Unified 5s polling for all live-changing context state ──────────────
    // Audit fix: previously these values were loaded once on mount and only
    // refreshed when the user switched plants. The simulation engine updates
    // machine health/RUL/yield/energy/safety every 10s, but the dashboards
    // showed stale data until plant change or page reload. This single
    // setInterval ensures every dashboard refreshes at the same 15s cadence
    // as the agent-specific dashboard polls and the mini KPI tiles.
    const livePoll = () => {
      fetchMachines(plantSel).then(d=>{setMch(d??[]);}).catch(()=>{});
      fetchQualityLines(plantSel).then(d=>{setQualityLines(d??[]);}).catch(()=>{});
      fetchProductionOrders(plantSel).then(d=>{setSapOrders(d??[]);}).catch(()=>{});
      fetchWorkOrders(plantSel).then(d=>{setWos(d??[]);}).catch(()=>{});
      fetchSupplyRisks(plantSel).then(d=>{setSupplyRisksData(d??[]);}).catch(()=>{});
      fetchEnergyWaste(plantSel).then(d=>{setEnergyWaste(d??[]);}).catch(()=>{});
      fetchSafetyEvents(7,plantSel).then(d=>{setSafetyEvents(d??[]);}).catch(()=>{});
      fetchSafetyPermits(plantSel).then(d=>{setPtwList(d??[]);}).catch(()=>{});
      fetchTwinScenarios(plantSel).then(d=>{setTwinScenarios(d??[]);}).catch(()=>{});
      fetchDivergenceLog(plantSel).then(d=>{setDivergenceLog(d??[]);}).catch(()=>{});
      fetchUtilities(plantSel).then(d=>{setUtil(d??[]);}).catch(()=>{});
      fetchDcsSetpoints(plantSel).then(d=>{setDcs(d??[]);}).catch(()=>{});
      fetchLims(plantSel).then(d=>{setLims(d??[]);}).catch(()=>{});
      fetchOeeTrend(7,plantSel).then(d=>{setOeeTrend(d??[]);}).catch(()=>{});   // 7 days matches chart
      fetchSixLosses('today',plantSel).then(d=>{setSixLosses(d??[]);}).catch(()=>{});
      fetchMachineLossesToday(plantSel).then(d=>{setMachineLossesToday(d??[]);}).catch(()=>{});
      fetchRulTrend(14,plantSel).then(d=>{setRulTrend(d??[]);}).catch(()=>{});
      fetchCarbonTrend(plantSel).then(d=>{setCarbonTrend(d??[]);}).catch(()=>{});
      fetchEnergyTrend(1,plantSel).then(d=>{setEnergyTrend((d??[]).map((r:any)=>({h:r.h??r.hour,kw:Number(r.kw??0),anomalies:r.anomalies})));}).catch(()=>{});
    };
    const liveIv = setInterval(whenVisible(livePoll), 15000);
    cleanupFns.push(()=>clearInterval(liveIv));

    // Batch 2 — OEE/PdM data (100ms delay)
    delay(100,()=>{
      fetchOeeTrend(7,plantSel).then(d=>{setOeeTrend(d??[]);}).catch(()=>{});   // 7 days — chart shows slice(-7) anyway
      fetchOeeScorecard(plantSel).then(d=>{setOeeScorecard(d??[]);}).catch(()=>{});  // moved from Batch 5 — scorecard chart visible sooner
      fetchSixLosses('today',plantSel).then(d=>{setSixLosses(d??[]);}).catch(()=>{});  // V37: today-only — matches chart's rightmost bar
      fetchMachineLossesToday(plantSel).then(d=>{setMachineLossesToday(d??[]);}).catch(()=>{});
      fetchLossTrend(7,plantSel).then(d=>{setLossTrend(d??[]);}).catch(()=>{});
      fetchRulTrend(14,plantSel).then(d=>{setRulTrend(d??[]);}).catch(()=>{});
      fetchWorkOrders(plantSel).then(d=>{setWos(d??[]);}).catch(()=>{});
    });
    // Batch 3 — Supply/Energy (250ms delay; qualityLines moved to Batch 1)
    delay(250,()=>{
      // Quality defects + qualityLines already loaded in Batch 1
      fetchSupplyRisks(plantSel).then(d=>{setSupplyRisksData(d??[]);}).catch(()=>{});
      fetchEnergyWaste(plantSel).then(d=>{setEnergyWaste(d??[]);}).catch(()=>{});
      fetchEnergyAssets(plantSel).then(d=>{setEnergyAssets(d??[]);}).catch(()=>{});
      // Issue fix: energy assets are live (sim ticks kW/anomaly) — poll every 5s
      const energyIv=setInterval(whenVisible(()=>{fetchEnergyAssets(plantSel).then(d=>{setEnergyAssets(d??[]);}).catch(()=>{});}),15000);
      cleanupFns.push(()=>clearInterval(energyIv));
    });
    // Batch 4 — Safety/Twin/Yield/Config (450ms delay)
    delay(450,()=>{
      fetchSafetyEvents(7,plantSel).then(d=>{setSafetyEvents(d??[]);}).catch(()=>{}); // 7 days for sufficient event history
      fetchSafetyPermits(plantSel).then(d=>{setPtwList(d??[]);}).catch(()=>{});
      fetchTwinScenarios(plantSel).then(d=>{setTwinScenarios(d??[]);}).catch(()=>{});
      fetchDivergenceLog(plantSel).then(d=>{setDivergenceLog(d??[]);}).catch(()=>{});
      fetchCarbonTrend(plantSel).then(d=>{setCarbonTrend(d??[]);}).catch(()=>{});
      fetchDemandForecast(plantSel).then(d=>{setDemandForecast(d??[]);}).catch(()=>{});
    });
    // Batch 5 — Secondary config (650ms delay)
    delay(650,()=>{
      fetchTechStack().then(d=>{if(Object.keys(d).length){setTechStacks(d);SC.techStacks=d;}}).catch(()=>{});
      fetchSemanticKpiDefs().then(d=>{if(d.length)setSemanticDefs(d);}).catch(()=>{});
      fetchPersonas().then(d=>{if(Object.keys(d).length)setPersonasCfg(d);}).catch(()=>{});
      fetchPdmRules().then(d=>{if(d.length)setPdmRules(d);}).catch(()=>{});
      fetchUtilities(plantSel).then(d=>{setUtil(d??[]);}).catch(()=>{});
      fetchShifts(plantSel).then(d=>{setShifts(d??[]);}).catch(()=>{});
      fetchLims(plantSel).then(d=>{setLims(d??[]);}).catch(()=>{});
      fetchDcsSetpoints(plantSel).then(d=>{setDcs(d??[]);}).catch(()=>{});
      // sapOrders moved to Batch 1 so YIELD mini-tile populates immediately
      fetchEnergyTrend(1,plantSel).then(d=>{setEnergyTrend((d??[]).map((r:any)=>({h:r.h??r.hour,kw:Number(r.kw??0),anomalies:r.anomalies})));}).catch(()=>{});
    });
    return()=>{cleanupFns.forEach(fn=>fn());};
  },[plantSel]);

  const mchFiltered=useMemo(()=>{
    const code=codeFor(plantSel);
    if(!code) return mch;
    return mch.filter((m:any)=>m.plant===code);
  },[mch,plantSel]);
  const value:AppState={
    energyWaste,carbonTrend,supplyRisksData,demandForecast,
    defectTrend,defectLog,safetyEvents,ptwList,
    twinScenarios,divergenceLog,qualityLines,energyAssets,
    energyTrend,pdmRules,
    mch:mchFiltered,util,wos,shifts,
    oeeTrend,sixLosses,lossTrend,machineLossesToday,oeeScorecard,rulTrend,
    lims,dcs,sapOrders,
    appCfg,baselines,personasCfg,techStacks,semanticDefs,
    agsMachines:agsMachines as any[],agsOee,critical,
    agsUtilities:agsUtilities as any[],criticalMachines,criticalUtilities,
    agsYield:agsYield as any[],crossEvents:crossEvents as any[],
    _sharedCfg:SC,
  };

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
