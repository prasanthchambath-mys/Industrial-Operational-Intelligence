// ─────────────────────────────────────────────────────────────────────────────
// Frontend plant topology — single source of truth, fetched from the backend
// (/api/config/plant-topology) which derives everything from CSV.
//
// Replaces every hardcoded ['MCH-01','MCH-02',...] / ['Line A','Line B',...]
// array in the UI. The backend is the authority; this module caches the
// result and exposes synchronous accessors after the first fetch resolves.
//
// Usage:
//   import { loadTopology, plantForAsset, assetsFor, humanLabelFor, codeFor } from './topology';
//   await loadTopology();              // call once at app startup
//   plantForAsset('MCH-06')            // => 'P2'
//   assetsFor('P1')                    // => ['MCH-01','MCH-02','MCH-03','MCH-04','CMP-001',...]
//   humanLabelFor('P1')                // => 'Plant 1'
//   codeFor('Plant 1')                 // => 'P1'
//   codeFor('All Plants')              // => null
// ─────────────────────────────────────────────────────────────────────────────

export type PlantCode = string;

export interface PlantTopology {
  code:      PlantCode;
  label:     string;     // 'Plant 1', 'Plant 2', ...
  machines:  string[];
  utilities: string[];
  assets:    string[];   // machines + utilities
  lines:     string[];
  zones:     string[];
}

interface TopologyState {
  plants:           PlantTopology[];
  plantByAsset:     Map<string, PlantCode>;
  plantByLine:      Map<string, PlantCode>;
  plantByZone:      Map<string, PlantCode>;
  codeByHumanLabel: Map<string, PlantCode>; // 'Plant 1' → 'P1'
  humanByCode:      Map<PlantCode, string>; // 'P1' → 'Plant 1'
}

// Empty default so accessors don't throw before loadTopology() resolves.
const EMPTY: TopologyState = {
  plants: [],
  plantByAsset:     new Map(),
  plantByLine:      new Map(),
  plantByZone:      new Map(),
  codeByHumanLabel: new Map(),
  humanByCode:      new Map(),
};

let _state: TopologyState = EMPTY;
let _loadPromise: Promise<TopologyState> | null = null;

function indexTopology(plants: PlantTopology[]): TopologyState {
  const plantByAsset     = new Map<string, PlantCode>();
  const plantByLine      = new Map<string, PlantCode>();
  const plantByZone      = new Map<string, PlantCode>();
  const codeByHumanLabel = new Map<string, PlantCode>();
  const humanByCode      = new Map<PlantCode, string>();
  for (const p of plants) {
    codeByHumanLabel.set(p.label, p.code);
    humanByCode.set(p.code, p.label);
    for (const id of p.assets) plantByAsset.set(id, p.code);
    for (const line of p.lines) plantByLine.set(line, p.code);
    for (const zone of p.zones) plantByZone.set(zone, p.code);
  }
  return { plants, plantByAsset, plantByLine, plantByZone, codeByHumanLabel, humanByCode };
}

/**
 * Load the plant topology from the backend. Idempotent — safe to call multiple
 * times; only one network request fires. Returns the cached state once resolved.
 *
 * Call once at app startup (e.g. in context.tsx mount) before any helpers
 * are used. Helpers tolerate being called before the load resolves; they'll
 * return empty/null until the data arrives.
 */
export async function loadTopology(apiBase = ''): Promise<TopologyState> {
  if (_loadPromise) return _loadPromise;
  _loadPromise = (async () => {
    try {
      const url = `${apiBase}/api/config/plant-topology`;
      const r = await fetch(url, { credentials: 'include' });
      if (!r.ok) throw new Error(`topology fetch failed: ${r.status}`);
      const data = await r.json();
      const plants = (data?.plants ?? []) as PlantTopology[];
      _state = indexTopology(plants);
      return _state;
    } catch {
      // Leave _state empty; helpers degrade to "no match" rather than throw.
      return _state;
    }
  })();
  return _loadPromise;
}

/** Discard cache and force a fresh fetch on next loadTopology() call. */
export function resetTopology(): void {
  _state = EMPTY;
  _loadPromise = null;
}

// ─── Synchronous accessors (post-load) ───────────────────────────────────────

export function getAllPlants(): PlantTopology[] {
  return _state.plants;
}

export function getPlantCodes(): PlantCode[] {
  return _state.plants.map((p) => p.code);
}

export function getHumanLabels(): string[] {
  return _state.plants.map((p) => p.label);
}

export function machinesFor(code: PlantCode): string[] {
  return _state.plants.find((p) => p.code === code)?.machines ?? [];
}

export function utilitiesFor(code: PlantCode): string[] {
  return _state.plants.find((p) => p.code === code)?.utilities ?? [];
}

export function assetsFor(code: PlantCode): string[] {
  return _state.plants.find((p) => p.code === code)?.assets ?? [];
}

export function linesFor(code: PlantCode): string[] {
  return _state.plants.find((p) => p.code === code)?.lines ?? [];
}

export function zonesFor(code: PlantCode): string[] {
  return _state.plants.find((p) => p.code === code)?.zones ?? [];
}

export function plantForAsset(assetId: string | undefined | null): PlantCode | null {
  if (!assetId) return null;
  return _state.plantByAsset.get(String(assetId)) ?? null;
}

export function plantForLine(line: string | undefined | null): PlantCode | null {
  if (!line) return null;
  return _state.plantByLine.get(String(line)) ?? null;
}

export function plantForZone(zone: string | undefined | null): PlantCode | null {
  if (!zone) return null;
  return _state.plantByZone.get(String(zone)) ?? null;
}

// ─── Label / code conversion ────────────────────────────────────────────────

/**
 * Convert a UI selector value ('Plant 1' / 'P1' / 'All Plants') to a canonical
 * plant code, or null when "all plants" / unknown. Replaces every
 * `plant === 'Plant 1' ? 'P1' : 'P2'` ternary in the codebase.
 */
export function codeFor(rawLabelOrCode: string | undefined | null): PlantCode | null {
  if (!rawLabelOrCode) return null;
  const s = String(rawLabelOrCode).trim();
  if (!s || s === 'All Plants') return null;
  // Direct code match
  if (_state.humanByCode.has(s)) return s;
  // Human label match ('Plant 1' → 'P1')
  const fromLabel = _state.codeByHumanLabel.get(s);
  if (fromLabel) return fromLabel;
  // Generic 'Plant N' → 'PN' fallback if codes follow that convention
  const m = s.match(/^Plant\s+(\d+)$/i);
  if (m) {
    const code = `P${m[1]}`;
    if (_state.humanByCode.has(code)) return code;
  }
  return null;
}

/** Get the human label for a plant code ('P1' → 'Plant 1'). */
export function humanLabelFor(code: PlantCode | undefined | null): string {
  if (!code) return 'All Plants';
  return _state.humanByCode.get(code) ?? String(code);
}

/** True when the selector represents a specific plant (not "All Plants"). */
export function hasPlantFilter(rawLabelOrCode: string | undefined | null): boolean {
  return codeFor(rawLabelOrCode) !== null;
}

// ─── Filtering helpers (consumed by App / context / store) ──────────────────

/** Returns true if an event belongs to the given plant selector. */
export function evMatchesPlant(e: any, rawLabel: string): boolean {
  const code = codeFor(rawLabel);
  if (!code) return true; // 'All Plants' or unresolved
  // Explicit plant_id is AUTHORITATIVE
  if (e?.plant_id != null && String(e.plant_id).length > 0) return e.plant_id === code;
  // Fallback only for events with no plant_id
  const a = String(e?.asset ?? e?.asset_id ?? '');
  const l = String(e?.line_id ?? '');
  if (a && plantForAsset(a) === code) return true;
  if (l && plantForLine(l) === code) return true;
  // Substring match for line/zone names that may appear inside asset or line text
  for (const name of [...linesFor(code), ...zonesFor(code)]) {
    if (a.includes(name) || l.includes(name)) return true;
  }
  return false;
}

/** Filter array rows by an asset/machine id key. */
export function filterByMachine<T extends Record<string, any>>(
  arr: T[], rawLabel: string, key: keyof T | string = 'asset_id',
): T[] {
  const code = codeFor(rawLabel);
  if (!code) return arr;
  const ids = new Set(assetsFor(code));
  return arr.filter((r) => {
    const v = r[key as string] ?? r.asset ?? r.machine_id ?? r.id;
    return v ? ids.has(String(v)) : true;
  });
}

/** Filter array rows by a production line key. */
export function filterByLine<T extends Record<string, any>>(
  arr: T[], rawLabel: string, key: keyof T | string = 'line',
): T[] {
  const code = codeFor(rawLabel);
  if (!code) return arr;
  const lines = linesFor(code);
  if (!lines.length) return arr;
  return arr.filter((r) => {
    const v = String(r[key as string] ?? '');
    return !v || lines.some((l) => v.includes(l));
  });
}

/** Filter array rows by a `plant` column ('P1'/'P2'/'Both'). */
export function filterByPlantColumn<T extends { plant?: string }>(
  arr: T[], rawLabel: string,
): T[] {
  const code = codeFor(rawLabel);
  if (!code) return arr;
  return arr.filter((r) => !r.plant || r.plant === code || r.plant === 'Both');
}
