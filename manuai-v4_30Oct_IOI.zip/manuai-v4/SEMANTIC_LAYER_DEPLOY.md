# Semantic layer — deployment sequence

Three parts, in this order. Each is reversible on its own.

## Part 1 — Install the semantic model in PostgreSQL (no app change)
Use `manuai_semantic_postgres.zip` → follow its README: files 00–08 in DBeaver as admin.
File 07 grants the app login `manuai-db-user` the right to trigger a refresh.
File 08 does the first full-history load (off-peak) and prints the checks.

Rollback: `99_remove.sql`.

## Part 2 — Deploy the API (two changes, both off until enabled)
Source: `manuai-v4-semantic-app.zip`. Diff: `SEMANTIC_LAYER_APP_CHANGES.patch`.

| File | Change |
|---|---|
| `apps/api/src/ai/semantic-history.ts` | NEW — governed trends for the AI assistant |
| `apps/api/src/analytics/refresh-scheduler.ts` | NEW — hourly refresh trigger |
| `apps/api/src/ai/ai-context-builder.ts` | 19 lines — adds the Governed History section |
| `apps/api/src/index.ts` | 4 lines — starts the scheduler after a clean boot |

Build and deploy with the feature OFF first, so any difference between this source and the running v89
image shows up on its own:

    RG="Manu-AI-Solution-RG"; ACR="manuaicontainerregistry"; SERVER="manuaicontainerregistry.azurecr.io"
    az acr build --registry "$ACR" --image "manuai-api:v90" --file infra/docker/Dockerfile.api .
    az containerapp update -n manuai-api-app -g "$RG" --image "$SERVER/manuai-api:v90"

Check: dashboard tiles show data, chat answers, logs show `[Analytics] Refresh scheduler disabled`.
Rollback: `--image "$SERVER/manuai-api:v89"`.

## Part 3 — Switch on (no rebuild)

    az containerapp update -n manuai-api-app -g "$RG" --set-env-vars ANALYTICS_SEMANTIC_ENABLED=true

This enables both the hourly refresh and the AI's governed history. Within ~2 minutes the logs show
`[Analytics] Refresh scheduler active`; after the first hour, `[Analytics] Refresh complete`.
Ask the assistant: "How has OEE trended for Plant 2 over the last two weeks?"

Optional: `ANALYTICS_REFRESH_MINUTES=30` to refresh more often (minimum 5).
Rollback: set `ANALYTICS_SEMANTIC_ENABLED=false`.

## Constraint check
- No new tool, service, container, managed resource or dependency: the model is tables and procedures
  in the existing database; the refresh is a timer in the existing API using its existing driver.
- Output unchanged: dashboards and API responses are untouched. The one intended change is that the AI
  assistant's answers include governed trends once Part 3 is enabled.
