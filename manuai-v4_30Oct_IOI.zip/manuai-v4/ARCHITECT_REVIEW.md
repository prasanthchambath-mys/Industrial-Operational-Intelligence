# ManuAI v4 — Solution Architect Review

**Date:** June 16, 2026
**Reviewer scope:** Phase 1 (current) → Phase A (Azure Basic) → Phase E (Full Enterprise)
**Codebase:** `manuai-v4/` at commit-equivalent of the current packaged build

This is a structural review of the platform from a Phase A/E scalability lens.
I'm answering the question: *given where we are today, what hurts most when we
deploy to Azure with real load and real plants?*

---

## TL;DR — Top 7 refactors, ranked

| # | Finding | Phase blocked | Effort | Risk if not done |
|---|---|---|---|---|
| 1 | **Hardcoded `'Plant 1' ? 'P1'` ternaries** still in 25 places across history/oee/csv-loader routes (after the topology refactor) | Phase A onwards | S (½ day) | Adding a 3rd plant requires editing 25 files |
| 2 | **DB queries use SQLite-only date functions** (`strftime`, `unixepoch`, `datetime(..., 'unixepoch')`) in 14 query functions | Phase A blocker | M (3-4 days) | Cannot migrate to PostgreSQL / Azure SQL without rewriting every history query |
| 3 | **Simulation engine is a process singleton** with `setInterval` driving DB writes and WebSocket broadcasts | Phase E blocker | L (1-2 weeks) | Horizontal scaling impossible — would broadcast duplicate ticks; need a leader-election or extract to a separate worker |
| 4 | **`all-routes.ts` is 460 lines with 26 routes** spanning PdM/Twin/Quality/Supply concerns | Phase E maintainability | M (2 days) | Single file becomes the merge-conflict bottleneck for any agent team's parallel work |
| 5 | **Secrets read directly from `process.env`** in 8+ places (PI password, SAP OAuth secret, Anthropic key) | Phase A | M (2 days) | No Key Vault integration; rotating a credential requires re-deploying the API |
| 6 | **WebSocket broadcaster is in-memory** (no Redis adapter wired despite Redis being in docker-compose with `profiles: ["redis"]`) | Phase E blocker | S (1 day) | 2+ API replicas can't share WS state; users lose updates on the replica they're not connected to |
| 7 | **Hardcoded `MCH-05/06/07/08` machine list in schema migration** to backfill plant_id | Phase A | XS (1h) | Adding new P2 machines means rewriting a migration; contradicts the "no hardcoded asset IDs" principle from the recent refactor |

These 7 cover ~80% of the technical debt that matters for Phase A/E. Below I
walk through them and a longer list of secondary findings.

---

## Phase A blockers (must fix before Azure migration)

### A1. SQLite-only date arithmetic across 14 query functions

**File:** `apps/api/src/database/queries.ts`

**Problem:** Every historical query relies on SQLite's `strftime('%Y-%m-%d',
datetime(ts/1000, 'unixepoch'))` pattern to group by day, week, or hour. PostgreSQL,
Azure SQL, and Synapse Serverless each use different syntax:

| Engine | Equivalent |
|---|---|
| PostgreSQL | `TO_CHAR(TO_TIMESTAMP(ts/1000), 'YYYY-MM-DD')` |
| Azure SQL  | `FORMAT(DATEADD(SECOND, ts/1000, '1970-01-01'), 'yyyy-MM-dd')` |
| Synapse    | `CONVERT(date, DATEADD(SECOND, ts/1000, '1970-01-01'))` |

**Refactor approach:** introduce a thin SQL dialect layer
(`apps/api/src/database/dialect.ts`) with portable helpers:

```ts
export const sql = {
  toDate: (col: string) => process.env.DB_DIALECT === 'sqlite'
    ? `strftime('%Y-%m-%d', datetime(${col}/1000, 'unixepoch'))`
    : `TO_CHAR(TO_TIMESTAMP(${col}/1000), 'YYYY-MM-DD')`,
  toHour: (col: string) => /* ... */,
  // ... etc
};
```

Then every query becomes `${sql.toDate('o.ts')} as day`. Switching engines is a
single env var change. The dialect layer is ~80 LOC and replaces the per-query
SQLite assumptions.

**Phase A target:** `DB_DIALECT=postgres` + `DATABASE_URL=postgresql://...` and
the same queries run on Azure PostgreSQL Flexible Server.

### A2. `better-sqlite3` is synchronous + native — wrong fit for Azure Container Apps

**File:** `apps/api/src/database/connection.ts`

**Problem:** `better-sqlite3` is great for local dev (zero-install, fast) but it's
a native module that requires `python3 + make + g++` in the build stage (see
`Dockerfile.api`). On Azure Container Apps this means a 4-minute build per
deployment. It's also synchronous — fine on a single instance, terrible under
concurrency.

**Refactor approach:** abstract `getDb()` to return a query interface, not a
specific driver:

```ts
// connection.ts
export interface Db {
  prepare(sql: string): { run: (...args: any[]) => any; all: (...args: any[]) => any[]; };
  exec(sql: string): void;
  transaction<T>(fn: () => T): () => T;
}

export function getDb(): Db {
  if (process.env.DB_DIALECT === 'postgres') return getPgPool();
  return getSqliteDb();
}
```

The 320 lines of `queries.ts` don't change; they keep calling `prepare(...).all(...)`.
The driver swap is invisible.

### A3. Secrets read directly from `process.env`

**Problem locations:**
- `apps/api/src/ai/llm-client.ts:47,48,82` — STARGATE/AZURE_OPENAI/ANTHROPIC keys
- `apps/api/src/connectors/sap-odata.ts:41` — `SAP_OAUTH_CLIENT_SECRET!`
- `apps/api/src/connectors/pi-historian.ts:31` — `PI_PASSWORD_*`

**Refactor approach:** introduce a tiny `secrets.ts` module:

```ts
// apps/api/src/config/secrets.ts
import { SecretClient } from '@azure/keyvault-secrets';
import { DefaultAzureCredential } from '@azure/identity';

const KV_URL = process.env.AZURE_KEY_VAULT_URL;
let _kv: SecretClient | null = null;

const cache = new Map<string, { value: string; expires: number }>();

export async function getSecret(name: string): Promise<string> {
  // 1. Cache (5 min TTL)
  const c = cache.get(name);
  if (c && c.expires > Date.now()) return c.value;

  // 2. Azure Key Vault if configured
  if (KV_URL) {
    _kv ??= new SecretClient(KV_URL, new DefaultAzureCredential());
    const sec = await _kv.getSecret(name);
    if (sec.value) {
      cache.set(name, { value: sec.value, expires: Date.now() + 300_000 });
      return sec.value;
    }
  }

  // 3. Fallback to env var (dev/Phase 1)
  const env = process.env[name];
  if (!env) throw new Error(`Secret ${name} not found in KV or env`);
  return env;
}
```

Every secret-reading call site becomes `await getSecret('PI_PASSWORD_P1')` instead
of `process.env.PI_PASSWORD_P1`. The Azure SDK's `DefaultAzureCredential`
auto-handles Managed Identity in Container Apps — no client_id/client_secret in env.

**This is the single highest-value Phase A refactor for security posture.**

### A4. Remaining hardcoded plant ternaries (25 callsites)

Despite the topology refactor, these files still have `'Plant 1' ? 'P1' : 'P2'` :

```
apps/api/src/data/csv-loader.ts:523
apps/api/src/routes/oee.ts:84, 109
apps/api/src/routes/history.ts:31, 92, 112, 131, 162, 184, ...
```

These should all use `normalizePlant(req.query.plant)` from `data/plant.ts`. The
refactor is mechanical (~30-min find/replace) but it matters because adding a
"Plant 3 (Chennai)" today requires editing all 25 callsites.

### A5. CORS / origin config doesn't support multi-environment

**File:** `apps/api/src/index.ts:39-42`

```ts
app.use(cors({
  origin: process.env.CORS_ORIGINS?.split(',') ?? ['http://localhost:5173'],
  credentials: true,
}));
```

Works, but doesn't validate the values. For Phase A there will be at least
`https://app-dev.manuai.com`, `https://app-staging.manuai.com`,
`https://app.manuai.com`. The current single-env-var approach is fine, but the
schema for these origins should be validated at startup so a typo doesn't silently
break auth.

### A6. AI system prompts are hardcoded — should be CSV/Purview-driven

**File:** `apps/api/src/ai/llm-client.ts:18-30`

```ts
const SYSTEM_9_AGENT = `You are the ManuAI Unified Platform AI...`;
const AGENT_PROMPTS: Record<string, string> = {
  yield: 'You are the Yield Optimisation agent...',
  pdm: 'You are the Predictive Maintenance agent. RUL < 14d = critical...',
  // ...
};
```

The PdM prompt embeds business rules (`RUL < 14d = critical`) that are now
CSV-driven in `ml_thresholds.csv` (urgent_days, critical_days). The prompt should
reference the same source so prompt and engine agree.

**Refactor approach:** move agent prompts to `data/csv/ai_prompts.csv` with
template variables:

```csv
agent,prompt
yield,"You are the Yield Optimisation agent. Recommend DCS set-point adjustments. Max 80 words."
pdm,"You are the Predictive Maintenance agent. RUL < {critical_days}d = critical, RUL < {urgent_days}d = urgent. Max 80 words."
```

At runtime, substitute `{critical_days}` with `get_threshold('pdm','rul_thresholds','critical_days')`.

**Phase E target:** prompts move to Azure Purview as governed assets with version
history and approval workflow.

---

## Phase E blockers (must fix before multi-plant / multi-replica)

### E1. Simulation engine singleton + setInterval

**File:** `apps/api/src/simulation/engine.ts`

**Problem:**
```ts
export const simulationEngine = new SimulationEngine();   // module singleton
// inside class:
this.timer = setInterval(() => this.tick(), ms);
```

Every API replica that imports this module will spawn its own simulation tick
loop. Two API replicas = double tick rate, double DB writes, duplicate WebSocket
events. This was acceptable in Phase 1 but fails the moment we run `replicas: 2`
in Azure Container Apps.

**Refactor approach (Phase E):**

1. **Extract to a separate service** — `services/sim-engine/` running as a single
   container. The API stops simulating, just reads.
2. **Or, use a distributed lock** — Redis SETNX with TTL elects one API instance
   as the simulation leader. Other instances fall through to read-only.

For Phase A this isn't urgent (single-instance is fine), but it must be done
before Phase E auto-scaling.

### E2. WebSocket broadcaster has no Redis adapter

**File:** `apps/api/src/websocket/broadcaster.ts`

**Problem:** the broadcaster uses Socket.IO with default in-memory state. The
`docker-compose.yml` includes Redis but with `profiles: ["redis"]` — meaning
it's *off by default*. There is no `@socket.io/redis-adapter` import anywhere.

When you run multiple API replicas behind Azure Container Apps' load balancer:
- User A connects to replica 1
- User B connects to replica 2
- A scenario event is published on replica 1 via `io.emit(...)`
- User B never sees it

**Refactor approach:**

```ts
// websocket/broadcaster.ts
import { createAdapter } from '@socket.io/redis-adapter';
import { createClient } from 'redis';

export function initWebSocket(httpServer: HttpServer): void {
  io = new Server(httpServer, { /* ... */ });

  if (process.env.REDIS_URL) {
    const pub = createClient({ url: process.env.REDIS_URL });
    const sub = pub.duplicate();
    Promise.all([pub.connect(), sub.connect()]).then(() => {
      io.adapter(createAdapter(pub, sub));
      logger.info('[WS] Redis adapter active — multi-replica broadcasts enabled');
    });
  }
  // ... rest unchanged
}
```

That's a 10-line change. Plus remove `profiles: ["redis"]` from
`docker-compose.yml` so Redis is on by default.

**This is the smallest Phase E refactor with the highest impact** — turns
the API from single-instance to N-instance with zero application code changes
elsewhere.

### E3. `all-routes.ts` is a god-file

**Stats:** 460 lines, 26 routes, imports from `pdmRouter`, `qualityRouter`,
`twinRouter`, `supplyRouter`, `safetyRouter`, `energyRouter`, `aiRouter`,
`semanticRouter`. Touches 17 CSV loaders.

**Why it's a problem:**
- Every agent team's work conflicts in this file
- Test coverage is bimodal — either nothing or everything
- The `resolvePlant` helper, which is general infrastructure, lives here
- It violates the implicit module-per-agent structure that the rest of the codebase follows

**Refactor approach:** move each domain block to its corresponding agent router:

| Current location in all-routes.ts | Move to |
|---|---|
| `pdmRouter.get('/workorders')`, `/parts-spend`, `/parts-order` | `routes/pdm.ts` |
| `qualityRouter.*` | `routes/quality.ts` (currently empty re-export) |
| `twinRouter.get('/divergence')` etc. | `routes/twin.ts` |
| `supplyRouter.*` | `routes/supply.ts` (currently empty re-export) |
| `safetyRouter.*` | `routes/safety.ts` |
| `semanticRouter.*` | `routes/semantic.ts` |
| `aiRouter.post('/chat')` etc. | `routes/ai.ts` |
| `resolvePlant()` helper | `data/plant.ts` (it already has `plantForAsset` — merge) |

After refactor, `all-routes.ts` is gone. Each agent file is 60-150 lines and
owns its domain. Parallel work no longer conflicts.

### E4. KPI computation in-process

**File:** `apps/api/src/kpi/engine.ts`

**Problem:** KPIs are computed inside the simulation tick (`computeKPIs(state)`)
on every interval. At Phase E scale (10 plants × every 4 seconds × multiple KPIs)
this is ~25K KPI computations/minute, all in the API process.

**Refactor approach:** Phase E moves KPI computation to Azure Synapse Serverless
queries against the Delta Lake. The API serves cached results from a Redis
hash with 60s TTL. The simulation engine no longer computes KPIs at all — they
become a *projection* of the historical fact stream.

This is also where the Purview KPI definitions plug in (Phase E enterprise
roadmap document already calls for this).

### E5. Cross-event filter `evMatchesPlant` does substring matching

**File:** `apps/web/src/topology.ts`

```ts
for (const name of [...linesFor(code), ...zonesFor(code)]) {
  if (a.includes(name) || l.includes(name)) return true;
}
```

For 10 plants with 4 lines each = 40 substring tests per event. At Phase E
scale (1K events/sec across plants) this is 40K string operations/sec on the
client. Worse, `'Line A'.includes('A')` will false-positive on any asset name
containing the letter A.

**Refactor approach:** the backend already tags every event with `plant_id`.
Drop the substring fallback entirely — if `plant_id` is missing, the event is
malformed (server bug). Add a server-side test that asserts every published
event has `plant_id`.

### E6. CSV loader has no cache invalidation

**File:** `apps/api/src/data/csv-loader.ts`

**Problem:** every loader function calls `parseCSV(...)` on every invocation:
```ts
export function loadMachines() {
  return parseCSV('machines.csv').map(r => ({ ... }));
}
```

In a single request that touches 5 routes, the same CSV is parsed 5 times.
At Phase E scale this is wasteful (small CSVs) or fatal (large CSVs like a
50K-row supplier catalog).

**Refactor approach:** add a memoization layer with file-mtime-based invalidation:

```ts
// data/csv-cache.ts
const cache = new Map<string, { mtime: number; rows: any[] }>();

export function cachedCSV<T>(filename: string, parse: (row: any) => T): T[] {
  const path = csvPath(filename);
  const mtime = fs.statSync(path).mtimeMs;
  const cached = cache.get(filename);
  if (cached && cached.mtime === mtime) return cached.rows;
  const rows = parseCSV(filename).map(parse);
  cache.set(filename, { mtime, rows });
  return rows;
}
```

Editing a CSV invalidates its cache automatically.

### E7. Schema migration hardcodes asset → plant mapping

**File:** `apps/api/src/database/schema.ts:413-420`

```sql
UPDATE oee_readings SET plant_id = 'P2'
WHERE plant_id = 'P1' AND machine_id IN ('MCH-05','MCH-06','MCH-07','MCH-08');
```

This contradicts the entire topology refactor. If we add MCH-09 to Plant 2 in
`machines.csv`, this migration won't pick it up — historical rows for MCH-09
will be tagged P1 forever.

**Refactor approach:** make the migration data-driven:

```ts
import { loadMachines } from '../data/csv-loader';
for (const m of loadMachines()) {
  db.prepare(`UPDATE oee_readings SET plant_id = ? WHERE machine_id = ? AND plant_id != ?`)
    .run(m.plant, m.id, m.plant);
}
```

5-line refactor. Zero hardcoded asset IDs.

---

## Frontend findings

### F1. Frontend has no observability hooks

**Problem:** No Application Insights / Sentry / OpenTelemetry SDK is wired.
Operations team has no visibility into client-side errors, slow chart renders,
or API failure rates.

**Refactor approach:** Phase A should add `@microsoft/applicationinsights-web`
with a single init in `main.tsx`. Add `withProfiler` HOCs on the 8 agent
dashboards. Track button clicks, time-to-first-chart, plant-switch latency.

### F2. Bundle size is 540KB for charts (recharts) — single chunk

**Build output:** `dist/assets/charts-DzLIRX-5.js  540.80 kB  gzip: 152.81 kB`

For a manufacturing operator on a factory-floor tablet over 4G, that's a 3-5s
chart load. Recharts is already lazy-loaded per the Vite manualChunks setup,
but the chunk itself is monolithic.

**Refactor approach:** dynamically import per-chart-type
(`LineChart`, `BarChart`, `ScatterChart` as separate chunks) rather than bundling
all of recharts. Recharts supports this via subpath imports.

### F3. No service worker / PWA support

For a plant operator who walks the floor with a tablet, intermittent connectivity
is reality. A service worker that caches the last-known dashboard state and
queues operator actions for replay would be a major UX win — and it's a 2-day
Phase A addition.

### F4. Frontend topology fallback hardcodes plant codes

**File:** `apps/web/src/csvApi.ts:219`

```ts
const fallbackAssets = (code ? assetsFor(code) : [
  ...assetsFor('P1'), ...assetsFor('P2')
]).slice(0, 3);
```

Should iterate `getPlantCodes()` instead. Trivial fix but reintroduces the
hardcoding the prior refactor eliminated.

---

## Cross-cutting findings

### X1. No request tracing / correlation IDs

**File:** `apps/api/src/middleware/logger.ts:18`

```ts
export const requestLogger = (_req, _res, next): void => next();
```

The request logger is a no-op. There's no correlation ID propagated between
the API, the 7 Python services, and the SAP/PI connectors. When something fails
under load, you can't trace a single user action through the system.

**Refactor approach:** add `traceparent` header propagation (W3C Trace Context)
via OpenTelemetry. Every outbound call (`pi-historian`, `sap-odata`,
`pdm-inference`) forwards the header. Phase A wires Application Insights;
Phase E wires Azure Monitor + Sentinel.

### X2. No retry / circuit-breaker on external calls

**Files:** `apps/api/src/connectors/pi-historian.ts`, `sap-odata.ts`

When PI or SAP returns a 503, the request just fails. No exponential backoff,
no circuit breaker. At Phase E scale with real connectors, a transient SAP
outage cascades into UI errors.

**Refactor approach:** wrap external calls with a circuit-breaker library
(`opossum` is the Node standard) with `failureThreshold: 50%, timeout: 5s,
errorThresholdPercentage: 50`.

### X3. No rate limiting per user — only per IP

**File:** `apps/api/src/index.ts:43`

```ts
app.use(rateLimit({ windowMs: 60_000, max: 2000, ... }));
```

2000 req/min per IP is fine for a single user. But Phase A with 100 operators
sharing a corporate NAT means all 100 share one 2000/min budget. The first 5
plant managers refreshing dashboards consume the whole quota.

**Refactor approach:** key the rate limit by `req.user.oid` (the AAD object ID
from JWT) rather than IP. Each user gets their own budget.

### X4. No structured event schema (every event invents its own shape)

The `CrossAgentEvent` interface is loose:
```ts
{ id, from, to, type, sev, msg, impact, asset, asset_id, plant_id, line_id, ... }
```

Every route that publishes an event picks which fields to set. Some include
`scenario_id`, some don't. Some include `source_mode`, some don't.

**Refactor approach:** define a Zod schema for `CrossAgentEvent` and validate at
publish time. Catch shape drift at the source instead of in the UI.

### X5. AI chat doesn't preserve conversation history

**File:** `apps/api/src/ai/llm-client.ts`

The `unifiedChat` function takes a `messages: ChatMessage[]` array but no
session ID. Every chat is stateless — the user can't follow up "what about the
other plant?" because the LLM has no memory of the prior turn.

For Phase E enterprise UX, conversation history should be persisted to a session
table keyed by `req.user.oid + session_id`.

### X6. No feature flags

Phase E will need progressive rollout (e.g. enable AKS-backed inference for
plant 3 first, keep plants 1-2 on Container Apps). There's no flag system.

**Refactor approach:** Azure App Configuration with feature flags. Wrap any new
agent or behavior in `if (await isFeatureOn('aks-inference', user.tenant)) ...`.

---

## What's NOT a problem

Worth being explicit about what's actually solid:

1. **CSV-driven topology** — `plant.ts` is well-factored, derives from CSV, exposes
   clean accessors. The recent refactor closed the right loops.

2. **ML thresholds in `ml_thresholds.csv`** — 102 thresholds across 8 service
   categories with env-var override + hardcoded fallback. Production-grade.

3. **Connector mock-to-live pattern** — every connector checks
   `process.env.PI_WEB_API_URL` etc. and falls back to mock. Switching to live
   requires only env vars. Clean.

4. **Plant filtering on routes** — after the latest fixes, every domain route
   honors `?plant=` consistently via `normalizePlant()`.

5. **Type safety** — TypeScript end-to-end, zod schemas on key API boundaries.

6. **Semantic Layer** — `event-store.ts` persists events with full audit trail,
   distinct from in-memory bus. Good architecture for cross-agent traceability.

7. **Docker Compose layout** — 10 containers, named volumes for CSV/SQLite,
   healthchecks. Maps cleanly to Azure Container Apps.

---

## Recommended roadmap

### Sprint 1 (Phase A prep) — 1 week
- [F1, A4] Eliminate remaining 25 `'Plant 1' ? 'P1'` ternaries
- [A6] Move agent prompts to `ai_prompts.csv`
- [E2] Wire Socket.IO Redis adapter; remove `profiles: ["redis"]`
- [E7] Make schema migration CSV-driven (5-line fix)
- [F4] Fix `assetsFor('P1') + assetsFor('P2')` to iterate `getPlantCodes()`

**Outcome:** all hardcoding eliminated, multi-replica WebSocket works, prompts CSV-driven.

### Sprint 2 (Phase A migration) — 2-3 weeks
- [A1, A2] SQL dialect abstraction layer; PostgreSQL driver
- [A3] Azure Key Vault secrets module
- [X1] OpenTelemetry + Application Insights wiring
- [X2] Circuit breaker on external calls
- [X3] Per-user rate limiting via JWT oid

**Outcome:** can run on Azure Container Apps with Azure PostgreSQL Flexible,
Azure AD B2C, Azure Key Vault, Application Insights.

### Sprint 3 (Phase E foundation) — 3-4 weeks
- [E1] Extract simulation engine to separate service
- [E3] Break up `all-routes.ts` into agent routers
- [E4] KPI computation to Synapse Serverless
- [E6] CSV-loader memoization
- [X4] Structured event schema (Zod)
- [X6] Feature flags via Azure App Configuration

**Outcome:** can horizontally scale, ready for AKS, multi-tenant plant onboarding.

### Sprint 4 (Phase E productionization) — 3-4 weeks
- F2/F3 frontend optimizations (chart code splitting, service worker)
- X5 AI session persistence
- Full Purview integration for KPI catalog
- Federated learning for Quality Vision (cross-plant)

---

## Closing notes

The platform is in **good architectural shape** for its current Phase 1 ambition.
The patterns are sound — single source of truth, CSV-driven config, clean
connector abstractions, type safety end-to-end. The recent topology and ML
threshold refactors closed the worst of the hardcoding debt.

The work that remains is **Phase-appropriate operational hardening**, not
fundamental redesign. The 7 ranked findings are all addressable without
rewriting any agent. The Sprint 1 work (1 week) closes Phase A's blockers
sufficient for a pilot deployment.

The single highest-leverage refactor is **E2 (Socket.IO Redis adapter)** —
10 lines of code that unlocks horizontal scaling. Do that first.
