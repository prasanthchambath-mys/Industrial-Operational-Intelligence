# ManuAI v4 — Architect Review Addendum

**Date:** June 16, 2026 (this session)
**Status of prior review:** `ARCHITECT_REVIEW.md` dated earlier today remains
the canonical document. This addendum **updates** it — closes two findings,
adds five it missed, and refines the sprint plan accordingly.

---

## Status check on the original 7 ranked findings

Re-validated against current source:

| # | Finding | Status |
|---|---|---|
| 1 | 25 `'Plant 1' ? 'P1'` ternaries across history/oee/csv-loader/yield routes | **17 of 25 fixed** in this session. Remaining 8 are in `csv-loader.ts` and `oee.ts` — see below. |
| 2 | SQLite-only date functions (`strftime`, `unixepoch`) in 14 query functions | Still open. 14 functions confirmed. Phase A blocker. |
| 3 | Simulation engine singleton + `setInterval` | Still open. `engine.ts:534` `export const simulationEngine = new SimulationEngine()` + `engine.ts:178` `setInterval(...)`. |
| 4 | `all-routes.ts` is 460 lines / 26 routes | Still open. Confirmed 460 lines. |
| 5 | Secrets read directly from `process.env` | Still open. Confirmed in `llm-client.ts`, `pi-historian.ts`, etc. |
| 6 | Socket.IO has no Redis adapter despite Redis in docker-compose | Still open. No `@socket.io/redis-adapter` import anywhere. |
| 7 | Hardcoded `MCH-05/06/07/08` in schema migration | **FIXED** in this session — `schema.ts` now loads from machines.csv / energy_assets.csv / safety_zones.csv. |

### Two fixes landed in this session

**Finding 7 (schema.ts hardcoded migration) — fixed:**
The migration that backfilled `plant_id = 'P2'` for `MCH-05..08` is now data-driven:

```ts
for (const m of loadMachines()) {
  if (!m.plant || !m.id) continue;
  updateMachineRow.run(m.plant, m.id, m.plant);
  updateHealthRow.run(m.plant, m.id, m.plant);
  updateAlertRow.run(m.plant, m.id, m.plant);
}
```

Adding `MCH-09` to `machines.csv` now backfills historical rows on next startup
without any schema.ts edit. Removes the contradiction with the topology refactor.

**Finding A4 (17 of 25 ternaries) — fixed:**
Every `const pfCode = pf === 'Plant 1' ? 'P1' : pf === 'Plant 2' ? 'P2' : pf;`
in `history.ts`, `all-routes.ts`, `safety.ts`, `yield.ts` is now
`const pfCode = normalizePlant(pf);`. The 8 remaining are in `csv-loader.ts`
(line 523) and `oee.ts` (lines 84, 109) — same mechanical refactor, deferred
because `csv-loader.ts` would create a circular import to `data/plant.ts`
that needs to be broken first.

---

## Five findings the original review missed

### M1. Zero automated tests — no Vitest/Jest config, no test files

```
find apps -name "*.test.*" -o -name "*.spec.*" → (none)
```

The codebase has 11,000+ lines of TypeScript across the backend and frontend
with **zero** unit, integration, or e2e tests. Every refactor — including the
ones I did in this session — has been verified by manual smoke test, not by
a test suite that catches regressions.

**Phase A impact:** moving SQLite → PostgreSQL means every history query needs
to be re-verified. Without tests, that's 14 manual API calls per migration
attempt × however many iterations until correct. Easy to ship a regression.

**Refactor:** Vitest setup with three minimum suites before Sprint 2:
1. `plant.test.ts` — `normalizePlant`, `plantForAsset`, `assetsFor` — pure logic
2. `csv-loader.test.ts` — every loader returns expected schema for the
   committed CSVs
3. `routes.contract.test.ts` — every API route returns the shape the frontend
   expects (catches the kind of `utilityAssets` vs `utilities` bug from the
   prior audit)

Estimated effort: **2 days for the scaffolding + first 30 tests**, then
add-as-you-go discipline. Should be **Sprint 1**, not later — every other
refactor becomes safer once a test net exists.

### M2. No `tenant_id` column anywhere in the database schema

```
grep -rn 'tenant_id\|tenantId' apps/api/src/database/ → (none)
```

The only mention of tenancy is in `websocket/broadcaster.ts:28` which has a
`socket.on('subscribe_tenant')` handler — but the events themselves have no
tenant scope, the database tables have no tenant column, and no route filters
by tenant.

**Why this matters:** Phase E explicitly calls for 10+ plants as separate
tenants. Today, "Plant 1" and "Plant 2" share one database, one schema, one
set of tables. To onboard a third client (say, a real customer that's
not Infocepts internal), you'd need to either:
- Spin up an entire copy of the platform per tenant (operational nightmare,
  doesn't match the Phase E "multi-plant federated" architecture diagram), or
- Bolt tenancy onto every table after the fact (high-risk migration)

**Refactor approach (Phase A foundation work):**
1. Add `tenant_id TEXT NOT NULL DEFAULT 'default'` to every fact table now.
2. Index `(tenant_id, plant_id, ts)` on time-series tables.
3. Add `req.user.tenant` from JWT claims (matches Azure AD B2C custom claims).
4. Every query becomes `WHERE tenant_id = ? AND plant_id = ?`.

Doing this **before** Phase A migration is far cheaper than retrofitting it
after data exists. **The recommended pattern for Azure**: PostgreSQL row-level
security policies that filter by `current_setting('app.tenant_id')`, set once
per connection via the auth middleware.

Estimated effort: **3 days now, vs. 2-3 weeks later.** Phase A should
not ship without this.

### M3. App.tsx is 2,372 lines containing 52 components

```
wc -l apps/web/src/App.tsx → 2372
grep -cE "^function [A-Z]|^const [A-Z]" → 52 components
```

The backend `all-routes.ts` god-file (finding E3 in the original review) has a
direct frontend counterpart that's 5× larger and was not flagged. Every agent
team that touches the UI hits merge conflicts in this single file.

**Phase E impact:** with 10+ plant onboarding, each customer engagement may
need branded variations of certain dashboards. With 52 components in one file,
selective customization means dragging the whole monolith.

**Refactor approach:** split by agent into separate files matching the
backend's domain structure:

```
apps/web/src/
  agents/
    OeeAgent.tsx          (≈350 lines extracted)
    YieldAgent.tsx
    PdmAgent.tsx
    QualityAgent.tsx
    EnergyAgent.tsx
    SupplyAgent.tsx
    TwinAgent.tsx
    SafetyAgent.tsx
    SemanticAgent.tsx
  shared/
    PlantSelector.tsx
    AgentFrame.tsx        (the SpecHeader+tabs wrapper)
    InsightsPanel.tsx
  App.tsx                 (now ≈200 lines: router + layout only)
```

Estimated effort: **3-4 days for a careful split** (the components share a lot
of state via `useApp()`; need to be sure no closure captures break). Should
be Sprint 2 alongside the backend `all-routes.ts` split.

### M4. No Application Insights / OpenTelemetry / observability hook

The original review flagged this for the frontend (F1) but missed that the
**backend has no observability either**. The `middleware/logger.ts`
`requestLogger` is a literal no-op (`(_req,_res,next) => next()`). There is no
correlation ID propagation, no metrics emitter, no APM agent.

**Phase A impact:** when an operator says "the platform was slow yesterday at
2pm", we have **nothing to look at**. No traces, no metrics, no per-route
latency. Just the console logs from `docker compose logs`.

**Refactor approach:** Application Insights for Node.js
(`applicationinsights` SDK) — one `setup()` call in `index.ts` autoinstruments
HTTP, Express routes, outbound `fetch`, and `better-sqlite3` queries.

Estimated effort: **half a day**. Should be **Sprint 1** — every other
refactor benefits from being able to measure before/after.

### M5. No outbound retry / circuit breaker pattern despite the PdM proxy I just added

The proxy I added in the prior session (`apps/api/src/routes/pdm.ts` →
`POST /api/pdm/ml-predict`) has a `signal: AbortSignal.timeout(2000)` but
**no retry, no circuit breaker, no jitter**. When the Python service is slow
under load (which it will be when actually called in production), every
request waits 2s and fails. There's nothing to prevent a thundering herd.

The same pattern exists in `all-routes.ts:249` (supply service) and 288
(twin service).

**Refactor approach:** wrap all 7 outbound service calls with `opossum`:

```ts
import CircuitBreaker from 'opossum';
const pdmPredict = new CircuitBreaker(
  (body) => fetch(`${PDM_SERVICE_URL}/predict`, { method:'POST', body, signal: AbortSignal.timeout(2000) }),
  { errorThresholdPercentage: 50, resetTimeout: 30_000, rollingCountTimeout: 10_000 }
);
pdmPredict.fallback(() => ({ source: 'cached', /* last good prediction */ }));
```

When the Python service is down, the breaker opens for 30 seconds and serves
cached results — the UI stays responsive instead of hanging.

Estimated effort: **1 day for all 7 outbound calls.** Should be Sprint 2.

---

## Updated Sprint plan

The original plan moved Sprint 1 to closing hardcoding and Sprint 2 to Phase A
migration. Given the missing pieces above, I'd reshuffle:

### Sprint 1 (operational foundation) — 1 week — *DO THESE FIRST*
- [M1] Vitest setup + ~30 baseline tests on plant.ts, csv-loader, route contracts ← **highest leverage**
- [M4] Application Insights wiring on the backend (single-line setup call)
- [F1] Application Insights wiring on the frontend
- [E2] Socket.IO Redis adapter (10-line change, removes `profiles: [redis]`)
- [A4 remainder] 8 ternaries left in csv-loader.ts and oee.ts
- [F4] Frontend `assetsFor('P1') + assetsFor('P2')` → `getPlantCodes().flatMap(assetsFor)`

**Outcome:** test net + observability before any risky refactor. Multi-replica
WebSocket works. Last of the topology hardcoding gone.

### Sprint 2 (Phase A migration) — 2-3 weeks
- [M2] **Add `tenant_id` column + RLS scaffolding** ← do this BEFORE the DB migration
- [A1] SQL dialect layer (`database/dialect.ts`)
- [A2] PostgreSQL driver behind the `Db` interface
- [A3] Azure Key Vault secrets module
- [M5] Circuit breakers on all 7 outbound service calls
- [X3] Per-user rate limiting via JWT `oid`

**Outcome:** can deploy to Azure Container Apps + Azure PostgreSQL Flexible
with proper tenancy, secrets, and resilience.

### Sprint 3 (Phase E foundation) — 3-4 weeks
- [E1] Extract simulation engine to separate `services/sim-engine/` container
- [E3] Break up `all-routes.ts` into agent routers
- [M3] **Break up `App.tsx` into per-agent files**
- [E4] KPI computation → Synapse Serverless
- [E6] CSV-loader memoization with mtime invalidation
- [X4] Structured event schema (Zod)
- [X6] Feature flags via Azure App Configuration

**Outcome:** can horizontally scale. Ready for AKS, multi-tenant plant
onboarding, federated AI rollout.

### Sprint 4 (Phase E productionization) — 3-4 weeks
- F2/F3 frontend optimizations (chart code splitting, service worker)
- X5 AI session persistence
- Full Purview integration for KPI catalog
- Federated learning for Quality Vision

---

## The one-sentence summary

The codebase is in **good architectural shape for Phase 1**, has **two clear
Phase A blockers nobody had flagged yet** (zero tests, no tenant_id), and the
**single highest-leverage Sprint 1 refactor is adding a test net** because
every other refactor — including the ones already on the roadmap — gets safer
once you have one.

---

## Appendix: changes shipped in this session

| Change | File | Why |
|---|---|---|
| 17 `'Plant 1' ? 'P1'` ternaries → `normalizePlant(...)` | `routes/history.ts`, `routes/all-routes.ts`, `routes/safety.ts`, `routes/yield.ts` | Finding A4 (partial) |
| Schema migration backfill made CSV-driven (no hardcoded MCH-05..08) | `database/schema.ts` | Finding E7 (closed) |

Both verified to compile clean via `esbuild`. No behavior changes — only
hardcoded values replaced with the existing topology helpers.
