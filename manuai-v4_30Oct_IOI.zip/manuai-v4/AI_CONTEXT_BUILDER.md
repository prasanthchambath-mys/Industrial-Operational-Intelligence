# ManuAI — Unified AI Context Builder (V44)

## Problem fixed
The Unified AI answered from KPI **definitions** and semantic metadata only. The
context was built client-side and dominated by the governed-KPI dictionary
tagged "CSV definition only — no live feed". It never retrieved current records,
never calculated KPI values, never ranked, never joined cross-agent context — so
"which supplier has highest risk?" got a dictionary entry, not a ranked supplier.

## Architecture (server-side, all 8 agents)
New module: `apps/api/src/ai/ai-context-builder.ts`. For every question:

1. **Detect domain/agent(s)** — `detectAgents()` keyword-matches to one or more
   of: oee, pdm, quality, energy, supply, twin, yield, safety, semantic.
2. **Governed KPI definitions** — pulled for the matched agents from the
   semantic layer (`loadSemanticKpiDefs`).
3. **Current records** — retrieved from DB Tier 2/3 tables via `db-queries`
   (CSV fallback when a table is empty).
4. **Dynamic KPI calculation** — each agent builder computes values from records
   (e.g. supply_risk_score = lead-drift × financial × geo; OEE per line; RUL rank).
5. **Filters** — plant / line / asset / period applied to every retrieval.
6. **Ranking** — every agent returns a ranked list so "which X is highest/lowest"
   is answerable.
7. **Cross-agent enrichment** — a PdM-flagged asset is joined to its OEE impact,
   spare-part availability, blocking safety permit, twin scenario, and open WOs.
8. **Grounded packet** — `renderContextPacket()` emits records + calculated
   values + rankings + cross-agent impacts + a freshness timestamp.

The LLM system prompt (`llm-client.ts`) now answers ONLY from this packet and is
required to structure business answers as: direct answer → KPI value → drivers →
impacted plant/line/asset → cross-agent impact → recommended action → source data.
The old "CSV definition only / no live feed" hard rule is removed.

## Wiring
- `POST /api/ai/chat` now accepts `{ messages, liveContext?, filters? }`.
- `unifiedChat()` builds the grounded packet from the last user message + filters.
- Frontend passes `{ plant }` from dashboard state (line/asset extensible).

## Validation
`apps/api/src/ai/ai-context-builder.test.ts` runs a business question per agent
and asserts: correct agent matched, recordCount > 0 (live data, not definitions),
calculated block non-empty, ranked results present, freshness timestamp, and the
packet never says "definition only" when records exist.

Logic verified against the real seeded data — all 8 agents produce grounded,
ranked answers:
| Question | Grounded answer |
|----------|-----------------|
| Highest-risk supplier | BASF Chemicals (CMPD-X12), score 232, lead 51d/30d |
| Asset to fail first | MCH-03 CNC, RUL 9d, health 17%, vib 9.1 |
| Lowest-OEE line | Line B, 75.7% |
| Highest defect line | Line B, 18 defects |
| Param hurting yield | Mixing Speed 420 vs 395 RPM (12.5% of span) |
| Abnormal energy | Injection Moulding #1, 148kW (100% of rated) |
| Blocking permit | reports blocked count + first blocked PTW |
| Twin projected impact | top scenario impact + confidence |
