# Unified AI / Semantic Layer — End-to-End Audit (V44)

**Scope:** Why the Unified AI answers from KPI definitions ("CSV definition only — no live feed yet")
instead of live, calculated, ranked, plant-filtered data — across all 8 agents.

**Verdict:** The V44 server-side grounded-context builder **exists and is wired in**, but the AI is
still degraded by **three compounding defects**. The reported symptom is the visible result of all three.

---

## 1. Root cause summary

| # | Root cause | Effect | Severity |
|---|-----------|--------|----------|
| **RC-1** | **Plant-code mismatch.** Frontend sends `filters.plant = 'Plant 1' / 'Plant 2' / 'All Plants'` (store value). The `/chat` route never calls `normalizePlant()`. The builder filters rows against DB `plant_id = 'P1'/'P2'`. `'P1' === 'Plant 1'` is false. | When **any specific plant** is selected, **every** agent's record set filters to **zero** → packet reports "MISSING DATASET" for all agents → only the frontend dictionary survives → pure definition-only answers. Only "All Plants" partially works. | **Critical** |
| **RC-2** | **Wrong data source for live machine KPIs.** `buildOEE`/`buildPdM`/`buildEnergy` read `m.oee, m.rul, m.health, m.vib, m.status, a.current_kw` from `getMachines()`/`getEnergyAssets()` (reference tables). Those columns **do not exist** in `ref_machines` and are static in `ref_energy_assets`. The live values live in `getPlantState()` (the simulation engine — the dashboard's actual source), which the builder never imports. | Even under "All Plants", OEE/PdM/Energy packet values are **zeros** (avg OEE 0%, all RUL 999, 0 critical, current_kw = rated). The model has no real values → reverts to the dictionary. | **Critical** |
| **RC-3** | **Frontend context pollution.** `App.tsx` still builds the `=== GOVERNED KPI DICTIONARY ===` block (`buildKpiDictionary`) with literal `[CSV definition only — no live feed yet]` tags and hard rules ("you MUST list ONLY KPIs from this dictionary", "respond exactly: …"). It is sent as `liveContext` and the backend **appends** it after the grounded packet. | The LLM receives the grounded packet **and** a large, authoritative-sounding dictionary that contradicts it and contains the exact "definition only" phrasing the user sees echoed back. | **High** |

**One-line summary:** The grounding pipeline is built but (a) silently empties itself on any plant
selection, (b) reads machine KPIs from the wrong (reference) source so they're zero, and (c) is
overridden by a leftover client-side "definition only" dictionary. Fixing all three makes operational
answers data-grounded across all 8 agents.

---

## 2. File-level findings

| File | Lines | Finding |
|------|-------|---------|
| `apps/web/src/App.tsx` | 3431–3493 (`buildKpiDictionary`) | Emits `[CSV definition only — no live feed yet]` tags + hard MUST-rules. Sent as `liveContext`. **RC-3.** |
| `apps/web/src/App.tsx` | 3495–3523 (`buildLiveContext`) | Returns `liveSnapshot + buildKpiDictionary()`. The snapshot is fine; the dictionary is the problem. |
| `apps/web/src/App.tsx` | 3561 | `filters = {plant: useStore.getState().plant}` → sends `'Plant 1'`, not `'P1'`. **RC-1 origin.** |
| `apps/web/src/store/index.ts` | 42 | `plant: 'All Plants'` default; values are `'Plant 1'/'Plant 2'`. Confirms format. |
| `apps/api/src/routes/all-routes.ts` | 1428–1438 (`/chat`) | Forwards `filters` straight to `unifiedChat`. **Never calls `normalizePlant()`.** **RC-1.** |
| `apps/api/src/ai/llm-client.ts` | 198–233 (`unifiedChat`) | Correctly builds + prepends the server packet, but **appends `liveContext`** (the polluting dictionary). System prompt (l.71–94) is correct. |
| `apps/api/src/ai/ai-context-builder.ts` | 95–120 (`buildOEE`) | Reads `m.oee` from `getMachines()` → 0 (column absent). **RC-2.** |
| `apps/api/src/ai/ai-context-builder.ts` | 122–148 (`buildPdM`) | Reads `m.rul/health/vib/status` → defaults (999/0/undefined). **RC-2.** |
| `apps/api/src/ai/ai-context-builder.ts` | 185–214 (`buildEnergy`) | Reads `a.current_kw` (static/null in ref) → no anomaly detected. **RC-2.** |
| `apps/api/src/ai/ai-context-builder.ts` | 75–78 (`applyPlantFilter`) | Compares against `plant_id`/`plant` = `'P1'`. Never matches `'Plant 1'`. **RC-1 mechanism.** |
| `apps/api/src/database/seed-master.ts` | ref_machines insert | Inserts only `(id,name,line,plant_id,asset_type,degrade_rate,…)`. **Live KPI columns dropped at seed.** Confirms RC-2. |
| `apps/api/src/database/schema.ts` | `ref_machines` | No `oee/rul/health/vib/temp/status` columns — by design (reference master, not runtime state). |
| `apps/api/src/simulation/engine.ts` | 33–46, 556 | `getPlantState()` machines carry live `oee, health, rul, status, vib, temp, pressure` — **the correct source the builder should use.** |

**Agents that work server-side (read tables that carry their data):** Supply, Yield, Quality, Safety,
Twin — but only under "All Plants" (RC-1) and still polluted by RC-3. Note: their values are the
**static CSV-seeded** values, not live sim drift (yield live values are also in `getPlantState().yieldParams`).

**Agents broken even under All Plants:** OEE, PdM, Energy (RC-2).

---

## 3. Per-question trace (the 8 sample questions)

Assumes the common case: a specific plant (e.g. Plant 1) is selected on the dashboard.

| Question | Detected agent(s) | KPI | Source used (actual) | Function called | Records | Calc | Filter applied | Context to LLM | Answer | Gap |
|----------|------------------|-----|----------------------|-----------------|---------|------|----------------|----------------|--------|-----|
| Highest-risk supplier this week? | supply | supply_risk_score | `getSupplyRisks('Plant 1')` → SQL `WHERE plant_id='Plant 1'` | `buildSupply` | **0** (RC-1) | none | 'Plant 1' ≠ 'P1' | "MISSING: ref_supply_risks" + dict | "definition only" | RC-1 |
| Asset with highest failure risk? | pdm | rul_days/health | `getMachines('Plant 1')` | `buildPdM` | 0 (RC-1); even at All Plants, `m.rul` absent → 999 (RC-2) | RUL rank on zeros | 'Plant 1' ≠ 'P1' | empty/zeros + dict | "RUL 999 / definition only" | RC-1 + RC-2 |
| Line with lowest OEE? | oee | oee_pct | `getMachines('Plant 1')` | `buildOEE` | 0 (RC-1); at All Plants `m.oee` absent → 0% (RC-2) | avg/rank on zeros | 'Plant 1' ≠ 'P1' | "0%" + dict | "OEE 0% / definition only" | RC-1 + RC-2 |
| Batch with highest quality risk? | quality | defect_count | `getQualityDefects('Plant 1')` | `buildQuality` | 0 (RC-1) | none | 'Plant 1' ≠ 'P1' | "MISSING" + dict | "definition only" | RC-1 |
| Process parameter hurting yield? | yield | deviation_pct_of_span | `getYieldParams('Plant 1')` | `buildYield` | 0 (RC-1) | none | 'Plant 1' ≠ 'P1' | "MISSING: ref_yield_params" + dict | "definition only" | RC-1 (also static vs live) |
| Equipment consuming abnormal energy? | energy | pct_of_rated | `getEnergyAssets('Plant 1')` | `buildEnergy` | 0 (RC-1); at All Plants `current_kw` static (RC-2) | anomaly on static | 'Plant 1' ≠ 'P1' | empty/flat + dict | "no anomaly / definition only" | RC-1 + RC-2 |
| Safety permit blocking maintenance? | safety | blocked_count | `getSafetyPermits('Plant 1')` | `buildSafety` | 0 (RC-1) | none | 'Plant 1' ≠ 'P1' | "MISSING" + dict | "definition only" | RC-1 |
| Projected Digital Twin impact? | twin | divergence_pct | `getTwinScenarios/KPIs('Plant 1')` | `buildTwin` | 0 (RC-1) | none | 'Plant 1' ≠ 'P1' | "MISSING" + dict | "definition only" | RC-1 |

Under **All Plants**, columns 5 (supply/yield/quality/safety/twin) return real ranked data and the
answers are correct *if* RC-3's dictionary doesn't anchor the model; OEE/PdM/Energy still fail on RC-2.

---

## 4. Broken data flow (current)

```
User question + Plant 1 selected
        │
        ▼
Frontend App.tsx
  ├─ filters = { plant: 'Plant 1' }            ← raw store value (RC-1)
  └─ liveContext = liveSnapshot
                 + "=== GOVERNED KPI DICTIONARY ==="
                   with [CSV definition only — no live feed yet]  (RC-3)
        │
        ▼
POST /api/chat  (all-routes.ts)
  └─ passes filters through UNCHANGED          ← no normalizePlant() (RC-1)
        │
        ▼
unifiedChat() → buildGroundedContext('...', {plant:'Plant 1'})
        │
        ▼
AGENT_BUILDERS
  ├─ getMachines('Plant 1')  → SQL plant_id='Plant 1' → 0 rows   (RC-1)
  │     └─ even if matched: m.oee / m.rul ABSENT → 0 / 999        (RC-2)
  └─ applyPlantFilter(rows,'Plant 1')  → 'P1' ≠ 'Plant 1' → []    (RC-1)
        │
        ▼
renderContextPacket → "MISSING DATASET" for every agent
        │
        ▼
system = SYSTEM_9_AGENT
       + (empty grounded packet)
       + liveContext (GOVERNED KPI DICTIONARY w/ "definition only")   (RC-3)
        │
        ▼
LLM → echoes "CSV definition only — no live feed yet"
```

## 5. Corrected data flow (target)

```
User question + Plant 1 selected
        │
        ▼
Frontend App.tsx
  ├─ filters = { plant: store.plant }          (raw is fine — normalize server-side)
  └─ liveContext = thin dashboard-only supplement (running scenarios) — NO dictionary, NO "definition only"
        │
        ▼
POST /api/chat
  └─ filters.plant = normalizePlant(filters.plant)   ← 'Plant 1' → 'P1'   (fix RC-1)
        │
        ▼
unifiedChat() → buildGroundedContext(question, {plant:'P1'})
        │
        ▼
AGENT_BUILDERS  (fix RC-2)
  ├─ live = getPlantState()        ← SAME source as the dashboard
  ├─ ref  = getMachines('P1')      ← static attrs (name, line, rated_kw)
  └─ merge by id → rows with live oee/rul/health/vib/status/current_kw
        │  applyPlantFilter(rows,'P1') → matches plant_id='P1'  ✓
        ▼
calculate (avg OEE, RUL rank, anomaly) on REAL values → ranked
        │
        ▼
cross-agent enrich (PdM asset → OEE + parts + permit + twin + WOs)
        │
        ▼
renderContextPacket → live records + calculated KPIs + rankings + freshness
        │
        ▼
system = SYSTEM_9_AGENT + grounded packet   (authoritative; client context demoted)
        │
        ▼
LLM → "Line B lowest OEE 75.7% — driven by MCH-03 (RUL 9d)…"
```

---

## 6. Missing APIs / data joins

No new HTTP endpoints are required — the dashboard endpoints already exist (`/oee/summary`,
`/pdm/health-summary`, `/qm/defects`, `/scada/energy`, `/risks`, `/divergence`, `/mes/yield-params`,
`/ehs/permits`, etc.). The missing pieces are **internal data joins inside the context builder**:

1. **Live-state join (RC-2):** join `getPlantState().machines` (live oee/rul/health/vib/status) with
   `getMachines()` (static name/line/rated_kw) by `id`. Same for `getPlantState().energyAssets` →
   `current_kw`, and `getPlantState().yieldParams` → live `value`.
2. **Plant normalization (RC-1):** apply `normalizePlant()` once at the `/chat` boundary so every
   downstream getter and `applyPlantFilter` receives `P1`/`P2`/null.
3. **Quality "batch" join:** the question "which batch has highest quality risk" maps to defects per
   line today; to answer at batch granularity, join `trx_quality_defects` → `trx_lims_results`/`batches`
   by `batch_id` (optional enhancement; line-level works now).

---

## 7. Hardcoded / fallback messages (locations)

| String | File:line | Wrongly triggered? |
|--------|-----------|--------------------|
| `[CSV definition only — no live feed yet]` | `App.tsx:3472`, `3485` | **Yes** — emitted for any KPI without a client-side resolver, and sent to the LLM every message. |
| `carbon_intensity: null, // CSV def only` | `App.tsx` (liveValueByKpi) | Yes — hardcoded null even though carbon data exists server-side. |
| `rec_acceptance: null, // CSV def only` | `App.tsx` (liveValueByKpi) | Yes — hardcoded null. |
| "you MUST list ONLY KPIs from this dictionary" / "respond exactly: …" | `App.tsx:3468–3471` | Yes — over-constrains the model toward definitions. |
| `· Dashboard live + CSV definitions` | `App.tsx:3581` | UI label only — harmless, update wording after fix. |
| System-prompt rule "Never say 'CSV definition only'…" | `llm-client.ts:80` | Correct guard — **keep**. |

Server-side (`ai-context-builder.ts`, `renderContextPacket`) **never** emits "definition only" — the
phrase originates entirely in the frontend (RC-3).

---

## 8. Semantic layer assessment

The "Semantic Layer" today is **mostly a governed KPI glossary**, not a full semantic model:

| Capability | Present? | Where |
|------------|----------|-------|
| Governed KPI definitions (name, formula, unit, owner agent) | ✅ | `semantic_kpi_definitions.csv` / `kpiDefsForAgents()` |
| Source-system tag | ✅ (string) | `source_system` column |
| Source **table** mapping (KPI → DB table/column) | ❌ | not modelled |
| Metric calculation logic | ⚠️ partial | hard-coded inside each `buildX()`, not declared in the semantic model |
| Current values | ⚠️ | computed in builder (when sources are correct), not exposed by the semantic layer itself |
| Drill-down records | ⚠️ | builder `ranked[]`, not a semantic-layer feature |
| Entity relationships (asset↔line↔plant↔supplier) | ⚠️ partial | `dim_*` tables exist; not used by the builder |
| Cross-agent impact mapping | ✅ (asset-centric) | `crossAgentForAsset()` |
| Conflict rules | ✅ | `semantic/service.ts` + `conflict_rules.csv` |

**Gap:** calculation logic and KPI→source mapping live in code, not in the governed model, so the
"single source of truth" is split between the CSV (definitions) and `ai-context-builder.ts` (math +
source binding). Phase E (Purview) is the intended consolidation; not required to fix this bug.

---

## 9. Per-agent matrix

| Agent | Data file/table | Endpoint | Calculated KPI in builder | Can AI retrieve calc'd data today? | top/lowest/why answerable? |
|-------|-----------------|----------|---------------------------|-----------------------------------|----------------------------|
| OEE | `ref_machines` + **`getPlantState()`** | `/oee/summary` | avg OEE, line/machine rank | ❌ reads ref (no oee col) — RC-2 | After fix |
| PdM | `ref_machines` + **`getPlantState()`** | `/pdm/health-summary` | RUL rank, health, vib | ❌ ref has no rul/health — RC-2 | After fix |
| Quality | `trx_quality_defects`, `ref_quality_lines` | `/qm/defects` | defects/line, top type | ✅ (All Plants) — RC-1 blocks plant filter | After RC-1 fix |
| Energy | `ref_energy_assets` + **`getPlantState()`** | `/scada/energy` | pct of rated, anomaly, waste | ❌ current_kw static — RC-2 | After fix |
| Supply | `ref_supply_risks` | `/risks` | risk score, below-reorder | ✅ (All Plants) — RC-1 blocks plant filter | After RC-1 fix |
| Twin | `trx_twin_scenarios/kpis` | `/divergence` | divergence %, top scenario | ✅ (All Plants) — RC-1 | After RC-1 fix |
| Yield | `ref_yield_params` + **`getPlantState().yieldParams`** | `/mes/yield-params` | deviation % of span | ⚠️ static seed values; RC-1 blocks plant | After fix (live join optional) |
| Safety | `trx_safety_permits`, `ref_safety_zones` | `/ehs/permits` | blocked/pending, first blocked | ✅ (All Plants) — RC-1 | After RC-1 fix |

---

## 10. Required code changes

**Fix RC-1 — normalize plant at the boundary** (`apps/api/src/routes/all-routes.ts`, `/chat`):
```ts
import { normalizePlant } from '../data/plant';
// inside /chat handler, before unifiedChat():
const f = parsed.data.filters ?? {};
const normFilters = { ...f, plant: normalizePlant(f.plant) ?? 'All Plants' };
const reply = await unifiedChat(parsed.data.messages as any, parsed.data.liveContext, normFilters);
```
(Alternatively normalize inside `buildGroundedContext`. Boundary is cleaner — one place.)

**Fix RC-2 — source live machine KPIs from `getPlantState()`** (`apps/api/src/ai/ai-context-builder.ts`):
```ts
import { getPlantState } from '../simulation/engine';

function liveMachines(): any[] {
  const st = getPlantState();                       // live: oee, rul, health, vib, status
  const ref = getMachines();                        // static: name, line, plant_id, rated_kw
  const byId = new Map(ref.map(r => [r.id, r]));
  return (st.machines ?? []).map((m: any) => ({
    ...byId.get(m.id), ...m,
    plant_id: byId.get(m.id)?.plant_id ?? m.plant,  // canonical plant code
  }));
}
// buildOEE / buildPdM: replace `getMachines(f.plant)` with `applyPlantFilter(liveMachines(), f.plant)`.
// buildEnergy: merge getPlantState().energyAssets current_kw onto getEnergyAssets() the same way.
// crossAgentForAsset: use liveMachines() so oee_impact is real.
```
This makes the AI read the **same source the dashboard reads** — the literal answer to audit point #5.

**Fix RC-3 — stop sending the polluting dictionary** (`apps/web/src/App.tsx`):
- In `buildLiveContext()`, return **only** the thin `liveSnapshot` (or just the running-scenario state).
  Remove the `+ '\n\n' + buildKpiDictionary()` concatenation. The server packet already includes
  governed KPI definitions for the matched agents (`kpiDefsForAgents`).
- Delete the hardcoded `[CSV definition only — no live feed yet]`, the "MUST list ONLY" and
  "respond exactly" rules, and the `carbon_intensity/rec_acceptance: null // CSV def only` lines.
- Keep the grounding badge but relabel "· Dashboard live (server-grounded)".

**Optional — make server packet authoritative** (`llm-client.ts`): keep prepending the grounded packet;
if `liveContext` is retained, label it `-- Supplementary dashboard state (non-authoritative) --` so it
can't override the packet.

**Optional — yield live join:** merge `getPlantState().yieldParams` value/target onto `getYieldParams()`
so yield reflects live drift, not seed values.

---

## 11. Validation checklist

- [ ] `POST /api/chat` normalizes `'Plant 1' → 'P1'` (log the normalized filter).
- [ ] With Plant 1 selected, `buildGroundedContext` returns `recordCount > 0` for OEE/PdM/Quality/Energy/Supply/Safety/Twin/Yield (no "MISSING DATASET").
- [ ] OEE packet avg OEE is non-zero and matches `/oee/summary` for the same plant.
- [ ] PdM packet `first_to_fail.rul_days` matches `/pdm/health-summary` lowest RUL.
- [ ] Energy packet `highest_draw.current_kw` matches `/scada/energy`.
- [ ] LLM answer contains no "CSV definition only" / "no live feed" string for operational questions.
- [ ] Frontend no longer sends `buildKpiDictionary()` in `liveContext` (inspect network payload).
- [ ] Switching Plant 1 → Plant 2 changes the named asset/line/supplier in the answer.
- [ ] All Plants returns fleet-wide aggregates (both plants represented in rankings).
- [ ] `ai-context-builder.test.ts` still passes (recordCount > 0, calculated non-empty, no "definition only").
- [ ] Cross-agent block present when a PdM asset is flagged (parts + permit + twin + WOs).

## 12. Test questions & expected answers (post-fix, against current seed data)

| Agent | Question | Expected grounded answer (shape) |
|-------|----------|----------------------------------|
| Supply | Which supplier poses the highest risk this week? | BASF Chemicals (CMPD-X12) — highest risk score; lead 51d vs 30d contracted; below reorder; recommend dual-source/expedite. |
| PdM | Which asset has the highest failure risk? | MCH-03 (CNC) — lowest RUL (~9d), health ~17%, vibration ~9 mm/s, status critical; cross-agent: blocking PTW + open WO. |
| OEE | Which line has the lowest OEE? | Line B ~75.7% (lowest of the lines for the selected plant); worst machine named with its OEE. |
| Quality | Which line/batch has the highest quality risk? | Line B — highest defect count today; top defect type named; quality rate %. |
| Yield | Which process parameter is hurting yield? | Mixing Speed ~420 vs target ~395 RPM (largest % of operating span off-target). |
| Energy | Which equipment is consuming abnormal energy? | Injection Moulding #1 — current_kw ≈ rated (≈100%+), flagged abnormal; daily waste Rs total. |
| Safety | Which safety permit is blocking maintenance? | The blocked PTW id, work type, asset, and blocking rule; count of blocked vs pending. |
| Twin | What is the projected Digital Twin impact? | Top scenario name + projected impact + confidence + horizon; count of KPIs diverging beyond threshold. |

Each answer must follow the system-prompt structure: direct answer → KPI value → drivers → impacted
plant/line/asset → cross-agent impact → recommended action → source + freshness timestamp.

---

### Bottom line
The builder is sound in design; it is defeated by a **plant-code mismatch (RC-1)** that empties the
packet on any plant selection, a **wrong data source (RC-2)** that zeros out machine KPIs, and a
**leftover frontend dictionary (RC-3)** that injects the "definition only" phrasing. The three fixes
above are small and localized (one route line, one join in the builder, one frontend trim) and together
make all 8 agents answer from live, calculated, ranked, plant-filtered data.
